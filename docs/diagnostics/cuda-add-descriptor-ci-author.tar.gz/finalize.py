from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess,tarfile
root=Path.cwd().resolve();e=root/'target/descriptor-ci/evidence'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def result(p):
 text=p.read_text(); count=int(re.search(r'Ran (\d+) tests?',text).group(1));skip=re.search(r'skipped=(\d+)',text);fail=re.search(r'failures=(\d+)',text)
 skipped=int(skip.group(1)) if skip else 0; failed=int(fail.group(1)) if fail else 0
 return {'run':count,'passed':count-skipped-failed,'skipped':skipped,'failed':failed}
identity=json.loads((e/'final/identity-before-tests.json').read_text())
after=json.loads((e/'final/verification-after.json').read_text())
assert after['source_hashes_unchanged'] and after['prior_evidence_unchanged']
for p,h in identity['source_hashes'].items(): assert digest(root/p)==h,p
for p,h in identity['frozen_hashes'].items(): assert digest(root/p)==h,p
for p,h in identity['preserved_evidence_hashes'].items(): assert digest(root/p)==h,p
owner=result(e/'final/owner-tests.log');smoke=result(e/'final/validator-smoke.log');full=result(e/'final/full-portable.log');first=result(e/'full-portable.log')
assert owner['failed']==smoke['failed']==full['failed']==0
assert all(x['returncode']==0 for x in json.loads((e/'final/commands.json').read_text()))
report={'phase':'author-only dirty one-line test correction','parent':identity['parent'],'generated_utc':datetime.now(timezone.utc).isoformat(),'first_owner':result(e/'owner-tests.log'),'first_full':first,'first_full_failure':'Existing stack-validator smoke test requires a real repository-root .venv; the initial target/descriptor-ci/venv did not satisfy its path contract.','correction':'Fresh environment at .venv; no test/validator/native/dependency change.','final_owner':owner,'final_validator_smoke':smoke,'final_full':full,'all_source_hashes_preserved':True,'prior_evidence_preserved':True,'limitations':['Linux x86_64/Python 3.12.12 only; macOS ARM64/Python 3.12 and Ubuntu/Python 3.14 Actions remain required','No new GPU capability, independent review, clean-commit evidence refresh or canonical evaluation']}
(e/'outcomes.json').write_text(json.dumps(report,indent=2)+'\n')
md=f'''# Portable `Tensor.add_` descriptor assertion repair

Author-only correction against `{identity['parent']}`: the existing
`tests/test_top_level_add.py` assertion now requires a native method descriptor,
matching `test_tensor_add.py`. The separate module-level `torch_rs.add_` absence
assertion, CPU/gradient/saved-alias rejection tests and implementation are unchanged.

Verification used the exact revised test source and a freshly packaged native
wheel in a fresh worktree-local `.venv`, with installation destinations and
source/wheel/import hashes verified before tests. Local Linux x86_64/Python
3.12.12 used locked PyTorch 2.13.0 and CUDA-hidden suite execution.

- Owner modules and ungated `AddInplaceBindingTests`: {owner['passed']} passed.
- Previously failing validator smoke test: {smoke['passed']} passed.
- Full portable Python suite: {full['run']:,} run, {full['passed']:,} passed, {full['skipped']} skipped, {full['failed']} failures.

The initial full run had {first['failed']} failure and {first['skipped']} skips:
an existing stack-validator smoke test requires dependencies in the real root
`.venv`, while the first environment was under `target/descriptor-ci/venv`.
Recreating the environment at the supported path resolved it without changing
the validator or adding skips. The initial failure, final results, warnings,
commands and actual provenance are retained in the
[author receipts](cuda-add-descriptor-ci-author.tar.gz). Prior committed evidence
is byte-identical and has not been attributed to this revision.

This is dirty author verification, not a clean-commit capture or CI approval.
macOS ARM64/Python 3.12 and Ubuntu/Python 3.14 Actions remain required after
publication. No dependency, implementation, evaluator, managed progress artifact
or unrelated documentation changed; no commit, push or publication was performed.
'''
(root/'docs/diagnostics/cuda-add-descriptor-ci-author.md').write_text(md)
files=sorted(p for p in e.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(e/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(e)}\n' for p in files))
archive=root/'docs/diagnostics/cuda-add-descriptor-ci-author.tar.gz'
with tarfile.open(archive,'w:gz') as a:
 for p in sorted(e.rglob('*')):
  if p.is_file(): a.add(p,arcname=str(p.relative_to(e)),recursive=False)
with tarfile.open(archive,'r:gz') as a:
 for line in a.extractfile('SHA256SUMS').read().decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
print(json.dumps(report,indent=2));print('archive',archive.stat().st_size,digest(archive))
