for task_conda_name in ${!CONDA_@} ${!_CONDA_@}; do unset "$task_conda_name"; done
unset VIRTUAL_ENV UV_PROJECT_ENVIRONMENT PYTHONHOME PYTHONPATH
export VIRTUAL_ENV="$PWD/.venv"
export UV_PROJECT_ENVIRONMENT="$VIRTUAL_ENV" PYO3_PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PIP_CONFIG_FILE=/dev/null
export CUDA_VISIBLE_DEVICES=''
export CARGO_HOME="$PWD/target/descriptor-ci/cargo-home" CARGO_TARGET_DIR="$PWD/target/descriptor-ci/cargo-target"
export XDG_CACHE_HOME="$PWD/target/descriptor-ci/cache" UV_CACHE_DIR="$PWD/target/descriptor-ci/cache/uv"
export UV_PYTHON_INSTALL_DIR="$PWD/target/descriptor-ci/python" CUDA_CACHE_PATH="$PWD/target/descriptor-ci/cache/cuda"
export TORCHINDUCTOR_CACHE_DIR="$PWD/target/descriptor-ci/cache/inductor" TRITON_CACHE_DIR="$PWD/target/descriptor-ci/cache/triton"
export TMPDIR="$PWD/target/descriptor-ci/tmp" BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/descriptor-ci/evidence/final"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CARGO_BUILD_JOBS=8
