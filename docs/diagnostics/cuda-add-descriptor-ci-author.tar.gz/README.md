# Portable add_ descriptor assertion repair: author receipts

Request: compile-cuda-add-portable-descriptor-ci-20260918.
Parent: 3eb6a1861bd4e30108b3f3adbb9c2134ef45310d.
Pinned base: 60202557b4f110d07777f585e804ab5f55e1ff7b.
The sole test edit replaces the obsolete Tensor.add_ absence assertion with
inspect.ismethoddescriptor; the module-level add_ absence assertion is retained.
No implementation, skips, dependencies, evaluator or workflow changed.

The supplied public-CI diagnosis was read in full and verified against SHA256
42534557744a208377976b8e2a47b58eb002e8b29e894cd05d049df8acd5a592.
It describes historical failures in workflow 35289403224, not this local run.
Existing committed developer and scoring evidence is preserved unchanged.
This archive records dirty author verification, not a clean-commit capture,
independent review, CI rerun, evaluation, score or publication approval.

Every shell used login:false. env.sh clears inherited CONDA_*/_CONDA_* metadata,
VIRTUAL_ENV, UV_PROJECT_ENVIRONMENT, PYTHONHOME and PYTHONPATH, then explicitly
selects the fresh worktree-local environment and writable caches. All tests used
CUDA_VISIBLE_DEVICES='' with OMP/MKL thread limits set to one; no GPU workload was requested.
The shared Python 3.10 installation was neither modified nor repaired. The
read-only Python 3.12.12 base is used through a standard venv executable symlink;
sys.prefix and package installation destinations remain inside the worktree.

Exact setup/build commands, from the worktree root:

```bash
source target/descriptor-ci/env.sh
/home/bobren/.local/share/uv/python/cpython-3.12.12-linux-x86_64-gnu/bin/python3.12 -B -I -m venv "$VIRTUAL_ENV"
"$PYO3_PYTHON" -B -I - <<'PY'
from pathlib import Path
import sys,sysconfig
expected=Path.cwd().resolve()/'target/descriptor-ci/venv'
assert Path(sys.prefix).resolve()==expected
for key in ('purelib','platlib','scripts','data'):
    assert Path(sysconfig.get_path(key)).resolve().is_relative_to(expected)
PY
uv --no-config export --locked --no-emit-project --group dev --group reference --format requirements-txt > target/descriptor-ci/requirements.txt
"$PYO3_PYTHON" -B -I -m pip --isolated install --require-hashes -r target/descriptor-ci/requirements.txt
"$VIRTUAL_ENV/bin/maturin" build --release --locked --interpreter "$PYO3_PYTHON" --out target/descriptor-ci/wheels
"$PYO3_PYTHON" -B -I target/descriptor-ci/verify.py
```

`verify.py` rechecks actual installation destinations, installs the exact wheel
with pip --isolated --no-deps, runs the unchanged repository native-extension
verifier, then checks wheel/extension hashes and packaged Python/source bytes
before any tests. It runs these two requested commands in sequence:

```bash
"$PYO3_PYTHON" -B -m unittest -v tests.test_top_level_add tests.test_tensor_add tests.test_cuda_add_inplace.AddInplaceBindingTests
"$PYO3_PYTHON" -B -m unittest discover -s tests -p 'test_*.py'
```

`commands.json` records argv, UTC timestamps, durations and return codes.
`identity-before-tests.json` records source hashes, the exact one-line diff,
prefix/import/wheel identity, Rust/Python/reference versions, and prior evidence
and frozen-file hashes. `final/verification-after.json` verifies unchanged source and
prior artifacts following the suite. The raw logs preserve warnings and complete
outcomes. No broad warning suppression or test skipping was added.

This Linux x86_64/Python 3.12 run does not reproduce macOS ARM64/Python 3.12 or
Ubuntu/Python 3.14 CI. Existing Actions remain required after publication. No
canonical evaluator, new controller, commit, push or publication was invoked.

## Initial failure and environment correction

The first owner run passed 18 tests. The first full run completed 6,292 tests
with one failure and 601 skips: the generated stack-validator smoke test requires
package paths lexically and physically below REPOSITORY_ROOT/.venv. Its source
does not resolve the expected root, so a symlink alias would not satisfy it. Our
initial target/descriptor-ci/venv was local and valid for the import verifier,
but did not satisfy that stricter, existing test contract. The corrected add
assertion did not fail. The complete first log and identity remain unchanged.

A new real environment was created at the repository-supported .venv path; no
test, validator, dependency, native source or tolerance was changed or skipped.
The initial worktree-local download/native-build caches were reused. A fresh
wheel was packaged for the explicitly selected .venv interpreter (Cargo reported
a cache hit). Final setup commands:

```bash
source target/descriptor-ci/final-env.sh
/home/bobren/.local/share/uv/python/cpython-3.12.12-linux-x86_64-gnu/bin/python3.12 -B -I -m venv "$VIRTUAL_ENV"
# The same sys.prefix/purelib/platlib/scripts/data assertions above were repeated
# with expected=Path.cwd().resolve()/'.venv' before installing dependencies.
"$PYO3_PYTHON" -B -I -m pip --isolated install --require-hashes -r target/descriptor-ci/requirements.txt
"$VIRTUAL_ENV/bin/maturin" build --release --locked --interpreter "$PYO3_PYTHON" --out target/descriptor-ci/final-wheels
"$PYO3_PYTHON" -B -I target/descriptor-ci/final-verify.py
```

`final/` contains the subsequent setup, import, owner and full-suite receipts.
Before rerunning the full suite, final-verify.py also ran the previously failing
`tests.test_top_level_stack_benchmark_artifact.TopLevelStackBenchmarkArtifactTests.test_generated_validator_smoke_artifact_validates`
unchanged, which passed. The full-suite rerun verifies the changed installation
path, not a changed workload or repeated scoring. This is an existing unit-test
fixture, not a manual canonical evaluator invocation. That fixture overrides its
child visibility to GPU0 for environment metadata, as in the unchanged suite;
no separate GPU test or other device was requested. Deprecation, reference
recompile-limit and other warnings remain in the raw logs.
