"""Package retained development evidence after checks; produces no score."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path.cwd().resolve()
work = root/'target/method-guard-repair'
dest = root/'docs/diagnostics/program-identity/method-guard-repair'
def sha(data): return hashlib.sha256(data).hexdigest()
def suite(name, count, skips=0):
    text=(work/name).read_text()
    assert re.search(rf'Ran {count} tests in ',text), name
    assert text.rstrip().endswith(f'OK (skipped={skips})' if skips else 'OK'), name
    return dict(run=count, skipped=skips, failed=0)
checks = dict(pointwiseH100=suite('pointwise-h100.log',396,9), nativeIdentityAndCompilerFailuresH100=suite('native-identity-h100.log',9), portableGuards=suite('portable-guards-final.log',10,1))
assert 'test result: ok. 290 passed; 0 failed' in (work/'rust-tests.log').read_text()
assert not (work/'rust-format.log').read_text()
assert 'Finished' in (work/'clippy.log').read_text()
controls=json.loads(gzip.decompress((work/'consumer-controls/result.json.gz').read_bytes()))
assert controls['passed'] and controls['testsRun']==33
bindings=json.loads((work/'source-bindings.json').read_text())
gpu=json.loads((work/'gpu-bindings.json').read_text())
assert gpu['passed']
diag=json.loads(gzip.decompress((work/'diagnosis/result.json.gz').read_bytes()))
assert diag['passed'] and not diag['ordinaryCallLatencyOrScore']
assert [diag['controls'][label]['dictionaryFetches'] for label in ('before','grouped')]==[38,2]
assert all(diag['controls'][label]['comparisons']==38 for label in ('before','grouped'))
assert len(diag['timings'])==4 and all(len(t['elapsedNs'])==17 for t in diag['timings'])
checks.update(rust=dict(passed=290,failed=0), format='passed',clippy='passed',frozenConsumerControls=dict(run=33,passed=True),sourceWheelDocAndFixture='passed',gpuProviders='passed')
entries={}
for p in sorted(work.rglob('*')):
    if p.is_file() and not any(part in ('wheels','__pycache__') for part in p.relative_to(work).parts):
        entries[str(p.relative_to(work))]=p.read_bytes()
for name, expected in bindings['sourceHashes'].items():
    data=(root/name).read_bytes()
    assert sha(data)==expected
    entries['sources/'+name]=data
entries['production.patch']=subprocess.check_output(['git','diff','HEAD','--','python/torch_rs/_compile_pointwise.py','python/torch_rs/__init__.py'])
assert sha(entries['sources/docs/diagnostics/program-identity/method-guard-block.py'])==diag['scriptSha256']
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
        archive.addfile(info,io.BytesIO(data))
blob=gzip.compress(stream.getvalue(),mtime=0)
archive_path=dest/'development-evidence.tar.gz'
with archive_path.open('xb') as f: f.write(blob)
manifest=dict(kind='non-scoring-method-guard-development-evidence',createdAt=datetime.now(timezone.utc).isoformat(),baseHead=bindings['head'],cleanImplementationCapture=False,qualificationOrScoreProduced=False,worktree=str(root),sourceHashes=bindings['sourceHashes'],diagnosis=dict(sourceCommits={k:v['commit'] for k,v in diag['sources'].items()},scriptSha256=diag['scriptSha256'],nativeExtensionSha256=diag['nativeExtensionSha256'],sameNativeExtensionForBothBlockArms=True,fetchesBefore=38,fetchesGrouped=2,comparisonsEach=38,rawSamples=68,iterationsPerSample=20000,mediansNsPerBlock=[dict(arm=t['arm'],median=t['medianNsPerBlock']) for t in diag['timings']]),testWheel=dict(path=bindings['wheel'],sha256=bindings['wheelSha256'],nativeExtensionSha256=bindings['nativeExtensionSha256'],identicalToBlockTimingWheel=bindings['identicalNativeExtensionToPreviousWheel']),checks=checks,preservedFailures=[dict(log='pointwise-h100-failed-setup.log',errors=5,cause='New test used unsupported CUDA ones creation; corrected to CPU creation then transfer without production change.'),dict(log='source-bindings-failed-native-equality.log',cause='Supplementary cross-build native-byte equality assertion failed. Both hashes retained; both timed block arms use the same earlier extension. No frozen verifier changed.')],reviewFix='Historical Git dependency in tests replaced by exact AST-extracted local fixture for shallow/source-only checkouts.',pending='Burner implementation commit, clean eight-leg public comparison, independent review, full qualification and exact-head CI.',archive=dict(path=archive_path.name,bytes=len(blob),sha256=sha(blob)),members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as archive:
    assert sorted(archive.getnames())==sorted(entries)
    for member in archive:
        assert sha(archive.extractfile(member).read())==manifest['members'][member.name]['sha256']
print(f'PASS: {len(entries)} archive member hashes, {len(blob)} compressed bytes, source/diagnosis bindings and recorded checks')
