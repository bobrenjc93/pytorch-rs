"""Untimed post-test provider and GPU verification; no performance claim."""
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
root=Path.cwd().resolve()
spec=importlib.util.spec_from_file_location('frozen_consumer',root/'docs/diagnostics/program-identity/consumer.py')
c=importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
before=c.gpu_identity()
compiler=c.CompilerPin(Path(os.environ['TORCH_RS_NVRTC']))
barrier=c.Synchronizer(Path(os.environ['TORCH_RS_CUDART']))
record=dict(kind='untimed-post-test-provider-verification',createdAt=datetime.now(timezone.utc).isoformat(),command=sys.orig_argv,gpuBefore=before,gpuAfter=c.inventory(),compiler=compiler.metadata,runtime=barrier.metadata,libraries=c.libraries(),passed=True)
(root/'target/method-guard-repair/gpu-bindings.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS: GPU0 UUID, one visible device, actual NVRTC/runtime symbol providers')
