"""Development source/wheel/doc checks; no performance measurement."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path.cwd().resolve()
out = root / 'target/method-guard-repair'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def command(*args):
    return subprocess.check_output(args, text=True).strip()
import torch_rs as native
from torch_rs import torch_rs as bridge
wheel = next((out / 'wheels').glob('*.whl'))
old = next((root / 'target/program-identity-fc6c345/build-c/wheels').glob('*.whl'))
package = Path(native.__file__).resolve().parent
assert package.is_relative_to(root)
with zipfile.ZipFile(wheel) as z:
    hashes = {}
    for name in z.namelist():
        if name.startswith('torch_rs/') and name.endswith(('.py', '.so')):
            data = z.read(name)
            assert (package.parent / name).read_bytes() == data
            if name.endswith('.py'):
                assert (root / 'python' / name).read_bytes() == data
            hashes[name] = sha(data)
    native_members = {name: z.read(name) for name in z.namelist() if name.endswith('.so')}
with zipfile.ZipFile(old) as z:
    identical_native = all(z.read(name) == data for name, data in native_members.items())
source_doc = ast.get_docstring(next(n for n in ast.parse((root/'python/torch_rs/__init__.py').read_text()).body if isinstance(n, ast.FunctionDef) and n.name == 'compile'))
import inspect
assert source_doc == inspect.cleandoc(native.compile.__doc__)
assert all(s in source_doc for s in ('straight-line CUDA', 'generic VM', 'exact identity', 'compiler failures still', 'docs/compile-pointwise-jit.md'))
assert (root/'docs/compile-pointwise-jit.md').is_file()
spec = importlib.util.spec_from_file_location('guard_blocks', root/'docs/diagnostics/program-identity/method-guard-block.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
source = (root/helper.FRONTEND).read_text()
old_source = command('git','show',f'{helper.BEFORE}:{helper.FRONTEND}')
reused = command('git','show',f'{helper.REUSED}:{helper.FRONTEND}')
def blocks(text):
    return [ast.dump(n) for n in helper.extract_blocks(text)]
assert blocks(source) == blocks(reused)
assert blocks((root/'tests/fixtures/program_identity_method_guards_before.py').read_text()) == blocks(old_source)
paths = ['python/torch_rs/_compile_pointwise.py', 'python/torch_rs/__init__.py', 'tests/test_compile_pointwise_method_guards.py', 'tests/fixtures/program_identity_method_guards_before.py', 'docs/diagnostics/program-identity/method-guard-block.py']
record = dict(kind='non-scoring-development-bindings', createdAt=datetime.now(timezone.utc).isoformat(), head=command('git','rev-parse','HEAD'), status=command('git','status','--short'), cleanImplementationCapture=False, command=sys.orig_argv, worktree=str(root), interpreter=sys.executable, python=sys.version, interpreterSha256=sha(Path(sys.executable).read_bytes()), wheel=str(wheel), wheelSha256=sha(wheel.read_bytes()), previousWheel=str(old), previousWheelSha256=sha(old.read_bytes()), installedHashes=hashes, sourceHashes={p:sha((root/p).read_bytes()) for p in paths}, nativeExtension=str(Path(bridge.__file__).resolve()), nativeExtensionSha256=sha(Path(bridge.__file__).read_bytes()), identicalNativeExtensionToPreviousWheel=identical_native, exactHistoricalGuardHunks=True, exactHistoricalFixture=True, docstringMatchesSource=True, rust=command('rustc','--version'), cargo=command('cargo','--version'), nvcc=command('nvcc','--version'), environment={k:os.environ[k] for k in ('CUDA_VISIBLE_DEVICES','CUDA_DEVICE_ORDER','OMP_NUM_THREADS','MKL_NUM_THREADS','TORCH_RS_CUDART','TORCH_RS_NVRTC','LD_LIBRARY_PATH','CARGO_HOME','TMPDIR')})
(out/'source-bindings.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS: installed wheel/source, recorded native hashes, docstring/link, historical guard AST and fixture')
