#!/usr/bin/env bash
set -euo pipefail
source target/program-identity-4e291f5/shell-environment.sh
capture_attempt="$PWD/target/program-identity-4e291f5"
.venv/bin/python "$capture_attempt/previous-install-wheels.py"
"$capture_attempt/venv-b/bin/python" "$capture_attempt/previous-runtime-check.py" "$capture_attempt/runtime-b/result.json.gz"
.venv/bin/python "$capture_attempt/previous-runtime-check.py" "$capture_attempt/runtime-c/result.json.gz"
.venv/bin/python docs/diagnostics/program-identity/consumer.py preflight \
  --build-record "$capture_attempt/build-c/result.json.gz" \
  --freeze "$capture_attempt/freeze/result.json.gz" \
  --runtime "$TORCH_RS_CUDART" --nvrtc "$TORCH_RS_NVRTC" \
  --output "$capture_attempt/preflight/result.json.gz" > "$capture_attempt/preflight.log" 2>&1
bash "$capture_attempt/run-legs.sh" > "$capture_attempt/ordered-legs.log" 2>&1
.venv/bin/python docs/diagnostics/program-identity/consumer.py verify \
  "$capture_attempt"/leg-{0,1,2,3,4,5,6,7}/result.json.gz \
  --output "$capture_attempt/verification/result.json.gz" > "$capture_attempt/verification.log" 2>&1
"$capture_attempt/venv-b/bin/python" "$capture_attempt/integrity.py" b "$capture_attempt/integrity-b/result.json.gz" > "$capture_attempt/integrity-b.log" 2>&1
.venv/bin/python "$capture_attempt/integrity.py" c "$capture_attempt/integrity-c/result.json.gz" > "$capture_attempt/integrity-c.log" 2>&1
.venv/bin/python "$capture_attempt/render-results.py" > "$capture_attempt/render-results.log" 2>&1
nvidia-smi --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used --format=csv,noheader > "$capture_attempt/gpu-final.csv"
