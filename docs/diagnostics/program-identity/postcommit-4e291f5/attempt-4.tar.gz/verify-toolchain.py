"""Post-capture setup metadata; not attributed to workload timings."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import platform
import subprocess

R=Path.cwd().resolve()
P=Path(__file__).resolve().parent
files={}
sysroot=Path(subprocess.check_output(['rustc','--print','sysroot'],text=True).strip())
for name in ('rustc','cargo'):
    path=sysroot/'bin'/name
    files[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'version':subprocess.check_output([str(path),'--version'],text=True).strip()}
for label in ('b','c'):
    build=json.loads(gzip.decompress((P/f'build-{label}/result.json.gz').read_bytes()))
    assert build['rustc'].splitlines()[0]==files['rustc']['version']
    path=Path(build['buildCommand'][0])
    assert path.is_relative_to(R)
    files[f'maturin-{label}']={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(P/'toolchain-verification.json').write_text(json.dumps({'kind':'post-capture-toolchain-file-verification','capturedAt':datetime.now(timezone.utc).isoformat(),'files':files},indent=2)+'\n')
(P/'setup-command-index.json').write_text(json.dumps({'kind':'post-capture-setup-command-index','recordedAt':datetime.now(timezone.utc).isoformat(),'note':'Script invocations executed during setup/capture; this index timestamp is not attributed to build or workload timings. Those retain timestamps in their raw records.','worktree':str(R),'platform':platform.platform(),'baseline':'60202557b4f110d07777f585e804ab5f55e1ff7b','candidate':'4e291f5272b4b872ddc1704398b088b1917affc8','commands':['bash target/program-identity-4e291f5/setup.sh','bash target/program-identity-4e291f5/run-evidence.sh'],'scriptHashes':{name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ['setup.sh','shell-environment.sh','run-evidence.sh','run-legs.sh']},'buildCommands':[json.loads(gzip.decompress((P/f'build-{label}/result.json.gz').read_bytes()))['command'] for label in ('b','c')]},indent=2)+'\n')
print('Toolchain binary hashes and exact setup/build command index recorded')
