"""Archive verified raw evidence and derive a manifest; performs no measurement."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path.cwd().resolve()
P=Path(__file__).resolve().parent
D=ROOT/'docs/diagnostics/program-identity/postcommit-4e291f5'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(name): return json.loads(gzip.decompress((P/name/'result.json.gz').read_bytes()))
freeze=read('freeze'); verified=read('verification')
assert freeze['source']['commit']=='4e291f5272b4b872ddc1704398b088b1917affc8'
assert verified['passed'] and not verified['failures']
assert verified['ledger']==dict(cells=96,samples=1632,warmups=480,firstCalls=96)
assert all(read(name)['passed'] for name in ('build-b','build-c','runtime-b','runtime-c','preflight','integrity-b','integrity-c'))
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
for label in ('b','c'):
    assert read('integrity-'+label)['source']==freeze['source']
for helper in ('previous-dependency-setup.py','previous-install-wheels.py','previous-runtime-check.py','integrity.py'):
    assert (P/helper).read_bytes()==(ROOT/'target/program-identity-fc6c345'/helper).read_bytes()
inspection=json.loads((P/'inspection.json').read_text())
for path,expected in inspection['priorArchives'].items():
    assert sha((ROOT/path).read_bytes())==expected
statistics=json.loads((P/'statistics.json').read_text())
assert len(statistics['legs'])==8
ledger={**verified['ledger'], 'churnCalls':sum(len(leg['churn']) for leg in statistics['legs'])}
assert ledger['churnCalls']==96
for n,r in enumerate(statistics['legs']):
    assert r['index']==n
    assert r['sourceCommit']==('60202557b4f110d07777f585e804ab5f55e1ff7b' if n in (0,1,6,7) else freeze['source']['commit'])
    raw=P/f'leg-{n}/result.json.gz'
    assert sha(raw.read_bytes())==r['rawSha256']==verified['inventory'][n]['sha256']
    assert Path(verified['inventory'][n]['path'])==raw
entries={}
for path in sorted(P.iterdir()):
    if path.is_file() and path.name not in ('packaging.log',):
        entries[path.name]=path.read_bytes()
for dirname in ('check','freeze','build-b','build-c','runtime-b','runtime-c','preflight',*(f'leg-{n}' for n in range(8)),'verification','integrity-b','integrity-c'):
    folder=P/dirname
    for path in sorted(folder.iterdir()):
        if path.is_file(): entries[str(path.relative_to(P))]=path.read_bytes()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as archive:
    for name,data in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
blob=gzip.compress(stream.getvalue(),mtime=0)
D.mkdir()
(D/'attempt-4.tar.gz').write_bytes(blob)
(D/'results.md').write_bytes((P/'results.md').read_bytes())
manifest=dict(kind='complete-non-scoring-clean-public-comparison',createdAt=datetime.now(timezone.utc).isoformat(),candidateCommit=freeze['source']['commit'],candidateTree=freeze['source']['tree'],baselineCommit='60202557b4f110d07777f585e804ab5f55e1ff7b',worktree=str(ROOT),bindings=freeze['bindings'],qualificationOrScoreProduced=False,verified=True,ledger=ledger,rawBitDifferences=sum(r['rawBitDifferences'] for r in verified['ratios']),archive=dict(path='attempt-4.tar.gz',sha256=sha(blob),bytes=len(blob)),wheelSha256={label:read('build-'+label)['wheelSha256'] for label in ('b','c')},members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())})
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as archive:
    assert sorted(archive.getnames())==sorted(entries)
    for item in archive:
        assert sha(archive.extractfile(item).read())==manifest['members'][item.name]['sha256']
print(f'Verified {len(entries)} archived member hashes; {len(blob)} compressed bytes; all historical archive hashes unchanged.')
