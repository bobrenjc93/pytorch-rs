#!/usr/bin/env bash
set -euo pipefail
source target/program-identity-4e291f5/shell-environment.sh
nvidia-smi --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used --format=csv,noheader > target/program-identity-4e291f5/gpu-initial.csv
git init -q target/program-identity-4e291f5/baseline
git -C target/program-identity-4e291f5/baseline fetch --no-tags "$PWD" 60202557b4f110d07777f585e804ab5f55e1ff7b
git -C target/program-identity-4e291f5/baseline checkout --detach FETCH_HEAD
cp -a --reflink=auto .venv target/program-identity-4e291f5/venv-b
.venv/bin/python target/program-identity-4e291f5/previous-dependency-setup.py
.venv/bin/python docs/diagnostics/program-identity/consumer.py check --output target/program-identity-4e291f5/check/result.json.gz
.venv/bin/python docs/diagnostics/program-identity/consumer.py freeze --controls target/program-identity-4e291f5/check/result.json.gz --output target/program-identity-4e291f5/freeze/result.json.gz
