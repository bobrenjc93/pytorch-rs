#!/usr/bin/env bash
set -euo pipefail
capture_root="$PWD"
capture_attempt="$capture_root/target/program-identity-fc6c345"
export CUDA_VISIBLE_DEVICES=0 PYTHONDONTWRITEBYTECODE=1
export LD_LIBRARY_PATH="$capture_root/.venv/lib/python3.12/site-packages/nvidia/cu13/lib"
for leg_index in 0 1 2 3 4 5 6 7; do
  case "$leg_index" in
    0|1|6|7) capture_python="$capture_attempt/venv-b/bin/python"; capture_build=b ;;
    *) capture_python="$capture_root/.venv/bin/python"; capture_build=c ;;
  esac
  "$capture_python" docs/diagnostics/program-identity/consumer.py leg \
    --index "$leg_index" \
    --build-record "$capture_attempt/build-$capture_build/result.json.gz" \
    --freeze "$capture_attempt/freeze/result.json.gz" \
    --preflight "$capture_attempt/preflight/result.json.gz" \
    --runtime "$LD_LIBRARY_PATH/libcudart.so.13" \
    --nvrtc "$LD_LIBRARY_PATH/libnvrtc.so.13" \
    --output "$capture_attempt/leg-$leg_index/result.json.gz" \
    > "$capture_attempt/leg-$leg_index.log" 2>&1
  echo "Completed ordered leg $leg_index"
done
