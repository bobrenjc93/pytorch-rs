export CUDA_VISIBLE_DEVICES=0 CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export CARGO_HOME="$PWD/target/cargo-home"
export PYO3_PYTHON="$PWD/.venv/bin/python"
export TMPDIR="$PWD/target/tmp" XDG_CACHE_HOME="$PWD/target/test-cache/xdg"
export CUDA_CACHE_PATH="$PWD/target/test-cache/cuda"
export TORCHINDUCTOR_CACHE_DIR="$PWD/target/test-cache/inductor"
export TRITON_CACHE_DIR="$PWD/target/test-cache/triton" TORCH_HOME="$PWD/target/test-cache/torch"
export UV_CACHE_DIR="$PWD/target/test-cache/uv"
export TORCH_RS_CUDART="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
export TORCH_RS_NVRTC="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libnvrtc.so.13"
export LD_LIBRARY_PATH="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib"
