"""Recorded environment setup only; does not change package/library bytes."""
import datetime
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ATTEMPT = Path(__file__).resolve().parent
SOURCE = ROOT / '.venv/lib/python3.12/site-packages/nvidia/cu13/lib'
DESTINATION = ATTEMPT / 'venv-b/lib/python3.12/site-packages/nvidia/cu13/lib'

def inventory(directory):
    result = {}
    for path in sorted(directory.iterdir()):
        assert path.resolve().is_relative_to(ROOT)
        assert path.is_file(), path
        result[path.name] = {
            'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest(),
            'bytes': path.stat().st_size,
        }
    return result

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not DESTINATION.is_symlink()
original = inventory(DESTINATION)
assert original == inventory(SOURCE)
preserved = DESTINATION.with_name('lib-before-shared-identity')
assert not preserved.exists()
DESTINATION.rename(preserved)
target = os.path.relpath(SOURCE, DESTINATION.parent)
DESTINATION.symlink_to(target, target_is_directory=True)
assert DESTINATION.resolve() == SOURCE.resolve()
assert inventory(DESTINATION) == original == inventory(preserved)
record = {
    'kind': 'worktree-local-shared-cuda-library-identity-setup',
    'startedAt': started,
    'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': str(SOURCE), 'destination': str(DESTINATION),
    'preservedOriginal': str(preserved), 'symlinkTarget': target,
    'files': original, 'byteChanges': False,
    'setupScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'Only the new baseline environment; previous failed-attempt environment unchanged',
}
with (ATTEMPT / 'dependency-setup.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print('Shared CUDA directory verified:', len(original), 'unchanged files')
