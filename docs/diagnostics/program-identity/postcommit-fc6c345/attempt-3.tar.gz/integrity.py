"""Post-capture byte/source validation through the frozen consumer."""
import datetime
import importlib.util
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
ATTEMPT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('consumer', ROOT / 'docs/diagnostics/program-identity/consumer.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
label = sys.argv[1]
output = c.inside(sys.argv[2])
output.parent.mkdir()
record = {'kind': 'post-capture-integrity', 'passed': False, 'command': sys.orig_argv,
          'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scriptSha256': c.sha(Path(__file__).read_bytes()), 'timingData': False}
try:
    frozen = c.read(ATTEMPT / 'freeze/result.json.gz')
    assert c.source(ROOT) == frozen['source']
    record['source'] = c.source(ROOT)
    record['installed'] = c.installed(c.read(ATTEMPT / f'build-{label}/result.json.gz'))
    record['libraries'] = []
    for name in ('libcudart.so.13', 'libnvrtc.so.13', 'libnvrtc-builtins.so.13.0'):
        path = c.inside(ROOT / '.venv/lib/python3.12/site-packages/nvidia/cu13/lib' / name)
        record['libraries'].append({'path':str(path),'sha256':c.sha(path.read_bytes())})
    record['passed'] = True
finally:
    record['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    c.write(output, record)
