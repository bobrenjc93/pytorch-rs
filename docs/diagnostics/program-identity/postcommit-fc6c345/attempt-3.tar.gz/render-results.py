"""Render already-verified records; performs no benchmark or scoring."""
import gzip
import hashlib
import json
from pathlib import Path
P = Path(__file__).resolve().parent
def read(name):
    return json.loads(gzip.decompress((P / name / 'result.json.gz').read_bytes()))
verified = read('verification')
assert verified['passed'] and not verified['failures']
legs = []
for index in range(8):
    r = read(f'leg-{index}')
    legs.append({'index': index, 'label': r['label'], 'implementation': r['implementation'],
        'sourceCommit': r['source']['commit'], 'startedAt': r['startedAt'], 'finishedAt': r['finishedAt'],
        'rawSha256': hashlib.sha256((P / f'leg-{index}/result.json.gz').read_bytes()).hexdigest(),
        'cells': [{k: row[k] for k in ('family','size','factoryNs','firstNs','samples','statistics')}
                  for row in r['cells']],
        'churn': [{'size': row['size'], 'elapsedNs': row['elapsedNs']} for row in r['churn']['calls']]})
    del r
summary = {'kind':'derived-non-scoring-complete-comparison', 'qualificationOrScoreProduced':False,
    'verificationSha256':hashlib.sha256((P/'verification/result.json.gz').read_bytes()).hexdigest(),
    'ledger':verified['ledger'], 'ratios':verified['ratios'], 'legs':legs,
    'renderScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(P/'statistics.json').write_text(json.dumps(summary,indent=2)+'\n')
labels = ['B0','R1','C2','R3','R4','C5','R6','B7']
lines = ['# Complete public comparison: fc6c345', '',
    'B is accepted main `60202557`; C is clean repaired `fc6c345`. R uses ordinary default PyTorch 2.13.',
    'Columns follow the actual serial leg order. Every median uses all 17 retained-output calls.',
    'No outlier removal, order pooling or parity score is applied. All dispersion statistics',
    '(Q1/Q3/MAD/min/max), factory times and raw samples are in the archived `statistics.json` and leg records.', '']
def matrix(title, field, scale):
    lines.extend([f'## {title}', '', '| Family | Size | '+' | '.join(labels)+' |',
                  '| --- | ---: | '+' | '.join(['---:']*8)+' |'])
    for j, cell in enumerate(legs[0]['cells']):
        values = [(r['cells'][j]['statistics']['median'] if field=='median' else r['cells'][j][field])/scale for r in legs]
        lines.append('| '+cell['family']+' | '+str(cell['size'])+' | '+' | '.join(f'{v:.3f}' for v in values)+' |')
    lines.append('')
matrix('Steady median (microseconds)', 'median', 1000)
comparisons = ['B/C-forward','B/C-reverse','reference/B-forward','reference/C-forward','reference/C-reverse','reference/B-reverse']
lines.extend(['## All median ratios', '', 'Ratios divide the named numerator latency by the denominator latency.',
              'Reference comparisons are separate from native before/after gains.', '',
              '| Family | Size | '+' | '.join(comparisons)+' |', '| --- | ---: | '+' | '.join(['---:']*6)+' |'])
for cell in legs[0]['cells']:
    values = [next(r['medianRatio'] for r in verified['ratios'] if r['comparison']==label and r['family']==cell['family'] and r['size']==cell['size']) for label in comparisons]
    lines.append('| '+cell['family']+' | '+str(cell['size'])+' | '+' | '.join(f'{v:.3f}' for v in values)+' |')
lines.append('')
matrix('First completed call (milliseconds)', 'firstNs', 1000000)
matrix('Callable factory (microseconds)', 'factoryNs', 1000)
lines.extend(['## Ordinary negation churn (microseconds)', '',
              'These are single completed calls, not medians or isolated compiler times.', '',
              '| Step | Length | '+' | '.join(labels)+' |','| ---: | ---: | '+' | '.join(['---:']*8)+' |'])
for j, row in enumerate(legs[0]['churn']):
    lines.append('| '+str(j)+' | '+str(row['size'])+' | '+' | '.join(f"{r['churn'][j]['elapsedNs']/1000:.3f}" for r in legs)+' |')
lines.extend(['', 'Exact B/C and finite reference/metadata checks passed. Raw bit differences across all verified pairs: '+str(sum(r['rawBitDifferences'] for r in verified['ratios']))+'.', ''])
(P/'results.md').write_text('\n'.join(lines))
print(json.dumps({'ledger':verified['ledger'],'ratios':verified['ratios']},indent=2))
