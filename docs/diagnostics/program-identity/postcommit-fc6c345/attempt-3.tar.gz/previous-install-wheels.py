"""Install the two source-bound wheels into separate worktree environments."""
import datetime
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
ATTEMPT = Path(__file__).resolve().parent
for label, interpreter in [('b', ATTEMPT / 'venv-b/bin/python'), ('c', ROOT / '.venv/bin/python')]:
    build = json.loads(gzip.decompress((ATTEMPT / f'build-{label}/result.json.gz').read_bytes()))
    assert build['passed']
    command = ['uv', 'pip', 'install', '--python', str(interpreter), '--no-deps', '--reinstall',
               '--no-cache', '--no-config', build['wheel']]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.perf_counter_ns()
    result = subprocess.run(command, capture_output=True, text=True, env={
        **os.environ, 'TMPDIR': str(ROOT / 'target/tmp'),
        'UV_CACHE_DIR': str(ROOT / 'target/test-cache/uv'), 'PYTHONDONTWRITEBYTECODE': '1'})
    record = {'command': command, 'driverCommand': sys.orig_argv, 'startedAt': started,
              'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'elapsedNs': time.perf_counter_ns() - clock, 'returncode': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr, 'wheelSha256': build['wheelSha256']}
    with (ATTEMPT / f'install-{label}.json').open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    result.check_returncode()
    print('Installed', label, build['wheelSha256'])
