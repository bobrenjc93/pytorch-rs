"""Untimed dependency check using the frozen consumer's validation functions."""
import datetime
import importlib.util
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('consumer', ROOT / 'docs/diagnostics/program-identity/consumer.py')
c = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(c)
output = c.inside(sys.argv[1])
output.parent.mkdir()
record = {'kind': 'untimed-reference-runtime-setup-check', 'passed': False,
          'command': sys.orig_argv, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'bindings': c.bindings(), 'source': c.source(ROOT),
          'scriptSha256': c.sha(Path(__file__).read_bytes()), 'timingData': False}
try:
    c.environment(output.parent)
    assert os.environ['CUDA_VISIBLE_DEVICES'] == '0'
    pin = ROOT / '.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13'
    os.environ['TORCH_RS_CUDART'] = str(pin)
    record['gpuBefore'] = c.gpu_identity()
    sync = c.Synchronizer(pin)
    import torch
    assert torch.__version__ == '2.13.0+cu130'
    assert torch.cuda.device_count() == 1
    assert 'GPU-' + str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == c.GPU
    sync()
    record.update(implementation='reference', synchronization=sync.metadata,
                  environment={'TORCH_RS_CUDART': str(pin)}, libraries=c.libraries(),
                  referencePath=str(c.inside(torch.__file__)),
                  referenceSha256=c.sha(Path(torch.__file__).read_bytes()),
                  referenceVersion=torch.__version__)
    c.validate_libraries(record)
    record['passed'] = True
except BaseException:
    record['failure'] = traceback.format_exc()
    raise
finally:
    record['gpuAfter'] = c.gpu_identity()
    record['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    c.write(output, record)
