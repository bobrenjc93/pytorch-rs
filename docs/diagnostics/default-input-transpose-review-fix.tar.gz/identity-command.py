import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import torch_rs
from torch_rs import torch_rs as bridge, _compile_pointwise as frontend
import torch
root=Path.cwd()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
x=torch_rs.ones(2,3).to('cuda:0')
def f(x): return (x.transpose(0,1),-x)
fcompiled=torch_rs.compile(f)
out=fcompiled(x)
torch.cuda.synchronize()
loaded=sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines()
               if any(name in line for name in ('libcuda.', 'libcudart.', 'libnvrtc.', 'libnvrtc-builtins.'))})
versions={}
for path in loaded:
    lib=ctypes.CDLL(path)
    if 'libcudart.' in path:
        version=ctypes.c_int(); lib.cudaRuntimeGetVersion(ctypes.byref(version)); versions[path]=version.value
    elif 'libnvrtc.' in path:
        major=ctypes.c_int();minor=ctypes.c_int();lib.nvrtcVersion(ctypes.byref(major),ctypes.byref(minor));versions[path]=[major.value,minor.value]
assert Path(frontend.__file__).read_bytes() == Path('python/torch_rs/_compile_pointwise.py').read_bytes()
files=['python/torch_rs/_compile_pointwise.py','src/python_compile_cuda_graph.rs','src/python.rs','tests/test_compile_pointwise_input_transpose.py']
record={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'working_tree_changes':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True).strip(),
        'measurement_status':'uncommitted review correction; not clean-commit performance evidence',
        'source_root':str(root),
        'source_sha256':{file:sha(file) for file in files},
        'python':sys.version,'executable':sys.executable,'base_prefix':sys.base_prefix,
        'frontend_source_matches_installed':True,
        'wheel_sha256':{str(path):sha(path) for path in Path('target/runtime-axis-review/wheels').glob('*.whl')},
        'native_package':torch_rs.__file__,'native_extension':bridge.__file__,
        'native_sha256':sha(bridge.__file__),'reference':torch.__version__,
        'reference_path':torch.__file__,'reference_cuda':torch.version.cuda,
        'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),
        'gpu':torch.cuda.get_device_name(0),'runtime_versions':versions,'loaded_libraries':loaded,
        'nvcc':subprocess.check_output(['nvcc','--version'],text=True),
        'rustc':subprocess.check_output(['rustc','--version'],text=True),
        'build':'maturin build --release --locked; abi3-py310; Cargo release thin LTO, codegen-units=1',
        'native_nvrtc_version':next(iter(fcompiled._torch_rs_pointwise_cache.executors.values())).nvrtc_version,
        'native_nvrtc_options':next(iter(fcompiled._torch_rs_pointwise_cache.executors.values())).options,
        'kernel_source':next(iter(fcompiled._torch_rs_pointwise_cache.executors.values())).source}
Path(os.environ['BURNER_EVALUATION_ARTIFACT_DIR'],'identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('kernel_source','nvcc','loaded_libraries')},indent=2))
