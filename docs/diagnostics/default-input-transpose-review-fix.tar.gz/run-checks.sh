#!/usr/bin/env bash
set -uo pipefail
cd /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_8276490b
source target/env.sh
unset PYTHONPATH PYTHONHOME
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/runtime-axis-review"
run_check() {
    local label="$1"
    shift
    date --utc --iso-8601=seconds
    printf '%q ' "$@"
    printf '\n'
    "$@" > "$BURNER_EVALUATION_ARTIFACT_DIR/$label.log" 2>&1
    local outcome=$?
    printf '%s exit=%s\n' "$label" "$outcome"
}
run_check install uv --no-config pip install --python .venv/bin/python --force-reinstall --no-deps target/runtime-axis-review/wheels/torch_rs-0.1.0-cp310-abi3-manylinux_2_34_x86_64.whl
run_check gpu-before nvidia-smi --id=0 --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used --format=csv
run_check focused .venv/bin/python -u -m unittest tests.test_compile_pointwise_input_transpose
run_check regressions .venv/bin/python -u -m unittest tests.test_compile_pointwise_helpers tests.test_compile_pointwise_loops tests.test_compile_pointwise_shape_branches tests.test_compile_pointwise_structured_inputs tests.test_compile_pointwise_structured_outputs.StructuredAdmission tests.test_compile_pointwise_structured_outputs.StructuredCache tests.test_compile_pointwise_prepared tests.test_compile_pointwise_guards tests.test_compile_pointwise_static_guards tests.test_compile_pointwise_signature_guards
run_check portable env CUDA_VISIBLE_DEVICES= .venv/bin/python -u -m unittest tests.test_compile_pointwise_input_transpose tests.test_compile_pointwise_shape_branches.ShapeBranchAdmission
run_check gpu-after nvidia-smi --id=0 --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used --format=csv
