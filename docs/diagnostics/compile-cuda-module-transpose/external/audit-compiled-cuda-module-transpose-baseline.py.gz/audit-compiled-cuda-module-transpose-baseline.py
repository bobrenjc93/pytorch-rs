"""Read-only audit of a fresh exact-main H100 native-module transpose baseline.

Requires a verified preceding managed merge. Preparing this helper does not
create a worktree, run a GPU test, submit an idea, or change a score.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile

notes = Path('/tmp/pytorch-rs-compiler-recovery.3UB6mU')
root = Path('/data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/probe-compiled-cuda-module-transpose')
assert len(sys.argv) == 2 and re.fullmatch(r'merge-[0-9]+-verified\.json', sys.argv[1])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


prior = json.loads((notes / sys.argv[1]).read_text())
build_path = root / 'target/release/build-record.json'
build = json.loads(build_path.read_text())
preflight = json.loads((notes / 'compiled-cuda-module-transpose-baseline-preflight.json').read_text())
probe = json.loads((notes / 'compiled-cuda-module-transpose-baseline-probe.json').read_text())
receipt = json.loads((notes / 'compiled-cuda-module-transpose-baseline-receipt.json').read_text())
assert prior['verified'] and prior['allTenBaselinesPromoted']
assert git('rev-parse', 'HEAD') == git('rev-parse', 'main') == prior['main'] == build['commit'] == probe['commit'] == preflight['commit']
assert git('status', '--porcelain') == '' and build['clean_checkout'] and build['source_unchanged_during_build']
production_names = git('ls-tree', '-r', '--name-only', 'HEAD', '--', 'src', 'python', 'Cargo.toml', 'Cargo.lock', 'pyproject.toml', 'rust-toolchain.toml').splitlines()
production = {name: sha(root/name) for name in production_names}
assert hashlib.sha256(json.dumps(production, sort_keys=True).encode()).hexdigest() == build['source_sha256'] == '0a68f0cd8b1cc5af363c2a0e5e8add84a74065c66d42df5a555d65dcd941575e'
assert preflight['source_sha256'] == build['source_sha256']
assert build['production_diff_sha256'] == hashlib.sha256(b'').hexdigest()
assert '--locked' in build['build_command'] and '--offline' in build['build_command']
assert '--allow-dirty' not in build['build_command']
assert probe['verified_baseline_gap'] and preflight['root_preflight']
assert probe['source_provenance']['source_sha256'] == build['source_sha256'] and probe['source_provenance']['commit'] == prior['main']
assert probe['genuine_transpose_is_native_module_function']
assert isinstance(probe['variable_function_owner_contains_transpose'], bool)
assert probe['probe_sha256'] == sha(root / 'target/probe-compiled-cuda-module-transpose.py') == sha(notes / 'probe-compiled-cuda-module-transpose.py')
assert probe['metadata_helper_sha256'] == sha(root / 'tests/test_cuda_contiguous.py')
assert sha(root / 'target/root-preflight.py') == sha(notes / 'compiled-cuda-reshape-root-preflight.py')
for kind in ('extension', 'source_extension', 'wheel', 'interpreter'):
    path = Path(build[kind + '_path'])
    assert path.resolve().is_relative_to(root)
    expected = build['extension_sha256'] if kind == 'source_extension' else build[kind + '_sha256']
    assert sha(path) == expected
assert probe['native_extension_sha256'] == preflight['extension_sha256'] == build['extension_sha256']
assert probe['native_extension'] == preflight['extension'] == build['extension_path']
with zipfile.ZipFile(build['wheel_path']) as wheel:
    native_members = [name for name in wheel.namelist() if name.endswith('.so')]
    assert len(native_members) == 1
    assert hashlib.sha256(wheel.read(native_members[0])).hexdigest() == build['extension_sha256']
    python_members = [name for name in wheel.namelist() if name.startswith('torch_rs/') and name.endswith('.py')]
    committed = {path.removeprefix('python/') for path in git('ls-tree', '-r', '--name-only', 'HEAD', '--', 'python/torch_rs').splitlines() if path.endswith('.py')}
    assert set(python_members) == committed
    for name in python_members:
        assert wheel.read(name) == (root / 'python' / name).read_bytes()
        assert wheel.read(name) == (root / '.venv/lib/python3.12/site-packages' / name).read_bytes()
assert len(build['commands']) == 2
for command in build['commands']:
    assert command['exit_status'] == 0 and sha(command['log']) == command['log_sha256']
assert build['uv_lock_sha256'] == sha(root / 'uv.lock')
assert sha(preflight['native_runtime_library']) == preflight['runtime_sha256']
assert preflight['native_runtime'] == preflight['native_driver'] == 13000
assert preflight['gpu'] == probe['gpu'] == 'NVIDIA H100' and preflight['visible_count'] == 1
assert preflight['reference'] == probe['reference'] == '2.13.0+cu130'
assert preflight['capability'] == [9, 0] and not preflight['nvcc_used']
assert prior['prNumber'] == 1985
assert '--release' in build['build_command']
assert probe['probe_sha256'] == 'bc98874d08f12e7deb9e6f5284b0703104d292e6bed4fbbb49fe58c20030590f'
specifications = {
    'module_transpose': ('m.transpose(x, {dim0}, {dim1})', 1, True),
    'imported_transpose': ('transpose_alias(x, {dim0}, {dim1})', 1, True),
    'module_transpose_after_add': ('m.transpose(x + x, {dim0}, {dim1})', 1, True),
    'imported_transpose_after_add': ('transpose_alias(x + x, {dim0}, {dim1})', 1, True),
    'module_transpose_before_packed_relu': ('m.relu(m.transpose(x, {dim0}, {dim1}).contiguous())', 1, True),
    'imported_transpose_before_packed_relu': ('m.relu(transpose_alias(x, {dim0}, {dim1}).contiguous())', 1, True),
    'module_transpose_after_relu': ('m.transpose(m.relu(x), {dim0}, {dim1})', 1, True),
    'imported_transpose_after_relu': ('transpose_alias(m.relu(x), {dim0}, {dim1})', 1, True),
    'existing_method_transpose': ('x.transpose({dim0}, {dim1})', 1, False),
    'existing_module_t': ('m.t(x)', 1, False),
    'existing_module_squeeze': ('m.squeeze(x)', 1, False),
    'existing_module_relu': ('m.relu(x)', 1, False),
}
layouts = {
    ((), (0, 0)), ((), (-1, 0)),
    ((7,), (0, 0)), ((7,), (-1, -1)),
    ((3, 5), (0, 1)), ((3, 5), (-1, -2)),
    ((3, 5), (0, 0)), ((3, 5), (1, 1)),
    ((0, 1), (0, 1)), ((0, 1), (-1, -2)),
    ((1, 7), (0, 1)), ((1, 7), (-1, -2)),
}
expected = {(name, shape, axes) for name in specifications for shape, axes in layouts}
assert {(case['name'], tuple(case['shape']), tuple(case['axes'])) for case in probe['cases']} == expected
assert len(probe['cases']) == len(expected) == 144
for case in probe['cases']:
    expression_template, arity, is_gap = specifications[case['name']]
    expression = expression_template.format(dim0=case['axes'][0], dim1=case['axes'][1])
    assert (case['expression'], case['arity'], case['expected_gap']) == (expression, arity, is_gap)
    assert case['native_eager_passed'] and case['reference_inductor_cold_and_repeat_passed']
    assert case['original_native_program_body_not_executed']
    assert len(case['input_sha256']) == arity
    assert all(re.fullmatch(r'[0-9a-f]{64}', value) for value in case['input_sha256'])
    assert [call['call'] for call in case['native_calls']] == ['cold', 'repeat']
    for call in case['native_calls']:
        if is_gap:
            assert call['unsupported']['type'] == 'CompileTraceUnsupportedError'
            assert call['unsupported']['message']
            assert 'passed' not in call
        else:
            assert call['passed'] is True and 'unsupported' not in call
assert probe['gap_cases'] == 96 and probe['existing_positive_cases'] == 48
assert sum(case['expected_gap'] for case in probe['cases']) == 96
assert len(probe['unrelated_rebindings']) == 4
assert {row['attribute'] for row in probe['unrelated_rebindings']} == {'transpose'}
assert {row['expression'] for row in probe['unrelated_rebindings']} == {'m.t(x)', 'm.relu(x)', 'm.squeeze(x)', 'm.neg(x)'}
assert all(row['existing_module_program_preserved'] and row['replacement_callback_calls'] == 0
           for row in probe['unrelated_rebindings'])
assert probe['reference_compile_backend'] == 'inductor' and probe['native_compile_backend'] == 'eager'
assert not probe['cuda_performance_measured'] and not probe['scores_changed']
assert probe['gpu_snapshot_is_not_reservation']
watch = json.loads((notes / 'compiled-cuda-module-transpose-watch.json').read_text())
assert receipt['exitCode'] == 0 and receipt['sessionId'] == watch['baselineProbeSessionId']
assert isinstance(receipt['sessionId'], int) and receipt['sessionId'] > 0
assert watch['baselineProbeCompleted'] and watch['baselineProbeExitCode'] == 0
assert receipt['preflightPassed'] and receipt['repositoryUnchanged'] and not receipt['scoresChanged']
assert receipt['head'] == prior['main']
assert receipt['outputSha256'] == sha(notes / 'compiled-cuda-module-transpose-baseline-output.log')
assert receipt['preparationSha256'] == sha(notes / 'prepare-compiled-cuda-module-transpose-probe.sh')
assert receipt['probeSha256'] == probe['probe_sha256']
assert receipt['preparationSha256'] == '8c8e7638d3f3a5f3682e6cd38766896c6c8423a7d9b014157e9b13462a3ca1cf'
assert sha(notes / 'bootstrap-module-transpose-probe-python.py') == '223ebd07f55a251177f66b287a790fa5faa694fb8f138a0000915ec7f0c1fb8f'
assert receipt['referenceBackend'] == 'inductor' and receipt['nativeBackend'] == 'eager'
assert (receipt['gapCases'], receipt['existingPositiveCases'], receipt['unrelatedRebindingControls']) == (96, 48, 4)
bootstrap_path = notes / 'compiled-cuda-module-transpose-python-bootstrap.json'
bootstrap = json.loads(bootstrap_path.read_text())
assert receipt['interpreterBootstrapSha256'] == sha(bootstrap_path)
assert receipt['interpreterBootstrapHelperSha256'] == sha(notes / 'bootstrap-module-transpose-probe-python.py')
assert bootstrap['verified'] and bootstrap['sourcePreserved'] and bootstrap['destinationWasAbsent']
assert bootstrap['entireInstallationByteAndLinkIdentical'] and bootstrap['toolchainCacheReusedOnly']
assert not bootstrap['projectEnvironmentCopied'] and not bootstrap['nativeWheelCopied'] and not bootstrap['globalSettingsChanged']
assert bootstrap['installationManifestSha256'] == '519ae888f6f47836a48399b7eff35b28582673e893a08261bd5e2758f9a4f265'
assert bootstrap['interpreterSha256'] == build['interpreter_sha256'] == 'f7c6210eb40fadcd3c2889dddd24a15fc2c9f926aec5a03bf9da66e12d581526'
assert Path(bootstrap['destination']).resolve().is_relative_to(root)
assert preflight['runtime_sha256'] == '96c42e418cec19054186b9429c321603cc190bf26a18104e19408117a2a817b0'
log = (notes / 'compiled-cuda-module-transpose-baseline-output.log').read_text()
for marker, saved in [('root_preflight', preflight), ('verified_baseline_gap', probe)]:
    matches = list(re.finditer(r'\{\s*"' + re.escape(marker) + r'"\s*:', log))
    assert len(matches) == 1
    recorded, _ = json.JSONDecoder().raw_decode(log[matches[0].start():])
    assert recorded == saved
print(json.dumps({'verified': True, 'checkedAt': datetime.now(timezone.utc).isoformat(),
    'base': prior['main'], 'priorMergeAudit': str(notes / sys.argv[1]), 'worktree': str(root),
    'sourceSha256': build['source_sha256'], 'buildRecordSha256': sha(build_path), 'build': build,
    'probe': probe, 'preflight': preflight, 'receipt': receipt, 'interpreterBootstrap': bootstrap,
    'gapCaseCount': 96, 'existingPositiveCases': 48, 'unrelatedRebindingControls': 4,
    'referenceInductorVerified': True, 'generalCompileParityClaimed': False,
    'baselineScoresUnchanged': True, 'implementationNotStarted': True}, indent=2))
