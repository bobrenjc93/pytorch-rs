export CUDA_VISIBLE_DEVICES=0
export CUDA_CACHE_PATH=$PWD/target/cache/cuda
export CARGO_HOME=$PWD/target/cargo-home
export CARGO_TARGET_DIR=$PWD/target/cargo-target
export UV_CACHE_DIR=$PWD/target/cache/uv
export UV_PYTHON_INSTALL_DIR=$PWD/target/python
export TMPDIR=$PWD/target/tmp
export XDG_CACHE_HOME=$PWD/target/cache
export TORCHINDUCTOR_CACHE_DIR=$PWD/target/cache/inductor
export TRITON_CACHE_DIR=$PWD/target/cache/triton
export PYTHONNOUSERSITE=1
export BURNER_EVALUATION_ARTIFACT_DIR=$PWD/target/evidence
export PYO3_PYTHON=$PWD/.venv/bin/python
export OMP_NUM_THREADS=1
export CARGO_BUILD_JOBS=8
unset CONDA_PREFIX VIRTUAL_ENV
