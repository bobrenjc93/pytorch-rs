"""Audit this capture's bytes and provenance; does not execute or rescore workloads."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path.cwd().resolve()
base = root / 'target/postcommit-evidence'
report_path = base / 'export/report.json'
report = json.loads(report_path.read_text())
commit = 'd22c5acbf83be77a789d32839ee57a6e5d4b41f8'
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def local(path):
    path = Path(path).resolve()
    assert path.is_relative_to(root), path
    return path
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == commit
assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], text=True).strip() == ''
assert report['valid'] and not report['diagnostic']
assert report['provenance']['commit'] == commit
assert report['provenance']['working_tree_changes'] == ''
assert report['setup']['build_identity']['commit'] == commit
assert report['setup']['build_identity']['working_tree_changes'] == ''
assert report['setup']['build_identity']['source_sha256'] == report['provenance']['source_sha256']
assert report['compile_call'] == 'framework.compile(program)'
assert (report['warmups'], report['samples'], report['rtol'], report['atol']) == (5, 17, 1e-4, 1e-4)
assert len(report['cells']) == 112
assert len([cell for cell in report['cells'] if cell['device'] == 'cuda']) == 56
assert len(report['workers']) == 6
assert sha(report_path) == sha(base / 'default-compile-report.json')
for name, expected in report['provenance']['files'].items():
    assert sha(root / name) == expected, name
wheel = report['wheel']
assert sha(local(wheel['path'])) == wheel['sha256']
raw = {}
reference_cases = 0
for worker in report['workers']:
    env = worker['environment']
    assert env['cuda_visible_devices'] == '0'
    assert env['threads'] == 1
    assert sha(local(env['executable'])) == env['interpreter_sha256']
    local(env['prefix'])
    if worker['implementation'] == 'reference':
        assert env['framework_version'] == '2.13.0+cu130'
        assert len(worker['case_status']) == 28
        assert all(case['status'] == 'passed' for case in worker['case_status'].values())
        reference_cases += len(worker['case_status'])
        for origin in env['reference_provenance']['origins'].values():
            assert sha(local(origin['path'])) == origin['sha256']
    else:
        local(env['package'])
        assert sha(local(env['native_extension'])) == env['native_sha256']
    for kind in ('output', 'log'):
        path = local(worker['artifacts'][kind])
        expected = worker['artifacts'][kind + '_sha256']
        assert sha(path) == expected
        exported = base / 'export' / path.name
        assert sha(exported) == expected
        raw[path.name] = {'sha256': expected, 'bytes': exported.stat().st_size, 'exported_path': str(exported)}
identity = json.loads((base / 'checks/identity.json').read_text())
assert identity['commit'] == commit and identity['working_tree_changes'] == ''
assert identity['source_root'] == str(root) and identity['frontend_source_matches_installed']
for name in ('executable', 'base_prefix', 'native_package', 'native_extension', 'reference_path'):
    local(identity[name])
for name, expected in identity['source_sha256'].items():
    assert sha(root / name) == expected
statuses = re.findall(r'^([a-z-]+) exit=(\d+)$', (base / 'checks-commands.log').read_text(), re.M)
assert len(statuses) == 6 and all(code == '0' for _, code in statuses), statuses
assert 'Ran 20 tests' in (base / 'checks/transpose.log').read_text()
assert 'Ran 32 tests' in (base / 'checks/portable.log').read_text()
assert 'OK (skipped=9)' in (base / 'checks/portable.log').read_text()
assert '17 passed; 0 failed' in (base / 'checks/native.log').read_text()
assert 'recompile_limit' not in (base / 'checks/transpose.log').read_text()
assert 'native-only transpose passed' in (base / 'checks/transpose-native-only.log').read_text()
historical = root / 'docs/diagnostics/default-input-transpose-validation.tar.gz'
assert historical.read_bytes() == subprocess.check_output(['git', 'show', commit + ':docs/diagnostics/default-input-transpose-validation.tar.gz'])
result = {'verified_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'measured_commit': commit,
          'working_tree_changes_at_audit': '', 'source_files_verified': len(report['provenance']['files']),
          'report_sha256': sha(report_path), 'source_sha256': report['provenance']['source_sha256'],
          'reference_case_executions_passed': reference_cases, 'coverage_cells': 112, 'cuda_cells': 56,
          'raw_worker_artifacts': raw, 'check_exit_statuses': dict(statuses),
          'development_archive_unchanged_sha256': sha(historical)}
(base / 'evidence-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
