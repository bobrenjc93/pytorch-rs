#!/usr/bin/env bash
set -uo pipefail
cd /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_8276490b
source target/env.sh
unset PYTHONPATH PYTHONHOME
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/postcommit-evidence/checks"
export PYO3_PYTHON="$PWD/target/default-compile-eval/venv/bin/python"
run_check() {
    local label="$1"
    shift
    date --utc --iso-8601=seconds
    printf '%q ' "$@"
    printf '\n'
    "$@" > "$BURNER_EVALUATION_ARTIFACT_DIR/$label.log" 2>&1
    local outcome=$?
    printf '%s exit=%s\n' "$label" "$outcome"
    date --utc --iso-8601=seconds
}
run_check gpu-before nvidia-smi --id=0 --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used,memory.total --format=csv
run_check identity "$PYO3_PYTHON" target/postcommit-evidence/identity-command.py
run_check transpose "$PYO3_PYTHON" -u -m unittest tests.test_compile_pointwise_input_transpose
run_check portable env CUDA_VISIBLE_DEVICES= "$PYO3_PYTHON" -u -m unittest tests.test_compile_pointwise_input_transpose tests.test_compile_pointwise_shape_branches.ShapeBranchAdmission
run_check native cargo test --locked --features python-bindings --lib cuda_graph::tests -- --test-threads=1
run_check gpu-after nvidia-smi --id=0 --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used,memory.total --format=csv
