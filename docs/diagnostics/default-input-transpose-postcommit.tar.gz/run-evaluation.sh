#!/usr/bin/env bash
set -euo pipefail
cd /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_8276490b
source target/env.sh
export UV_CACHE_DIR="$PWD/target/uv-cache"
export UV_SYSTEM_CERTS=true
export PYTHON="$PWD/.venv/bin/python"
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/postcommit-evidence/export"
uv --no-config venv --python "$PWD/target/python312/bin/python3.12" target/default-compile-eval/venv
CUDA_VISIBLE_DEVICES=0 bash scripts/evaluate_torch_compile_default.sh --metric both --output target/postcommit-evidence/default-compile-report.json
