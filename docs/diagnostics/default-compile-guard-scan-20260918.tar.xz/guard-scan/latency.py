"""Author-only default-call diagnostic; no corpus score or evaluator invocation."""
import argparse, ctypes, hashlib, importlib, json, os, pathlib, platform, statistics, subprocess, sys, time
import numpy as np
p=argparse.ArgumentParser(); p.add_argument('--framework',choices=['torch','torch_rs'],required=True); p.add_argument('--output',required=True); p.add_argument('--label',required=True); args=p.parse_args()
root=pathlib.Path.cwd(); module=importlib.import_module(args.framework)
if args.framework=='torch': module.set_num_threads(1)
rt=ctypes.CDLL(os.environ['TORCH_RS_CUDART']); rt.cudaDeviceSynchronize.restype=ctypes.c_int
def sync():
    status=rt.cudaDeviceSynchronize()
    if status: raise RuntimeError(f'cudaDeviceSynchronize: {status}')
def neg(x,y): return -x
def chain(x,y): return (x*y+y).relu()
def trig(x,y): return (x.sin()*x.sin()+y.cos()-0.375).relu()
def mixed(x,y):
    a=x.transpose(0,-1)
    return (x+y,a,a,y,-x)
def views(x,y):
    a=x.transpose(0,-1)
    return (a,a,y.transpose(0,-1))
arrays_out={}
def fingerprint(value):
    if isinstance(value,tuple): return [fingerprint(v) for v in value]
    array=np.asarray(value.cpu().tolist(),dtype=np.float32).reshape(tuple(value.shape))
    key=str(len(arrays_out)); arrays_out[key]=array
    return dict(array_key=key,shape=list(value.shape),stride=list(value.stride()),offset=value.storage_offset(),dtype=str(value.dtype),device=str(value.device),grad=value.requires_grad,values=array.flatten().tolist())
def snapshot():
    return subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=index,uuid,name,driver_version,pstate,utilization.gpu,memory.used,temperature.gpu','--format=csv'],text=True)
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
record=dict(label=args.label,framework=args.framework,command=sys.argv,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty=subprocess.check_output(['git','status','--porcelain'],text=True),root=str(root),executable=sys.executable,prefix=sys.prefix,python=sys.version,platform=platform.platform(),module=module.__file__,version=module.__version__,gpu_before=snapshot(),cuda_visible=os.environ['CUDA_VISIBLE_DEVICES'],runtime=os.environ['TORCH_RS_CUDART'],source_hashes={s:sha(s) for s in ('python/torch_rs/_compile_pointwise.py','src/python_pointwise.rs')},warmups=10,samples=17,calls_per_sample=16,seed=20540918,cells=[])
if args.framework=='torch_rs':
    extension=importlib.import_module('torch_rs.torch_rs'); record['extension']=extension.__file__; record['extension_sha256']=sha(extension.__file__)
else: record['torch_cuda']=module.version.cuda
shapes=[(),(0,),(1,),(257,),(17,31),(512,512)]
# Fixed order and shape history on each public wrapper. No backend/options overrides.
for fn in (neg,chain,trig,mixed,views):
    compiled=module.compile(fn)
    for shape in shapes:
        rng=np.random.default_rng(20540918); arrays=[rng.uniform(-1,1,size=shape).astype(np.float32) for _ in range(2)]
        values=tuple(module.tensor(a.tolist(),dtype=module.float32).to('cuda:0') for a in arrays)
        cell=dict(program=fn.__name__,shape=shape)
        try:
            sync(); start=time.perf_counter_ns(); result=compiled(*values); sync(); cell['first_call_ns']=time.perf_counter_ns()-start
            # Materialize whole outputs outside timing; large arrays retained as samples + digest below.
            first=fingerprint(result)
            for _ in range(10): result=compiled(*values); sync()
            samples=[]
            for _ in range(17):
                sync(); start=time.perf_counter_ns()
                for _ in range(16): result=compiled(*values); sync()
                samples.append((time.perf_counter_ns()-start)/16)
            cell['samples_ns']=samples; cell['median_ns']=statistics.median(samples)
            changed=tuple(module.tensor((a+np.float32(.125)).tolist(),dtype=module.float32).to('cuda:0') for a in arrays)
            second=fingerprint(compiled(*changed)); sync()
            def compact(v):
                if isinstance(v,list): return [compact(x) for x in v]
                data=np.asarray(v.pop('values'),dtype=np.float32); v['bits_sha256']=hashlib.sha256(data.tobytes()).hexdigest(); v['values']=data[::max(1,len(data)//256)].tolist(); return v
            cell['first']=compact(first); cell['changed']=compact(second); cell['status']='ok'
            if fn is mixed or fn is views:
                assert result[0 if fn is views else 1] is result[1 if fn is views else 2]
        except Exception as e:
            cell.update(status='error',error=f'{type(e).__name__}: {e}')
        record['cells'].append(cell)
        print(fn.__name__,shape,cell['status'],cell.get('median_ns',cell.get('error')),flush=True)
record['gpu_after']=snapshot()
np.savez_compressed(args.output+'.npz',**arrays_out)
pathlib.Path(args.output).write_text(json.dumps(record,indent=2)+'\n')
