import cProfile, pstats
import torch_rs as t

def f(x,y):
    return (x+y).relu()
x=t.tensor([[0.1]*32]*32).to('cuda:0')
y=t.tensor([[0.2]*32]*32).to('cuda:0')
c=t.compile(f)
for _ in range(20): c(x,y)
p=cProfile.Profile(); p.enable()
for _ in range(2000): c(x,y)
p.disable(); p.dump_stats('target/performance-polish/evidence/before.prof'); pstats.Stats(p).strip_dirs().sort_stats('tottime').print_stats(35)
