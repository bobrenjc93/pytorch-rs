import ctypes, hashlib, importlib, json, os, pathlib, platform, subprocess, sys, zipfile, uuid
root=pathlib.Path.cwd(); dest=pathlib.Path(os.environ['BURNER_EVALUATION_ARTIFACT_DIR'])
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def cmd(*args): return subprocess.check_output(args,text=True).strip()
import torch_rs as n
import torch
ext=importlib.import_module('torch_rs.torch_rs')
def f(x): return -x
x=n.tensor([1.,-2.]).to('cuda:0'); fn=n.compile(f); fn(x)
k=next(iter(fn._torch_rs_pointwise_cache.executors.values()))
rt=ctypes.CDLL(os.environ['TORCH_RS_CUDART']); v=ctypes.c_int(); assert rt.cudaRuntimeGetVersion(ctypes.byref(v))==0
record=dict(head=cmd('git','rev-parse','HEAD'),dirty=cmd('git','status','--porcelain'),captured_at=cmd('date','-u','+%Y-%m-%dT%H:%M:%SZ'),root=str(root),executable=sys.executable,prefix=sys.prefix,platform=platform.platform(),python=sys.version,rust=cmd('rustc','--version'),cargo=cmd('cargo','--version'),nvcc=cmd('nvcc','--version'),torch=torch.__version__,torch_path=torch.__file__,torch_cuda=torch.version.cuda,nvrtc=k.nvrtc_version,nvrtc_options=k.options,runtime=dict(path=os.environ['TORCH_RS_CUDART'],sha256=sha(os.environ['TORCH_RS_CUDART']),version=v.value),extension=dict(path=ext.__file__,sha256=sha(ext.__file__)),cuda_visible=os.environ['CUDA_VISIBLE_DEVICES'],gpu=cmd('nvidia-smi','--id=0','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used','--format=csv'),environment={k:v for k,v in os.environ.items() if k in ('CUDA_VISIBLE_DEVICES','CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','OMP_NUM_THREADS','MKL_NUM_THREADS','CARGO_HOME','CARGO_TARGET_DIR','VIRTUAL_ENV','PYO3_PYTHON','TMPDIR','XDG_CACHE_HOME','BURNER_EVALUATION_ARTIFACT_DIR')})
paths=cmd('git','ls-files','--','src','python','Cargo.toml','Cargo.lock','pyproject.toml','uv.lock','rust-toolchain.toml').splitlines()
record['current_source_sha256']={p:sha(p) for p in paths}
record['wheels']={}
for phase in ('before','after'):
    wheel,=list((root/'target/performance-polish'/f'wheels-{phase}').glob('*.whl'))
    with zipfile.ZipFile(wheel) as z:
        so,=[p for p in z.namelist() if p.endswith('.so')]
        wheel_so=hashlib.sha256(z.read(so)).hexdigest()
        for name in z.namelist():
            if name.startswith('torch_rs/') and name.endswith('.py'):
                expected=subprocess.check_output(['git','show','HEAD:python/'+name]) if phase=='before' else (root/'python'/name).read_bytes()
                assert z.read(name)==expected, (phase,name)
        reports=list(dest.glob(phase+'-native-*.json'))
        assert len(reports)==2 and all(json.loads(p.read_text())['extension_sha256']==wheel_so for p in reports)
        record['wheels'][phase]=dict(path=str(wheel),sha256=sha(wheel),extension_sha256=wheel_so,python_source_match=True)
        if phase=='after': assert wheel_so==sha(ext.__file__)
driver=ctypes.CDLL('libcuda.so.1'); device=ctypes.c_int(); identity=(ctypes.c_ubyte*16)()
assert driver.cuInit(0)==0 and driver.cuDeviceGet(ctypes.byref(device),0)==0
assert driver.cuDeviceGetUuid(ctypes.byref(identity),device)==0
record['driver_logical_device_uuid']='GPU-'+str(uuid.UUID(bytes=bytes(identity)))
assert record['driver_logical_device_uuid'] in record['gpu']
record['python_executable_sha256']=sha(sys.executable)
record['base_prefix']=sys.base_prefix
record['libraries']={p:sha(p) for p in {line.split()[-1] for line in pathlib.Path('/proc/self/maps').read_text().splitlines() if 'libcudart.so' in line or 'libnvrtc.so' in line}}
frozen=['.burner/evaluations.json','scripts/run_with_unix_lock.py','.github/scripts/verify_native_extension.py','scripts/evaluate_torch_compile_default.sh','scripts/evaluate_torch_compile_default.py','scripts/torch_compile_default_corpus.py','Cargo.lock','uv.lock','docs/burner-evaluation-history.json','docs/burner-evaluation-progress.svg']
record['frozen_sha256']={p:sha(p) for p in frozen if (root/p).exists()}
for p in frozen:
    if subprocess.run(['git','ls-files','--error-unmatch',p],capture_output=True).returncode==0:
        assert (root/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p]),p
historical=cmd('git','ls-files','docs/diagnostics').splitlines()
assert not cmd('git','diff','--name-only','HEAD','--',*historical)
record['historical_artifacts_unchanged']=len(historical)
record['raw_output_hashes']={p.name:sha(p) for p in dest.glob('*.npz')}
(dest/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
(dest/'author.patch').write_text(cmd('git','diff','--','src','python','tests','README.md','docs/compile-pointwise-jit.md','docs/compile-cuda-add.md','docs/compile-cuda-t.md','docs/supported-surface.md','docs/README.md')+'\n')
print('Verified baseline/after wheel sources, measured extension hashes, frozen inputs and historical artifacts.')
