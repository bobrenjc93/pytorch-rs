import json, pathlib, statistics, numpy as np
root=pathlib.Path('target/performance-polish/evidence')
reports={p.stem:json.loads(p.read_text()) for p in root.glob('*-*-*.json') if p.name.startswith(('before-','after-'))}
assert len(reports)==8
comparisons=0
for name, r in reports.items():
    assert len(r['cells'])==30
    assert all(c['status']=='ok' for c in r['cells']), name
    expected=reports['before-reference-second']
    arrays=np.load(root/(name+'.json.npz')); ref_arrays=np.load(root/'before-reference-second.json.npz')
    def check(a,b):
        if isinstance(a,list):
            assert isinstance(b,list) and len(a)==len(b)
            for x,y in zip(a,b): check(x,y)
        else:
            for k in ('shape','stride','offset','dtype','device','grad'): assert a[k]==b[k],(name,k,a[k],b[k])
            np.testing.assert_allclose(arrays[a['array_key']],ref_arrays[b['array_key']],rtol=1e-5,atol=1e-6,equal_nan=True)
    for a,b in zip(r['cells'],expected['cells']):
        assert a['program']==b['program'] and a['shape']==b['shape']
        check(a['first'],b['first']); check(a['changed'],b['changed']); comparisons+=1
rows=[]
for i,c in enumerate(reports['before-native-first']['cells']):
    med=lambda phase,fw: statistics.median([reports[f'{phase}-{fw}-{order}']['cells'][i]['median_ns']/1000 for order in ('first','second')])
    b,a=med('before','native'),med('after','native')
    rows.append(dict(program=c['program'],shape=c['shape'],before_us=b,after_us=a,change_percent=(a/b-1)*100,reference_before_us=med('before','reference'),reference_after_us=med('after','reference')))
record=dict(comparisons=comparisons,rtol=1e-5,atol=1e-6,rows=rows)
(root/'latency-summary.json').write_text(json.dumps(record,indent=2)+'\n')
for program in ('neg','chain','trig','mixed','views'):
    r=[r for r in rows if r['program']==program]
    print(program,'before_us',round(statistics.median(x['before_us'] for x in r),3),'after_us',round(statistics.median(x['after_us'] for x in r),3),'median cell change %',round(statistics.median(x['change_percent'] for x in r),2))
print('checked cells:',comparisons,'including full first/fresh arrays and exact metadata; cells slower:',[(r['program'],r['shape'],round(r['change_percent'],2)) for r in rows if r['change_percent']>0])
