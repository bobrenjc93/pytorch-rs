#!/usr/bin/env bash
set -euo pipefail
task_root=/data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/probe-compiled-cuda-module-t
cd "$task_root"
test "$#" -eq 1
[[ "$1" =~ ^[0-9a-f]{40}$ ]]
test "$(git rev-parse HEAD)" = "$1"
test "$(git rev-parse main)" = "$1"
test -z "$(git status --porcelain)"
jq -e --arg task_head "$1" '.verified == true and .prNumber == 1984 and .main == $task_head and .allTenBaselinesPromoted == true' /tmp/pytorch-rs-compiler-recovery.3UB6mU/merge-1984-verified.json
test ! -e .venv
test -f target/probe-compiled-cuda-module-t.py
test "$(sha256sum target/probe-compiled-cuda-module-t.py | cut -d ' ' -f 1)" = fecd393d78b70d7cba9dbfe7993fb94d7bf0c51057fd9a53018770291c79fc24
test -f target/root-preflight.py
test "$(sha256sum target/root-preflight.py | cut -d ' ' -f 1)" = 8a5e24fc2c80a21f8ea26044c74a4fb5f3d7ea4b28bd0a37e9ddb5c471838b21
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1
export CARGO_HOME="$task_root/target/local-cargo"
export CARGO_TARGET_DIR="$task_root/target/release-build"
export UV_CACHE_DIR="$task_root/target/uv-cache"
export UV_PYTHON_INSTALL_DIR="$task_root/target/uv-python"
export UV_PYTHON_BIN_DIR="$task_root/target/python-bin"
export UV_PROJECT_ENVIRONMENT="$task_root/.venv"
export TMPDIR="$task_root/target/tmp"
export XDG_CACHE_HOME="$task_root/target/xdg-cache"
export CUDA_CACHE_PATH="$task_root/target/cuda-cache"
export TORCHINDUCTOR_CACHE_DIR="$task_root/target/inductor-cache"
export TRITON_CACHE_DIR="$task_root/target/triton-cache"
export PYTHONPYCACHEPREFIX="$task_root/target/pycache"
export VIRTUAL_ENV="$task_root/.venv"
export PYO3_PYTHON="$task_root/.venv/bin/python"
export CUDA_VISIBLE_DEVICES=0
export TORCH_RS_CUDART="$task_root/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
mkdir -p target/local-cargo target/uv-cache target/tmp target/xdg-cache target/cuda-cache target/inductor-cache target/triton-cache target/pycache
test -x "$task_root/target/uv-python/cpython-3.12.14-linux-x86_64-gnu/bin/python3.12"
test "$(sha256sum "$task_root/target/uv-python/cpython-3.12.14-linux-x86_64-gnu/bin/python3.12" | cut -d ' ' -f 1)" = f7c6210eb40fadcd3c2889dddd24a15fc2c9f926aec5a03bf9da66e12d581526
uv sync --locked --no-install-project --group dev --group reference --managed-python --python 3.12.14
cargo fetch --locked
.venv/bin/python scripts/capture_depth_concat_build.py --output target/release
TORCH_RS_VERIFY_VIRTUALENV="$task_root/.venv" .venv/bin/python .github/scripts/verify_native_extension.py
.venv/bin/python target/root-preflight.py target/release/build-record.json
.venv/bin/python target/probe-compiled-cuda-module-t.py "$1"
git status --short
