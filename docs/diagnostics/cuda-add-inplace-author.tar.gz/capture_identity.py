import ctypes
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import sysconfig
from datetime import datetime, timezone
import zipfile

root = Path.cwd().resolve()
out = Path(os.environ['BURNER_EVALUATION_ARTIFACT_DIR']).resolve()
assert out.is_relative_to(root)
expected = root / 'target/author-add/venv'
assert Path(sys.prefix).resolve() == expected

def command(*args):
    return subprocess.check_output(args, text=True).strip()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

changed = command('git', 'diff', '--name-only', 'HEAD').splitlines()
new = command('git', 'ls-files', '--others', '--exclude-standard').splitlines()
source_files = [p for p in changed + new if p.startswith(('src/', 'python/', 'tests/'))]
frozen = ['.burner/evaluations.json', 'scripts/run_with_unix_lock.py',
          '.github/scripts/verify_native_extension.py', 'scripts/evaluate_torch_compile_default.sh',
          'scripts/evaluate_torch_compile_default.py', 'scripts/torch_compile_default_corpus.py',
          'Cargo.lock', 'uv.lock', 'docs/burner-evaluation-history.json',
          'docs/burner-evaluation-progress.svg', 'README.md']
frozen_result = {}
for p in frozen:
    historical = subprocess.check_output(['git', 'show', f'HEAD:{p}'])
    current = (root / p).read_bytes()
    assert current == historical, p
    frozen_result[p] = hashlib.sha256(current).hexdigest()

package = importlib.import_module('torch_rs')
native = importlib.import_module('torch_rs.torch_rs')
import torch
import numpy
for module in (package, native, torch, numpy):
    assert Path(module.__file__).resolve().is_relative_to(expected), module.__file__
wheel = root / 'target/author-add/final-wheels/torch_rs-0.1.0-cp310-abi3-manylinux_2_34_x86_64.whl'
with zipfile.ZipFile(wheel) as archive:
    extension = next(n for n in archive.namelist() if n.endswith('.so'))
    assert hashlib.sha256(archive.read(extension)).hexdigest() == digest(native.__file__)
    python_files = {}
    for p in (root / 'python/torch_rs').rglob('*.py'):
        name = str(p.relative_to(root / 'python'))
        assert archive.read(name) == p.read_bytes(), name
        python_files[name] = digest(p)
lib = ctypes.CDLL(os.environ['TORCH_RS_CUDART'])
versions = {}
for func in ('cudaRuntimeGetVersion', 'cudaDriverGetVersion', 'cudaGetDevice'):
    value = ctypes.c_int()
    code = getattr(lib, func)(ctypes.byref(value))
    assert code == 0, (func, code)
    versions[func] = value.value
assert torch.cuda.is_available() and torch.cuda.device_count() == 1
assert os.environ['CUDA_VISIBLE_DEVICES'] == '0'
result = {
    'phase': 'author-only dirty source verification; not clean-commit or scoring evidence',
    'captured_utc': datetime.now(timezone.utc).isoformat(),
    'source_parent': command('git', 'rev-parse', 'HEAD'),
    'pinned_base': '60202557b4f110d07777f585e804ab5f55e1ff7b',
    'worktree': str(root), 'git_status': command('git', 'status', '--short'),
    'source_hashes': {p: digest(root / p) for p in source_files},
    'frozen_unchanged_hashes': frozen_result,
    'python': {'version': sys.version, 'executable': sys.executable,
               'resolved_executable': str(Path(sys.executable).resolve()),
               'prefix': sys.prefix, 'base_prefix_read_only': sys.base_prefix,
               'install_paths': {k: sysconfig.get_path(k) for k in ('purelib', 'platlib', 'scripts', 'data')}},
    'imports': {m.__name__: {'path': m.__file__, 'sha256': digest(m.__file__)} for m in (package, native, torch, numpy)},
    'versions': {n: importlib.metadata.version(n) for n in ('torch-rs', 'torch', 'numpy', 'maturin', 'pip')},
    'wheel': {'path': str(wheel), 'sha256': digest(wheel), 'installed_extension_matches_wheel': True,
              'packaged_python_matches_worktree': python_files},
    'cuda': {'visible_devices': os.environ['CUDA_VISIBLE_DEVICES'], 'runtime_path': os.environ['TORCH_RS_CUDART'],
             'runtime_sha256': digest(os.environ['TORCH_RS_CUDART']), 'runtime_results': versions,
             'torch_version': torch.__version__, 'torch_cuda': torch.version.cuda, 'device': torch.cuda.get_device_name(0),
             'capability': torch.cuda.get_device_capability(0),
             'inventory': command('nvidia-smi', '-i', '0', '--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used', '--format=csv'),
             'primitive_compiler': 'embedded PTX loaded by CUDA driver JIT; nvcc is not used to compile add_',
             'installed_nvcc': command('nvcc', '--version')},
    'rustc': command('rustc', '-Vv'), 'cargo': command('cargo', '-V'),
    'platform': platform.platform(),
    'environment': {k: v for k, v in os.environ.items() if k in (
        'VIRTUAL_ENV', 'UV_PROJECT_ENVIRONMENT', 'PYO3_PYTHON', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE',
        'PIP_CONFIG_FILE', 'CUDA_VISIBLE_DEVICES', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'UV_CACHE_DIR',
        'UV_PYTHON_INSTALL_DIR', 'XDG_CACHE_HOME', 'CUDA_CACHE_PATH', 'TORCHINDUCTOR_CACHE_DIR',
        'TRITON_CACHE_DIR', 'TMPDIR', 'BURNER_EVALUATION_ARTIFACT_DIR', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
        'CARGO_BUILD_JOBS', 'TORCH_RS_CUDART')},
}
(out / 'identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('captured_utc', 'source_parent', 'wheel', 'cuda')}, indent=2))
