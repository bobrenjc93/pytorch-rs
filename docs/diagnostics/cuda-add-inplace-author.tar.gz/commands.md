# Author-only receipts

Parent: 41499a26015380a5d6c09dae80e0a0b9f7354dbf.
Pinned base: 60202557b4f110d07777f585e804ab5f55e1ff7b.
All commands used non-login bash from the current worktree. `env.sh` records
explicit task-local interpreter, installation and cache selection after clearing
CONDA_*/_CONDA_*, VIRTUAL_ENV, UV_PROJECT_ENVIRONMENT, PYTHONHOME and PYTHONPATH.
GPU0 and the existing gpu/cpu-heavy lease were used; no other GPU was used.
These are uncommitted author checks, not clean-commit captures or scored evidence.
`identity.json` was generated from the actual source/import/build paths; source
hashes identify the final author implementation. Original failed logs are retained.

## Environment and installation

A fresh venv at `target/author-add/venv` was created with the read-only base
`/home/bobren/.local/share/uv/python/cpython-3.12.12-linux-x86_64-gnu/bin/python3.12`.
Standard venv executable symlinks point to that base; its prefix, packages and
all effective install destinations are worktree-local. No shared Python install
was modified or repaired.

Locked dependency export and isolated installation:

```
source target/author-add/env.sh
uv --no-config export --locked --no-emit-project --group dev --group reference --format requirements-txt > target/author-add/requirements.txt
"$VIRTUAL_ENV/bin/python" -I -m pip --isolated install --require-hashes -r target/author-add/requirements.txt
```

`dependencies.log` preserves installation output; `pip-config.log` records the
isolated configuration. `install-destination*.log` records explicit sys.prefix
and purelib/platlib/scripts/data assertions before wheel installs. No prefix,
target or user install option was used. The final exact assertion is in the
installation command below. `TORCH_RS_CUDART` was added to env.sh after the first
Python test run and before native tests, pinning the worktree-local CUDA 13 runtime.
Earlier unpinned runs are development diagnostics, not final-runtime evidence.

Build (initial `wheels`, then final `final-wheels`, both retained locally):

```
"$VIRTUAL_ENV/bin/maturin" build --release --locked --interpreter "$PYO3_PYTHON" --out target/author-add/wheels
"$VIRTUAL_ENV/bin/maturin" build --release --locked --interpreter "$PYO3_PYTHON" --out target/author-add/final-wheels
```

`build.log` and `build-final.log`: success. Build does not use `maturin develop`.
Final install, after prefix/destination assertions:

```
"$PYO3_PYTHON" -B -I - <<'PY'
from pathlib import Path
import sys, sysconfig
expected = Path.cwd().resolve() / 'target/author-add/venv'
assert Path(sys.prefix).resolve() == expected
for key in ('purelib', 'platlib', 'scripts', 'data'):
    assert Path(sysconfig.get_path(key)).resolve().is_relative_to(expected)
PY
"$PYO3_PYTHON" -B -I -m pip --isolated install --no-deps --force-reinstall target/author-add/final-wheels/torch_rs-0.1.0-cp310-abi3-manylinux_2_34_x86_64.whl
TORCH_RS_VERIFY_VIRTUALENV="$VIRTUAL_ENV" "$PYO3_PYTHON" -B .github/scripts/verify_native_extension.py
```

Initial install/verifier used the same wheel filename under `wheels`. All installs
and verifier calls succeeded. The final wheel extension hash is verified against
the imported extension; packaged Python sources are compared with the worktree.
The initial and final native binaries differ; final-wheel tests are separately
retained and do not rely on substituting an earlier build identity.

## Checks and first failures

Every command below sourced env.sh. Combined stdout/stderr was retained with
`set -o pipefail` and `tee "$BURNER_EVALUATION_ARTIFACT_DIR/<log>"`.

```
cargo clippy --locked --all-targets --features python-bindings -- -D warnings
cargo fmt --check
cargo test --locked --features python-bindings --lib scalar_add_inplace_ -- --test-threads=1
cargo test --locked --features python-bindings --lib cuda_graph::tests -- --test-threads=1
"$PYO3_PYTHON" -B -m unittest tests.test_cuda_add_inplace
"$PYO3_PYTHON" -B -m unittest -v tests.test_cuda_add_inplace
"$PYO3_PYTHON" -B -m unittest tests.test_tensor_add tests.test_tensor_add_reference tests.test_tensor_sub tests.test_tensor_sub_reference tests.test_cuda_add tests.test_cuda_add_trailing_vector tests.test_cuda_mul_scalar tests.test_compile_pointwise_input_transpose
CUDA_VISIBLE_DEVICES='' "$PYO3_PYTHON" -B -m unittest tests.test_cuda_add_inplace tests.test_tensor_add tests.test_tensor_sub
```

- `clippy-first.log`: failed, nine scoped unsafe-code/test-lint errors. Direct
  refcount FFI was moved to an audited test helper; pointer, unit-pattern, cast
  and semicolon lints were fixed. `clippy-final.log` and final-source
  `clippy-final-source.log`: pass. No broad warning suppression.
- `fmt-final.log`: pass, no output.
- `native-inplace-first.log`: five passed, one fixture failure: a view's effective
  gradient flag was not set by changing the leaf flag. The fixture now asserts
  effective requires_grad before rejection. `native-inplace-final.log`: six pass.
- `native-graph.log`: 17 pass, including partial wrapping/refcount rollback.
- `add-inplace-first.log`: 15 run, two fixture errors (meta exception type and
  unsupported CUDA factory spelling). After fixture correction,
  `add-inplace-final.log`: 15 pass. After final build and explicit GPU0 device
  assertions for rejection/empties, `add-inplace-final-wheel.log`: 15 pass.
- `regression.log`: 78 run, 72 pass, six expected skips. Final wheel repeat uses
  `regression-final-wheel.log`: 72 pass, six expected skips; the rebuilt native
  identity justifies that repeat.
- `portable-final.log`: 27 run, 17 pass, ten explicit GPU skips.

Reference default compilation emitted the existing PyTorch script_method
deprecation warning. It did not fail the run. Linux Clippy success is not a
macOS CI rerun; the supplied macOS CI failure remains historical input.

## Provenance and scope

```
"$PYO3_PYTHON" -B target/author-add/capture_identity.py
nvidia-smi -i 0 --query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used --format=csv
sha256sum /tmp/burner-approved-default-compile.UA2M6I/compile-cuda-inplace-add-proposal.md /tmp/burner-approved-default-compile.UA2M6I/compile-cuda-inplace-add-independent-design.md
git diff --check
```

`capture_identity.py` is retained here; `identity.json` includes the actual UTC
capture time, parent, dirty status, source/frozen-file hashes, Python prefix and
imports, final wheel/extension hashes, Rust and CUDA identities. The installed
nvcc version is inventory, not the compiler for add_: its embedded PTX is loaded
by the existing CUDA driver JIT. The two approved design hashes were verified as
7c72f1340d66ab193322223b9b74298b1d2378243cd86152c709962ec86a5f8a and
455b9a6a58109f9a64614fec8227d2223e0269a2092ab749260802be044ce379.

The focused GPU suite tests untouched-default torch_rs.compile and torch.compile
for returned-view mutation/reuse, without timing. No canonical evaluator or
private performance measurement was run. No dependency locks, evaluation
inputs, managed progress files, other PRs, historical reports or Burner state
were changed. No commit, branch, push or publication was performed. Existing
current-candidate performance evidence predates this author revision; a later
refresh is pending explicit operator admission, not waived or relabeled.
