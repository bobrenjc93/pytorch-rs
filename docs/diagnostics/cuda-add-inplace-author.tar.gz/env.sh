for task_conda_name in ${!CONDA_@} ${!_CONDA_@}; do unset "$task_conda_name"; done
unset VIRTUAL_ENV UV_PROJECT_ENVIRONMENT PYTHONHOME PYTHONPATH
export VIRTUAL_ENV="$PWD/target/author-add/venv"
export UV_PROJECT_ENVIRONMENT="$VIRTUAL_ENV"
export PYO3_PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export PIP_CONFIG_FILE=/dev/null
export CUDA_VISIBLE_DEVICES=0
export CARGO_HOME="$PWD/target/author-add/cargo-home"
export CARGO_TARGET_DIR="$PWD/target/author-add/cargo-target"
export UV_CACHE_DIR="$PWD/target/author-add/cache/uv"
export UV_PYTHON_INSTALL_DIR="$PWD/target/author-add/python"
export XDG_CACHE_HOME="$PWD/target/author-add/cache"
export CUDA_CACHE_PATH="$PWD/target/author-add/cache/cuda"
export TORCHINDUCTOR_CACHE_DIR="$PWD/target/author-add/cache/inductor"
export TRITON_CACHE_DIR="$PWD/target/author-add/cache/triton"
export TMPDIR="$PWD/target/author-add/tmp"
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/author-add/evidence"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CARGO_BUILD_JOBS=8
export TORCH_RS_CUDART="$VIRTUAL_ENV/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
