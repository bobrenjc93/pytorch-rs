// torch_rs typed pointwise scalar program v3; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n, const unsigned int* plan, unsigned long long instruction_count, float* scratch, unsigned long long scratch_stride, float s0) {
const unsigned long long worker = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
float* registers = scratch + worker;
#define R(index) registers[(unsigned long long)(index) * scratch_stride]
for (unsigned long long i = worker; i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
for (unsigned long long pc = 0; pc < instruction_count; ++pc) {
const unsigned int* instruction = plan + pc * 6;
const unsigned int opcode = instruction[0], d = instruction[1], a = instruction[2], b = instruction[3], c = instruction[4], flags = instruction[5];
switch (opcode) {
case 0: switch (a) {
case 0: R(d) = x0[i]; break;
default: return; } break;
case 1: { float value; switch (a) {
case 0: value = s0; break;
default: return; } R(d) = flags ? __uint_as_float(__float_as_uint(value) ^ 0x80000000u) : value; break; }
case 2: R(d) = __uint_as_float(a); break;
case 3: R(d) = R(a); break;
case 4: R(d) = __fadd_rn(R(a), R(b)); break;
case 5: R(d) = __fsub_rn(R(a), R(b)); break;
case 6: R(d) = __fmul_rn(R(a), R(b)); break;
case 7: R(d) = __fsub_rn(0.0f, R(a)); break;
case 8: R(d) = __uint_as_float(__float_as_uint(R(a)) ^ 0x80000000u); break;
case 9: R(d) = (R(a) < 0.0f ? 0.0f : R(a)); break;
case 10: R(d) = sinf((__float_as_uint(R(a)) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(R(a)) & 0x80000000u) : R(a)); break;
case 11: R(d) = cosf(R(a)); break;
case 16: R(d) = erff((__float_as_uint(R(a)) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(R(a)) & 0x80000000u) : R(a)); break;
case 12: R(d) = (float)sin((double)R(a)); break;
case 13: R(d) = (float)cos((double)R(a)); break;
case 14: {
float left = R(a), addend = (flags & 4u) ? 0.0f : R(c);
if (flags & 1u) left = __uint_as_float(__float_as_uint(left) ^ 0x80000000u);
if (flags & 2u) addend = __uint_as_float(__float_as_uint(addend) ^ 0x80000000u);
R(d) = fmaf(left, R(b), addend); break; }
case 15: switch (d) {
case 0: out0[i] = R(a); break;
case 1: out1[i] = R(a); break;
case 2: out2[i] = R(a); break;
default: return; } break;
default: return;
}
}
}
#undef R
}
