
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_gelu_mul_sin_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 6}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_gelu_mul_sin_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl_math.sin(tmp0)
    tmp2 = tl_math.sin(tmp1)
    tmp3 = tl_math.sin(tmp2)
    tmp4 = tl_math.sin(tmp3)
    tmp5 = tl_math.sin(tmp4)
    tmp6 = tl_math.sin(tmp5)
    tmp7 = tl_math.sin(tmp6)
    tmp8 = tl_math.sin(tmp7)
    tmp9 = tl_math.sin(tmp8)
    tmp10 = tl_math.sin(tmp9)
    tmp11 = tl_math.sin(tmp10)
    tmp12 = tl_math.sin(tmp11)
    tmp13 = tl_math.sin(tmp12)
    tmp14 = tl_math.sin(tmp13)
    tmp15 = tl_math.sin(tmp14)
    tmp16 = tl_math.sin(tmp15)
    tmp17 = tl_math.sin(tmp16)
    tmp18 = tl_math.sin(tmp17)
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl_math.sin(tmp19)
    tmp21 = tl_math.sin(tmp20)
    tmp22 = tl_math.sin(tmp21)
    tmp23 = tl_math.sin(tmp22)
    tmp24 = tl_math.sin(tmp23)
    tmp25 = tl_math.sin(tmp24)
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl_math.sin(tmp26)
    tmp28 = tl_math.sin(tmp27)
    tmp29 = tl.full([1], 0.5, tl.float32)
    tmp30 = tmp28 * tmp29
    tmp31 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp32 = tmp28 * tmp31
    tmp33 = libdevice.erf(tmp32)
    tmp34 = tl.full([1], 1.0, tl.float32)
    tmp35 = tmp33 + tmp34
    tmp36 = tmp30 * tmp35
    tmp37 = tmp28 * tmp28
    tmp38 = tmp36 + tmp37
    tl.store(out_ptr0 + (x0), tmp38, xmask)
