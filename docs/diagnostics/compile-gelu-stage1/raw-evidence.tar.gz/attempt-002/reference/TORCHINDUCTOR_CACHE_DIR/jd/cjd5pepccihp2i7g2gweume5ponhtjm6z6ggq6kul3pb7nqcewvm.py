# AOT ID: ['70_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_6ada2b33/docs/diagnostics/compile-gelu-stage1/attempt-002/reference/TORCHINDUCTOR_CACHE_DIR/zw/czwjj5t2bmlt4cbrtoth5ym3jvi5lxvnnw2ydiak4yrlsmuigtq5.py
# Topologically Sorted Source Nodes: [mul, z, e, sub, mul_1, g, sub_1, mul_2], Original ATen: [aten.mul, aten.add, aten.erf, aten.sub, aten.gelu]
# Source node to ATen node mapping:
#   e => erf
#   g => add_1, erf_1, mul_1, mul_2, mul_3
#   mul => mul
#   mul_1 => mul_4
#   mul_2 => mul_5
#   sub => sub
#   sub_1 => sub_1
#   z => add
# Graph fragment:
#   %arg0_1 : Tensor "f32[148][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %erf : Tensor "f32[148][1]cuda:0" = PlaceHolder[target=erf]
#   %mul_3 : Tensor "f32[148][1]cuda:0" = PlaceHolder[target=mul_3]
#   %mul : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg0_1, 0.0), kwargs = {})
#   %add : Tensor "f32[148][1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul, -1.401298464324817e-45), kwargs = {})
#   %erf : Tensor "f32[148][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.erf.default](args = (%add,), kwargs = {})
#   %sub : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%erf, 0.5), kwargs = {})
#   %mul_4 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub, 1048576.0), kwargs = {})
#   %mul_1 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add, 0.5), kwargs = {})
#   %mul_2 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add, 0.7071067811865476), kwargs = {})
#   %erf_1 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.erf.default](args = (%mul_2,), kwargs = {})
#   %add_1 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%erf_1, 1), kwargs = {})
#   %mul_3 : Tensor "f32[148][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %add_1), kwargs = {})
#   %sub_1 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_3, 0.58), kwargs = {})
#   %mul_5 : Tensor "f32[148][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sub_1, 1048576.0), kwargs = {})
#   return %erf,%mul_4,%mul_3,%mul_5
triton_poi_fused_add_erf_gelu_mul_sub_0 = async_compile.triton('triton_poi_fused_add_erf_gelu_mul_sub_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_erf_gelu_mul_sub_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 4, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 5328}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_erf_gelu_mul_sub_0(in_ptr0, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, XBLOCK : tl.constexpr):
    xnumel = 148
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl.full([1], 0.0, tl.float32)
    tmp2 = tmp0 * tmp1
    tmp3 = tl.full([1], -1.401298464324817e-45, tl.float32)
    tmp4 = tmp2 + tmp3
    tmp5 = libdevice.erf(tmp4)
    tmp6 = tl.full([1], 0.5, tl.float32)
    tmp7 = tmp5 - tmp6
    tmp8 = tl.full([1], 1048576.0, tl.float32)
    tmp9 = tmp7 * tmp8
    tmp10 = tmp4 * tmp6
    tmp11 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp12 = tmp4 * tmp11
    tmp13 = libdevice.erf(tmp12)
    tmp14 = tl.full([1], 1.0, tl.float32)
    tmp15 = tmp13 + tmp14
    tmp16 = tmp10 * tmp15
    tmp17 = tl.full([1], 0.58, tl.float32)
    tmp18 = tmp16 - tmp17
    tmp19 = tmp18 * tmp8
    tl.store(out_ptr0 + (x0), tmp5, xmask)
    tl.store(out_ptr1 + (x0), tmp9, xmask)
    tl.store(out_ptr2 + (x0), tmp16, xmask)
    tl.store(out_ptr3 + (x0), tmp19, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, = args
        args.clear()
        assert_size_stride(arg0_1, (148, ), (1, ), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf0 = empty_strided_cuda((148, ), (1, ), torch.float32)
            buf1 = empty_strided_cuda((148, ), (1, ), torch.float32)
            buf2 = empty_strided_cuda((148, ), (1, ), torch.float32)
            buf3 = empty_strided_cuda((148, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [mul, z, e, sub, mul_1, g, sub_1, mul_2], Original ATen: [aten.mul, aten.add, aten.erf, aten.sub, aten.gelu]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_add_erf_gelu_mul_sub_0.run(arg0_1, buf0, buf1, buf2, buf3, 148, stream=raw_stream0)
            del arg0_1
        return (buf0, buf2, buf1, buf3, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((148, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
