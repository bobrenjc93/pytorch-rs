
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_erf_gelu_mul_sin_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 260}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_erf_gelu_mul_sin_0(in_ptr0, out_ptr1, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 13
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl_math.sin(tmp0)
    tmp2 = tl_math.sin(tmp1)
    tmp3 = tl_math.sin(tmp2)
    tmp4 = tl_math.sin(tmp3)
    tmp5 = tl_math.sin(tmp4)
    tmp6 = tl_math.sin(tmp5)
    tmp7 = tl_math.sin(tmp6)
    tmp8 = tl_math.sin(tmp7)
    tmp9 = tl_math.sin(tmp8)
    tmp10 = tl_math.sin(tmp9)
    tmp11 = tl_math.sin(tmp10)
    tmp12 = tl_math.sin(tmp11)
    tmp13 = tl_math.sin(tmp12)
    tmp14 = tl_math.sin(tmp13)
    tmp15 = tl_math.sin(tmp14)
    tmp16 = tl_math.sin(tmp15)
    tmp17 = tl_math.sin(tmp16)
    tmp18 = tl_math.sin(tmp17)
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl_math.sin(tmp19)
    tmp21 = tl_math.sin(tmp20)
    tmp22 = tl_math.sin(tmp21)
    tmp23 = tl_math.sin(tmp22)
    tmp24 = tl_math.sin(tmp23)
    tmp25 = tl_math.sin(tmp24)
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl_math.sin(tmp26)
    tmp28 = tl_math.sin(tmp27)
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl_math.sin(tmp29)
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl_math.sin(tmp31)
    tmp33 = tl_math.sin(tmp32)
    tmp34 = tl_math.sin(tmp33)
    tmp35 = tl_math.sin(tmp34)
    tmp36 = tl_math.sin(tmp35)
    tmp37 = tl_math.sin(tmp36)
    tmp38 = tl_math.sin(tmp37)
    tmp39 = tl_math.sin(tmp38)
    tmp40 = tl_math.sin(tmp39)
    tmp41 = tl_math.sin(tmp40)
    tmp42 = tl_math.sin(tmp41)
    tmp43 = tl_math.sin(tmp42)
    tmp44 = tl_math.sin(tmp43)
    tmp45 = tl_math.sin(tmp44)
    tmp46 = tl_math.sin(tmp45)
    tmp47 = tl_math.sin(tmp46)
    tmp48 = tl_math.sin(tmp47)
    tmp49 = tl_math.sin(tmp48)
    tmp50 = tl_math.sin(tmp49)
    tmp51 = tl_math.sin(tmp50)
    tmp52 = tl_math.sin(tmp51)
    tmp53 = tl_math.sin(tmp52)
    tmp54 = tl_math.sin(tmp53)
    tmp55 = tl_math.sin(tmp54)
    tmp56 = tl_math.sin(tmp55)
    tmp57 = tl_math.sin(tmp56)
    tmp58 = tl_math.sin(tmp57)
    tmp59 = tl_math.sin(tmp58)
    tmp60 = tl_math.sin(tmp59)
    tmp61 = tl_math.sin(tmp60)
    tmp62 = tl_math.sin(tmp61)
    tmp63 = tl_math.sin(tmp62)
    tmp64 = tl_math.sin(tmp63)
    tmp65 = tl_math.sin(tmp64)
    tmp66 = tl_math.sin(tmp65)
    tmp67 = tl_math.sin(tmp66)
    tmp68 = tl_math.sin(tmp67)
    tmp69 = tl_math.sin(tmp68)
    tmp70 = tl_math.sin(tmp69)
    tmp71 = tl_math.sin(tmp70)
    tmp72 = tl_math.sin(tmp71)
    tmp73 = tl_math.sin(tmp72)
    tmp74 = tl_math.sin(tmp73)
    tmp75 = tl_math.sin(tmp74)
    tmp76 = tl_math.sin(tmp75)
    tmp77 = tl_math.sin(tmp76)
    tmp78 = tl_math.sin(tmp77)
    tmp79 = tl_math.sin(tmp78)
    tmp80 = tl_math.sin(tmp79)
    tmp81 = tl_math.sin(tmp80)
    tmp82 = tl_math.sin(tmp81)
    tmp83 = tl_math.sin(tmp82)
    tmp84 = tl_math.sin(tmp83)
    tmp85 = tl_math.sin(tmp84)
    tmp86 = tl_math.sin(tmp85)
    tmp87 = tl_math.sin(tmp86)
    tmp88 = tl_math.sin(tmp87)
    tmp89 = tl_math.sin(tmp88)
    tmp90 = tl_math.sin(tmp89)
    tmp91 = tl_math.sin(tmp90)
    tmp92 = tl_math.sin(tmp91)
    tmp93 = tl_math.sin(tmp92)
    tmp94 = tl_math.sin(tmp93)
    tmp95 = tl_math.sin(tmp94)
    tmp96 = tl_math.sin(tmp95)
    tmp97 = tl_math.sin(tmp96)
    tmp98 = tl_math.sin(tmp97)
    tmp99 = libdevice.erf(tmp98)
    tmp100 = tl.full([1], 0.5, tl.float32)
    tmp101 = tmp98 * tmp100
    tmp102 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp103 = tmp98 * tmp102
    tmp104 = libdevice.erf(tmp103)
    tmp105 = tl.full([1], 1.0, tl.float32)
    tmp106 = tmp104 + tmp105
    tmp107 = tmp101 * tmp106
    tmp108 = tmp98 * tmp98
    tmp109 = tmp107 + tmp108
    tl.store(out_ptr1 + (x0), tmp99, xmask)
    tl.store(out_ptr2 + (x0), tmp109, xmask)
