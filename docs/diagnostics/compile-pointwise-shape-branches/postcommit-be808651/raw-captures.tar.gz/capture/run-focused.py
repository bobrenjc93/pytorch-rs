"""Evidence orchestration only: execute the committed unittest cases unchanged."""
from datetime import datetime, timezone
import ctypes, hashlib, importlib.util, json, os, pathlib, subprocess, sys, time, unittest, zipfile
root = pathlib.Path.cwd()
out = pathlib.Path(__file__).resolve().parent
label = sys.argv[1]
mode = sys.argv[2]
def command(*args): return subprocess.check_output(args, text=True).strip()
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
assert command('git','rev-parse','HEAD') == 'be808651fa90415c951e46180d3417e7939d61e8'
assert not command('git','status','--porcelain=v1','--untracked-files=all')
# Import test modules from this committed checkout, never the package source tree.
sys.path.insert(0,str(root))
sys.path.insert(0,str(root/'tests'))
import torch_rs as native
from torch_rs import _compile_pointwise as frontend
wheel = next((out/'wheels').glob('*.whl'))
assert pathlib.Path(native.__file__).resolve().is_relative_to(pathlib.Path(sys.prefix).resolve())
with zipfile.ZipFile(wheel) as archive:
    for module in (native, native.torch_rs, frontend):
        path=pathlib.Path(module.__file__).resolve()
        member='torch_rs/'+path.name
        assert path.read_bytes()==archive.read(member), member
report={'label':label,'mode':mode,'startedUTC':stamp(),'commit':command('git','rev-parse','HEAD'),
        'root':str(root),'statusBefore':command('git','status','--porcelain=v1','--untracked-files=all'),
        'python':sys.version,'executable':sys.executable,'resolvedExecutable':str(pathlib.Path(sys.executable).resolve()),
        'prefix':sys.prefix,'wheel':str(wheel),'wheelSHA256':sha(wheel),
        'nativeImport':native.__file__,'extensionImport':native.torch_rs.__file__,
        'extensionSHA256':sha(native.torch_rs.__file__),'frontendImport':frontend.__file__,
        'frontendSHA256':sha(frontend.__file__),'testSHA256':sha(root/'tests/test_compile_pointwise_shape_branches.py'),
        'command':[sys.executable,str(pathlib.Path(__file__).resolve()),*sys.argv[1:]],
        'environment':{k:os.environ.get(k) for k in ('CUDA_VISIBLE_DEVICES','TORCH_RS_NVRTC','TORCH_RS_CUDART','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','TMPDIR','PYTHONPATH','PYTHONHOME')},
        'tests':[]}
if mode=='gpu':
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='0'
    report['gpuBefore']=command('nvidia-smi','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used','--format=csv')
    import torch
    assert torch.cuda.is_available() and native.cuda.is_available() and torch.cuda.device_count()==1
    report.update(torchVersion=torch.__version__,torchCUDA=torch.version.cuda,torchImport=torch.__file__,device=torch.cuda.get_device_name(0))
    assert torch.__version__=='2.13.0+cu130'
    report['nvcc']=command('nvcc','--version')
class Result(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test)
        self.start=time.perf_counter()
        self.row={'id':test.id(),'startedUTC':stamp()}
        report['tests'].append(self.row)
    def addSuccess(self,test): self.row['outcome']='passed';super().addSuccess(test)
    def addSkip(self,test,reason): self.row.update(outcome='skipped',reason=reason);super().addSkip(test,reason)
    def addFailure(self,test,error): self.row['outcome']='failed';super().addFailure(test,error)
    def addError(self,test,error): self.row['outcome']='error';super().addError(test,error)
    def stopTest(self,test):
        self.row['elapsedSeconds']=time.perf_counter()-self.start
        if mode=='gpu' and 'ShapeBranchHardware.test_persistent_' in test.id():
            from torch._dynamo.utils import counters
            from torch._inductor import metrics
            self.row['referenceInstrumentation']={'uniqueGraphs':counters['stats']['unique_graphs'],'graphBreaks':dict(counters['graph_break']),'generatedKernels':metrics.generated_kernel_count}
        super().stopTest(test)
try:
    suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_compile_pointwise_shape_branches')
    result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
    report.update(testsRun=result.testsRun,skipped=len(result.skipped),passed=result.wasSuccessful())
    if mode=='gpu':
        assert not result.skipped, 'GPU validation must not silently skip'
        # Use the committed diagnostic's runtime accessor, without running its workload.
        path=root/'docs/diagnostics/compile-pointwise-positional/warm-dispatch/gpu-dispatch.py'
        spec=importlib.util.spec_from_file_location('runtime_provenance',path)
        diag=importlib.util.module_from_spec(spec);spec.loader.exec_module(diag)
        report['runtimeAccessorSHA256']=sha(path)
        report['loadedCUDALibraries']=diag.runtime_identity()
        report['gpuAfter']=command('nvidia-smi','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used','--format=csv')
    report['statusAfter']=command('git','status','--porcelain=v1','--untracked-files=all')
    assert not report['statusAfter']
finally:
    report['finishedUTC']=stamp()
    (out/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
