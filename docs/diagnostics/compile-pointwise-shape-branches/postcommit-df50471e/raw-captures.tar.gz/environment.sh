# Source from repository root before build/test commands.
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 UV_SYSTEM_CERTS=true
unset PYTHONPATH PYTHONHOME CONDA_PREFIX
export CARGO_HOME="$PWD/target/cargo-home" CARGO_TARGET_DIR="$PWD/target"
export RUSTC=/home/bobren/.rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc
export CARGO=/home/bobren/.rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/cargo
export PATH="/home/bobren/.rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:$PATH"
export UV_CACHE_DIR="$PWD/target/uv-cache" UV_PYTHON_INSTALL_DIR="$PWD/target/uv-python"
export UV_PYTHON_BIN_DIR="$PWD/target/uv-bin" UV_TOOL_DIR="$PWD/target/uv-tools"
export UV_PROJECT_ENVIRONMENT="$PWD/.venv" VIRTUAL_ENV="$PWD/.venv" PYO3_PYTHON="$PWD/.venv/bin/python"
export TMPDIR="$PWD/target/tmp" TEMP="$PWD/target/tmp" TMP="$PWD/target/tmp"
export CUDA_CACHE_PATH="$PWD/target/cuda-cache" XDG_CACHE_HOME="$PWD/target/xdg-cache"
export TORCHINDUCTOR_CACHE_DIR="$PWD/target/torchinductor-cache" TRITON_CACHE_DIR="$PWD/target/triton-cache"
export CUDA_VISIBLE_DEVICES=0
