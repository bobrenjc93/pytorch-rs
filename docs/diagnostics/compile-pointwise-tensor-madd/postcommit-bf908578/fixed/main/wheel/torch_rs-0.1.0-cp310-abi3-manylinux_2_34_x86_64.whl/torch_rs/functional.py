"""Functional interface."""

from collections.abc import Sequence

from .overrides import (
    _dispatch_exact_native_variadic_torch_function,
    _dispatch_unary_torch_function,
    _get_current_function_mode,
)
from .torch_rs import (
    Size,
    Tensor,
    atleast_1d as _VF_atleast_1d,
    atleast_2d as _VF_atleast_2d,
    atleast_3d as _VF_atleast_3d,
    broadcast_tensors as _VF_broadcast_tensors,
)


__all__ = [
    "atleast_1d",
    "atleast_2d",
    "atleast_3d",
    "broadcast_shapes",
    "broadcast_tensors",
    "split",
]


def _split_impl(tensor, split_size_or_sections, dim):
    if type(tensor) is not Tensor:
        raise NotImplementedError(
            "split(): only exact native CPU float32 Tensor inputs are supported"
        )
    return tensor.split(split_size_or_sections, dim)


def split(
    tensor: Tensor,
    split_size_or_sections: int | list[int],
    dim: int = 0,
) -> tuple[Tensor, ...]:
    """Split an exact native CPU float32 tensor into shared-storage views.

    An integer gives the maximum view size; the last view may be shorter.
    A list or tuple gives nonnegative section sizes summing to the dimension
    size. Zero-length sections are preserved; an empty sequence requires an
    empty dimension.
    """
    return _dispatch_unary_torch_function(
        split,
        _split_impl,
        tensor,
        {"dim": dim},
        positional_arguments=(split_size_or_sections,),
    )


_ATLEAST_1D_SEQUENCE_UNSUPPORTED = (
    "atleast_1d() sequence inputs only support an exact tuple or list of "
    "exact Tensors"
)
_ATLEAST_1D_VARIADIC_UNSUPPORTED = (
    "atleast_1d() only supports a single Tensor input"
)
_ATLEAST_2D_SEQUENCE_UNSUPPORTED = (
    "atleast_2d() sequence inputs only support an exact tuple or list of "
    "exact Tensors"
)
_ATLEAST_2D_VARIADIC_UNSUPPORTED = (
    "atleast_2d() only supports a single Tensor input"
)
_ATLEAST_3D_SEQUENCE_UNSUPPORTED = (
    "atleast_3d() sequence inputs only support an exact tuple or list of "
    "exact Tensors"
)
_ATLEAST_3D_VARIADIC_UNSUPPORTED = (
    "atleast_3d() only supports a single Tensor input"
)


def _atleast_sequence(input, variable_function, unsupported):
    if type(input) in (tuple, list):
        if any(type(tensor) is not Tensor for tensor in input):
            raise TypeError(unsupported)
        return tuple(variable_function(tensor) for tensor in input)
    return variable_function(input)


def _atleast_1d_impl(input):
    if type(input) is Tensor:
        return _VF_atleast_1d(input)
    return _atleast_sequence(
        input,
        _VF_atleast_1d,
        _ATLEAST_1D_SEQUENCE_UNSUPPORTED,
    )


def _atleast_1d_variadic_impl(tensors):
    return tuple(_VF_atleast_1d(tensor) for tensor in tensors)


def atleast_1d(*tensors):
    r"""
    Returns a 1-dimensional view of each input tensor with zero dimensions.
    Input tensors with one or more dimensions are returned as-is.

    Args:
        input (Tensor or sequence of Tensors): tensor(s) to be converted to at least 1-dimensional.

    Returns:
        output (Tensor or tuple of Tensors)

    Example::

        >>> x = torch.arange(2)
        >>> x
        tensor([0, 1])
        >>> torch.atleast_1d(x)
        tensor([0, 1])
        >>> x = torch.tensor(1.)
        >>> x
        tensor(1.)
        >>> torch.atleast_1d(x)
        tensor([1.])
        >>> x = torch.tensor(0.5)
        >>> y = torch.tensor(1.)
        >>> torch.atleast_1d((x, y))
        (tensor([0.5000]), tensor([1.]))
        >>> torch.atleast_1d()
        ()
    """
    if len(tensors) > 1:
        if any(type(tensor) is not Tensor for tensor in tensors):
            raise TypeError(_ATLEAST_1D_VARIADIC_UNSUPPORTED)
        return _dispatch_exact_native_variadic_torch_function(
            atleast_1d,
            _atleast_1d_variadic_impl,
            tensors,
            {},
        )
    if not tensors:
        if _get_current_function_mode() is not None:
            return _VF_atleast_1d(tensors)
        return _atleast_1d_impl(tensors)
    return _dispatch_unary_torch_function(
        atleast_1d,
        _atleast_1d_impl,
        tensors[0],
        {},
    )


def _atleast_2d_impl(input):
    if type(input) is Tensor:
        return _VF_atleast_2d(input)
    return _atleast_sequence(
        input,
        _VF_atleast_2d,
        _ATLEAST_2D_SEQUENCE_UNSUPPORTED,
    )


def _atleast_2d_variadic_impl(tensors):
    return tuple(_VF_atleast_2d(tensor) for tensor in tensors)


def atleast_2d(*tensors):
    r"""
    Returns a 2-dimensional view of each input tensor with zero dimensions.
    Input tensors with two or more dimensions are returned as-is.

    Args:
        input (Tensor or sequence of Tensors): tensor(s) to be converted to at least 2-dimensional.

    Returns:
        output (Tensor or tuple of Tensors)

    Example::

        >>> x = torch.tensor(1.)
        >>> x
        tensor(1.)
        >>> torch.atleast_2d(x)
        tensor([[1.]])
        >>> x = torch.arange(4).view(2, 2)
        >>> x
        tensor([[0, 1],
                [2, 3]])
        >>> torch.atleast_2d(x)
        tensor([[0, 1],
                [2, 3]])
        >>> x = torch.tensor(0.5)
        >>> y = torch.tensor(1.)
        >>> torch.atleast_2d((x, y))
        (tensor([[0.5000]]), tensor([[1.]]))
        >>> torch.atleast_2d()
        ()
    """
    if len(tensors) > 1:
        if any(type(tensor) is not Tensor for tensor in tensors):
            raise TypeError(_ATLEAST_2D_VARIADIC_UNSUPPORTED)
        return _dispatch_exact_native_variadic_torch_function(
            atleast_2d,
            _atleast_2d_variadic_impl,
            tensors,
            {},
        )
    if not tensors:
        if _get_current_function_mode() is not None:
            return _VF_atleast_2d(tensors)
        return _atleast_2d_impl(tensors)
    return _dispatch_unary_torch_function(
        atleast_2d,
        _atleast_2d_impl,
        tensors[0],
        {},
    )


def _atleast_3d_impl(input):
    if type(input) is Tensor:
        return _VF_atleast_3d(input)
    return _atleast_sequence(
        input,
        _VF_atleast_3d,
        _ATLEAST_3D_SEQUENCE_UNSUPPORTED,
    )


def _atleast_3d_variadic_impl(tensors):
    return tuple(_VF_atleast_3d(tensor) for tensor in tensors)


def atleast_3d(*tensors):
    r"""
    Returns a 3-dimensional view of each input tensor with zero dimensions.
    Input tensors with three or more dimensions are returned as-is.

    Args:
        input (Tensor or sequence of Tensors): tensor(s) to be converted to at least 3-dimensional.

    Returns:
        output (Tensor or tuple of Tensors)

    Example:

        >>> x = torch.tensor(0.5)
        >>> x
        tensor(0.5000)
        >>> torch.atleast_3d(x)
        tensor([[[0.5000]]])
        >>> y = torch.arange(4).view(2, 2)
        >>> y
        tensor([[0, 1],
                [2, 3]])
        >>> torch.atleast_3d(y)
        tensor([[[0],
                 [1]],
                <BLANKLINE>
                [[2],
                 [3]]])
        >>> x = torch.tensor(1).view(1, 1, 1)
        >>> x
        tensor([[[1]]])
        >>> torch.atleast_3d(x)
        tensor([[[1]]])
        >>> x = torch.tensor(0.5)
        >>> y = torch.tensor(1.0)
        >>> torch.atleast_3d((x, y))
        (tensor([[[0.5000]]]), tensor([[[1.]]]))
        >>> torch.atleast_3d()
        ()
    """
    if len(tensors) > 1:
        if any(type(tensor) is not Tensor for tensor in tensors):
            raise TypeError(_ATLEAST_3D_VARIADIC_UNSUPPORTED)
        return _dispatch_exact_native_variadic_torch_function(
            atleast_3d,
            _atleast_3d_variadic_impl,
            tensors,
            {},
        )
    if not tensors:
        if _get_current_function_mode() is not None:
            return _VF_atleast_3d(tensors)
        return _atleast_3d_impl(tensors)
    return _dispatch_unary_torch_function(
        atleast_3d,
        _atleast_3d_impl,
        tensors[0],
        {},
    )


def _broadcast_tensors_impl(tensors):
    return tensors


def broadcast_tensors(*tensors):
    r"""broadcast_tensors(*tensors) -> List of Tensors

    Broadcasts the given tensors according to :ref:`broadcasting-semantics`.

    Args:
        *tensors: any number of tensors of the same type

    .. warning::

        More than one element of a broadcasted tensor may refer to a single
        memory location. As a result, in-place operations (especially ones that
        are vectorized) may result in incorrect behavior. If you need to write
        to the tensors, please clone them first.

    Example::

        >>> x = torch.arange(3).view(1, 3)
        >>> y = torch.arange(2).view(2, 1)
        >>> a, b = torch.broadcast_tensors(x, y)
        >>> a.size()
        torch.Size([2, 3])
        >>> a
        tensor([[0, 1, 2],
                [0, 1, 2]])
    """
    if not tensors:
        return _VF_broadcast_tensors(tensors)

    # Validate the complete tuple before mode dispatch. Unsupported operands
    # cannot run overrides, and differing shapes cannot allocate expand views.
    _VF_broadcast_tensors(tensors)
    return _dispatch_exact_native_variadic_torch_function(
        broadcast_tensors,
        _broadcast_tensors_impl,
        tensors,
        {},
    )


def _guard_or_false(condition):
    if not isinstance(condition, bool):
        raise AssertionError(f"Expected bool, got {type(condition)}")
    return condition


def _check(condition, message):
    if not isinstance(condition, bool):
        raise TypeError(f"cond must be a bool, but got {type(condition)}")
    if not condition:
        raise RuntimeError(message())


def broadcast_shapes(*shapes):
    r"""broadcast_shapes(*shapes) -> Size

    Similar to :func:`broadcast_tensors` but for shapes.

    This is equivalent to
    ``torch.broadcast_tensors(*map(torch.empty, shapes))[0].shape``
    but avoids the need to create intermediate tensors. This is useful for
    broadcasting tensors of common batch shape but different rightmost shape,
    e.g. to broadcast mean vectors with covariance matrices.

    Example::

        >>> torch.broadcast_shapes((2,), (3, 1), (1, 1, 1))
        torch.Size([1, 3, 2])

    Args:
        \*shapes (torch.Size): Shapes of tensors.

    Returns:
        shape (torch.Size): A shape compatible with all input shapes.

    Raises:
        RuntimeError: If shapes are incompatible.
    """
    normalized_shapes = tuple(
        (shape,) if isinstance(shape, int) else shape
        for shape in shapes
        if shape is not None
    )
    if not normalized_shapes:
        return Size([])

    for shape in normalized_shapes:
        if not isinstance(shape, Sequence):
            raise RuntimeError(
                "Input shapes should be of type ints, a tuple of ints, or a "
                f"list of ints, got {shape}"
            )

    common_shape = [1] * max(len(shape) for shape in normalized_shapes)
    for argument_index, shape in enumerate(normalized_shapes):
        for index in range(-1, -1 - len(shape), -1):
            dimension = shape[index]
            if _guard_or_false(dimension == common_shape[index]):
                continue

            if _guard_or_false(common_shape[index] == 1):
                if dimension < 0:
                    raise ValueError(
                        "Attempting to broadcast a dimension with negative length!"
                    )
                common_shape[index] = dimension

            if _guard_or_false(dimension == 1):
                continue

            _check(
                common_shape[index] == dimension,
                lambda: (
                    "Attempting to broadcast a dimension of length "
                    f"{dimension} at {index}! Mismatching argument at index "
                    f"{argument_index} had {shape}; but expected shape should "
                    f"be broadcastable to {common_shape}"
                ),
            )

    return Size(common_shape)
