"""Functional interface."""

import math
import operator as _operator
import warnings

import torch_rs as torch
from torch_rs import Tensor
from torch_rs._diagnostics import _format_single_element_tensor
from torch_rs.overrides import _dispatch_unary_torch_function

from ..torch_rs import (
    _nn_functional_dropout,
    _nn_functional_glu_vector,
    _nn_functional_l1_loss,
    _nn_functional_linear as linear,
    _nn_functional_mse_loss,
    _nn_functional_softsign,
)


_L1_LOSS_DOC = r"""
l1_loss(input, target, size_average=None, reduce=None, reduction='mean', weight=None) -> Tensor

Measures the element-wise absolute error between ``input`` and ``target``.

The current native implementation requires exact ``torch_rs.Tensor`` operands
with CPU ``float32`` storage, broadcastable shapes, ``reduction='none'``,
``reduction='mean'``, or ``reduction='sum'``, ``size_average=None``,
``reduce=None``, and ``weight=None``. With autograd recording inactive, it
fuses same-shape row-major contiguous operands, same-shape operands with
identical strides and non-overlapping dense storage, non-empty same-shape
rank-4 channels-last-contiguous operands, and
rank-0 scalar broadcasts over row-major contiguous tensors into one native
absolute-difference pass, otherwise preserving the established subtraction and
absolute-value behavior. For ``reduction='mean'``, supported layouts compose the
absolute-difference result with the supported full-tensor mean. For
``reduction='sum'``, same-shape row-major contiguous operands, rank-0 scalar
broadcasts over row-major contiguous tensors, and a row-major rank-2 tensor
paired with a row-major rank-1 tensor over its trailing dimension use a direct
fused absolute-difference scalar reduction; other supported layouts compose the
absolute-difference result with the supported full-tensor sum. The operation
returns a fresh, independent tensor with PyTorch-compatible values, shape,
strides, scalar metadata, and size-mismatch warning.

For active autograd recording, ``reduction='none'``, default or explicit
``reduction='mean'``, and ``reduction='sum'`` support matching shapes and finite values in both operands
through native subtraction and absolute value, followed by the supported
full-tensor mean or checked full-tensor sum for the corresponding reduction.
Either operand or both may require
gradients, including shared operands and supported views (scalar, empty,
transposed, offset, and channels-last). First-order backward multiplies the upstream gradient by
``sign(input - target)`` for input and its negative for target; equal elements,
including signed zeros, have zero gradient. Finiteness applies to logical view
elements, not unused storage; finite operands whose difference overflows are
also supported. Mean backward divides the upstream gradient by the element
count before the absolute-value derivative; sum backward broadcasts it unchanged.
An empty mean is NaN and an empty sum is zero, both with empty gradients.
Scalar weighting may be applied to the mean or sum loss. Nonuniform
weighting may be applied to the unreduced output before summing. Repeated uses
accumulate leaf gradients, and backward releases the graph. Backward uses the
existing scalar-loss API; explicit backward gradients, graph retention,
higher-order differentiation, and the ``weight`` argument remain unsupported.
Existing leaf-gradient layout handling may produce different singleton strides
from PyTorch after channels-last copies; logical gradient values are preserved.

Unbroadcastable shapes, legacy ``size_average``/``reduce`` behavior, weights,
unsupported dtypes or devices, Tensor subclasses, active ``TorchFunctionMode``
contexts, and module loss wrappers are not supported. Active autograd recording
with broadcasting or nonfinite operands remains unsupported.
Gradient-requiring operands may use the inference paths inside ``torch.no_grad()``.
"""


_MSE_LOSS_DOC = r"""
mse_loss(input, target, size_average=None, reduce=None, reduction='mean', weight=None) -> Tensor

Measures the element-wise mean squared error between ``input`` and ``target``.

The current native implementation requires exact ``torch_rs.Tensor`` operands
with CPU ``float32`` storage, broadcastable shapes, ``reduction='none'`` or
``reduction='mean'`` or ``reduction='sum'``, ``size_average=None``,
``reduce=None``, and ``weight=None``. It fuses subtraction and square into one
native pass. For ``reduction='mean'`` or ``reduction='sum'``, same-shape
row-major contiguous operands that are not recording autograd use a direct
scalar reduction. For ``reduction='sum'``, a row-major rank-2 tensor paired
with a matching row-major trailing rank-1 vector also uses a direct scalar
reduction when no autograd edge would be recorded. Other reduction cases
compose the fused squared-error tensor with the supported full-tensor reduction.
The operation returns a fresh, independent tensor with PyTorch-compatible
values, shape, strides, scalar metadata, and size-mismatch warning.

Unbroadcastable shapes, broadcasted active autograd for ``reduction='none'``,
legacy ``size_average``/``reduce`` behavior, weights, unsupported dtypes or
devices, Tensor subclasses, active ``TorchFunctionMode`` contexts, and module
loss wrappers are not supported. Gradient-requiring operands may be used with
``reduction='none'`` for matching shapes, with ``reduction='mean'`` or
``reduction='sum'``, or inside ``torch.no_grad()``.
"""


def _validate_dropout_probability(p):
    range_probability, probability_for_error = _dropout_range_probability(p)
    if range_probability < 0.0 or range_probability > 1.0:
        if type(probability_for_error) is Tensor:
            probability_for_error = _format_single_element_tensor(
                probability_for_error, range_probability
            )
        raise ValueError(
            "dropout probability has to be between 0 and 1, but got "
            f"{probability_for_error}"
        )


def _dropout_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    if inplace:
        return _nn_functional_dropout("dropout", input, p, training, True)
    return _nn_functional_dropout("dropout", input, p, training, False)


def _dropout1d_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    # Preserve PyTorch's pre-native invalid-input validation order.
    input.dim()
    if inplace:
        return _nn_functional_dropout("dropout1d", input, p, training, True)
    return _nn_functional_dropout("dropout1d", input, p, training, False)


def _dropout2d_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    # Preserve PyTorch's pre-native invalid-input validation order.
    input_dimension = input.dim()
    if input_dimension == 2:
        warnings.warn(
            "dropout2d: Received a 2-D input to dropout2d, which is deprecated "
            "and will result in an error in a future release. To retain the "
            "behavior and silence this warning, please use dropout instead. "
            "Note that dropout2d exists to provide channel-wise dropout on "
            "inputs with 2 spatial dimensions, a channel dimension, and an "
            "optional batch dimension (i.e. 3D or 4D inputs).",
            stacklevel=4,
        )
    if input_dimension == 3:
        warnings.warn(
            "dropout2d: Received a 3D input to dropout2d and assuming that "
            "channel-wise 1D dropout behavior is desired - input is interpreted "
            "as shape (N, C, L), where C is the channel dim. This behavior will "
            "change in a future release to interpret the input as one without a "
            "batch dimension, i.e. shape (C, H, W). To maintain the 1D "
            "channel-wise dropout behavior, please switch to using dropout1d "
            "instead.",
            stacklevel=4,
        )
    if inplace:
        return _nn_functional_dropout("dropout2d", input, p, training, True)
    return _nn_functional_dropout("dropout2d", input, p, training, False)


def _dropout3d_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    # Preserve PyTorch's pre-native invalid-input validation order.
    input.dim()
    if inplace:
        return _nn_functional_dropout("dropout3d", input, p, training, True)
    return _nn_functional_dropout("dropout3d", input, p, training, False)


def _alpha_dropout_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    if inplace:
        return _nn_functional_dropout("alpha_dropout", input, p, training, True)
    return _nn_functional_dropout("alpha_dropout", input, p, training, False)


def _feature_alpha_dropout_impl(input, p, training, inplace):
    _validate_dropout_probability(p)
    if inplace:
        return _nn_functional_dropout("feature_alpha_dropout", input, p, training, True)
    return _nn_functional_dropout("feature_alpha_dropout", input, p, training, False)


def _dropout_range_probability(p):
    if type(p) is not Tensor:
        return p, p

    element_count = p.numel()
    if element_count == 0:
        raise RuntimeError("Boolean value of Tensor with no values is ambiguous")
    if element_count != 1:
        raise RuntimeError(
            "Boolean value of Tensor with more than one value is ambiguous"
        )

    value = p.item()
    if len(p.shape) == 0:
        return value, value
    return value, p


def relu(input: Tensor, inplace: bool = False) -> Tensor:
    r"""relu(input, inplace=False) -> Tensor

    Applies the rectified linear unit function element-wise. See
    :class:`~torch.nn.ReLU` for more details.
    """
    if inplace:
        raise NotImplementedError(
            "torch_rs.nn.functional.relu does not support inplace=True"
        )
    return torch.relu(input)


def tanh(input):
    r"""tanh(input) -> Tensor

    Applies element-wise,
    :math:`\text{Tanh}(x) = \tanh(x) = \frac{\exp(x) - \exp(-x)}{\exp(x) + \exp(-x)}`

    See :class:`~torch.nn.Tanh` for more details.
    """
    return input.tanh()


def sigmoid(input):
    r"""sigmoid(input) -> Tensor

    Applies the element-wise function :math:`\text{Sigmoid}(x) = \frac{1}{1 + \exp(-x)}`

    See :class:`~torch.nn.Sigmoid` for more details.
    """
    return input.sigmoid()


def _torch_functional_type_name(value):
    value_type = type(value)
    module = value_type.__module__
    name = value_type.__name__
    if module == "numpy":
        return f"numpy.{name}"
    if module in ("torch_rs", "torch_rs.torch_rs") and name in (
        "device",
        "dtype",
        "finfo",
        "layout",
        "memory_format",
        "Size",
    ):
        return f"torch.{name}"
    return name


def _silu_tensor_type_error(input, operation):
    type_name = _torch_functional_type_name(input)
    raise TypeError(
        f"{operation}(): argument 'input' (position 1) must be Tensor, not {type_name}"
    )


def _silu_impl(input, inplace):
    inplace_enabled = bool(inplace)
    operation = "silu_" if inplace_enabled else "silu"
    if type(input) is not Tensor:
        _silu_tensor_type_error(input, operation)
    if inplace_enabled:
        raise NotImplementedError(
            "torch_rs.nn.functional.silu does not support inplace=True"
        )
    return input * input.sigmoid()


def silu(input: Tensor, inplace: bool = False) -> Tensor:
    r"""Apply the Sigmoid Linear Unit (SiLU) function, element-wise.

    The SiLU function is also known as the swish function.

    .. math::
        \text{silu}(x) = x * \sigma(x), \text{where } \sigma(x) \text{ is the logistic sigmoid.}

    .. note::
        See `Gaussian Error Linear Units (GELUs) <https://arxiv.org/abs/1606.08415>`_
        where the SiLU (Sigmoid Linear Unit) was originally coined, and see
        `Sigmoid-Weighted Linear Units for Neural Network Function Approximation
        in Reinforcement Learning <https://arxiv.org/abs/1702.03118>`_ and `Swish:
        a Self-Gated Activation Function <https://arxiv.org/abs/1710.05941v1>`_
        where the SiLU was experimented with later.

    See :class:`~torch.nn.SiLU` for more details.
    """
    return _dispatch_unary_torch_function(
        silu,
        _silu_impl,
        input,
        {"inplace": inplace},
    )


def _glu_impl(input, dim):
    # PyTorch checks scalar inputs before binding the native dimension argument.
    rank = input.dim()
    if rank == 0:
        raise RuntimeError(
            "glu does not support scalars because halving size must be even"
        )
    if type(input) is not Tensor:
        _silu_tensor_type_error(input, "glu")

    # Reuse size's native integer, overflow, and dimension-range validation.
    # Unlike size, GLU has no optional-None dimension overload.
    if dim is None:
        raise TypeError("glu(): argument 'dim' (position 2) must be int, not NoneType")
    try:
        size = input.size(dim)
    except TypeError as error:
        prefix = "size(): argument 'dim' (position 1) must be int, not "
        if str(error).startswith(prefix):
            raise TypeError(
                "glu(): argument 'dim' (position 2) must be int, not "
                + str(error)[len(prefix):]
            ) from None
        raise
    axis = _operator.index(dim) % rank
    if size % 2:
        raise RuntimeError(
            f"Halving dimension must be even, but dimension {axis} is size {size}"
        )
    if input.device.type != "cpu" or input.dtype is not torch.float32 or rank > 3:
        raise NotImplementedError(
            "glu(): only exact native CPU float32 Tensor inputs of ranks 1 through 3 are supported"
        )
    recording = torch.is_grad_enabled() and input.requires_grad
    if recording and rank != 1:
        raise RuntimeError("glu(): autograd recording is not supported")
    first, second = input.chunk(2, axis)
    if recording:
        # Sigmoid records finite owned vectors, but chunk returns views. Clone
        # the gate differentiably so both halves still backpropagate to input.
        # Combine the multiplication/sigmoid VJP to apply the sigmoid factors
        # before multiplying the first half by a potentially large upstream.
        return _nn_functional_glu_vector(first, second.clone())
    return first * second.sigmoid()


def glu(input: Tensor, dim: int = -1) -> Tensor:
    r"""Apply the gated linear unit: split input along dim and return a * sigmoid(b).

    Supports exact native CPU float32 tensors of ranks one through three with
    an even selected dimension (including zero). Outputs own fresh storage.
    Finite rank-one inputs support first-order gradients for dim=0 or -1.
    Higher-rank tracked inputs work only in no_grad.
    """
    return _dispatch_unary_torch_function(glu, _glu_impl, input, {"dim": dim})


def _tanhshrink_impl(input):
    return input - input.tanh()


def tanhshrink(input):
    r"""tanhshrink(input) -> Tensor

    Applies element-wise, :math:`\text{Tanhshrink}(x) = x - \text{Tanh}(x)`

    See :class:`~torch.nn.Tanhshrink` for more details.
    """
    return _dispatch_unary_torch_function(
        tanhshrink,
        _tanhshrink_impl,
        input,
        {},
    )


def _softsign_impl(input):
    if isinstance(input, Tensor) and torch.is_grad_enabled() and input.requires_grad:
        raise RuntimeError("softsign(): autograd recording is not supported")
    if type(input) is Tensor:
        return _nn_functional_softsign(input)
    return input / (input.abs() + 1)


def softsign(input):
    r"""softsign(input) -> Tensor

    Applies element-wise, the function :math:`\text{SoftSign}(x) = \frac{x}{1 + |x|}`

    See :class:`~torch.nn.Softsign` for more details.
    """
    return _dispatch_unary_torch_function(
        softsign,
        _softsign_impl,
        input,
        {},
    )


def l1_loss(
    input: Tensor,
    target: Tensor,
    size_average: bool | None = None,
    reduce: bool | None = None,
    reduction: str = "mean",
    weight: Tensor | None = None,
) -> Tensor:
    return _nn_functional_l1_loss(
        input,
        target,
        size_average,
        reduce,
        reduction,
        weight,
    )


l1_loss.__doc__ = _L1_LOSS_DOC


def mse_loss(
    input: Tensor,
    target: Tensor,
    size_average: bool | None = None,
    reduce: bool | None = None,
    reduction: str = "mean",
    weight: Tensor | None = None,
) -> Tensor:
    return _nn_functional_mse_loss(
        input,
        target,
        size_average,
        reduce,
        reduction,
        weight,
    )


mse_loss.__doc__ = _MSE_LOSS_DOC


def dropout(
    input: Tensor,
    p: float = 0.5,
    training: bool = True,
    inplace: bool = False,
) -> Tensor:
    r"""During training, randomly zeroes some elements of the input tensor with probability :attr:`p`.

    Uses samples from a Bernoulli distribution.

    See :class:`~torch.nn.Dropout` for details.

    Args:
        p: probability of an element to be zeroed. Default: 0.5
        training: apply dropout if is ``True``. Default: ``True``
        inplace: If set to ``True``, will do this operation in-place. Default: ``False``
    """
    return _dispatch_unary_torch_function(
        dropout,
        _dropout_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )


def dropout1d(
    input: Tensor,
    p: float = 0.5,
    training: bool = True,
    inplace: bool = False,
) -> Tensor:
    r"""Randomly zero out entire channels (a channel is a 1D feature map).

    For example, the :math:`j`-th channel of the :math:`i`-th sample in the
    batched input is a 1D tensor :math:`\text{input}[i, j]` of the input tensor.
    Each channel will be zeroed out independently on every forward call with
    probability :attr:`p` using samples from a Bernoulli distribution.

    See :class:`~torch.nn.Dropout1d` for details.

    Args:
        p: probability of a channel to be zeroed. Default: 0.5
        training: apply dropout if is ``True``. Default: ``True``
        inplace: If set to ``True``, will do this operation in-place. Default: ``False``
    """
    return _dispatch_unary_torch_function(
        dropout1d,
        _dropout1d_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )


def dropout2d(
    input: Tensor,
    p: float = 0.5,
    training: bool = True,
    inplace: bool = False,
) -> Tensor:
    r"""Randomly zero out entire channels (a channel is a 2D feature map).

    For example, the :math:`j`-th channel of the :math:`i`-th sample in the
    batched input is a 2D tensor :math:`\text{input}[i, j]` of the input tensor.
    Each channel will be zeroed out independently on every forward call with
    probability :attr:`p` using samples from a Bernoulli distribution.

    See :class:`~torch.nn.Dropout2d` for details.

    Args:
        p: probability of a channel to be zeroed. Default: 0.5
        training: apply dropout if is ``True``. Default: ``True``
        inplace: If set to ``True``, will do this operation in-place. Default: ``False``
    """
    return _dispatch_unary_torch_function(
        dropout2d,
        _dropout2d_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )


def dropout3d(
    input: Tensor,
    p: float = 0.5,
    training: bool = True,
    inplace: bool = False,
) -> Tensor:
    r"""Randomly zero out entire channels (a channel is a 3D feature map).

    For example, the :math:`j`-th channel of the :math:`i`-th sample in the
    batched input is a 3D tensor :math:`\text{input}[i, j]` of the input tensor.
    Each channel will be zeroed out independently on every forward call with
    probability :attr:`p` using samples from a Bernoulli distribution.

    See :class:`~torch.nn.Dropout3d` for details.

    Args:
        p: probability of a channel to be zeroed. Default: 0.5
        training: apply dropout if is ``True``. Default: ``True``
        inplace: If set to ``True``, will do this operation in-place. Default: ``False``
    """
    return _dispatch_unary_torch_function(
        dropout3d,
        _dropout3d_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )


def alpha_dropout(
    input: Tensor,
    p: float = 0.5,
    training: bool = False,
    inplace: bool = False,
) -> Tensor:
    r"""Apply alpha dropout to the input.

    See :class:`~torch.nn.AlphaDropout` for details.
    """
    return _dispatch_unary_torch_function(
        alpha_dropout,
        _alpha_dropout_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )


def feature_alpha_dropout(
    input: Tensor,
    p: float = 0.5,
    training: bool = False,
    inplace: bool = False,
) -> Tensor:
    r"""Randomly masks out entire channels (a channel is a feature map).

    For example, the :math:`j`-th channel of the :math:`i`-th sample in the batch input
    is a tensor :math:`\text{input}[i, j]` of the input tensor. Instead of
    setting activations to zero, as in regular Dropout, the activations are set
    to the negative saturation value of the SELU activation function.

    Each element will be masked independently on every forward call with
    probability :attr:`p` using samples from a Bernoulli distribution.
    The elements to be masked are randomized on every forward call, and scaled
    and shifted to maintain zero mean and unit variance.

    See :class:`~torch.nn.FeatureAlphaDropout` for details.

    Args:
        p: dropout probability of a channel to be zeroed. Default: 0.5
        training: apply dropout if is ``True``. Default: ``True``
        inplace: If set to ``True``, will do this operation in-place. Default: ``False``
    """
    return _dispatch_unary_torch_function(
        feature_alpha_dropout,
        _feature_alpha_dropout_impl,
        input,
        {"p": p, "training": training, "inplace": inplace},
    )
