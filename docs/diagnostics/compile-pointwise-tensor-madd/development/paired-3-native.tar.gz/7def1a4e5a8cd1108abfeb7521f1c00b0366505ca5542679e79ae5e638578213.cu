// torch_rs typed pointwise SSA v1; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[((i / 271ull) % 239ull) * 1ull];
const float v2 = __fmul_rn(v0, v1);
const float v3 = fmaf(v0, v1, v0);
out[i] = v3;
}
}
