#!/bin/bash
set -euo pipefail
source target/full-call/env.sh
set -x
capture() {
    local label="$1" framework="$2" build="$3" source="$4" revision="$5"
    export CUDA_CACHE_PATH="$PWD/target/full-call/cache/$label/cuda"
    export TORCHINDUCTOR_CACHE_DIR="$PWD/target/full-call/cache/$label/inductor"
    export TRITON_CACHE_DIR="$PWD/target/full-call/cache/$label/triton"
    local options=()
    if [ "$framework" = torch_rs ]; then
        local wheels=("$PWD/target/full-call/wheels/$build/"*.whl)
        options=(--import-dir "$PWD/target/full-call/imports/$build" --wheel "${wheels[0]}")
    fi
    "$PYO3_PYTHON" -B -I scripts/diagnose_compile_full_call.py --framework "$framework" --label "$label" --source-root "$source" --source-commit "$revision" --output "$BURNER_EVALUATION_ARTIFACT_DIR/$label.json" "${options[@]}" > "$BURNER_EVALUATION_ARTIFACT_DIR/$label.log" 2>&1
}
for build in accepted incoming measured; do
    case "$build" in
        accepted) source="$PWD/target/full-call/accepted"; revision=60202557b4f110d07777f585e804ab5f55e1ff7b ;;
        incoming) source="$PWD/target/full-call/incoming"; revision=9a436482d3e49dd40df7ce1d75198890b16b8f95 ;;
        measured) source="$PWD"; revision=9a436482d3e49dd40df7ce1d75198890b16b8f95+uncommitted ;;
    esac
    capture "$build-native-first" torch_rs "$build" "$source" "$revision"
    capture "$build-reference-second" torch "$build" "$source" "$revision"
    capture "$build-reference-first" torch "$build" "$source" "$revision"
    capture "$build-native-second" torch_rs "$build" "$source" "$revision"
done
