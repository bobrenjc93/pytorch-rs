"""Later untimed setup receipt; never relabels earlier timing observations."""
import sys,pathlib,importlib.util,hashlib,json,time,os,importlib.abc
root=pathlib.Path.cwd(); label=sys.argv[1];sys.path.insert(0,str(root/'target/full-call/imports'/label))
class BlockTorch(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='torch' or fullname.startswith('torch.'):raise ImportError('native-only setup')
sys.meta_path.insert(0,BlockTorch())
spec=importlib.util.spec_from_file_location('diagnostic',root/'scripts/diagnose_compile_full_call.py'); diagnostic=importlib.util.module_from_spec(spec);spec.loader.exec_module(diagnostic)
import torch_rs as fw
from torch_rs import _compile_trace
fn=diagnostic.polynomial;compiled=fw.compile(fn);args=diagnostic.inputs(fw,fn,(257,),0);result=compiled(*args)
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt={'purpose':'later untimed same-build setup, not original timing metadata','timestamp_ns':time.time_ns(),'argv':sys.argv,'label':label,'package':fw.__file__,'native':_compile_trace._native.__file__,'native_sha256':sha(pathlib.Path(_compile_trace._native.__file__).read_bytes()),'runtime':os.environ['TORCH_RS_CUDART'],'compilers':[{'nvrtc_version':k.nvrtc_version,'options':k.options,'source_sha256':sha(k.source.encode()),'ptx_sha256':sha(k.ptx.encode()),'device':k.device} for k in compiled._torch_rs_pointwise_cache.executors.values()],'torch_imported':'torch' in sys.modules}
(root/f'target/full-call/evidence/{label}-later-kernel-setup.json').write_text(json.dumps(receipt,indent=2)+'\n')
