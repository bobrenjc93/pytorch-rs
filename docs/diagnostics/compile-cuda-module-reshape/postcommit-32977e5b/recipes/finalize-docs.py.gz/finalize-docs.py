import gzip,json
from pathlib import Path
root=Path.cwd();src=root/'target/reshape-postcommit-32977e5b';dst=root/'docs/diagnostics/compile-cuda-module-reshape/postcommit-32977e5b'
commands=json.loads(gzip.decompress((dst/'commands.json.gz').read_bytes()));summary=json.loads((dst/'compiler-summary.json').read_text())
def counts(name):
 x=commands[name]['unittest'];n=x['run'];skips=x.get('skipped',0)
 return f'{n} run, {n-skips} passed, {skips} skipped'
rows=[('Complete compiler selection',f"{summary['modules']} modules; {summary['run']} run, {summary['passed']} passed, {summary['skipped']} skipped; {summary['warnings']} warning records"),('Frozen replay','144 cells + 4 rebinding controls; 96 closures, 94 strict eligible, 2 zero-credit diagnostics'),('Focused CUDA/reference regressions',counts('focused')),('CUDA-hidden frontend/CPU/reference boundaries',counts('hidden')),('Two-device restoration',counts('restoration')),('Default Rust CUDA packing/reshape','1 passed on H100; hidden run returned early'),('Python-binding Rust graph/planner','15 passed on H100; 15 passed with CUDA hidden (hardware sections return early)'),('Formatting and default/binding Clippy','All passed'),('Documentation/navigation',counts('docs')+'; CUDA guide example passed'),('Interpreter, frozen-input and installed-wheel audits','Passed; all 60 installed package members verified')]
table='| Check | Result |\n| --- | --- |\n'+'\n'.join(f'| {a} | {b} |' for a,b in rows)
(dst/'README.md').write_text((src/'README.template.md').read_text().replace('@@RESULTS@@',table))
p=dst.parent/'README.md';s=p.read_text();old='''Burner owns the implementation commit, independent review, draft delivery and
fresh merge gates. A separate clean-commit capture must run after that managed
commit exists; this uncommitted development capture does not stand in for it.
No branch, commit, push or PR was created by this implementation session.
''';new='''The separate [clean-commit capture](postcommit-32977e5b/README.md) measures
`32977e5dbab09e4b069dad921286d31697ecadb5` after Burner's managed implementation
commit. These development measurements remain pinned to their original source
and build identities. Burner owns independent review, draft delivery and fresh
merge gates. No branch, commit, push or PR was created by this implementation session.
''';assert old in s;p.write_text(s.replace(old,new))
p=root/'docs/compile-cuda-reshape.md';s=p.read_text();old='''The [latest clean-commit capture](diagnostics/compile-cuda-reshape/postcommit-93441a9f/README.md)
measures `93441a9fc13e8124a507a34810f2c3d97f7e69f1` with a fresh local environment
''';new='''The [top-level clean-commit capture](diagnostics/compile-cuda-module-reshape/postcommit-32977e5b/README.md)
measures `32977e5dbab09e4b069dad921286d31697ecadb5` with a fresh source-bound
release wheel, the frozen 144-cell replay, all four policies, the complete compiler
selection and device/portability checks.

The [earlier method-only capture](diagnostics/compile-cuda-reshape/postcommit-93441a9f/README.md)
measures `93441a9fc13e8124a507a34810f2c3d97f7e69f1` with a fresh local environment
''';assert old in s;p.write_text(s.replace(old,new))
for name,p in [('finalize-docs.py',Path(__file__)),('README.template.md',src/'README.template.md')]:
 (dst/'recipes'/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
print('published evidence documentation and two navigation updates')
