import gzip, hashlib, json, re, subprocess, zipfile
from pathlib import Path
root=Path.cwd(); e=root/'target/reshape-postcommit-32977e5b'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def payload(name):
 s=(e/(name+'.log')).read_text();return json.loads(s[s.index('{'):])
b,c=payload('baseline'),payload('candidate')
assert len(b['cases'])==len(c['cases'])==144
for before,after in zip(b['cases'],c['cases'],strict=True):
 for k in ('name','expression','arity','shape','requested_shape','expected_gap','input_sha256','native_eager_passed','reference_strict_parity_eligible','reference_metadata_divergences'):
  assert before[k]==after[k],(k,before['name'])
 assert all(call['passed'] for call in after['native_calls'])
 assert all(('unsupported' in call)==before['expected_gap'] for call in before['native_calls'])
assert sum(x['expected_gap'] for x in b['cases'])==96
assert sum(x['expected_gap'] and x['reference_strict_parity_eligible'] for x in c['cases'])==94
assert sum(not x['reference_strict_parity_eligible'] for x in c['cases'])==2
assert b['unrelated_rebindings']==c['unrelated_rebindings'] and len(c['unrelated_rebindings'])==4
frozen=e/'frozen'
for name,h in {'probe-compiled-cuda-module-reshape.py':'70fc9e24cdc6d9bfc1d829fa6e965ad767ec5ccd42225dc14352637e86e34ee0','probe-compiled-cuda-module-reshape-v2.py':'058e9ae774afbb977a14246e4370043fee28eda93dfd6540f48a29ff25946c7c','compiled-cuda-module-reshape-reference-metadata-survey.json':'794ce27b74b5ab88bbbd34ca064208d48da57c62f1391770c68cf329fc69b8aa','compiled-cuda-module-reshape-baseline-initial-failure.log':'2049a9853d4b9c6c328202be842a3424e16a272bf59eb1546a8059b1699c248f'}.items():
 assert sha((frozen/name).read_bytes())==h,name
build=json.loads((root/'target/cuda-add-diagnostic/module-reshape-postcommit-32977e5b/build-record.json').read_text())
import torch_rs as n
with zipfile.ZipFile(build['wheel']) as z:
 checked=[]
 for member in z.namelist():
  if member.startswith('torch_rs/') and not member.endswith('/'):
   installed=Path(n.__file__).parent.parent/member
   assert installed.is_file() and sha(installed.read_bytes())==sha(z.read(member)),member
   source=root/'python'/member
   if source.is_file(): assert source.read_bytes()==z.read(member),member
   checked.append(member)
assert sha(Path(n._C.__file__).read_bytes())==c['native_extension_sha256']==build['installed_native_sha256']
print(json.dumps(dict(verified=True,original_cells=144,original_gap_rejections=96,strict_gap_closures=94,zero_credit_diagnostics=2,positive_controls=48,rebinding_controls=4,inputs_and_classification_preserved=True,installed_wheel_members_verified=len(checked),source_provenance=c['source_provenance'],timing_credit=False),indent=2))
