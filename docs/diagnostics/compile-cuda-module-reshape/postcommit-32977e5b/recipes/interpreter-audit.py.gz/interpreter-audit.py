"""Reverify the already local interpreter; do not copy or change installation."""
import ast, hashlib, json, os, stat, subprocess, sys
from pathlib import Path
root=Path.cwd(); script=root/'target/reshape-postcommit-32977e5b/recipes/bootstrap.py'
tree=ast.parse(script.read_text())
functions=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('sha','inventory')],type_ignores=[])
exec(compile(functions,str(script),'exec'))
destination=root/'target/uv-python/cpython-3.12.14-linux-x86_64-gnu'
entries=inventory(destination)
manifest=sha(json.dumps(entries,sort_keys=True).encode())
assert manifest=='519ae888f6f47836a48399b7eff35b28582673e893a08261bd5e2758f9a4f265'
exe=destination/'bin/python3.12'
assert sha(exe.read_bytes())=='f7c6210eb40fadcd3c2889dddd24a15fc2c9f926aec5a03bf9da66e12d581526'
command=[str(exe),'-I','-B','-c','import json,sys,sysconfig;print(json.dumps(dict(version=sys.version,executable=sys.executable,base_prefix=sys.base_prefix,stdlib=sysconfig.get_path("stdlib"),include=sysconfig.get_path("include"))))']
identity=json.loads(subprocess.check_output(command,text=True))
assert identity['version'].startswith('3.12.14')
for k in ('executable','base_prefix','stdlib','include'):assert Path(identity[k]).resolve().is_relative_to(destination.resolve())
assert Path(sys.executable).absolute().is_relative_to(root)
assert Path(sys.prefix).resolve()==root/'.venv'
print(json.dumps(dict(verified=True,installation_manifest_sha256=manifest,interpreter_sha256=sha(exe.read_bytes()),entries=len(entries),identity=identity,venv_executable=sys.executable,venv_prefix=sys.prefix,copied_during_postcommit_capture=False),indent=2))
