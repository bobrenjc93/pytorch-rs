import gzip,hashlib,json
from pathlib import Path
root=Path.cwd();d=root/'docs/diagnostics/compile-cuda-module-reshape'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p):return json.loads((d/p).read_text())
base=json.loads(gzip.decompress((d/'base-source-manifest.json.gz').read_bytes()))
for key,delta in js('source-manifests.json')['snapshots'].items():
 files={k:v for k,v in base.items() if k not in delta['removed']}|delta['changed']
 assert sha(json.dumps(files,sort_keys=True).encode())==key
 for path,h in delta['changed'].items():assert sha(gzip.decompress((d/'source-blobs'/(h+'.gz')).read_bytes()))==h
commands=js('commands.json')
for name,r in commands.items():
 assert sha(gzip.decompress((d/r['log']).read_bytes()))==r['log_sha256'],name
 assert r['source_snapshot'] in js('source-manifests.json')['snapshots']
for name,r in js('frozen-manifest.json').items():
 raw=gzip.decompress((d/'frozen'/(name+'.gz')).read_bytes());assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
build_base=json.loads(gzip.decompress((d/'builds/base-source.json.gz').read_bytes()))
for name,r in js('builds.json').items():
 if r['source_inventory'].endswith('.gz'):files=build_base
 else:
  delta=js(r['source_inventory']);files={k:v for k,v in build_base.items() if k not in delta['removed']}|delta['changed']
 assert sha(json.dumps(files,sort_keys=True).encode())==r['source_manifest_sha256'],name
selection=js('compiler-partition.json');summary=js('compiler-summary.json')
assert summary['complete'] and len(selection)==summary['modules']
expected=sorted(str(p.relative_to(root)) for p in set(root.glob('tests/test_compile*.py'))|{root/'tests/test_top_level_compile.py'})
actual=[p for group in selection.values() for p in group]
assert sorted(actual)==expected and len(actual)==len(set(actual))
# Every selected module and production input matches the final source.
# The method-reshape placeholder was corrected before its sweep subprocess;
# earlier processes do not import that test module. Full snapshots retain both versions.
for name in selection:
 r=commands['sweep-'+name];assert r['status']==0
 delta=js('source-manifests.json')['snapshots'][r['source_snapshot']]
 files={k:v for k,v in base.items() if k not in delta['removed']}|delta['changed']
 for p,h in files.items():
  if p.startswith(('src/', 'python/')) or p in selection[name]:
   assert sha((root/p).read_bytes())==h,(name,p)
print(json.dumps(dict(verified=True,commands=len(commands),compiler=summary,lossless_test_source_reconstruction=True,all_selected_test_modules_and_production_match_worktree=True),indent=2))
