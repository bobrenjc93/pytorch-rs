export task_root="$PWD"
unset PYTHONPATH PYTHONHOME CONDA_PREFIX
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export CARGO_HOME="$PWD/target/cargo-home" CARGO_TARGET_DIR="$PWD/target/build" CARGO_BUILD_JOBS=8
export UV_CACHE_DIR="$PWD/target/uv-cache" UV_PYTHON_INSTALL_DIR="$PWD/target/uv-python" UV_PYTHON_BIN_DIR="$PWD/target/python-bin" UV_PROJECT_ENVIRONMENT="$PWD/.venv"
export TMPDIR="$PWD/target/tmp" XDG_CACHE_HOME="$PWD/target/xdg-cache" CUDA_CACHE_PATH="$PWD/target/cuda-cache" TORCHINDUCTOR_CACHE_DIR="$PWD/target/inductor-cache" TRITON_CACHE_DIR="$PWD/target/triton-cache"
export VIRTUAL_ENV="$PWD/.venv" PYO3_PYTHON="$PWD/.venv/bin/python" RUSTUP_TOOLCHAIN=1.92.0
export CUDA_VISIBLE_DEVICES=0 TORCH_RS_CUDART="$PWD/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
mkdir -p "$TMPDIR" "$XDG_CACHE_HOME" "$CUDA_CACHE_PATH" "$TORCHINDUCTOR_CACHE_DIR" "$TRITON_CACHE_DIR"

export GIT_OPTIONAL_LOCKS=0
