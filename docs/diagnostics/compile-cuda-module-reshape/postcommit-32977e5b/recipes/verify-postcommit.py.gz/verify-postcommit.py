"""Verify the published measurements and the artifact-only follow-up diff."""
import gzip, hashlib, json, re, subprocess
from pathlib import Path
root=Path.cwd();d=root/'docs/diagnostics/compile-cuda-module-reshape/postcommit-32977e5b';head='32977e5dbab09e4b069dad921286d31697ecadb5'
def sha(b):return hashlib.sha256(b).hexdigest()
def unpack(p):return gzip.decompress((d/p).read_bytes())
def js(p):return json.loads((d/p).read_text())
build=json.loads(unpack('build-record.json.gz'));commands=json.loads(unpack('commands.json.gz'));snapshots=json.loads(unpack('source-snapshots.json.gz'))
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert build['measured_code_commit']==head and build['source_matches_commit'] and build['origin_status']==''
assert sha(json.dumps(build['source_files'],sort_keys=True).encode())==build['source_manifest_sha256']
for key,files in snapshots.items():
 assert sha(json.dumps(files,sort_keys=True).encode())==key
 for path,h in files.items():assert sha((root/path).read_bytes())==h==build['source_files'][path],path
for name,r in commands.items():
 assert r['head']==head and r['status_before']=='' and r['status']==0,name
 raw_text=json.loads(unpack('raw-receipts.json.gz'))[name]
 assert sha(raw_text.encode())==r['raw_receipt_sha256']
 raw_receipt=json.loads(raw_text)
 for key in ('command','head','status_before','status','source_snapshot','log_sha256','environment','effective_mask','started','finished'):
  assert raw_receipt[key]==r[key],(name,key)
 assert r['source_snapshot'] in snapshots
 assert sha(unpack(r['log']))==r['log_sha256'],name
 assert Path(r['cwd']).resolve()==root
 if 'python_native' in r:
  ident=json.loads(r['python_native']['output']);assert ident['sha256']==build['installed_native_sha256']
  for k in ('executable','prefix','native'):assert Path(ident[k]).absolute().is_relative_to(root)
for key in ('source_root','wheel','installed_package','installed_native','build_target'):assert Path(build[key]).resolve().is_relative_to(root)
assert sha(Path(build['wheel']).read_bytes())==build['wheel_sha256']
assert sha(Path(build['installed_native']).read_bytes())==build['installed_native_sha256']
partition=js('compiler-partition.json');summary=js('compiler-summary.json')
expected=sorted(str(p.relative_to(root)) for p in set(root.glob('tests/test_compile*.py'))|{root/'tests/test_top_level_compile.py'})
actual=[p for group in partition.values() for p in group]
assert sorted(actual)==expected and len(actual)==len(set(actual))==summary['modules']==64
receipts=[commands['sweep-'+name] for name in partition]
assert summary['run']==sum(r['unittest']['run'] for r in receipts)
assert summary['skipped']==sum(r['unittest'].get('skipped',0) for r in receipts)
assert summary['warnings']==sum(len(r['warnings']) for r in receipts)
assert summary['statuses']==js('compiler-statuses.json')=={name:commands['sweep-'+name]['status'] for name in partition}
candidate_text=unpack(commands['candidate']['log']).decode();candidate=json.loads(candidate_text[candidate_text.index('{'):])
assert candidate['commit']==head and candidate['native_extension_sha256']==build['installed_native_sha256']
assert candidate['probe_sha256']==sha(unpack('recipes/candidate.py.gz'))
assert len(candidate['cases'])==144 and len(candidate['unrelated_rebindings'])==4
assert candidate['resolved_native_rejections']==96 and candidate['strict_gap_closures']==94
assert candidate['reference_metadata_ineligible_cases']==2
for name,record in js('recipe-adaptations.json').items():
 assert sha(gzip.decompress((d/record['original']).read_bytes()))==record['original_sha256']
 assert sha(unpack('recipes/'+name+'.gz'))==record['current_sha256']
history=js('historical-inputs.json')
assert sha(gzip.decompress((d/history['baseline_log']).read_bytes()))==history['baseline_raw_sha256']
assert sha((d/history['frozen_manifest']).read_bytes())==history['frozen_manifest_sha256']
# Only the capture and two navigation paragraphs may differ from the measured commit.
allowed={'docs/diagnostics/compile-cuda-module-reshape/README.md','docs/compile-cuda-reshape.md'}
tracked=subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
assert set(tracked)<=allowed,tracked
prefix=str(d.relative_to(root))+'/'
assert all(p.startswith(prefix) for p in untracked),untracked
# Historical measurement bytes are immutable; README navigation is the only exception.
for p,h in build['source_files'].items():
 if p.startswith('docs/diagnostics/compile-cuda-module-reshape/') and p not in allowed:assert sha((root/p).read_bytes())==h,p
subprocess.run(['git','diff','--check'],check=True)
# Validate the Markdown links introduced by publication, including gzip evidence.
for p in (d/'README.md',root/'docs/compile-cuda-reshape.md',d.parent/'README.md'):
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in link and not link.startswith('#'):assert (p.parent/link.split('#',1)[0]).exists(),(p,link)
print(json.dumps(dict(verified=True,measured_code_commit=head,clean_measurement_commands=len(commands),compiler=summary,source_and_installed_wheel_verified=True,historical_measurement_bytes_unchanged=True,artifact_only_followup=True,changed_tracked_paths=tracked,performance_credit=False),indent=2))
