import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();head='32977e5dbab09e4b069dad921286d31697ecadb5'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
status=subprocess.check_output(['git','status','--porcelain'],text=True)
assert status==''
build=json.loads((root/'target/cuda-add-diagnostic/module-reshape-postcommit-32977e5b/build-record.json').read_text())
for p,h in build['source_files'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
print(json.dumps(dict(verified=True,measured_code_commit=head,git_status=status,source_files_verified=len(build['source_files']),source_manifest_sha256=build['source_manifest_sha256']),indent=2))
