import json,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
root=Path.cwd()
files=sorted(set(root.glob('tests/test_compile*.py')) | {root/'tests/test_top_level_compile.py'})
assert len(files)==len(set(files))
partition={f.stem:[str(f.relative_to(root))] for f in files}
assert sorted(p for group in partition.values() for p in group)==sorted(str(f.relative_to(root)) for f in files)
(root/'target/reshape-postcommit-32977e5b/compiler-partition.json').write_text(json.dumps(partition,indent=2))
statuses={}
def run_file(f):
 command=[sys.executable,'target/reshape-postcommit-32977e5b/recipes/run.py','sweep-'+f.stem,sys.executable,'-m','unittest','-v','tests.'+f.stem]
 return f.stem,subprocess.run(command).returncode
# File-isolated correctness only; prioritize the longest existing module.
ordered=sorted(files,key=lambda f:(f.stem!='test_compile_cuda_module_transpose',f.name))
with ThreadPoolExecutor(max_workers=3) as pool:
 for name,status in pool.map(run_file,ordered): statuses[name]=status
(root/'target/reshape-postcommit-32977e5b/compiler-statuses.json').write_text(json.dumps(statuses,indent=2))
assert not any(statuses.values()), statuses
