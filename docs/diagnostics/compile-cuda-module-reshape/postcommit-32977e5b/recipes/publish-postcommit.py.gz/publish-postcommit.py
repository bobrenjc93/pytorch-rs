"""Package only observed clean-commit evidence; no workloads or scores are changed."""
import difflib, gzip, hashlib, io, json, re, subprocess, tarfile
from pathlib import Path
root=Path.cwd(); src=root/'target/reshape-postcommit-32977e5b'; historical=root/'docs/diagnostics/compile-cuda-module-reshape'
dst=historical/'postcommit-32977e5b'; head='32977e5dbab09e4b069dad921286d31697ecadb5'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value):
 p=dst/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def packed(name,raw):
 p=dst/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(raw,mtime=0))
def totals(text):
 m=re.search(r'Ran (\d+) tests? in ([\d.]+)s',text)
 if not m:return None
 end=text[m.end():];counts={k:int(v) for k,v in re.findall(r'(failures|errors|skipped|expected failures|unexpected successes)=(\d+)',end)}
 return dict(run=int(m[1]),**counts,summary=end.strip().splitlines()[0])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
assert not dst.exists()
records={}
for p in sorted(src.glob('*.json')):
 rec=json.loads(p.read_text())
 if not isinstance(rec,dict) or 'command' not in rec:continue
 label=p.stem;raw=(src/(label+'.log')).read_bytes()
 assert sha(raw)==rec['log_sha256']
 assert rec['head']==head and rec['status_before']=='' and rec['status']==0,(label,rec)
 assert Path(rec['cwd']).resolve()==root
 rec['raw_receipt_sha256']=sha(p.read_bytes())
 rec['log']='logs/'+label+'.log.gz';rec['unittest']=totals(raw.decode())
 rec['warnings']=[s for s in raw.decode().splitlines() if re.search(r'\w+Warning:',s)]
 rec['rust_results']=re.findall(r'test result: .*',raw.decode())
 # Standalone Rust and the build launcher do not claim a pre-command Python identity.
 if 'cargo' in rec['command'] or label=='build':rec.pop('python_native',None)
 records[label]=rec
required={'build','candidate','provenance','historical-audit','interpreter-audit','focused','hidden','restoration','rust-default-graph','rust-binding-graph','rust-binding-hidden','fmt','clippy','clippy-bindings','docs','doc-example','evidence-audit','native-extension','compiler-sweep','clean-source','rust-default-cuda-layout','rust-default-hidden-layout'}
assert required<=records.keys(),required-records.keys()
builddir=root/'target/cuda-add-diagnostic/module-reshape-postcommit-32977e5b'
build=json.loads((builddir/'build-record.json').read_text())
assert build['measured_code_commit']==head and build['source_matches_commit'] and not build['origin_status']
assert sha(json.dumps(build['source_files'],sort_keys=True).encode())==build['source_manifest_sha256']
assert sha(Path(build['installed_native']).read_bytes())==build['installed_native_sha256']
assert sha(Path(build['wheel']).read_bytes())==build['wheel_sha256']
# Full commit archive proves every executed source version can be reconstructed losslessly.
archive=subprocess.check_output(['git','archive',head])
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for path,h in build['source_files'].items():assert sha(tar.extractfile(path).read())==h,path
snapshots={}
for key in {r['source_snapshot'] for r in records.values()}:
 files=json.loads((src/'snapshots'/key/'manifest.json').read_text())
 assert sha(json.dumps(files,sort_keys=True).encode())==key
 for path,h in files.items():assert build['source_files'][path]==h==sha((root/path).read_bytes()),path
 snapshots[key]=files
for name,r in records.items():
 if 'python_native' in r:
  identity=json.loads(r['python_native']['output']);assert r['python_native']['status']==0
  assert identity['sha256']==build['installed_native_sha256']
  for k in ('executable','prefix','native'):assert Path(identity[k]).absolute().is_relative_to(root)
selection=json.loads((src/'compiler-partition.json').read_text());statuses=json.loads((src/'compiler-statuses.json').read_text())
expected=sorted(str(p.relative_to(root)) for p in set(root.glob('tests/test_compile*.py'))|{root/'tests/test_top_level_compile.py'})
actual=[p for paths in selection.values() for p in paths]
assert sorted(actual)==expected and len(actual)==len(set(actual))==64
assert set(statuses)==set(selection) and not any(statuses.values())
receipts=[records['sweep-'+name] for name in selection]
assert all(r['unittest'] and r['status']==0 for r in receipts)
summary=dict(measured_code_commit=head,complete=True,modules=len(selection),run=sum(r['unittest']['run'] for r in receipts),skipped=sum(r['unittest'].get('skipped',0) for r in receipts),warnings=sum(len(r['warnings']) for r in receipts),statuses=statuses,file_process_concurrency=3,performance_credit=False)
summary['passed']=summary['run']-summary['skipped']
# Validation completed before the first tracked evidence edit.
for name,r in records.items():
 packed(r['log'],(src/(name+'.log')).read_bytes())
packed('raw-receipts.json.gz',json.dumps({name:(src/(name+'.json')).read_text() for name in records},sort_keys=True).encode())
packed('commands.json.gz',json.dumps(records,indent=2).encode())
packed('build-record.json.gz',(builddir/'build-record.json').read_bytes())
packed('source-snapshots.json.gz',json.dumps(snapshots,sort_keys=True).encode())
for name in ('build.log','dependency_setup.log','origin.patch'):packed('build/'+name+'.gz',(builddir/name).read_bytes())
for name in ('compiler-partition.json','compiler-statuses.json'):write(name,json.loads((src/name).read_text()))
write('compiler-summary.json',summary)
recipe_names=('env.sh','run.py','sweep.py','candidate.py','provenance.py','audit.py','interpreter-audit.py','checks.sh','doc-example.py','audit-publication.py','clean-source.py','publish-postcommit.py','verify-postcommit.py')
adaptations={}
for name in recipe_names:
 raw=(src/'recipes'/name).read_bytes();packed('recipes/'+name+'.gz',raw)
 previous=historical/'recipes'/(name+'.gz')
 if previous.exists():
  old=gzip.decompress(previous.read_bytes())
  adaptations[name]=dict(original='../recipes/'+name+'.gz',original_sha256=sha(old),current_sha256=sha(raw))
  diff=''.join(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='committed/'+name,tofile='postcommit/'+name))
  if diff:packed('recipe-adaptations/'+name+'.diff.gz',diff.encode())
write('recipe-adaptations.json',adaptations)
# Frozen bytes and baseline remain historical, linked rather than republished or relabeled.
frozen=json.loads((historical/'frozen-manifest.json').read_text())
for name,r in frozen.items():assert sha((src/'frozen'/name).read_bytes())==r['sha256']
assert gzip.decompress((historical/'logs/baseline.log.gz').read_bytes())==(src/'baseline.log').read_bytes()
write('historical-inputs.json',dict(baseline_commit='6772c3405a8bc2baf70ca80106a27a390b19e9a0',baseline_log='../logs/baseline.log.gz',baseline_raw_sha256=sha((src/'baseline.log').read_bytes()),frozen_manifest='../frozen-manifest.json',frozen_manifest_sha256=sha((historical/'frozen-manifest.json').read_bytes()),bootstrap_recipe='../recipes/bootstrap.py.gz',historical_records_unchanged=True))
print(json.dumps(summary,indent=2))
