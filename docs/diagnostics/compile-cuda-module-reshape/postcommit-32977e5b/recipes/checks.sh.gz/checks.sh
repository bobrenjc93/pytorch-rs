source target/postcommit-env.sh
run() { .venv/bin/python target/reshape-postcommit-32977e5b/recipes/run.py "$@"; }
run interpreter-audit .venv/bin/python target/reshape-postcommit-32977e5b/recipes/interpreter-audit.py
run focused .venv/bin/python -m unittest -v tests.test_compile_cuda_module_reshape
run hidden env CUDA_VISIBLE_DEVICES= .venv/bin/python -m unittest -v tests.test_compile_cuda_module_reshape tests.test_compile_cuda_reshape tests.test_compile_cuda_view tests.test_compile_cuda_boundary tests.test_compile_static_analysis tests.test_reshape tests.test_reshape_reference
run restoration env CUDA_VISIBLE_DEVICES=0,1 .venv/bin/python -m unittest -v tests.test_compile_cuda_module_reshape.ModuleReshapeDeviceTests tests.test_compile_cuda_reshape.ReshapeDeviceTests tests.test_compile_cuda_module_squeeze.ModuleSqueezeDeviceTests tests.test_compile_cuda_module_relu.ModuleReluDeviceTests
run rust-default-graph env CUDA_VISIBLE_DEVICES= cargo test --locked --lib cuda_graph
run rust-binding-graph cargo test --locked --features python-bindings --lib cuda_graph
run rust-binding-hidden env CUDA_VISIBLE_DEVICES= cargo test --locked --features python-bindings --lib cuda_graph
run fmt cargo fmt --check
run clippy cargo clippy --locked --all-targets -- -D warnings
run clippy-bindings cargo clippy --locked --features python-bindings --lib -- -D warnings
run docs .venv/bin/python -m unittest -v tests.test_readme_quickstart
run doc-example .venv/bin/python target/reshape-postcommit-32977e5b/recipes/doc-example.py
