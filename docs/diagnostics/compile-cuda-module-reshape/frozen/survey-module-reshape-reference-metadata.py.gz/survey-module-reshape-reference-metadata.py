"""Survey reference metadata without changing the failed frozen reshape probe.

All original programs and input generation are executed from the original AST.
Native eager and value checks stay strict. Reference metadata discrepancies are
retained, not accepted as full parity, and no implementation gap is scored here.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys

root = Path.cwd().resolve()
probe = root / "target/probe-compiled-cuda-module-reshape.py"
raw = probe.read_bytes()
assert hashlib.sha256(raw).hexdigest() == "70fc9e24cdc6d9bfc1d829fa6e965ad767ec5ccd42225dc14352637e86e34ee0"
assert sys.argv[1:] == ["6772c3405a8bc2baf70ca80106a27a390b19e9a0"]
tree = ast.parse(raw)
loops = [node for node in tree.body if isinstance(node, ast.For) and
         isinstance(node.target, ast.Tuple) and
         [getattr(item, "id", None) for item in node.target.elts] ==
         ["label", "expression_template", "arity", "expected_gap"]]
assert len(loops) == 1
outer = loops[0]
prefix = tree.body[:tree.body.index(outer)]
namespace = {"__name__": "__main__", "__file__": str(probe)}
exec(compile(ast.Module(body=prefix, type_ignores=[]), str(probe), "exec"), namespace)
inner = outer.body[0]
assert isinstance(inner, ast.For)
names = [getattr(item, "id", None) for item in inner.target.elts]
assert names == ["shape", "requested_shape"]
body = copy.deepcopy(inner.body)
compiled_index = next(index for index, node in enumerate(body) if
    isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and
    target.id == "compiled" for target in node.targets))
body = body[:compiled_index]
reference_loop = next(node for node in body if isinstance(node, ast.For) and
                      isinstance(node.target, ast.Name) and node.target.id == "_")
comparison = reference_loop.body[-1]
assert isinstance(comparison, ast.Assert)
assert ast.unparse(comparison.test) == "metadata(actual_reference) == metadata(expected)"
reference_loop.body[-1] = ast.parse(
    "reference_observations.append(dict(equal=metadata(actual_reference) == metadata(expected), "
    "reference_metadata=metadata(actual_reference), eager_metadata=metadata(expected)))").body[0]
code = compile(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[])), str(probe), "exec")
cases = []
for label, expression_template, arity, expected_gap in namespace["specifications"]:
    for shape, requested_shape in namespace["layouts"]:
        namespace.update(label=label, expression_template=expression_template, arity=arity,
                         expected_gap=expected_gap, shape=shape, requested_shape=requested_shape,
                         reference_observations=[])
        exec(code, namespace)
        cases.append({"name": label, "shape": list(shape), "requested_shape": list(requested_shape),
                      "expression": namespace["expression"], "expected_native_gap": expected_gap,
                      "input_sha256": [hashlib.sha256(value.tobytes()).hexdigest() for value in namespace["data"]],
                      "reference_observations": namespace["reference_observations"],
                      "native_eager_strictly_matches_reference_eager": True,
                      "reference_compilation_and_values_passed": True})
assert len(cases) == 144
assert namespace["source_provenance"]() == namespace["source_before"]
mismatches = [case for case in cases if not all(row["equal"] for row in case["reference_observations"])]
print(json.dumps({"reference_survey_completed": True, "survey_only_not_gap_evidence": True,
                  "commit": namespace["head"], "source_provenance": namespace["source_before"],
                  "probe_sha256": hashlib.sha256(raw).hexdigest(),
                  "survey_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "all_original_cases_retained": True, "case_count": len(cases), "cases": cases,
                  "strict_reference_metadata_mismatch_cases": len(mismatches),
                  "mismatches": mismatches, "native_compilation_tested": False,
                  "scores_changed": False}, indent=2))
