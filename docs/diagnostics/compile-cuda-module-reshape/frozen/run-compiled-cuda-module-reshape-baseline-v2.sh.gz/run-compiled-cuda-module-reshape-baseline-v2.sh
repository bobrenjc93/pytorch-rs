#!/usr/bin/env bash
# V2 reuses the freshly built exact-main wheel from the preserved failed probe.
# Reference caches were warmed by that failure and its diagnostic survey.
# No timing claim, new build, package copy, or implementation change is made.
set -euo pipefail
task_root=/data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/probe-compiled-cuda-module-reshape
cd "$task_root"
test "$#" -eq 1
[[ "$1" =~ ^[0-9a-f]{40}$ ]]
test "$(git rev-parse HEAD)" = "$1"
test "$(git rev-parse main)" = "$1"
test -z "$(git status --porcelain)"
jq -e --arg task_head "$1" '.verified == true and .prNumber == 1986 and .main == $task_head and .allTenBaselinesPromoted == true' /tmp/pytorch-rs-compiler-recovery.3UB6mU/merge-1986-verified.json
test -x .venv/bin/python
test -f target/release/build-record.json
test -f target/probe-compiled-cuda-module-reshape-v2.py
test "$(sha256sum target/probe-compiled-cuda-module-reshape-v2.py | cut -d ' ' -f 1)" = 058e9ae774afbb977a14246e4370043fee28eda93dfd6540f48a29ff25946c7c
test -f target/root-preflight.py
test "$(sha256sum target/root-preflight.py | cut -d ' ' -f 1)" = 8a5e24fc2c80a21f8ea26044c74a4fb5f3d7ea4b28bd0a37e9ddb5c471838b21
unset PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1
export CARGO_HOME="$task_root/target/local-cargo"
export CARGO_TARGET_DIR="$task_root/target/release-build"
export UV_CACHE_DIR="$task_root/target/uv-cache"
export UV_PYTHON_INSTALL_DIR="$task_root/target/uv-python"
export UV_PYTHON_BIN_DIR="$task_root/target/python-bin"
export UV_PROJECT_ENVIRONMENT="$task_root/.venv"
export TMPDIR="$task_root/target/tmp"
export XDG_CACHE_HOME="$task_root/target/xdg-cache"
export CUDA_CACHE_PATH="$task_root/target/cuda-cache"
export TORCHINDUCTOR_CACHE_DIR="$task_root/target/inductor-cache"
export TRITON_CACHE_DIR="$task_root/target/triton-cache"
export PYTHONPYCACHEPREFIX="$task_root/target/pycache"
export VIRTUAL_ENV="$task_root/.venv"
export PYO3_PYTHON="$task_root/.venv/bin/python"
export CUDA_VISIBLE_DEVICES=0
export TORCH_RS_CUDART="$task_root/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
mkdir -p target/local-cargo target/uv-cache target/tmp target/xdg-cache target/cuda-cache target/inductor-cache target/triton-cache target/pycache
test -x "$task_root/target/uv-python/cpython-3.12.14-linux-x86_64-gnu/bin/python3.12"
test "$(sha256sum "$task_root/target/uv-python/cpython-3.12.14-linux-x86_64-gnu/bin/python3.12" | cut -d ' ' -f 1)" = f7c6210eb40fadcd3c2889dddd24a15fc2c9f926aec5a03bf9da66e12d581526
jq -e --arg task_head "$1" '.commit == $task_head and .source_sha256 == "c72cbef260d6c7f82cd2394856671df8d7886e2e3f0de03d5ff0764f1b85223e" and .extension_sha256 == "be4770c0d5982ce914e8bd62e99b924bdd56cfe2da93f67a7d69c0499c8bb46f" and .clean_checkout == true and .source_unchanged_during_build == true' target/release/build-record.json
TORCH_RS_VERIFY_VIRTUALENV="$task_root/.venv" .venv/bin/python .github/scripts/verify_native_extension.py
.venv/bin/python target/root-preflight.py target/release/build-record.json
.venv/bin/python target/probe-compiled-cuda-module-reshape-v2.py "$1"
git status --short
