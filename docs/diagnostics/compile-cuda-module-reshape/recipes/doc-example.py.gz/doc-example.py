import torch_rs as torch

def flatten_transpose(x):
    return torch.reshape(x.t(), [-1])

x = torch.tensor([[1., 2., 3.], [4., 5., 6.]]).to("cuda:0")
f = torch.compile(flatten_transpose, backend="eager", fullgraph=True)
y = f(x)
assert y.cpu().tolist() == [1., 4., 2., 5., 3., 6.]
assert y.data_ptr() != x.data_ptr()
