"""Non-scoring reshape baseline v2: preserve all original cases and failures.

The unchanged first probe stopped on an eager-versus-Inductor empty-result
stride difference. An independent reference-only survey found exactly two such
cases. They remain in this matrix but earn zero strict-parity credit. Native
outputs still have to match eager values and metadata exactly for every case.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from unittest.mock import patch

import numpy as np
import torch
import torch_rs as native

root = Path.cwd().resolve()
sys.path.insert(0, str(root))
from tests.test_cuda_contiguous import metadata
from scripts.evaluate_cuda_math import source_provenance


def program_for(expression, arity, module):
    namespace = {"__name__": __name__, "m": module,
                 "reshape_alias": module.reshape}
    arguments = "x" if arity == 1 else "x, y"
    exec(f"def program({arguments}):\n    return {expression}\n", namespace)
    return namespace["program"]


def no_original_body(program, callback):
    def reject(frame, event, argument):
        if event == "call" and frame.f_code is program.__code__:
            raise AssertionError("native compiled execution entered original Python body")
    previous = sys.getprofile()
    try:
        sys.setprofile(reject)
        return callback()
    finally:
        sys.setprofile(previous)


def compare(actual, expected):
    assert metadata(actual) == metadata(expected)
    np.testing.assert_allclose(
        np.asarray(actual.cpu().tolist(), dtype=np.float32).reshape(tuple(actual.shape)),
        expected.detach().cpu().numpy(), rtol=0, atol=0)


def gap(callback):
    try:
        callback()
    except NotImplementedError as error:
        assert type(error).__name__ == "CompileTraceUnsupportedError", repr(error)
        return {"type": type(error).__name__, "message": str(error)}
    raise AssertionError("Expected the native-module reshape capture gap on main")


head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert len(sys.argv) == 2 and re.fullmatch(r"[0-9a-f]{40}", sys.argv[1]) and head == sys.argv[1]
assert subprocess.check_output(["git", "rev-parse", "main"], text=True).strip() == head
promotion = json.loads(Path("/data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_21283913/target/reshape-evidence/frozen/merge-1986-verified.json").read_text())
assert promotion["verified"] and promotion["main"] == head and promotion["allTenBaselinesPromoted"]
assert subprocess.check_output(["git", "status", "--porcelain"], text=True) == ""
assert os.environ["CUDA_VISIBLE_DEVICES"] == "0"
assert torch.cuda.is_available() and torch.cuda.device_count() == 1
assert torch.cuda.get_device_name(0) == "NVIDIA H100"
assert Path(sys.prefix).resolve() == root / ".venv"
assert Path(native._C.__file__).resolve().is_relative_to(root / ".venv")

source_before = source_provenance()
assert source_before["source_sha256"] == "c72cbef260d6c7f82cd2394856671df8d7886e2e3f0de03d5ff0764f1b85223e"
assert source_before["commit"] == head
assert native.reshape is native._C.reshape
owner_contains_reshape = hasattr(native._C._VariableFunctionsClass, "reshape")
owner_reshape_is_genuine = owner_contains_reshape and native.reshape is native._C._VariableFunctionsClass.reshape
survey_path = Path("/data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_21283913/target/reshape-evidence/frozen/compiled-cuda-module-reshape-reference-metadata-survey.json")
survey_raw = survey_path.read_bytes()
assert hashlib.sha256(survey_raw).hexdigest() == "794ce27b74b5ab88bbbd34ca064208d48da57c62f1391770c68cf329fc69b8aa"
survey = json.loads(survey_raw)
assert survey["reference_survey_completed"] and survey["commit"] == head
assert survey["probe_sha256"] == "70fc9e24cdc6d9bfc1d829fa6e965ad767ec5ccd42225dc14352637e86e34ee0"
reference_exclusions = {
    (case["name"], tuple(case["shape"]), tuple(case["requested_shape"])): case
    for case in survey["mismatches"]}
assert set(reference_exclusions) == {
    ("module_reshape_after_add", (0, 3), (3, 0)),
    ("imported_reshape_after_add", (0, 3), (3, 0))}
specifications = (
    ("module_reshape_tuple", "m.reshape(x, {requested_tuple})", 1, True),
    ("imported_reshape_tuple", "reshape_alias(x, {requested_tuple})", 1, True),
    ("module_reshape_list", "m.reshape(x, {requested_list})", 1, True),
    ("imported_reshape_list", "reshape_alias(x, {requested_list})", 1, True),
    ("module_reshape_after_add", "m.reshape(x + x, {requested_tuple})", 1, True),
    ("imported_reshape_after_add", "reshape_alias(x + x, {requested_tuple})", 1, True),
    ("module_reshape_before_relu", "m.relu(m.reshape(x, {requested_tuple}))", 1, True),
    ("imported_reshape_before_relu", "m.relu(reshape_alias(x, {requested_tuple}))", 1, True),
    ("existing_method_reshape", "x.reshape({requested_tuple})", 1, False),
    ("existing_module_transpose", "m.transpose(x, 0, 0)", 1, False),
    ("existing_module_t", "m.t(x)", 1, False),
    ("existing_module_squeeze", "m.squeeze(x)", 1, False),
)
layouts = (
    ((), ()),
    ((), (1,)),
    ((), (1, 1)),
    ((6,), (2, 3)),
    ((6,), (-1, 2)),
    ((6,), (6,)),
    ((2, 3), (3, 2)),
    ((2, 3), (6,)),
    ((2, 3), (-1,)),
    ((0, 3), (0, 3)),
    ((0, 3), (3, 0)),
    ((0, 3), (0,)),
)
view_labels = {"module_reshape_tuple", "imported_reshape_tuple",
               "module_reshape_list", "imported_reshape_list",
               "existing_method_reshape", "existing_module_transpose",
               "existing_module_t", "existing_module_squeeze"}
rng = np.random.default_rng(198701)
cases = []
for label, expression_template, arity, expected_gap in specifications:
    for shape, requested_shape in layouts:
        expression = expression_template.format(requested_tuple=repr(requested_shape), requested_list=repr(list(requested_shape)))
        # Exact dyadic inputs; no special-value or performance claim is made.
        data = [np.asarray(rng.integers(-31, 32, size=shape) * .125, dtype=np.float32)
                for _ in range(arity)]
        args = [native.tensor(value.reshape(-1)).reshape(shape).to("cuda:0") for value in data]
        refs = [torch.tensor(value.reshape(-1), device="cuda:0").reshape(shape) for value in data]
        for actual, expected in zip(args, refs):
            assert metadata(actual) == metadata(expected), (label, shape, requested_shape)
        program = program_for(expression, arity, native)
        reference_program = program_for(expression, arity, torch)
        expected = reference_program(*refs)
        eager = program(*args)
        compare(eager, expected)
        assert all(eager is not arg for arg in args)
        if label in view_labels:
            assert eager.data_ptr() == args[0].data_ptr()
            assert expected.data_ptr() == refs[0].data_ptr()
        torch._dynamo.reset()
        reference = torch.compile(reference_program, backend="inductor", fullgraph=True, dynamic=False)
        case_key = (label, shape, requested_shape)
        reference_strict_parity_eligible = case_key not in reference_exclusions
        reference_metadata_divergences = []
        for _ in range(2):
            actual_reference = reference(*refs)
            torch.testing.assert_close(actual_reference, expected, rtol=0, atol=0)
            if reference_strict_parity_eligible:
                assert metadata(actual_reference) == metadata(expected)
            else:
                # These two retained cells are explicitly ineligible for strict
                # parity; enforce their observed discrepancy, not a tolerance.
                observed = {
                    "equal": metadata(actual_reference) == metadata(expected),
                    "reference_metadata": json.loads(json.dumps(metadata(actual_reference))),
                    "eager_metadata": json.loads(json.dumps(metadata(expected)))}
                assert observed == reference_exclusions[case_key]["reference_observations"][_]
                assert observed["equal"] is False
                assert observed["reference_metadata"][1] == [0, 0]
                assert observed["eager_metadata"][1] == [1, 1]
                assert observed["reference_metadata"][:1] + observed["reference_metadata"][2:] == observed["eager_metadata"][:1] + observed["eager_metadata"][2:]
                reference_metadata_divergences.append(observed)
        compiled = no_original_body(program, lambda: native.compile(
            program, backend="eager", fullgraph=True, dynamic=False))
        results = []
        for call in ("cold", "repeat"):
            invoke = lambda: no_original_body(program, lambda: compiled(*args))
            if expected_gap:
                results.append({"call": call, "unsupported": gap(invoke)})
            else:
                actual = invoke()
                compare(actual, expected)
                assert all(actual is not arg for arg in args)
                if label in view_labels:
                    assert actual.data_ptr() == args[0].data_ptr()
                results.append({"call": call, "passed": True})
        for actual, reference_input in zip(args, refs):
            compare(actual, reference_input)
        cases.append({"name": label, "expression": expression, "arity": arity,
                      "shape": list(shape), "requested_shape": list(requested_shape), "expected_gap": expected_gap,
                      "input_sha256": [hashlib.sha256(value.tobytes()).hexdigest() for value in data],
                      "native_eager_passed": True,
                      "reference_inductor_cold_and_repeat_passed": reference_strict_parity_eligible,
                      "reference_compilation_and_values_passed": True,
                      "reference_strict_parity_eligible": reference_strict_parity_eligible,
                      "reference_metadata_divergences": reference_metadata_divergences,
                      "original_native_program_body_not_executed": True, "native_calls": results})

unrelated_rebindings = []
for expression, reference_callback in (
    ("m.t(x)", lambda x: x.t()),
    ("m.relu(x)", lambda x: x.relu()),
    ("m.squeeze(x)", lambda x: x.squeeze()),
    ("m.transpose(x, 0, 0)", lambda x: x.transpose(0, 0)),
):
    calls = []
    def forbidden(*args, **kwargs):
        calls.append(True)
        raise AssertionError("executed unrelated replacement callable")
    program = program_for(expression, 1, native)
    x = native.tensor([1., -2., 3.]).to("cuda:0")
    tx = torch.tensor([1., -2., 3.], device="cuda:0")
    expected = reference_callback(tx)
    compiled = native.compile(program, backend="eager", fullgraph=True, dynamic=False)
    compare(no_original_body(program, lambda: compiled(x)), expected)
    with patch.object(native, "reshape", forbidden):
        compare(no_original_body(program, lambda: compiled(x)), expected)
        cold = native.compile(program, backend="eager", fullgraph=True, dynamic=False)
        compare(no_original_body(program, lambda: cold(x)), expected)
    assert not calls
    unrelated_rebindings.append({"attribute": "reshape", "expression": expression,
                                 "existing_module_program_preserved": True,
                                 "replacement_callback_calls": len(calls)})

assert len(cases) == 144 and sum(case["expected_gap"] for case in cases) == 96
assert subprocess.check_output(["git", "status", "--porcelain"], text=True) == ""
assert source_provenance() == source_before
for current, previous in zip(cases, survey["cases"], strict=True):
    for key in ("name", "expression", "shape", "requested_shape", "input_sha256"):
        assert current[key] == previous[key], (key, current["name"])
    assert current["expected_gap"] == previous["expected_native_gap"]
assert sum(case["reference_strict_parity_eligible"] for case in cases) == 142
assert sum(case["expected_gap"] and case["reference_strict_parity_eligible"] for case in cases) == 94
assert sum(not case["reference_strict_parity_eligible"] for case in cases) == 2
print(json.dumps({"verified_baseline_gap": True, "commit": head,
                  "diagnostic_protocol_version": 2,
                  "original_probe_sha256": survey["probe_sha256"],
                  "reference_metadata_survey_sha256": hashlib.sha256(survey_raw).hexdigest(),
                  "all_original_cases_and_input_bytes_unchanged": True,
                  "strict_reference_eligible_cases": 142,
                  "strict_reference_eligible_gap_cases": 94,
                  "reference_metadata_ineligible_cases": 2,
                  "reference_exclusion_policy": "Two retained empty-result stride divergences earn zero strict-parity credit; no cases are omitted and native eager metadata remains exact.",
                  "source_provenance": source_before,
                  "genuine_reshape_is_native_module_function": True,
                  "variable_function_owner_contains_reshape": owner_contains_reshape,
                  "variable_function_owner_reshape_is_genuine": owner_reshape_is_genuine,
                  "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "metadata_helper_sha256": hashlib.sha256((root / "tests/test_cuda_contiguous.py").read_bytes()).hexdigest(),
                  "native_extension": native._C.__file__,
                  "native_extension_sha256": hashlib.sha256(Path(native._C.__file__).read_bytes()).hexdigest(),
                  "reference": torch.__version__, "gpu": torch.cuda.get_device_name(0),
                  "cases": cases, "unrelated_rebindings": unrelated_rebindings,
                  "gap_cases": 96, "existing_positive_cases": 48,
                  "reference_compile_backend": "inductor", "native_compile_backend": "eager",
                  "native_backend_note": "Native CUDA graph capture/execution; original program body forbidden",
                  "cuda_performance_measured": False, "scores_changed": False,
                  "physical_gpu_snapshot_after": subprocess.check_output(["nvidia-smi",
                      "--query-gpu=index,uuid,name,utilization.gpu,memory.used", "--format=csv,noheader"], text=True),
                  "gpu_snapshot_is_not_reservation": True}, indent=2))
