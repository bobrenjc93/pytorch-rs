import os,sys,json,hashlib,subprocess,time,gzip
from pathlib import Path
root=Path.cwd(); out=root/'target/reshape-evidence'; out.mkdir(exist_ok=True)
name=sys.argv[1]; cmd=sys.argv[2:]
def sha(b):return hashlib.sha256(b).hexdigest()
def capture(cmd):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);return {'status':p.returncode,'output':p.stdout}
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')[:-1]
files={p:sha((root/p).read_bytes()) for p in paths if Path(p).is_file() and (p.startswith(('python/','src/','tests/')) or p in ('Cargo.toml','Cargo.lock','pyproject.toml','uv.lock','rust-toolchain.toml'))}
key=sha(json.dumps(files,sort_keys=True).encode()); snap=out/'snapshots'/key;snap.mkdir(parents=True,exist_ok=True)
(snap/'manifest.json').write_text(json.dumps(files,indent=2))
# Content-addressed lossless snapshots, including every executed test version.
blob=out/'blobs';blob.mkdir(exist_ok=True)
for p,h in files.items():
 dest=blob/(h+'.gz')
 if not dest.exists():dest.write_bytes(gzip.compress(Path(p).read_bytes(),mtime=0))
env={k:v for k,v in os.environ.items() if k.startswith(('CUDA','TORCH','TRITON','PYO3','PYTHON','UV_','CARGO_','RUSTUP_','XDG_')) or k in ('TMPDIR','VIRTUAL_ENV')}
rec={'command':cmd,'cwd':str(root),'source_snapshot':key,'environment':env,'head':capture(['git','rev-parse','HEAD'])['output'].strip(),'status_before':capture(['git','status','--short'])['output'],'started':time.time(),'gpu_before':capture(['nvidia-smi','--query-gpu=index,uuid,name,utilization.gpu,memory.used,driver_version','--format=csv'])}
# env overrides are retained in argv; record effective mask as well.
rec['effective_mask']=next((x.split('=',1)[1] for x in cmd if x.startswith('CUDA_VISIBLE_DEVICES=')),os.environ.get('CUDA_VISIBLE_DEVICES'))
if (root/'.venv/lib/python3.12/site-packages/torch_rs').exists():
 rec['python_native']=capture([str(root/'.venv/bin/python'),'-c','import torch_rs,sys,json,hashlib; from pathlib import Path; p=Path(torch_rs._C.__file__); print(json.dumps(dict(executable=sys.executable,prefix=sys.prefix,native=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())))'])
with (out/(name+'.log')).open('w') as log:
 result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
rec.update(status=result.returncode,finished=time.time(),gpu_after=capture(['nvidia-smi','--query-gpu=index,uuid,name,utilization.gpu,memory.used,driver_version','--format=csv']))
rec['log_sha256']=sha((out/(name+'.log')).read_bytes())
(out/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(name,result.returncode);sys.exit(result.returncode)
