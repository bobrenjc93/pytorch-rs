import json,subprocess,sys
from pathlib import Path
root=Path.cwd()
files=sorted(set(root.glob('tests/test_compile*.py')) | {root/'tests/test_top_level_compile.py'})
assert len(files)==len(set(files))
partition={f.stem:[str(f.relative_to(root))] for f in files}
assert sorted(p for group in partition.values() for p in group)==sorted(str(f.relative_to(root)) for f in files)
(root/'target/reshape-evidence/compiler-partition.json').write_text(json.dumps(partition,indent=2))
statuses={}
for f in files:
 command=[sys.executable,'target/run.py','sweep-'+f.stem,sys.executable,'-m','unittest','-v','tests.'+f.stem]
 statuses[f.stem]=subprocess.run(command).returncode
(root/'target/reshape-evidence/compiler-statuses.json').write_text(json.dumps(statuses,indent=2))
assert not any(statuses.values()), statuses
