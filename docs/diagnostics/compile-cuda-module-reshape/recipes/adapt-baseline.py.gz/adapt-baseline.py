from pathlib import Path
root=Path.cwd(); frozen=root/'target/reshape-evidence/frozen'
s=(frozen/'probe-compiled-cuda-module-reshape-v2.py').read_text()
s=s.replace('/tmp/pytorch-rs-compiler-recovery.3UB6mU/', str(frozen)+'/')
(root/'target/baseline.py').write_text(s)
