import sys, os, json, ctypes, hashlib, subprocess
from pathlib import Path
import torch, torch_rs as n
root=Path.cwd();sys.path.insert(0,str(root))
from scripts.evaluate_cuda_math import source_provenance, runtime_provenance
x=n.ones((2,3)).to('cuda:0');n.compile(lambda x:n.reshape(x,(3,2)),backend='eager',fullgraph=True)(x)
torch.ones(1,device='cuda:0'); torch.cuda.synchronize()
record=json.loads((root/'target/cuda-add-diagnostic/module-reshape-development-second/build-record.json').read_text())
for name,h in record['source_files'].items():
 if name.startswith(('src/','python/')) or name in ('Cargo.lock','Cargo.toml','pyproject.toml','rust-toolchain.toml','uv.lock'):
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
assert record['installed_native_sha256']==hashlib.sha256(Path(n._C.__file__).read_bytes()).hexdigest()
print(json.dumps(dict(production=source_provenance(),runtime=runtime_provenance(),torch=torch.__version__,torch_cuda=torch.version.cuda,gpu=str(torch.cuda.get_device_properties(0)),uuid=str(torch.cuda.get_device_properties(0).uuid),python=sys.version,executable=sys.executable,native=n._C.__file__,build=record['wheel_sha256'],nvcc=subprocess.check_output(['nvcc','--version'],text=True),rustc=subprocess.check_output(['rustc','--version'],text=True),mask=os.environ['CUDA_VISIBLE_DEVICES'],build_source_and_native_verified=True),indent=2))
