"""Publish compact, lossless non-scoring development evidence; no managed artifacts."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
root=Path.cwd(); src=root/'target/reshape-evidence'; dst=root/'docs/diagnostics/compile-cuda-module-reshape'
dst.mkdir(exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(name,value):
 (dst/name).parent.mkdir(parents=True,exist_ok=True)
 (dst/name).write_text(json.dumps(value,indent=2)+'\n')
def packed(name,raw):
 path=dst/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.compress(raw,mtime=0))
def totals(text):
 m=re.search(r'Ran (\d+) tests? in ([\d.]+)s',text)
 if not m:return None
 last=text[m.end():];counts={k:int(v) for k,v in re.findall(r'(failures|errors|skipped|expected failures|unexpected successes)=(\d+)',last)}
 return dict(run=int(m[1]),**counts,summary=last.strip().splitlines()[0])
base='6772c3405a8bc2baf70ca80106a27a390b19e9a0'
base_manifest=json.loads((src/'snapshots'/json.loads((src/'baseline.json').read_text())['source_snapshot']/'manifest.json').read_text())
packed('base-source-manifest.json.gz',json.dumps(base_manifest,sort_keys=True).encode())
archive=subprocess.check_output(['git','archive',base,'--',*base_manifest])
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
 for path,h in base_manifest.items():
  assert sha(tar.extractfile(path).read())==h,path
snapshots={}; blobs=set()
for p in sorted((src/'snapshots').glob('*/manifest.json')):
 m=json.loads(p.read_text());key=sha(json.dumps(m,sort_keys=True).encode());assert key==p.parent.name
 changed={k:v for k,v in m.items() if base_manifest.get(k)!=v};removed=sorted(set(base_manifest)-m.keys())
 snapshots[key]=dict(changed=changed,removed=removed)
 blobs.update(changed.values())
write('source-manifests.json',dict(base_commit=base,hash_recipe='sha256(json.dumps(files, sort_keys=True).encode())',snapshots=snapshots))
for h in blobs:
 raw=gzip.decompress((src/'blobs'/(h+'.gz')).read_bytes());assert sha(raw)==h;packed('source-blobs/'+h+'.gz',raw)
commands={}
for p in sorted(src.glob('*.json')):
 rec=json.loads(p.read_text())
 if not isinstance(rec,dict) or 'command' not in rec:continue
 label=p.stem;log=(src/(label+'.log')).read_bytes();assert sha(log)==rec['log_sha256']
 rec['log']='logs/'+label+'.log.gz';rec['unittest']=totals(log.decode())
 rec['warnings']=[line for line in log.decode().splitlines() if re.search(r'\w+Warning:',line)]
 rec['rust_results']=re.findall(r'test result: .*',log.decode())
 # An incidental native import on a Cargo receipt is not a Python test identity.
 if 'cargo' in rec['command']:rec.pop('python_native',None)
 commands[label]=rec;packed(rec['log'],log)
write('commands.json',commands)
frozen={}
for p in sorted((src/'frozen').iterdir()):
 raw=p.read_bytes();frozen[p.name]=dict(sha256=sha(raw),bytes=len(raw));packed('frozen/'+p.name+'.gz',raw)
write('frozen-manifest.json',frozen)
for name in ('bootstrap.json','compiler-partition.json','compiler-statuses.json'):
 if (src/name).exists():write(name,json.loads((src/name).read_text()))
for name in ('env.sh','bootstrap.py','adapt-baseline.py','baseline.py','candidate.py','run.py','sweep.py','provenance.py','audit.py','audit-publication.py','doc-example.py','publish.py'):
 packed('recipes/'+name+'.gz',(root/'target'/name).read_bytes())
for name in ('setup.log','sweep-launcher.log'):
 if (src/name).exists():packed('logs/'+name+'.gz',(src/name).read_bytes())
records={}
build_base=None
for path in sorted((root/'target/cuda-add-diagnostic').glob('module-reshape-*/build-record.json')):
 rec=json.loads(path.read_text());files=rec.pop('source_files');key=sha(json.dumps(files,sort_keys=True).encode())
 assert key==rec['source_manifest_sha256']
 # Entire immutable export inventory is retained once per build, compressed.
 if build_base is None:
  build_base=files
  packed('builds/base-source.json.gz',json.dumps(files,sort_keys=True).encode())
  rec['source_inventory']='builds/base-source.json.gz'
 else:
  delta=dict(changed={k:v for k,v in files.items() if build_base.get(k)!=v},removed=sorted(set(build_base)-files.keys()))
  rec['source_inventory']='builds/'+path.parent.name+'-delta.json'
  write(rec['source_inventory'],delta)
 old=dst/('builds/'+path.parent.name+'-source.json.gz')
 if old.exists(): old.unlink()
 for name in ('origin.patch','build.log','dependency_setup.log'):
  packed('builds/'+path.parent.name+'-'+name+'.gz',(path.parent/name).read_bytes())
 records[path.parent.name]=rec
write('builds.json',records)
# These are actual disjoint final-source subprocesses, not a denominator change.
selection=json.loads((src/'compiler-partition.json').read_text())
complete=all('sweep-'+name in commands for name in selection)
summary=dict(complete=complete,modules=len(selection),finished=sum('sweep-'+name in commands for name in selection))
if complete:
 receipts=[commands['sweep-'+name] for name in selection]
 assert all(r['status']==0 and r['unittest'] for r in receipts)
 summary.update(run=sum(r['unittest']['run'] for r in receipts),skipped=sum(r['unittest'].get('skipped',0) for r in receipts),warnings=sum(len(r['warnings']) for r in receipts),statuses={name:commands['sweep-'+name]['status'] for name in selection})
 summary['passed']=summary['run']-summary['skipped']
write('compiler-summary.json',summary)
print(json.dumps(summary))
