"""Verify and preserve clean-commit evidence without changing workload outcomes."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess,tarfile,zipfile
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-69a73844'
DOC=ROOT/'docs/diagnostics/compile-pointwise-structured-outputs/postcommit-69a73844'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def verify_tar(path,expected):
 seen={}
 with tarfile.open(path) as archive:
  for member in archive:
   if member.isfile():seen[member.name]=hashlib.sha256(archive.extractfile(member).read()).hexdigest()
 assert seen==expected,path
measure=json.loads((OUT/'measurements.json').read_text());runtime=json.loads((OUT/'runtime-provenance.json').read_text())
assert measure['commit']==runtime['commit']=='69a738444ee7c71044730d2bccecb735cad8b161'
assert measure['source_unchanged_after'] and measure['status_before']==measure['status_after']==''
assert runtime['status_before']==runtime['status_after']==''
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
assert all(sha(ROOT/p)==value for p,value in measure['source_sha256'].items())
assert all(c['exit_code']==(1 if c['label']=='pointwise' else 0) for c in measure['commands'])
wheel=Path(measure['wheel']['path']);assert sha(wheel)==measure['wheel']['sha256']==runtime['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
 members={name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('torch_rs/') and name.endswith(('.py','.so'))}
assert members==runtime['installed_wheel_members']
identities={}
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
 identity=json.loads((OUT/('identity-'+version+'.log')).read_text());assert identity['python'].startswith(version)
 assert {f'torch_rs/{k}':v for k,v in identity['members'].items()}==members
 identity['executable_sha256']=sha(Path(identity['executable']));identities[version]=identity
checks={}
for name in ('pointwise','two-device',*('portable-'+v for v in identities)):
 log=(OUT/(name+'.log')).read_text();found=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\n(OK|FAILED)(?: \(([^)]*)\))?',log);assert found,name
 details=found[4] or '';counts={k:int(v) for k,v in re.findall(r'(skipped|failures|errors)=(\d+)',details)}
 checks[name]={'total':int(found[1]),'passed':int(found[1])-sum(counts.values()),'skipped':counts.get('skipped',0),'failures':counts.get('failures',0),'errors':counts.get('errors',0),'seconds':float(found[2])}
 if name=='pointwise':
  failures=[line for line in log.splitlines() if line.startswith('FAIL:')]
  assert len(failures)==1 and 'test_nonlinear_large_unreturned_producer' in failures[0] and 'size=1' in failures[0]
  assert checks[name]['failures']==1 and checks[name]['errors']==0
 else:assert found[3]=='OK'
for name in ('native-pointwise','native-conversion'):
 log=(OUT/(name+'.log')).read_text();found=re.search(r'test result: ok\. (\d+) passed; (\d+) failed;',log);assert found,name
 assert 'skipping' not in log.lower();checks[name]={'passed':int(found[1]),'failed':int(found[2])}
raw_json=sorted((OUT/'raw').glob('*.json'))
for path in raw_json:
 assert set(json.loads(path.read_text()))=={'actual','expected'}
 assert path.with_suffix('.cu').exists() and path.with_suffix('.ptx').read_text().count('.visible .entry')==1
assert len(list((OUT/'raw').glob('large-unreturned-1-*.json')))==1
assert len(list((OUT/'raw').glob('history-*.json')))==52
assert len(list((OUT/'raw').glob('regions-*.json')))==1120
assert any('without PyTorch import or body replay' in p.read_text() for p in (OUT/'raw').glob('*.stdout'))
order=OUT/'order-probe';reference=json.loads((order/'results.json').read_text());native=json.loads((order/'native2_results.json').read_text());order_provenance=json.loads((order/'native2_provenance.json').read_text());ref_provenance=json.loads((order/'provenance.json').read_text())
assert order_provenance['git_head']==ref_provenance['git_head']==measure['commit']
assert order_provenance['git_status']==ref_provenance['git_status']==''
assert order_provenance['graph_equal'] and not order_provenance['result_spec_equal']
assert order_provenance['frontend_sha256']==members['torch_rs/_compile_pointwise.py']
assert order_provenance['extension']['sha256']==members['torch_rs/torch_rs.abi3.so']
assert Path(order_provenance['native_file']).resolve().is_relative_to(ROOT)
assert Path(ref_provenance['torch_file']).resolve().is_relative_to(ROOT)
assert order_provenance['nodes']==2117 and order_provenance['instructions']==[8211,8211]
assert [r['q'] for r in reference]==[[1024.0]*2,[1192.0928955078125]*2]
assert [r['q'] for r in native]==[[1024.0]*2]*2
assert all(r['executors']==1 for r in native)
assert (order/'native2_cache_identity.txt').read_text().startswith('same executor object')
assert (order/'native2-qr.cu').read_bytes()==(order/'native2-rq.cu').read_bytes()
assert (order/'native2-qr.ptx').read_bytes()==(order/'native2-rq.ptx').read_bytes()
verify_tar(OUT/'source-69a73844.tar.gz',measure['source_sha256'])
# Preserve nested diagnostics before any worktree cleanup, in the observer-covered root.
start=datetime.datetime.fromisoformat(measure['commands'][0]['start_utc']).timestamp()
nested=[p for p in (ROOT/'target').glob('dispatch-smoke-*') if p.stat().st_mtime>=start]
nested_hashes={str(p.relative_to(ROOT)):sha(p) for directory in nested for p in directory.rglob('*') if p.is_file()}
with tarfile.open(OUT/'nested-diagnostics.tar.gz','w:gz') as archive:
 for name in sorted(nested_hashes):archive.add(ROOT/name,arcname=name,recursive=False)
verify_tar(OUT/'nested-diagnostics.tar.gz',nested_hashes)
(OUT/'nested-diagnostics-manifest.json').write_text(json.dumps(nested_hashes,indent=2)+'\n')
cache_files=[]
for base in (OUT/'cache',order/'inductor',order/'triton',order/'cuda',order/'debug'):
 if base.exists():cache_files.extend(p for p in base.rglob('*') if p.is_file())
cache_hashes={str(p.relative_to(OUT)):sha(p) for p in cache_files}
with tarfile.open(OUT/'reference-cache.tar.gz','w:gz') as archive:
 for name in sorted(cache_hashes):archive.add(OUT/name,arcname=name,recursive=False)
verify_tar(OUT/'reference-cache.tar.gz',cache_hashes)
(OUT/'reference-cache-manifest.json.gz').write_bytes(gzip.compress(json.dumps(cache_hashes,indent=2).encode(),mtime=0))
prior=json.loads((OUT/'prior-artifacts-before.json').read_text());assert all(sha(ROOT/p)==value for p,value in prior.items())
(OUT/'prior-artifacts-after.json').write_text(json.dumps({p:sha(ROOT/p) for p in prior},indent=2)+'\n')
measure.update(runtime=runtime,checks=checks,interpreter_verification=identities,raw_comparisons=len(raw_json),known_failures={'pointwise':failures,'reference_order':reference,'native_order':native,'order_provenance':order_provenance,'reference_provenance':ref_provenance,'milestone_complete':False},prior_files_unchanged=len(prior))
DOC.mkdir(parents=True,exist_ok=False)
(DOC/'measurements.json.gz').write_bytes(gzip.compress((json.dumps(measure,indent=2)+'\n').encode(),mtime=0))
# Keep source/PTX, raw numerical observations and logs in git; compiler caches,
# wheel and complete committed source remain byte-verified in canonical root.
raw_files=[]
for p in OUT.rglob('*'):
 if not p.is_file():continue
 parts=p.relative_to(OUT).parts
 if any(s in ('cargo-build','cache','wheels','inductor','triton','cuda','tmp','xdg') for s in parts):continue
 if p.suffix=='.gz' or p.name in ('packaging.log','report-draft.md'):continue
 raw_files.append(p)
manifest={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(raw_files)}
with tarfile.open(DOC/'raw-captures.tar.gz','w:gz') as archive:
 for p in sorted(raw_files):archive.add(p,arcname=str(p.relative_to(OUT)),recursive=False)
verify_tar(DOC/'raw-captures.tar.gz',{n:r['sha256'] for n,r in manifest.items()})
retained={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (wheel,OUT/'source-69a73844.tar.gz',OUT/'reference-cache.tar.gz',OUT/'reference-cache-manifest.json.gz',OUT/'nested-diagnostics.tar.gz')}
(DOC/'raw-retention-manifest.json.gz').write_bytes(gzip.compress((json.dumps({'canonical_root':str(OUT),'archived_files':manifest,'large_canonical_artifacts':retained,'outer_archival':'Burner observer owns external archival; no cleanup performed or external archive path claimed.'},indent=2)+'\n').encode(),mtime=0))
summary={'commit':measure['commit'],'clean_capture':True,'checks':checks,'raw_comparisons':len(raw_json),'raw_files_verified':len(manifest),'cache_files_verified':len(cache_hashes),'nested_files_verified':len(nested_hashes),'prior_files_unchanged':len(prior),'wheel_sha256':runtime['wheel_sha256'],'milestone_complete':False}
(OUT/'packaging-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
(DOC/'verification.log').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
