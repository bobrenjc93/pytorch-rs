// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __uint_as_float(0x00000000u);
const float v3 = __fmul_rn(v0, v2);
const float v5 = __uint_as_float(0x3f918937u);
const float v6 = fmaf(v0, v2, v5);
const float v7 = __fmul_rn(v6, v1);
out0[i] = v3;
out1[i] = v6;
out2[i] = v7;
}
}
