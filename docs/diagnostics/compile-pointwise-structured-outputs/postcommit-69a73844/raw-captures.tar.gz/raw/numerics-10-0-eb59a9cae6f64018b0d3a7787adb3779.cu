// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v4 = __uint_as_float(0x40000000u);
const float v5 = __fmul_rn(v2, v4);
const float v6 = (-v5);
const float v8 = fmaf(-v2, v4, v0);
out0[i] = v2;
out1[i] = v6;
out2[i] = v8;
}
}
