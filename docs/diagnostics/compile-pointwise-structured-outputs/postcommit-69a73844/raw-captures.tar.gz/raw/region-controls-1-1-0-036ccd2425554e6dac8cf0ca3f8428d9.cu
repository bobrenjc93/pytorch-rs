// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
{
const float v3 = __uint_as_float(0x00000000u);
out0[i] = v3;
}
{
const float v4 = __uint_as_float(0x80000000u);
out1[i] = v4;
}
{
const float v3 = __uint_as_float(0x00000000u);
const float v5 = (float)sin((double)v3);
out2[i] = v5;
}
}
}
