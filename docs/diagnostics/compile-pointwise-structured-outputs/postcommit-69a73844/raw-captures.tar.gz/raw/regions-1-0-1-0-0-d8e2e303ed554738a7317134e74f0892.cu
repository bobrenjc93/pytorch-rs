// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
if (numerical_hint < 3ull) {
// numerical plan for hint >= 1
{
const float v0 = x0[i];
const float v2 = __fmul_rn(v0, v0);
const float v3 = fmaf(-v0, v0, 0.0f);
out0[i] = v3;
}
{
const float v0 = x0[i];
const float v2 = __fmul_rn(v0, v0);
const float v4 = sinf((__float_as_uint(v2) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v2) & 0x80000000u) : v2);
out1[i] = v4;
}
}
else {
// numerical plan for hint >= 3
const float v0 = x0[i];
const float v2 = __fmul_rn(v0, v0);
const float v3 = __fsub_rn(0.0f, v2);
const float v4 = sinf((__float_as_uint(v2) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v2) & 0x80000000u) : v2);
out0[i] = v3;
out1[i] = v4;
}
}
}
