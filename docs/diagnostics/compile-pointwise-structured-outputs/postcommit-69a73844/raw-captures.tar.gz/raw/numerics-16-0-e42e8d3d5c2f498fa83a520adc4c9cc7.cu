// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, float* out3, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v3 = __uint_as_float(0x00000000u);
const float v5 = __uint_as_float(0x3f918937u);
const float v6 = __fmul_rn(v5, v1);
const float v7 = __fadd_rn(v5, v0);
out0[i] = v3;
out1[i] = v5;
out2[i] = v6;
out3[i] = v7;
}
}
