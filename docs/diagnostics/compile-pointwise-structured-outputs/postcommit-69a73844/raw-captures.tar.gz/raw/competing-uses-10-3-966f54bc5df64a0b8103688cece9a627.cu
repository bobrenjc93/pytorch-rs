// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v4 = __uint_as_float(0x40000000u);
const float v5 = __fmul_rn(v2, v4);
const float v6 = (-v5);
const float v7 = sinf((__float_as_uint(v0) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v0) & 0x80000000u) : v0);
const float v8 = cosf(v1);
const float v9 = __fmul_rn(v7, v8);
const float v11 = fmaf(v7, v8, -v5);
out0[i] = v6;
out1[i] = v11;
}
}
