import os,sys,pathlib,json,subprocess,hashlib,time
root=pathlib.Path(__file__).resolve().parent
for name in ('tmp','inductor','triton','cuda','xdg','debug'):(root/name).mkdir(exist_ok=True)
for name,value in {'CUDA_VISIBLE_DEVICES':'0','TMPDIR':str(root/'tmp'),'TORCHINDUCTOR_CACHE_DIR':str(root/'inductor'),'TRITON_CACHE_DIR':str(root/'triton'),'CUDA_CACHE_PATH':str(root/'cuda'),'XDG_CACHE_HOME':str(root/'xdg'),'TORCH_COMPILE_DEBUG_DIR':str(root/'debug'),'TORCH_COMPILE_DEBUG':'1','TORCH_LOGS':'output_code','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}.items():os.environ[name]=value
import torch
torch.set_num_threads(1)
sys.setrecursionlimit(20000)
def command(argv):return subprocess.check_output(argv,text=True)
provenance={'argv':sys.argv,'time':time.time(),'cwd':str(pathlib.Path.cwd()),'executable':sys.executable,'torch_file':torch.__file__,'torch_version':torch.__version__,'torch_cuda':torch.version.cuda,'git_head':command(['git','rev-parse','HEAD']).strip(),'git_status':command(['git','status','--porcelain']),'gpu':command(['nvidia-smi','--query-gpu=index,uuid,name,driver_version','--format=csv']),'env':{k:v for k,v in os.environ.items() if k.endswith('CACHE_DIR') or k in ('CUDA_VISIBLE_DEVICES','TMPDIR','TORCH_LOGS','TORCH_COMPILE_DEBUG_DIR')}}
(root/'provenance.json').write_text(json.dumps(provenance,indent=2))
results=[]
for order in ('qr','rq'):
    lines=['def program(x,y):','    p=x*y','    q=p-x','    r=p']
    for segment in range(64):
        lines.extend(['    r=r.sin()']*30)
        lines.append('    r=r.sin()+r.cos()')
    lines+=['    r=r.sin()',f'    return ({order[0]},{order[1]})']
    source='\n'.join(lines)+'\n'
    path=root/f'program_{order}.py';path.write_text(source)
    scope={};exec(compile(source,str(path),'exec'),scope)
    torch.compiler.reset()
    fn=torch.compile(scope['program'])
    x=torch.full((2,),1e10,device='cuda',dtype=torch.float32)
    y=torch.full((2,),1.0000001192092896,device='cuda',dtype=torch.float32)
    start=time.time()
    outputs=fn(x,y);torch.cuda.synchronize()
    q=outputs[order.index('q')]
    row={'order':order,'shape':list(x.shape),'x':x.cpu().tolist(),'y':y.cpu().tolist(),'q':q.cpu().tolist(),'q_bits':q.view(torch.int32).cpu().tolist(),'r':outputs[order.index('r')].cpu().tolist(),'elapsed':time.time()-start,'source_sha256':hashlib.sha256(source.encode()).hexdigest()}
    results.append(row);print(json.dumps(row),flush=True)
    (root/'results.json').write_text(json.dumps(results,indent=2))
