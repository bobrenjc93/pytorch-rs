import os,sys,pathlib,json,hashlib,subprocess,dis,time
root=pathlib.Path(__file__).resolve().parent
os.environ['CUDA_VISIBLE_DEVICES']='0'
os.environ['TMPDIR']=str(root/'tmp')
os.environ['CUDA_CACHE_PATH']=str(root/'cuda')
os.environ['XDG_CACHE_HOME']=str(root/'xdg')
sys.path.insert(0,str(pathlib.Path.cwd()))
import torch_rs as native
from torch_rs import _compile_pointwise as frontend
from tests.test_compile_pointwise_structured_outputs import shape_lower,kernel
from tests.test_compile_pointwise_jit import cache
sources=[(root/f'program_{order}.py').read_text() for order in ('qr','rq')]
assert sources[0].splitlines()[:-1]==sources[1].splitlines()[:-1]
fns=[]
for order,source in zip(('qr','rq'),sources):
    scope={};exec(compile(source,str(root/f'program_{order}.py'),'exec'),scope);fns.append(scope['program'])
lowers=[shape_lower(fn,((2,),(2,))) for fn in fns]
assert lowers[0].graph==lowers[1].graph
record={'time':time.time(),'argv':sys.argv,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],text=True),'native_file':native.__file__,'frontend_file':frontend.__file__,'frontend_sha256':hashlib.sha256(pathlib.Path(frontend.__file__).read_bytes()).hexdigest(),'nodes':len(lowers[0].graph.nodes),'outputs':lowers[0].graph.outputs,'graph_equal':True,'result_spec_equal':lowers[0].result==lowers[1].result,'instructions':[len(tuple(dis.get_instructions(fn))) for fn in fns]}
for path in pathlib.Path(native.__file__).parent.glob('*.so'):record['extension']={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(root/'native2_provenance.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
x=native.tensor([1e10,1e10],dtype=native.float32).to('cuda:0')
y=native.tensor([1.0000001192092896]*2,dtype=native.float32).to('cuda:0')
fn=fns[0];compiled=native.compile(fn);results=[];executors=[]
for order,newfn in zip(('qr','rq'),fns):
    fn.__code__=newfn.__code__
    outputs=compiled(x,y)
    exe=kernel(compiled);executors.append(exe)
    row={'order':order,'q':outputs[order.index('q')].to('cpu').tolist(),'r':outputs[order.index('r')].to('cpu').tolist(),'executors':len(cache(compiled).executors),'logical_graphs':len(cache(compiled).graphs)}
    results.append(row);print(json.dumps(row),flush=True)
    (root/f'native2-{order}.cu').write_text(exe.source)
    (root/f'native2-{order}.ptx').write_text(exe.ptx)
    (root/'native2_results.json').write_text(json.dumps(results,indent=2))
assert executors[0] is executors[1]
assert len(cache(compiled).executors)==1
(root/'native2_cache_identity.txt').write_text('same executor object across both output orders; one executor entry\n')
