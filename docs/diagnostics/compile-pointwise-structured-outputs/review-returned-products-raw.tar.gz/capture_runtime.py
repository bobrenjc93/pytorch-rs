import ctypes,datetime,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-review-fix'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def libraries():return sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if any(k in line for k in ('libcuda','libnvrtc','libtorch','libpython'))})
import torch_rs as native
import torch_rs.torch_rs as bridge
assert 'torch' not in sys.modules
def fn(x,y):
    p=(-x)*y
    return p,p+x*y
compiled=native.compile(fn)
x=native.tensor([1e10,1e-38,2e38]).to('cuda:0');y=native.tensor([1.0000001192092896,-1e-38,-2e38]).to('cuda:0')
actual=compiled(x,y)
assert 'torch' not in sys.modules
before=libraries()
kernel=next(reversed(compiled._torch_rs_pointwise_cache.executors.values()))
(OUT/'runtime-native.cu').write_text(kernel.source);(OUT/'runtime-native.ptx').write_text(kernel.ptx)
import torch
assert torch.__version__.startswith('2.13.0')
expected=torch.compile(fn)(torch.tensor([1e10,1e-38,2e38],device='cuda:0'),torch.tensor([1.0000001192092896,-1e-38,-2e38],device='cuda:0'))
torch.cuda.synchronize()
wheel=next((OUT/'wheels-final').glob('*.whl'))
with zipfile.ZipFile(wheel) as archive:
    members={name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('torch_rs/') and name.endswith(('.py','.so'))}
for name,digest in members.items():
    assert sha(Path(native.__file__).parent.parent/name)==digest,name
    if name.endswith('.py'):assert sha(ROOT/'python'/name)==digest,name
runtime={}
for path in libraries():
    if 'libcudart.so' in path:
        v=ctypes.c_int();assert ctypes.CDLL(path).cudaRuntimeGetVersion(ctypes.byref(v))==0
        runtime[path]=v.value
record={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_kind':'uncommitted numerical repair; not a clean-commit qualification','status':subprocess.check_output(['git','status','--porcelain'],text=True),'python':sys.version,'executable':sys.executable,'resolved_executable':str(Path(sys.executable).resolve()),'native_package':native.__file__,'native_extension':bridge.__file__,'reference_package':torch.__file__,'reference_version':torch.__version__,'reference_cuda':torch.version.cuda,'native_libraries_before_torch_import':before,'loaded_libraries':libraries(),'runtime_versions':runtime,'nvrtc_version':kernel.nvrtc_version,'nvrtc_options':kernel.options,'wheel':str(wheel),'wheel_sha256':sha(wheel),'installed_members':members,'actual':[v.cpu().tolist() for v in actual],'expected':[v.cpu().tolist() for v in expected],'environment':{key:os.environ.get(key) for key in ('CUDA_VISIBLE_DEVICES','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','TMPDIR','PYTHONDONTWRITEBYTECODE')},'nvidia_smi':subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],text=True),'nvcc':subprocess.check_output(['nvcc','--version'],text=True),'rustc':subprocess.check_output(['rustc','--version'],text=True)}
assert record['actual']==record['expected']
for a,e in zip(record['actual'],record['expected']):
    import math
    assert all(v!=0 or math.copysign(1,v)==math.copysign(1,w) for v,w in zip(a,e))
(OUT/'runtime-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('base_commit','source_kind','wheel_sha256','nvrtc_version','runtime_versions','actual','expected')},indent=2))
