from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile
ROOT=Path.cwd(); OUT=ROOT/'target/default-compile-eval/structured-outputs-review-fix'
DOC=ROOT/'docs/diagnostics/compile-pointwise-structured-outputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def archive(name,paths,base):
    dest=OUT/name
    assert not dest.exists(),dest
    files=sorted(set(p for p in paths if p.is_file()))
    members={str(p.relative_to(base)):sha(p) for p in files}
    with tarfile.open(dest,'w:gz') as tar:
        for p in files:tar.add(p,arcname=str(p.relative_to(base)),recursive=False)
    with tarfile.open(dest,'r:gz') as tar:
        actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}
    assert actual==members
    (OUT/(name+'.manifest.json')).write_text(json.dumps(members,indent=2)+'\n')
    return {'path':str(dest.relative_to(ROOT)),'sha256':sha(dest),'bytes':dest.stat().st_size,'files':len(members),'verified_byte_exact':True}
validation=json.loads((OUT/'validation-ready.json').read_text())
assert validation['source_unchanged_after']
assert all(c['exit_code']==0 for c in validation['commands'])
runtime=json.loads((OUT/'runtime-ready.json').read_text())
assert runtime['wheel_sha256']==validation['wheel']['sha256']
for p,digest in validation['source_sha256'].items():assert sha(ROOT/p)==digest,p
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
    identity=json.loads((OUT/('identity-ready-final-'+version+'.log')).read_text())
    assert {'torch_rs/'+k:v for k,v in identity['members'].items()}==runtime['installed_members'],version
(OUT/'repair-source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','python','tests']))
artifacts={}
artifacts['source']=archive('repair-source.tar.gz',[*ROOT.glob('src/**/*'),*ROOT.glob('python/torch_rs/**/*.py'),*ROOT.glob('tests/test_compile_pointwise*.py'),*[ROOT/p for p in ('Cargo.toml','Cargo.lock','pyproject.toml','rust-toolchain.toml','uv.lock')]],ROOT)
artifacts['nested_diagnostics']=archive('nested-dispatch-diagnostics.tar.gz',[p for d in ROOT.glob('target/dispatch-smoke-*') for p in d.rglob('*')],ROOT)
artifacts['reference_caches']=archive('reference-caches.tar.gz',(OUT/'cache').rglob('*'),OUT)
paths=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ('.log','.json','.txt','.py','.patch','.cu','.ptx','.csv')]
paths += [p for d in OUT.glob('raw-*') if d.is_dir() for p in d.rglob('*')]
artifacts['raw']=archive('review-returned-products-raw.tar.gz',paths,OUT)
raw=OUT/'review-returned-products-raw.tar.gz'; (DOC/raw.name).write_bytes(raw.read_bytes())
for name in ('original-review.tar.gz',):
    p=OUT/name;artifacts[name]={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
for d in OUT.glob('wheels-*'):
    for p in d.glob('*.whl'):artifacts[d.name]={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
record={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':validation['base_commit'],'source_kind':validation['source_kind'],'validation':validation,'build':json.loads((OUT/'build-ready-command.json').read_text()),'runtime':runtime,'artifacts':artifacts,'retention':'All archives remain inside the canonical report root. No disposable-worktree cleanup or external retention is claimed. Burner owns outer archival. Raw archive also checked into docs. Historical pre-repair and exploratory failures remain under their actual original provenance.'}
with gzip.open(DOC/'review-returned-products-measurements.json.gz','wt') as f:json.dump(record,f,indent=2);f.write('\n')
manifest={'base_commit':validation['base_commit'],'source_kind':validation['source_kind'],'artifacts':artifacts,'checked_in':{p.name:sha(p) for p in (DOC/'review-returned-products-measurements.json.gz',DOC/raw.name)},'source_hashes_unchanged':True,'five_installed_packages_match_final_wheel':True}
(DOC/'review-returned-products-retention.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'packaging-verification.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
