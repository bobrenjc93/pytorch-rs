// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[((i / 3ull) % 2ull) * 1ull];
const float v1 = x1[((i / 1ull) % 3ull) * 1ull];
const float v2 = __fadd_rn(v0, v1);
const float v3 = __fsub_rn(v0, v1);
out0[i] = v2;
out1[i] = v3;
}
}
