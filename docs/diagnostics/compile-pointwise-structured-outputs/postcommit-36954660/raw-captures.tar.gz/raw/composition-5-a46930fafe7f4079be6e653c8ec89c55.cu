// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = __fsub_rn(0.0f, v0);
const float v2 = __uint_as_float(0x40000000u);
const float v3 = __fadd_rn(v0, v2);
out0[i] = v1;
out1[i] = v3;
}
}
