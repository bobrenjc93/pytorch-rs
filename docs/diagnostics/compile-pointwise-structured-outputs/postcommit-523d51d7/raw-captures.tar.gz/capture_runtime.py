"""Record actual runtime/build identities; semantic workload tests are unchanged."""
import ctypes, datetime, hashlib, importlib.metadata, json, os
from pathlib import Path
import subprocess, sys, zipfile
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-523d51d7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def query(*args):return subprocess.check_output(args,text=True)
def libraries():
    return sorted({line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if any(name in line for name in ('libcuda','libnvrtc','libtorch','libpython'))})
commit=query('git','rev-parse','HEAD').strip()
assert commit=='523d51d73bb90237f8675ee584bfb890d39c84df'
status=query('git','status','--porcelain')
assert not status
import torch_rs as native
import torch_rs.torch_rs as bridge
assert 'torch' not in sys.modules
# Same setup workload as the retained development provenance probe.
def fn(x):
    p=x*1.25
    shared=[p,x,x.shape[-1]]
    return {'a':shared,'b':shared,'sum':p+x}
compiled=native.compile(fn)
x=native.tensor([0.,-0.,1.25,-3.5],dtype=native.float32).to('cuda:0')
actual=compiled(x)
assert actual['a'] is actual['b'] and actual['a'][1] is x
assert 'torch' not in sys.modules
kernel=next(reversed(compiled._torch_rs_pointwise_cache.executors.values()))
native_libraries=libraries()
(OUT/'runtime-kernel.cu').write_text(kernel.source)
(OUT/'runtime-kernel.ptx').write_text(kernel.ptx)
(OUT/'runtime-kernel.plan').write_text(kernel.plan(4, (0,1)))
import torch
assert torch.__version__.startswith('2.13.0')
expected=torch.compile(fn)(torch.tensor([0.,-0.,1.25,-3.5],device='cuda:0'))
torch.cuda.synchronize()
wheel=next((OUT/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as archive:
    members={name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('torch_rs/') and name.endswith(('.py','.so'))}
for name,digest in members.items():
    assert sha(Path(native.__file__).parent.parent/name)==digest,name
    if name.endswith('.py'):assert sha(ROOT/'python'/name)==digest,name
runtime_versions={}
for path in libraries():
    if 'libcudart.so' in path:
        lib=ctypes.CDLL(path);version=ctypes.c_int()
        assert lib.cudaRuntimeGetVersion(ctypes.byref(version))==0
        runtime_versions[path]=version.value
record={'commit':commit,'status_before':status,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(ROOT),'python':sys.version,'executable':sys.executable,'resolved_executable':str(Path(sys.executable).resolve()),'executable_sha256':sha(sys.executable),'native_package':native.__file__,'native_extension':bridge.__file__,'reference_package':torch.__file__,'reference_version':torch.__version__,'reference_cuda':torch.version.cuda,'reference_device':str(torch.cuda.get_device_properties(0)),'native_libraries_before_torch_import':native_libraries,'all_loaded_libraries':libraries(),'runtime_versions':runtime_versions,'nvrtc_version':kernel.nvrtc_version,'nvrtc_options':kernel.options,'wheel':str(wheel),'wheel_sha256':sha(wheel),'installed_wheel_members':members,'packages':{d.metadata['Name']:d.version for d in importlib.metadata.distributions()},'native_output':[actual['a'][0].cpu().tolist(),actual['sum'].cpu().tolist()],'reference_output':[expected['a'][0].cpu().tolist(),expected['sum'].cpu().tolist()],'environment':{k:os.environ.get(k) for k in ('CUDA_VISIBLE_DEVICES','TMPDIR','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','PYTHONDONTWRITEBYTECODE')},'nvidia_smi':query('nvidia-smi','--query-gpu=index,uuid,name,utilization.gpu,memory.used,driver_version','--format=csv'),'status_after':query('git','status','--porcelain')}
assert record['native_output']==record['reference_output']
assert record['status_after']==status
(OUT/'runtime-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('commit','reference_version','runtime_versions','nvrtc_version','wheel_sha256','native_output','reference_output')},indent=2))
