from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-postcommit-523d51d7'
label,*command=sys.argv[1:]
env=os.environ.copy()
for key in ('PYTHONPATH','CONDA_PREFIX'):env.pop(key,None)
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(out/'tmp'),UV_CACHE_DIR=str(out/'cache/uv'),CARGO_HOME=str(root/'target/native-output-checks/cargo-home'),CARGO_TARGET_DIR=str(out/'cargo-build'),CARGO_BUILD_JOBS='8',PYO3_PYTHON=str(root/'.venv/bin/python'),TORCHINDUCTOR_CACHE_DIR=str(out/'cache/inductor'),TRITON_CACHE_DIR=str(out/'cache/triton'),CUDA_CACHE_PATH=str(out/'cache/cuda'),XDG_CACHE_HOME=str(out/'cache/xdg'),TORCH_COMPILE_DEBUG_DIR=str(out/'cache/debug'),TORCH_COMPILE_DEBUG='1',TORCH_RS_STRUCTURED_EVIDENCE=str(out/'raw'),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
env.setdefault('CUDA_VISIBLE_DEVICES','0')
def query(*args):return subprocess.check_output(args,text=True).strip()
assert query('git','rev-parse','HEAD')=='523d51d73bb90237f8675ee584bfb890d39c84df'
assert not query('git','status','--porcelain'), 'capture requires clean checkout'
source={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for base in ('src','python/torch_rs','tests') for p in (root/base).rglob('*') if p.is_file() and p.suffix in ('.rs','.py')}
record={'label':label,'argv':command,'cwd':str(root),'head':query('git','rev-parse','HEAD'),'status_before':query('git','status','--porcelain'),'source_before':source,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:v for k,v in env.items() if k in ('CUDA_VISIBLE_DEVICES','TMPDIR','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PYO3_PYTHON','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','TORCH_COMPILE_DEBUG_DIR','TORCH_COMPILE_DEBUG','TORCH_RS_STRUCTURED_EVIDENCE','OMP_NUM_THREADS','MKL_NUM_THREADS','PYTHONDONTWRITEBYTECODE')}}
with (out/(label+'.log')).open('xb') as stream:
 completed=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
record.update(exit_code=completed.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source.items()),status_after=query('git','status','--porcelain'))
record['tracked_unchanged']=all(__import__('hashlib').sha256((root/p).read_bytes()).hexdigest()==h for p,h in __import__('json').loads((out/'tracked-source-sha256.json').read_text()).items())
record['clean_after']=not record['status_after']
(out/(label+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(label,completed.returncode,flush=True)
assert record['tracked_unchanged'] and record['clean_after']
sys.exit(completed.returncode)
