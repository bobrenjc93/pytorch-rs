"""Package clean-commit captures; retain original bytes and source identities."""
from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-postcommit-523d51d7'
doc=root/'docs/diagnostics/compile-pointwise-structured-outputs/postcommit-523d51d7'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_gzip(p,data):
 with p.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as stream:stream.write(data)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit=='523d51d73bb90237f8675ee584bfb890d39c84df'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
tracked=json.loads((out/'tracked-source-sha256.json').read_text())
for name,digest in tracked.items():assert sha(root/name)==digest,name
records=[json.loads(p.read_text()) for p in sorted(out.glob('*.command.json'))]
by_label={r['label']:r for r in records}
required=['fmt','clippy','wheel-build','pointwise','native','conversion','two-device','runtime','verify-extension','interpreter-identities']+['portable-'+v for v in ('312','3.10.19','3.11.15','3.13.13','3.14.5')]
for label in required:
 r=by_label[label];assert r['exit_code']==0 and r['head']==commit and r['source_unchanged'] and r['tracked_unchanged'] and r['clean_after'] and not r['status_before'],label
for name,digest in by_label['wheel-build']['source_before'].items():assert sha(Path(name))==digest,name
# Check the exact committed-source archive against recorded tracked hashes.
with tarfile.open(out/'committed-source.tar.gz','r|gz') as archive:
 for member in archive:
  assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==tracked[member.name],member.name
# Record every report byte except rebuildable Cargo output and this manifest.
retained={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0]!='cargo-build'}
write_gzip(out/'retention-manifest.json.gz',(json.dumps(retained,indent=2)+'\n').encode())
doc.mkdir()
write_gzip(doc/'measurements.json.gz',(json.dumps(records,indent=2)+'\n').encode())
# Keep wheels/source/compiler caches in the canonical root; package every raw
# result/plan/source/PTX and command/provenance log for review. Byte-identical
# files use tar hardlinks, verified by streaming below.
selected=[p for p in sorted(out.rglob('*')) if p.is_file() and (len(p.relative_to(out).parts)==1 or p.relative_to(out).parts[0]=='raw') and p.name not in ('committed-source.tar.gz','retention-manifest.json.gz')]
manifest={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected}
with tarfile.open(doc/'raw-captures.tar.gz','x:gz') as archive:
 seen={}
 for p in selected:
  name=str(p.relative_to(out));digest=manifest[name]['sha256']
  if digest in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;archive.addfile(info)
  else:
   archive.add(p,arcname=name,recursive=False);seen[digest]=name
verified={}
with tarfile.open(doc/'raw-captures.tar.gz','r|gz') as archive:
 for member in archive:
  if member.islnk(): entry=verified[member.linkname]
  else:
   data=archive.extractfile(member).read();entry={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  assert entry==manifest[member.name],member.name
  verified[member.name]=entry
write_gzip(doc/'raw-manifest.json.gz',(json.dumps(manifest,indent=2)+'\n').encode())
(doc/'verification.json').write_text(json.dumps({'measured_commit':commit,'root':str(root),'source_status':'clean before and after every measured command','required_checks':required,'tracked_files_verified':len(tracked),'raw_files_verified':len(verified),'canonical_retained_files':len(retained),'canonical_report_root':str(out),'retention_manifest_sha256':sha(out/'retention-manifest.json.gz'),'artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(doc.glob('*.gz'))}},indent=2)+'\n')
print((doc/'verification.json').read_text())
