"""Complete runtime provenance and byte-exact retention after the clean tests."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-4554bbe8'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
measure=json.loads((OUT/'measurements.json').read_text())
assert measure['source_unchanged_after'] and measure['status_before']==measure['status_after']==''
assert all(c['exit_code']==0 for c in measure['commands'])
env=os.environ.copy()
for k in ('PYTHONPATH','CONDA_PREFIX'):env.pop(k,None)
env.update(measure['environment'])
argv=[str(ROOT/'.venv/bin/python'),str(OUT/'capture_runtime.py')]
record={'argv':argv,'environment':measure['environment'],'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (OUT/'runtime-provenance.log').open('xb') as f:result=subprocess.run(argv,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'runtime-command.json').write_text(json.dumps(record,indent=2)+'\n')
assert result.returncode==0
# Preserve a clean-commit reproduction of the documented numerical blocker.
argv=[str(ROOT/'.venv/bin/python'),str(OUT/'capture_blocker.py')]
blocker_env=env|{'TORCH_RS_STRUCTURED_EVIDENCE':str(OUT/'raw-blocker')}
blocker={'argv':argv,'environment':measure['environment']|{'TORCH_RS_STRUCTURED_EVIDENCE':str(OUT/'raw-blocker')},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status_before':subprocess.check_output(['git','status','--porcelain'],text=True)}
with (OUT/'blocker.log').open('xb') as f:result=subprocess.run(argv,cwd=ROOT,env=blocker_env,stdout=f,stderr=subprocess.STDOUT)
blocker.update(exit_code=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status_after=subprocess.check_output(['git','status','--porcelain'],text=True))
(OUT/'blocker-command.json').write_text(json.dumps(blocker,indent=2)+'\n')
assert result.returncode==1 and 'FAILED (failures=4)' in (OUT/'blocker.log').read_text()
assert blocker['status_before']==blocker['status_after']==''
assert all(sha(ROOT/p)==h for p,h in measure['source_sha256'].items())
prior=json.loads((OUT/'prior-artifacts-before.json').read_text())
assert all(sha(ROOT/p)==h for p,h in prior.items())
(OUT/'prior-artifacts-after.json').write_text(json.dumps({'verified_files':len(prior),'all_bytes_unchanged':True,'manifest':'prior-artifacts-before.json'},indent=2)+'\n')
files=sorted(p for d in ROOT.glob('target/dispatch-smoke-*') for p in d.rglob('*') if p.is_file())
members={str(p.relative_to(ROOT)):sha(p) for p in files}
with tarfile.open(OUT/'nested-diagnostics.tar.gz','w:gz') as archive:
    for p in files:archive.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
with tarfile.open(OUT/'nested-diagnostics.tar.gz') as archive:
    actual={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}
assert actual==members
(OUT/'nested-diagnostics-manifest.json').write_text(json.dumps({'files':members,'verified_byte_exact':True,'scope':'Original and new dispatch smoke diagnostics preserved with actual original provenance; no cleanup performed.'},indent=2)+'\n')
print('Runtime capture, prior retention and',len(files),'nested raw files verified')
