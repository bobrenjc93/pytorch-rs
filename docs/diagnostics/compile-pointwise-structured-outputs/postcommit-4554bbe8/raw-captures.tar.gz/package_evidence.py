"""Verify measured artifacts and package byte-exact evidence after capture."""
from pathlib import Path
import gzip, hashlib, json, math, re, tarfile, zipfile
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-4554bbe8'
DOC=ROOT/'docs/diagnostics/compile-pointwise-structured-outputs/postcommit-4554bbe8'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
measure=json.loads((OUT/'measurements.json').read_text())
runtime=json.loads((OUT/'runtime-provenance.json').read_text())
assert measure['source_unchanged_after'] and measure['status_before']==measure['status_after']==''
assert runtime['status_before']==runtime['status_after']==''
assert all(c['exit_code']==0 for c in measure['commands'])
assert all(sha(ROOT/p)==digest for p,digest in measure['source_sha256'].items())
wheel=Path(measure['wheel']['path']);assert sha(wheel)==measure['wheel']['sha256']==runtime['wheel_sha256']
with zipfile.ZipFile(wheel) as archive:
    members={name:hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('torch_rs/') and name.endswith(('.py','.so'))}
assert members==runtime['installed_wheel_members']
identities={}
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
    identity=json.loads((OUT/('identity-'+version+'.log')).read_text())
    assert identity['python'].startswith(version)
    assert {f'torch_rs/{k}':v for k,v in identity['members'].items()}==members
    identity['executable_sha256']=sha(Path(identity['executable']))
    identities[version]=identity
checks={}
for name in ('pointwise','two-device',*('portable-'+v for v in identities)):
    log=(OUT/(name+'.log')).read_text()
    found=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK(?: \(skipped=(\d+)\))?',log)
    assert found,name
    checks[name]={'total':int(found[1]),'skipped':int(found[3] or 0),'passed':int(found[1])-int(found[3] or 0),'seconds':float(found[2])}
for name in ('native-pointwise','native-conversion'):
    log=(OUT/(name+'.log')).read_text()
    found=re.search(r'test result: ok\. (\d+) passed; (\d+) failed;',log);assert found,name
    assert 'skipping' not in log.lower()
    checks[name]={'passed':int(found[1]),'failed':int(found[2])}
raw_json=sorted((OUT/'raw').glob('*.json'))
assert len(raw_json)==757
for p in raw_json:
    data=json.loads(p.read_text());assert set(data)=={'actual','expected'}
    assert p.with_suffix('.cu').exists() and p.with_suffix('.ptx').exists()
    assert p.with_suffix('.ptx').read_text().count('.visible .entry')==1
assert 'without PyTorch import or body replay' in next((OUT/'raw').glob('*.stdout')).read_text()
with tarfile.open(OUT/'source-4554bbe8.tar.gz') as archive:
    for member in archive:
        if member.isfile():assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==measure['source_sha256'][member.name]
with tarfile.open(OUT/'reference-cache.tar.gz','w:gz') as archive:
    for name in ('inductor','triton'):
        path=OUT/'cache'/name
        if path.exists():archive.add(path,arcname=name)
with tarfile.open(OUT/'reference-cache.tar.gz') as archive:
    for member in archive:
        if member.isfile():assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==sha(OUT/'cache'/member.name)
blocker=json.loads((OUT/'blocker-command.json').read_text())
assert blocker['commit']==measure['commit']
assert blocker['exit_code']==1 and blocker['status_before']==blocker['status_after']==''
assert 'FAILED (failures=4)' in (OUT/'blocker.log').read_text()
blocker_files=sorted((OUT/'raw-blocker').glob('*.json'))
assert len(blocker_files)==6
observations=[]
for path in blocker_files:
    data=json.loads(path.read_text())
    actual,expected=data['actual'],data['expected']
    size=actual[0]['shape'][0]
    a,e=actual[0]['values'][0],expected[0]['values'][0]
    assert a==e==0 and math.copysign(1,a)==-1
    assert math.copysign(1,e)==(-1 if size==1 else 1)
    assert path.with_suffix('.ptx').read_text().count('.visible .entry')==1
    observations.append({'file':str(path.relative_to(OUT)),'size':size,'actual_first':a,'reference_first':e,'matches_zero_sign':math.copysign(1,a)==math.copysign(1,e)})
blocker['observations']=observations
blocker['numerical_failures']=sum(not item['matches_zero_sign'] for item in observations)
assert blocker['numerical_failures']==4
blocker['scope']='Known admitted nonlinear program; unresolved correctness failure, not a passing qualification.'
measure.update(known_blocker=blocker,runtime=runtime,interpreter_verification=identities,checks=checks,raw_comparisons=len(raw_json))
DOC.mkdir(parents=True,exist_ok=False)
(DOC/'measurements.json.gz').write_bytes(gzip.compress((json.dumps(measure,indent=2)+'\n').encode(),mtime=0))
# Keep raw measurements, scripts and all logs together; binary wheels/build/cache
# bundles remain in the canonical observer-covered report root.
raw_files=sorted(p for p in OUT.rglob('*') if p.is_file() and not any(part in ('cargo-build','cache','wheels') for part in p.relative_to(OUT).parts) and p.suffix not in ('.gz',) and p.name not in ('packaging.log','report-draft.md'))
with tarfile.open(DOC/'raw-captures.tar.gz','w:gz') as archive:
    for path in raw_files:archive.add(path,arcname=str(path.relative_to(OUT)),recursive=False)
manifest={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in raw_files}
with tarfile.open(DOC/'raw-captures.tar.gz') as archive:
    for name,item in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==item['sha256']
retained={}
for path in [wheel,OUT/'source-4554bbe8.tar.gz',OUT/'reference-cache.tar.gz',OUT/'nested-diagnostics.tar.gz']:
    retained[str(path.relative_to(ROOT))]={'bytes':path.stat().st_size,'sha256':sha(path)}
(DOC/'raw-retention-manifest.json').write_text(json.dumps({'canonical_root':str(OUT),'archived_files':manifest,'large_canonical_artifacts':retained,'outer_archival':'Burner observer owns external archival; no cleanup performed or external archive path claimed.'},indent=2)+'\n')
print(json.dumps({'checks':checks,'raw_comparisons':len(raw_json),'archive_files':len(manifest),'wheel_sha256':runtime['wheel_sha256'],'source_sha256':sha(OUT/'source-4554bbe8.tar.gz'),'reference_cache_bytes':(OUT/'reference-cache.tar.gz').stat().st_size},indent=2))
