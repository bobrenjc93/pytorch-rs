from pathlib import Path
import os,subprocess,sys
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-history-repair'
runner=[str(root/'.venv/bin/python'),str(out/'run.py')]
wheel=next((out/'wheels').glob('*.whl'))
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
 python=root/('.venv/bin/python' if version=='3.12.12' else 'target/portable-'+version+'/bin/python')
 if version!='3.12.12':subprocess.run(runner+['install-'+version,'uv','pip','install','--python',str(python),'--no-deps','--force-reinstall',str(wheel)],check=True)
 p=subprocess.run(runner+['portable-'+version,str(python),'-m','unittest','discover','-v','-s','tests','-p','test_compile_pointwise*.py'],env=os.environ|{'CUDA_VISIBLE_DEVICES':''})
 if p.returncode:sys.exit(p.returncode)
