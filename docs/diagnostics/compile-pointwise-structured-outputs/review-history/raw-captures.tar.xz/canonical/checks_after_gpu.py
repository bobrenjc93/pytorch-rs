from pathlib import Path
import os,subprocess,sys
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-history-repair';runner=[str(root/'.venv/bin/python'),str(out/'run.py')]
commands=[
 ('runtime-1',[str(root/'.venv/bin/python'),str(out/'capture_runtime.py'),'1'],{}),
 ('two-device',[str(root/'.venv/bin/python'),'-m','unittest','-v','tests.test_compile_pointwise_structured_outputs.StructuredHardware.test_two_device_restoration_and_wrong_device_failure','tests.test_compile_pointwise_jit.Hardware.test_two_device_restoration_and_module_ownership'],{'CUDA_VISIBLE_DEVICES':'0,1'}),
 ('native',['cargo','test','--locked','--offline','--release','--lib','pointwise','--','--nocapture','--test-threads=1'],{'CUDA_VISIBLE_DEVICES':'0,1'}),
 ('conversion',['cargo','test','--locked','--offline','--release','--lib','--features','python-bindings','python_conversion_failure','--','--nocapture'],{'CUDA_VISIBLE_DEVICES':'','LD_LIBRARY_PATH':str(root/'target/python-3.12/lib')}),
 ('fmt',['cargo','fmt','--check'],{}),
 ('gpu-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used,memory.total','--format=csv'],{})]
for label,argv,extra in commands:
 p=subprocess.run(runner+[label,*argv],env=os.environ|extra)
 if p.returncode:sys.exit(p.returncode)
