// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v3 = __fsub_rn(v2, v0);
const float v4 = sinf((__float_as_uint(v2) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v2) & 0x80000000u) : v2);
const float v5 = sinf((__float_as_uint(v4) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v4) & 0x80000000u) : v4);
const float v6 = sinf((__float_as_uint(v5) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v5) & 0x80000000u) : v5);
const float v7 = sinf((__float_as_uint(v6) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v6) & 0x80000000u) : v6);
const float v8 = sinf((__float_as_uint(v7) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v7) & 0x80000000u) : v7);
const float v9 = sinf((__float_as_uint(v8) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v8) & 0x80000000u) : v8);
const float v10 = sinf((__float_as_uint(v9) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v9) & 0x80000000u) : v9);
out0[i] = v3;
out1[i] = v10;
}
}
