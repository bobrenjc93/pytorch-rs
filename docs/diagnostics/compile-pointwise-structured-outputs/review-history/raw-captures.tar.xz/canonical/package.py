from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess,tarfile
root=Path.cwd();report=root/'target/default-compile-eval/structured-outputs-history-repair'
out=root/'docs/diagnostics/compile-pointwise-structured-outputs/review-history'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
commands={p.stem:json.loads(p.read_text()) for p in sorted(report.glob('*-command.json'))}
checks={}
for label in ('history-tests','pointwise',*('portable-v2-'+v for v in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5')),'two-device','native','conversion','clippy','fmt','verify-native'):
 p=report/(label+'.log');text=p.read_text()
 summaries=[line for line in text.splitlines() if re.match(r'^(Ran \d+ tests|OK\b|FAILED\b|test result:)',line)]
 checks[label]={'exit_code':commands[label+'-command']['exit_code'],'summary':summaries,'log':str(p.relative_to(root)),'sha256':digest(p)}
measurement={'source_kind':'uncommitted history repair; not clean-commit qualification or evaluation score','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],text=True),'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':commands,'checks':checks,'runtime':json.loads((report/'runtime-final-1.json').read_text()),'build_source_audit':json.loads((report/'build-source-audit.json').read_text()),'reference_order_probe':json.loads((report/'order-probe/results.json').read_text()),'native_order_probe':json.loads((report/'order-probe/native2_results.json').read_text()),'native_order_provenance':json.loads((report/'order-probe/native2_provenance.json').read_text()),'remaining_blocker':'finite joint-lowering fallback; general plan requires output traversal provenance and plan-parameterized single native executable'}
with gzip.open(out/'measurements.json.gz','wb') as f:f.write((json.dumps(measurement,indent=2)+'\n').encode())
paths=[]
for p in report.rglob('*'):
 rel=p.relative_to(report)
 if p.is_file() and rel.parts[0] not in ('cargo-build','wheels'):
  paths.append((p,'canonical/'+str(rel)))
for name in json.loads((report/'nested-roots.json').read_text()):
 for p in (root/name).rglob('*'):
  if p.is_file():paths.append((p,'nested/'+str(p.relative_to(root))))
manifest={name:{'sha256':digest(p),'bytes':p.stat().st_size} for p,name in sorted(paths,key=lambda pair:pair[1])}
with tarfile.open(out/'raw-captures.tar.gz','w:gz',compresslevel=6) as archive:
 for p,name in sorted(paths,key=lambda pair:pair[1]):archive.add(p,arcname=name,recursive=False)
with tarfile.open(out/'raw-captures.tar.gz','r:gz') as archive:
 count=0
 for member in archive:
  assert member.isfile()
  h=hashlib.sha256(archive.extractfile(member).read()).hexdigest()
  assert h==manifest[member.name]['sha256'],member.name
  count+=1
assert count==len(manifest)
# Verify the nested original reviewer archive against its original member map.
original=json.loads((report/'reviewer-original-sha256.json').read_text())
with tarfile.open(report/'reviewer-original.tar.gz','r:gz') as archive:
 seen={}
 for member in archive:
  if member.isfile():seen[str(Path(member.name).relative_to('structured-output-review-c13d660'))]=hashlib.sha256(archive.extractfile(member).read()).hexdigest()
assert seen==original
retention={'archive':'raw-captures.tar.gz','sha256':digest(out/'raw-captures.tar.gz'),'files':manifest,'reviewer_original_verified_files':len(original),'omitted_build_products':'cargo-build and wheel binaries remain in canonical report root; wheel hashes and installed member identity are recorded in measurements.json.gz'}
with gzip.open(out/'raw-retention-manifest.json.gz','wb') as f:f.write((json.dumps(retention,indent=2)+'\n').encode())
(out/'verification.log').write_text(f'Verified {count} archived files byte-for-byte.\nVerified {len(original)} original reviewer files byte-for-byte.\nAll production source hashes equal release-build input hashes.\nInstalled Python/extension members equal the recorded release wheel.\nKnown finite-result regression remains failing; this is not an approval or evaluation score.\n')
print(json.dumps({'archive_files':count,'reviewer_files':len(original),'archive_bytes':(out/'raw-captures.tar.gz').stat().st_size,'archive_sha256':retention['sha256'],'checks':checks},indent=2))
