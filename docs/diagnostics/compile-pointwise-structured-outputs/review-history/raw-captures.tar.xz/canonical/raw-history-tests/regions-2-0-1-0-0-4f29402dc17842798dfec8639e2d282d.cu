// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n, unsigned long long numerical_hint) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
if (numerical_hint < 2ull) {
// numerical plan for hint >= 1
{
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v3 = fmaf(-v0, v1, 0.0f);
out0[i] = v3;
}
{
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v4 = cosf(v2);
out1[i] = v4;
}
}
else {
// numerical plan for hint >= 2
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v3 = __fsub_rn(0.0f, v2);
const float v4 = cosf(v2);
out0[i] = v3;
out1[i] = v4;
}
}
}
