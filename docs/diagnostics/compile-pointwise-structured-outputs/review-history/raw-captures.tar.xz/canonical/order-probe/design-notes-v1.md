# Source-derived replacement-plan investigation

This is an incomplete design investigation, not a correctness or performance measurement. Existing reports are unchanged. The reference-only probe uses ordinary `torch.compile` with no backend/mode/fullgraph/dynamic overrides. `probe.py`, `probe.log`, `provenance.json`, generated program files and all caches preserve its raw execution.

## Proposed scalar realization representation

Replace output-only groups and the ten-node fallback with immutable scalar-expression snapshots and realized-buffer records. Each Buffer records its original SSA root, expression DAG, ordered input/read IDs, public output slots and registration order. Inline expressions use hash-consed operation IDs; realization freezes its current expression and replaces its future loader with an opaque Read(buffer). Original allocation slots remain distinct even when expressions CSE.

For each canonical graph node, collect distinct canonical consumer nodes plus one synthetic Output user if returned. Do not count repeated occurrences in one consumer as separate FX users. Scalar expression counting precedes contraction and follows MockHandler/OpCounterCSE: each distinct typed constant/load/operator result counts once; reads are distinct buffer/index pairs. Neg and Relu each count as one MockHandler operator, regardless of later LLVM decomposition.

In source order: output stride enforcement may realize the result first (see the critical rank correction below). Otherwise, for users>1, realize if returned and not a cheap zero-read <=30-op expression, or if opcount>30, or reads>4. For every remaining Pointwise node, realize if (reads>8 or ops>30) and nontrivial_reads>1; independently realize if ops>100. Realization resets subsequent loader expression to a single buffer read. For rank-zero and all-singleton indices, nontrivial read count is zero. Remaining outputs realize at output processing in flattened output order.

Sources: torch/_inductor/graph.py 1955–2145; ir.py 1055–1093, 10039–10125; ops_handler.py 1096–1175. These paths are relative to the reference torch import recorded in provenance.json.

## Equal-shape scheduler subset

Start singleton groups in realized-buffer registration order. Writes are member buffers; reads are union of member reads minus writes. In each fusion round enumerate pairs through ordered common used-buffer lists, at most the next64 entries per first member, deduplicating pairs in insertion order. Reject empty shared dependencies, >64 member buffers, or a contraction creating a dependency-DAG cycle. For horizontal pairs also reject proximity>64 or shared bytes<10. Vertical pairs require matched linear read/write indices and no intervening producer dependency outside the pair; quotient-DAG cycle checking implements this condition in this pure same-index domain.

Sort candidates stably by descending shared-memory score, then negative proximity; other default pointwise score dimensions coincide. Resolve each original candidate to its current fused groups and recompute legality before merging. Group reads must remove all group writes. Topological sorting is reference DFS, visiting groups in minimum-registration order and dependencies in lexicographic buffer-name order, NOT stable Kahn sorting. Repeat up to ten rounds, then the configured final reorder round. Existing vertical-first fixed-point merging is not equivalent in general.

Same-size float32 buffer reuse has one reuse key, so peak-memory rejection cannot trigger when any shared buffer exists: overhead<=4*n, savings>=4*n, while rejection requires overhead>32*savings. Extern/reduction/mutation/stream/backend special cases do not belong in this restricted planner.

Sources: scheduler.py 4825–4851, 4986–5020, 5853–5930, 6399–6453, 6501–6555, 6606–6634, 7678–7750, 8080–8189; choices.py 569–734; dependencies.py 460–473.

## Native lowering

Each final numerical region receives its ordered member-buffer programs. Same-region Read(buffer) references inline their producer expressions; cross-region reads are opaque imported float32 leaves. Normalize/CSE/FMA-plan after this distinction, with export uses included. Emit ordered lexical regions inside the one existing CUDA element loop; exported floats survive into later regions, with no scratch allocation or extra launch. Public stores remain attached to original SSA allocation slots. Never recompute a cross-region producer from original Graph ancestors.

## Critical correction: output registration order and rank

The initial concern that all final outputs register in tuple order is false for ordinary rank-positive outputs. `graph.py` enforces exact output strides during each FX node's processing (1955–2029), before reuse realization; this realizes them in source order. The running shape(2,) chain probe's pre-fusion IR confirms q is buf0, despite its being the first output processed after64 internal boundaries in the discarded hypothesis. The initial chain order-counterexample premise is therefore invalid for rank-positive outputs.

Rank-zero results have empty strides and skip that stride-enforcement branch. Remaining rank-zero outputs do realize in flattened tuple order: graph.py:1637 has a direct left-to-right list comprehension over realize_input. The numerical plan needs rank-zero provenance, not just element count. Numerical_hint=1 alone conflates scalar and rank-positive singleton tensors.

A not-yet-measured rank-zero order-sensitive construction is:62 internal one-read buffers, each forced by >30-op reuse (`v=sin^30(r); r=v.sin()+v.cos()`), followed by `p=sin^30(r)*y` reused by q=-p and r=p.sin(), producing63 internal buffers. The64-buffer fusion cap can absorb only one of the two final-only outputs, whose registration order changes with return order. If q joins p, its product-negation can contract; if it does not, it sees a rounded imported p. Inputs x=y=1e-38 may distinguish -0/+0. This is a hypothesis pending raw default-reference evidence, not a substantiated blocker.

A full planner must resolve this scalar output-order question before claiming a topology-invariant cached executable for all admitted graphs. Rank-positive output order cannot be used as evidence for this claim. No production implementation is proposed until that missing invariant or required provenance is resolved.
