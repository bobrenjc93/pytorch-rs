# Source-derived replacement-plan investigation

This is an incomplete design investigation, not a correctness or performance measurement. Existing reports are unchanged. The reference-only probe uses ordinary `torch.compile` with no backend/mode/fullgraph/dynamic overrides. `probe.py`, `probe.log`, `provenance.json`, generated program files and all caches preserve its raw execution.

## Proposed scalar realization representation

Replace output-only groups and the ten-node fallback with immutable scalar-expression snapshots and realized-buffer records. Each Buffer records its original SSA root, expression DAG, ordered input/read IDs, public output slots and registration order. Inline expressions use hash-consed operation IDs; realization freezes its current expression and replaces its future loader with an opaque Read(buffer). Original allocation slots remain distinct even when expressions CSE.

For each canonical graph node, collect distinct canonical consumer nodes plus one synthetic Output user if returned. Do not count repeated occurrences in one consumer as separate FX users. Scalar expression counting precedes contraction and follows MockHandler/OpCounterCSE: each distinct typed constant/load/operator result counts once; reads are distinct buffer/index pairs. Neg and Relu each count as one MockHandler operator, regardless of later LLVM decomposition.

In source order: output stride enforcement may realize the result first (see the critical rank correction below). Otherwise, for users>1, realize if returned and not a cheap zero-read <=30-op expression, or if opcount>30, or reads>4. For every remaining Pointwise node, realize if (reads>8 or ops>30) and nontrivial_reads>1; independently realize if ops>100. Realization resets subsequent loader expression to a single buffer read. For rank-zero and all-singleton indices, nontrivial read count is zero. Remaining outputs realize at output processing in flattened output order.

Sources: torch/_inductor/graph.py 1955–2145; ir.py 1055–1093, 10039–10125; ops_handler.py 1096–1175. These paths are relative to the reference torch import recorded in provenance.json.

## Equal-shape scheduler subset

Start singleton groups in realized-buffer registration order. Writes are member buffers; reads are union of member reads minus writes. In each fusion round enumerate pairs through ordered common used-buffer lists, at most the next64 entries per first member, deduplicating pairs in insertion order. Reject empty shared dependencies, >64 member buffers, or a contraction creating a dependency-DAG cycle. For horizontal pairs also reject proximity>64 or shared bytes<10. Vertical pairs require matched linear read/write indices and no intervening producer dependency outside the pair; quotient-DAG cycle checking implements this condition in this pure same-index domain.

Sort candidates stably by descending shared-memory score, then negative proximity; other default pointwise score dimensions coincide. Resolve each original candidate to its current fused groups and recompute legality before merging. Group reads must remove all group writes. Topological sorting is reference DFS, visiting groups in minimum-registration order and dependencies in lexicographic buffer-name order, NOT stable Kahn sorting. Repeat up to ten rounds, then the configured final reorder round. Existing vertical-first fixed-point merging is not equivalent in general.

Same-size float32 buffer reuse has one reuse key, so peak-memory rejection cannot trigger when any shared buffer exists: overhead<=4*n, savings>=4*n, while rejection requires overhead>32*savings. Extern/reduction/mutation/stream/backend special cases do not belong in this restricted planner.

Sources: scheduler.py 4825–4851, 4986–5020, 5853–5930, 6399–6453, 6501–6555, 6606–6634, 7678–7750, 8080–8189; choices.py 569–734; dependencies.py 460–473.

## Native lowering

Each final numerical region receives its ordered member-buffer programs. Same-region Read(buffer) references inline their producer expressions; cross-region reads are opaque imported float32 leaves. Normalize/CSE/FMA-plan after this distinction, with export uses included. Emit ordered lexical regions inside the one existing CUDA element loop; exported floats survive into later regions, with no scratch allocation or extra launch. Public stores remain attached to original SSA allocation slots. Never recompute a cross-region producer from original Graph ancestors.

## Verified output-order counterexample and missing provenance

The two retained shape(2,) source files have byte-identical bodies and differ only in the final return tuple order. Ordinary default stock torch.compile produced q=1024.0 for return(q,r), and q=1192.0928955078125 for return(r,q), with x=1e10 and y=1.0000001192092896. Both r values were0.9488263726234436. Raw outputs are in results.json and probe.log (lines6644 and13330); generated reference sources, PTX and IR are retained in inductor/, triton/ and debug/.

Native frontend lowering accepts both programs:2117 SSA nodes and8211 bytecode instructions, within the4096/16384 budgets. The Graph values compare equal with output slots(3,2116), while their ResultSpecs differ. native_provenance.json preserves this check and records imported source/extension hashes. The first native launch attempt used unsupported unindexed cuda and failed before launch; native-probe.log is preserved, and native_probe_retry.py corrects only the device spelling with distinct output paths.

The native retry completed: q=1024.0 in both orders, r=0.9488263726234436 in both orders. One persistent public native.compile wrapper switched only the underlying function code's return order. Both calls used the same executor object; executable cache size remained1 while logical specialization count changed1→2. native2_results.json and native2_cache_identity.txt retain these observations; native2-{qr,rq}.cu and .ptx retain generated code. The source files are269185 bytes each and PTX files8929889 bytes each. This is development-source evidence, explicitly recording dirty status and imported file hashes, not a clean-commit capture.

Reference partition summaries derived from retained IR show QR groups of64 and2 realized buffers (two kernels), versus RQ groups of64,1,1 (three kernels). The original summary parser counted nested member listings too; reference_partition_summary-v1.json preserves that rejected derivation, while reference_partition_summary.json removes nested members to report top-level groups.

The mechanism is more general than output buffer registration alone. post_grad.py:160–162 runs reorder_for_locality for inference. That pass (828–888) walks nodes in reverse, visits arguments in their specified order, and prepends producers whose users have all been seen. Return tuple order therefore changes the transformed FX traversal itself. The retained QR fx_graph_transformed.py places sub atline7; RQ places the same sub atline6090. Exact-output-stride realization then follows this return-order-dependent traversal. The QR and RQ scheduler groups also differ under the64-buffer fusion cap. The initially considered explanation based only on rank-zero delayed realization was unnecessarily narrow.

Rank-positive output exact-stride enforcement (graph.py:1955–2029) still matters: it realizes each output during transformed FX processing. Rank-zero skips that branch; remaining scalar outputs realize in flat output order at graph.py:1637. Consequently both output traversal order and rank are relevant numerical-plan inputs. A numerical plan keyed only by the existing Graph and an element-count hint cannot distinguish the measured QR/RQ programs.

The proposed buffer/region planner above is therefore incomplete until it receives immutable logical-specialization output traversal provenance and applies reference locality reordering before realization. Native executable reuse must still ignore return topology per the approved contract. Passing only n or a frozen n hint is insufficient; implementing topology-dependent region variants requires a separately reviewed mechanism to preserve executable reuse without enumerating output permutations.

A scalar version was already launched before the finite counterexample was recognized. It completed with +0 for q in both return orders, so it does not substantiate the scalar signed-zero hypothesis. Its raw sources, outputs, logs and caches are retained independently under scalar/.
