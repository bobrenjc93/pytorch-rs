class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[2]", arg1_1: "f32[2]"):
        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:2 in program, code: p=x*y
        mul: "f32[2]" = torch.ops.aten.mul.Tensor(arg0_1, arg1_1);  arg1_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:5 in program, code: r=r.sin()
        sin: "f32[2]" = torch.ops.aten.sin.default(mul)

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:6 in program, code: r=r.sin()
        sin_1: "f32[2]" = torch.ops.aten.sin.default(sin);  sin = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:7 in program, code: r=r.sin()
        sin_2: "f32[2]" = torch.ops.aten.sin.default(sin_1);  sin_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:8 in program, code: r=r.sin()
        sin_3: "f32[2]" = torch.ops.aten.sin.default(sin_2);  sin_2 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:9 in program, code: r=r.sin()
        sin_4: "f32[2]" = torch.ops.aten.sin.default(sin_3);  sin_3 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:10 in program, code: r=r.sin()
        sin_5: "f32[2]" = torch.ops.aten.sin.default(sin_4);  sin_4 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:11 in program, code: r=r.sin()
        sin_6: "f32[2]" = torch.ops.aten.sin.default(sin_5);  sin_5 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:12 in program, code: r=r.sin()
        sin_7: "f32[2]" = torch.ops.aten.sin.default(sin_6);  sin_6 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:13 in program, code: r=r.sin()
        sin_8: "f32[2]" = torch.ops.aten.sin.default(sin_7);  sin_7 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:14 in program, code: r=r.sin()
        sin_9: "f32[2]" = torch.ops.aten.sin.default(sin_8);  sin_8 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:15 in program, code: r=r.sin()
        sin_10: "f32[2]" = torch.ops.aten.sin.default(sin_9);  sin_9 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:16 in program, code: r=r.sin()
        sin_11: "f32[2]" = torch.ops.aten.sin.default(sin_10);  sin_10 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:17 in program, code: r=r.sin()
        sin_12: "f32[2]" = torch.ops.aten.sin.default(sin_11);  sin_11 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:18 in program, code: r=r.sin()
        sin_13: "f32[2]" = torch.ops.aten.sin.default(sin_12);  sin_12 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:19 in program, code: r=r.sin()
        sin_14: "f32[2]" = torch.ops.aten.sin.default(sin_13);  sin_13 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:20 in program, code: r=r.sin()
        sin_15: "f32[2]" = torch.ops.aten.sin.default(sin_14);  sin_14 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:21 in program, code: r=r.sin()
        sin_16: "f32[2]" = torch.ops.aten.sin.default(sin_15);  sin_15 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:22 in program, code: r=r.sin()
        sin_17: "f32[2]" = torch.ops.aten.sin.default(sin_16);  sin_16 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:23 in program, code: r=r.sin()
        sin_18: "f32[2]" = torch.ops.aten.sin.default(sin_17);  sin_17 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:24 in program, code: r=r.sin()
        sin_19: "f32[2]" = torch.ops.aten.sin.default(sin_18);  sin_18 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:25 in program, code: r=r.sin()
        sin_20: "f32[2]" = torch.ops.aten.sin.default(sin_19);  sin_19 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:26 in program, code: r=r.sin()
        sin_21: "f32[2]" = torch.ops.aten.sin.default(sin_20);  sin_20 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:27 in program, code: r=r.sin()
        sin_22: "f32[2]" = torch.ops.aten.sin.default(sin_21);  sin_21 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:28 in program, code: r=r.sin()
        sin_23: "f32[2]" = torch.ops.aten.sin.default(sin_22);  sin_22 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:29 in program, code: r=r.sin()
        sin_24: "f32[2]" = torch.ops.aten.sin.default(sin_23);  sin_23 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:30 in program, code: r=r.sin()
        sin_25: "f32[2]" = torch.ops.aten.sin.default(sin_24);  sin_24 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:31 in program, code: r=r.sin()
        sin_26: "f32[2]" = torch.ops.aten.sin.default(sin_25);  sin_25 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:32 in program, code: r=r.sin()
        sin_27: "f32[2]" = torch.ops.aten.sin.default(sin_26);  sin_26 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:33 in program, code: r=r.sin()
        sin_28: "f32[2]" = torch.ops.aten.sin.default(sin_27);  sin_27 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:34 in program, code: r=r.sin()
        sin_29: "f32[2]" = torch.ops.aten.sin.default(sin_28);  sin_28 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:35 in program, code: r=r.sin()+r.cos()
        sin_30: "f32[2]" = torch.ops.aten.sin.default(sin_29)
        cos: "f32[2]" = torch.ops.aten.cos.default(sin_29);  sin_29 = None
        add: "f32[2]" = torch.ops.aten.add.Tensor(sin_30, cos);  sin_30 = cos = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:36 in program, code: r=r.sin()
        sin_31: "f32[2]" = torch.ops.aten.sin.default(add);  add = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:37 in program, code: r=r.sin()
        sin_32: "f32[2]" = torch.ops.aten.sin.default(sin_31);  sin_31 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:38 in program, code: r=r.sin()
        sin_33: "f32[2]" = torch.ops.aten.sin.default(sin_32);  sin_32 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:39 in program, code: r=r.sin()
        sin_34: "f32[2]" = torch.ops.aten.sin.default(sin_33);  sin_33 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:40 in program, code: r=r.sin()
        sin_35: "f32[2]" = torch.ops.aten.sin.default(sin_34);  sin_34 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:41 in program, code: r=r.sin()
        sin_36: "f32[2]" = torch.ops.aten.sin.default(sin_35);  sin_35 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:42 in program, code: r=r.sin()
        sin_37: "f32[2]" = torch.ops.aten.sin.default(sin_36);  sin_36 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:43 in program, code: r=r.sin()
        sin_38: "f32[2]" = torch.ops.aten.sin.default(sin_37);  sin_37 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:44 in program, code: r=r.sin()
        sin_39: "f32[2]" = torch.ops.aten.sin.default(sin_38);  sin_38 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:45 in program, code: r=r.sin()
        sin_40: "f32[2]" = torch.ops.aten.sin.default(sin_39);  sin_39 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:46 in program, code: r=r.sin()
        sin_41: "f32[2]" = torch.ops.aten.sin.default(sin_40);  sin_40 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:47 in program, code: r=r.sin()
        sin_42: "f32[2]" = torch.ops.aten.sin.default(sin_41);  sin_41 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:48 in program, code: r=r.sin()
        sin_43: "f32[2]" = torch.ops.aten.sin.default(sin_42);  sin_42 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:49 in program, code: r=r.sin()
        sin_44: "f32[2]" = torch.ops.aten.sin.default(sin_43);  sin_43 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:50 in program, code: r=r.sin()
        sin_45: "f32[2]" = torch.ops.aten.sin.default(sin_44);  sin_44 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:51 in program, code: r=r.sin()
        sin_46: "f32[2]" = torch.ops.aten.sin.default(sin_45);  sin_45 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:52 in program, code: r=r.sin()
        sin_47: "f32[2]" = torch.ops.aten.sin.default(sin_46);  sin_46 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:53 in program, code: r=r.sin()
        sin_48: "f32[2]" = torch.ops.aten.sin.default(sin_47);  sin_47 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:54 in program, code: r=r.sin()
        sin_49: "f32[2]" = torch.ops.aten.sin.default(sin_48);  sin_48 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:55 in program, code: r=r.sin()
        sin_50: "f32[2]" = torch.ops.aten.sin.default(sin_49);  sin_49 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:56 in program, code: r=r.sin()
        sin_51: "f32[2]" = torch.ops.aten.sin.default(sin_50);  sin_50 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:57 in program, code: r=r.sin()
        sin_52: "f32[2]" = torch.ops.aten.sin.default(sin_51);  sin_51 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:58 in program, code: r=r.sin()
        sin_53: "f32[2]" = torch.ops.aten.sin.default(sin_52);  sin_52 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:59 in program, code: r=r.sin()
        sin_54: "f32[2]" = torch.ops.aten.sin.default(sin_53);  sin_53 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:60 in program, code: r=r.sin()
        sin_55: "f32[2]" = torch.ops.aten.sin.default(sin_54);  sin_54 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:61 in program, code: r=r.sin()
        sin_56: "f32[2]" = torch.ops.aten.sin.default(sin_55);  sin_55 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:62 in program, code: r=r.sin()
        sin_57: "f32[2]" = torch.ops.aten.sin.default(sin_56);  sin_56 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:63 in program, code: r=r.sin()
        sin_58: "f32[2]" = torch.ops.aten.sin.default(sin_57);  sin_57 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:64 in program, code: r=r.sin()
        sin_59: "f32[2]" = torch.ops.aten.sin.default(sin_58);  sin_58 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:65 in program, code: r=r.sin()
        sin_60: "f32[2]" = torch.ops.aten.sin.default(sin_59);  sin_59 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:66 in program, code: r=r.sin()+r.cos()
        sin_61: "f32[2]" = torch.ops.aten.sin.default(sin_60)
        cos_1: "f32[2]" = torch.ops.aten.cos.default(sin_60);  sin_60 = None
        add_1: "f32[2]" = torch.ops.aten.add.Tensor(sin_61, cos_1);  sin_61 = cos_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:67 in program, code: r=r.sin()
        sin_62: "f32[2]" = torch.ops.aten.sin.default(add_1);  add_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:68 in program, code: r=r.sin()
        sin_63: "f32[2]" = torch.ops.aten.sin.default(sin_62);  sin_62 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:69 in program, code: r=r.sin()
        sin_64: "f32[2]" = torch.ops.aten.sin.default(sin_63);  sin_63 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:70 in program, code: r=r.sin()
        sin_65: "f32[2]" = torch.ops.aten.sin.default(sin_64);  sin_64 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:71 in program, code: r=r.sin()
        sin_66: "f32[2]" = torch.ops.aten.sin.default(sin_65);  sin_65 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:72 in program, code: r=r.sin()
        sin_67: "f32[2]" = torch.ops.aten.sin.default(sin_66);  sin_66 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:73 in program, code: r=r.sin()
        sin_68: "f32[2]" = torch.ops.aten.sin.default(sin_67);  sin_67 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:74 in program, code: r=r.sin()
        sin_69: "f32[2]" = torch.ops.aten.sin.default(sin_68);  sin_68 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:75 in program, code: r=r.sin()
        sin_70: "f32[2]" = torch.ops.aten.sin.default(sin_69);  sin_69 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:76 in program, code: r=r.sin()
        sin_71: "f32[2]" = torch.ops.aten.sin.default(sin_70);  sin_70 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:77 in program, code: r=r.sin()
        sin_72: "f32[2]" = torch.ops.aten.sin.default(sin_71);  sin_71 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:78 in program, code: r=r.sin()
        sin_73: "f32[2]" = torch.ops.aten.sin.default(sin_72);  sin_72 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:79 in program, code: r=r.sin()
        sin_74: "f32[2]" = torch.ops.aten.sin.default(sin_73);  sin_73 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:80 in program, code: r=r.sin()
        sin_75: "f32[2]" = torch.ops.aten.sin.default(sin_74);  sin_74 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:81 in program, code: r=r.sin()
        sin_76: "f32[2]" = torch.ops.aten.sin.default(sin_75);  sin_75 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:82 in program, code: r=r.sin()
        sin_77: "f32[2]" = torch.ops.aten.sin.default(sin_76);  sin_76 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:83 in program, code: r=r.sin()
        sin_78: "f32[2]" = torch.ops.aten.sin.default(sin_77);  sin_77 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:84 in program, code: r=r.sin()
        sin_79: "f32[2]" = torch.ops.aten.sin.default(sin_78);  sin_78 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:85 in program, code: r=r.sin()
        sin_80: "f32[2]" = torch.ops.aten.sin.default(sin_79);  sin_79 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:86 in program, code: r=r.sin()
        sin_81: "f32[2]" = torch.ops.aten.sin.default(sin_80);  sin_80 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:87 in program, code: r=r.sin()
        sin_82: "f32[2]" = torch.ops.aten.sin.default(sin_81);  sin_81 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:88 in program, code: r=r.sin()
        sin_83: "f32[2]" = torch.ops.aten.sin.default(sin_82);  sin_82 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:89 in program, code: r=r.sin()
        sin_84: "f32[2]" = torch.ops.aten.sin.default(sin_83);  sin_83 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:90 in program, code: r=r.sin()
        sin_85: "f32[2]" = torch.ops.aten.sin.default(sin_84);  sin_84 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:91 in program, code: r=r.sin()
        sin_86: "f32[2]" = torch.ops.aten.sin.default(sin_85);  sin_85 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:92 in program, code: r=r.sin()
        sin_87: "f32[2]" = torch.ops.aten.sin.default(sin_86);  sin_86 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:93 in program, code: r=r.sin()
        sin_88: "f32[2]" = torch.ops.aten.sin.default(sin_87);  sin_87 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:94 in program, code: r=r.sin()
        sin_89: "f32[2]" = torch.ops.aten.sin.default(sin_88);  sin_88 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:95 in program, code: r=r.sin()
        sin_90: "f32[2]" = torch.ops.aten.sin.default(sin_89);  sin_89 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:96 in program, code: r=r.sin()
        sin_91: "f32[2]" = torch.ops.aten.sin.default(sin_90);  sin_90 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:97 in program, code: r=r.sin()+r.cos()
        sin_92: "f32[2]" = torch.ops.aten.sin.default(sin_91)
        cos_2: "f32[2]" = torch.ops.aten.cos.default(sin_91);  sin_91 = None
        add_2: "f32[2]" = torch.ops.aten.add.Tensor(sin_92, cos_2);  sin_92 = cos_2 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:98 in program, code: r=r.sin()
        sin_93: "f32[2]" = torch.ops.aten.sin.default(add_2);  add_2 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:99 in program, code: r=r.sin()
        sin_94: "f32[2]" = torch.ops.aten.sin.default(sin_93);  sin_93 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:100 in program, code: r=r.sin()
        sin_95: "f32[2]" = torch.ops.aten.sin.default(sin_94);  sin_94 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:101 in program, code: r=r.sin()
        sin_96: "f32[2]" = torch.ops.aten.sin.default(sin_95);  sin_95 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:102 in program, code: r=r.sin()
        sin_97: "f32[2]" = torch.ops.aten.sin.default(sin_96);  sin_96 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:103 in program, code: r=r.sin()
        sin_98: "f32[2]" = torch.ops.aten.sin.default(sin_97);  sin_97 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:104 in program, code: r=r.sin()
        sin_99: "f32[2]" = torch.ops.aten.sin.default(sin_98);  sin_98 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:105 in program, code: r=r.sin()
        sin_100: "f32[2]" = torch.ops.aten.sin.default(sin_99);  sin_99 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:106 in program, code: r=r.sin()
        sin_101: "f32[2]" = torch.ops.aten.sin.default(sin_100);  sin_100 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:107 in program, code: r=r.sin()
        sin_102: "f32[2]" = torch.ops.aten.sin.default(sin_101);  sin_101 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:108 in program, code: r=r.sin()
        sin_103: "f32[2]" = torch.ops.aten.sin.default(sin_102);  sin_102 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:109 in program, code: r=r.sin()
        sin_104: "f32[2]" = torch.ops.aten.sin.default(sin_103);  sin_103 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:110 in program, code: r=r.sin()
        sin_105: "f32[2]" = torch.ops.aten.sin.default(sin_104);  sin_104 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:111 in program, code: r=r.sin()
        sin_106: "f32[2]" = torch.ops.aten.sin.default(sin_105);  sin_105 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:112 in program, code: r=r.sin()
        sin_107: "f32[2]" = torch.ops.aten.sin.default(sin_106);  sin_106 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:113 in program, code: r=r.sin()
        sin_108: "f32[2]" = torch.ops.aten.sin.default(sin_107);  sin_107 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:114 in program, code: r=r.sin()
        sin_109: "f32[2]" = torch.ops.aten.sin.default(sin_108);  sin_108 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:115 in program, code: r=r.sin()
        sin_110: "f32[2]" = torch.ops.aten.sin.default(sin_109);  sin_109 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:116 in program, code: r=r.sin()
        sin_111: "f32[2]" = torch.ops.aten.sin.default(sin_110);  sin_110 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:117 in program, code: r=r.sin()
        sin_112: "f32[2]" = torch.ops.aten.sin.default(sin_111);  sin_111 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:118 in program, code: r=r.sin()
        sin_113: "f32[2]" = torch.ops.aten.sin.default(sin_112);  sin_112 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:119 in program, code: r=r.sin()
        sin_114: "f32[2]" = torch.ops.aten.sin.default(sin_113);  sin_113 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:120 in program, code: r=r.sin()
        sin_115: "f32[2]" = torch.ops.aten.sin.default(sin_114);  sin_114 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:121 in program, code: r=r.sin()
        sin_116: "f32[2]" = torch.ops.aten.sin.default(sin_115);  sin_115 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:122 in program, code: r=r.sin()
        sin_117: "f32[2]" = torch.ops.aten.sin.default(sin_116);  sin_116 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:123 in program, code: r=r.sin()
        sin_118: "f32[2]" = torch.ops.aten.sin.default(sin_117);  sin_117 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:124 in program, code: r=r.sin()
        sin_119: "f32[2]" = torch.ops.aten.sin.default(sin_118);  sin_118 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:125 in program, code: r=r.sin()
        sin_120: "f32[2]" = torch.ops.aten.sin.default(sin_119);  sin_119 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:126 in program, code: r=r.sin()
        sin_121: "f32[2]" = torch.ops.aten.sin.default(sin_120);  sin_120 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:127 in program, code: r=r.sin()
        sin_122: "f32[2]" = torch.ops.aten.sin.default(sin_121);  sin_121 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:128 in program, code: r=r.sin()+r.cos()
        sin_123: "f32[2]" = torch.ops.aten.sin.default(sin_122)
        cos_3: "f32[2]" = torch.ops.aten.cos.default(sin_122);  sin_122 = None
        add_3: "f32[2]" = torch.ops.aten.add.Tensor(sin_123, cos_3);  sin_123 = cos_3 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:129 in program, code: r=r.sin()
        sin_124: "f32[2]" = torch.ops.aten.sin.default(add_3);  add_3 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:130 in program, code: r=r.sin()
        sin_125: "f32[2]" = torch.ops.aten.sin.default(sin_124);  sin_124 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:131 in program, code: r=r.sin()
        sin_126: "f32[2]" = torch.ops.aten.sin.default(sin_125);  sin_125 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:132 in program, code: r=r.sin()
        sin_127: "f32[2]" = torch.ops.aten.sin.default(sin_126);  sin_126 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:133 in program, code: r=r.sin()
        sin_128: "f32[2]" = torch.ops.aten.sin.default(sin_127);  sin_127 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:134 in program, code: r=r.sin()
        sin_129: "f32[2]" = torch.ops.aten.sin.default(sin_128);  sin_128 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:135 in program, code: r=r.sin()
        sin_130: "f32[2]" = torch.ops.aten.sin.default(sin_129);  sin_129 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:136 in program, code: r=r.sin()
        sin_131: "f32[2]" = torch.ops.aten.sin.default(sin_130);  sin_130 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:137 in program, code: r=r.sin()
        sin_132: "f32[2]" = torch.ops.aten.sin.default(sin_131);  sin_131 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:138 in program, code: r=r.sin()
        sin_133: "f32[2]" = torch.ops.aten.sin.default(sin_132);  sin_132 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:139 in program, code: r=r.sin()
        sin_134: "f32[2]" = torch.ops.aten.sin.default(sin_133);  sin_133 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:140 in program, code: r=r.sin()
        sin_135: "f32[2]" = torch.ops.aten.sin.default(sin_134);  sin_134 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:141 in program, code: r=r.sin()
        sin_136: "f32[2]" = torch.ops.aten.sin.default(sin_135);  sin_135 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:142 in program, code: r=r.sin()
        sin_137: "f32[2]" = torch.ops.aten.sin.default(sin_136);  sin_136 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:143 in program, code: r=r.sin()
        sin_138: "f32[2]" = torch.ops.aten.sin.default(sin_137);  sin_137 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:144 in program, code: r=r.sin()
        sin_139: "f32[2]" = torch.ops.aten.sin.default(sin_138);  sin_138 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:145 in program, code: r=r.sin()
        sin_140: "f32[2]" = torch.ops.aten.sin.default(sin_139);  sin_139 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:146 in program, code: r=r.sin()
        sin_141: "f32[2]" = torch.ops.aten.sin.default(sin_140);  sin_140 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:147 in program, code: r=r.sin()
        sin_142: "f32[2]" = torch.ops.aten.sin.default(sin_141);  sin_141 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:148 in program, code: r=r.sin()
        sin_143: "f32[2]" = torch.ops.aten.sin.default(sin_142);  sin_142 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:149 in program, code: r=r.sin()
        sin_144: "f32[2]" = torch.ops.aten.sin.default(sin_143);  sin_143 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:150 in program, code: r=r.sin()
        sin_145: "f32[2]" = torch.ops.aten.sin.default(sin_144);  sin_144 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:151 in program, code: r=r.sin()
        sin_146: "f32[2]" = torch.ops.aten.sin.default(sin_145);  sin_145 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:152 in program, code: r=r.sin()
        sin_147: "f32[2]" = torch.ops.aten.sin.default(sin_146);  sin_146 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:153 in program, code: r=r.sin()
        sin_148: "f32[2]" = torch.ops.aten.sin.default(sin_147);  sin_147 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:154 in program, code: r=r.sin()
        sin_149: "f32[2]" = torch.ops.aten.sin.default(sin_148);  sin_148 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:155 in program, code: r=r.sin()
        sin_150: "f32[2]" = torch.ops.aten.sin.default(sin_149);  sin_149 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:156 in program, code: r=r.sin()
        sin_151: "f32[2]" = torch.ops.aten.sin.default(sin_150);  sin_150 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:157 in program, code: r=r.sin()
        sin_152: "f32[2]" = torch.ops.aten.sin.default(sin_151);  sin_151 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:158 in program, code: r=r.sin()
        sin_153: "f32[2]" = torch.ops.aten.sin.default(sin_152);  sin_152 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:159 in program, code: r=r.sin()+r.cos()
        sin_154: "f32[2]" = torch.ops.aten.sin.default(sin_153)
        cos_4: "f32[2]" = torch.ops.aten.cos.default(sin_153);  sin_153 = None
        add_4: "f32[2]" = torch.ops.aten.add.Tensor(sin_154, cos_4);  sin_154 = cos_4 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:160 in program, code: r=r.sin()
        sin_155: "f32[2]" = torch.ops.aten.sin.default(add_4);  add_4 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:161 in program, code: r=r.sin()
        sin_156: "f32[2]" = torch.ops.aten.sin.default(sin_155);  sin_155 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:162 in program, code: r=r.sin()
        sin_157: "f32[2]" = torch.ops.aten.sin.default(sin_156);  sin_156 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:163 in program, code: r=r.sin()
        sin_158: "f32[2]" = torch.ops.aten.sin.default(sin_157);  sin_157 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:164 in program, code: r=r.sin()
        sin_159: "f32[2]" = torch.ops.aten.sin.default(sin_158);  sin_158 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:165 in program, code: r=r.sin()
        sin_160: "f32[2]" = torch.ops.aten.sin.default(sin_159);  sin_159 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:166 in program, code: r=r.sin()
        sin_161: "f32[2]" = torch.ops.aten.sin.default(sin_160);  sin_160 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:167 in program, code: r=r.sin()
        sin_162: "f32[2]" = torch.ops.aten.sin.default(sin_161);  sin_161 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:168 in program, code: r=r.sin()
        sin_163: "f32[2]" = torch.ops.aten.sin.default(sin_162);  sin_162 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:169 in program, code: r=r.sin()
        sin_164: "f32[2]" = torch.ops.aten.sin.default(sin_163);  sin_163 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:170 in program, code: r=r.sin()
        sin_165: "f32[2]" = torch.ops.aten.sin.default(sin_164);  sin_164 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:171 in program, code: r=r.sin()
        sin_166: "f32[2]" = torch.ops.aten.sin.default(sin_165);  sin_165 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:172 in program, code: r=r.sin()
        sin_167: "f32[2]" = torch.ops.aten.sin.default(sin_166);  sin_166 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:173 in program, code: r=r.sin()
        sin_168: "f32[2]" = torch.ops.aten.sin.default(sin_167);  sin_167 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:174 in program, code: r=r.sin()
        sin_169: "f32[2]" = torch.ops.aten.sin.default(sin_168);  sin_168 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:175 in program, code: r=r.sin()
        sin_170: "f32[2]" = torch.ops.aten.sin.default(sin_169);  sin_169 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:176 in program, code: r=r.sin()
        sin_171: "f32[2]" = torch.ops.aten.sin.default(sin_170);  sin_170 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:177 in program, code: r=r.sin()
        sin_172: "f32[2]" = torch.ops.aten.sin.default(sin_171);  sin_171 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:178 in program, code: r=r.sin()
        sin_173: "f32[2]" = torch.ops.aten.sin.default(sin_172);  sin_172 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:179 in program, code: r=r.sin()
        sin_174: "f32[2]" = torch.ops.aten.sin.default(sin_173);  sin_173 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:180 in program, code: r=r.sin()
        sin_175: "f32[2]" = torch.ops.aten.sin.default(sin_174);  sin_174 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:181 in program, code: r=r.sin()
        sin_176: "f32[2]" = torch.ops.aten.sin.default(sin_175);  sin_175 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:182 in program, code: r=r.sin()
        sin_177: "f32[2]" = torch.ops.aten.sin.default(sin_176);  sin_176 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:183 in program, code: r=r.sin()
        sin_178: "f32[2]" = torch.ops.aten.sin.default(sin_177);  sin_177 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:184 in program, code: r=r.sin()
        sin_179: "f32[2]" = torch.ops.aten.sin.default(sin_178);  sin_178 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:185 in program, code: r=r.sin()
        sin_180: "f32[2]" = torch.ops.aten.sin.default(sin_179);  sin_179 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:186 in program, code: r=r.sin()
        sin_181: "f32[2]" = torch.ops.aten.sin.default(sin_180);  sin_180 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:187 in program, code: r=r.sin()
        sin_182: "f32[2]" = torch.ops.aten.sin.default(sin_181);  sin_181 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:188 in program, code: r=r.sin()
        sin_183: "f32[2]" = torch.ops.aten.sin.default(sin_182);  sin_182 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:189 in program, code: r=r.sin()
        sin_184: "f32[2]" = torch.ops.aten.sin.default(sin_183);  sin_183 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:190 in program, code: r=r.sin()+r.cos()
        sin_185: "f32[2]" = torch.ops.aten.sin.default(sin_184)
        cos_5: "f32[2]" = torch.ops.aten.cos.default(sin_184);  sin_184 = None
        add_5: "f32[2]" = torch.ops.aten.add.Tensor(sin_185, cos_5);  sin_185 = cos_5 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:191 in program, code: r=r.sin()
        sin_186: "f32[2]" = torch.ops.aten.sin.default(add_5);  add_5 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:192 in program, code: r=r.sin()
        sin_187: "f32[2]" = torch.ops.aten.sin.default(sin_186);  sin_186 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:193 in program, code: r=r.sin()
        sin_188: "f32[2]" = torch.ops.aten.sin.default(sin_187);  sin_187 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:194 in program, code: r=r.sin()
        sin_189: "f32[2]" = torch.ops.aten.sin.default(sin_188);  sin_188 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:195 in program, code: r=r.sin()
        sin_190: "f32[2]" = torch.ops.aten.sin.default(sin_189);  sin_189 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:196 in program, code: r=r.sin()
        sin_191: "f32[2]" = torch.ops.aten.sin.default(sin_190);  sin_190 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:197 in program, code: r=r.sin()
        sin_192: "f32[2]" = torch.ops.aten.sin.default(sin_191);  sin_191 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:198 in program, code: r=r.sin()
        sin_193: "f32[2]" = torch.ops.aten.sin.default(sin_192);  sin_192 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:199 in program, code: r=r.sin()
        sin_194: "f32[2]" = torch.ops.aten.sin.default(sin_193);  sin_193 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:200 in program, code: r=r.sin()
        sin_195: "f32[2]" = torch.ops.aten.sin.default(sin_194);  sin_194 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:201 in program, code: r=r.sin()
        sin_196: "f32[2]" = torch.ops.aten.sin.default(sin_195);  sin_195 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:202 in program, code: r=r.sin()
        sin_197: "f32[2]" = torch.ops.aten.sin.default(sin_196);  sin_196 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:203 in program, code: r=r.sin()
        sin_198: "f32[2]" = torch.ops.aten.sin.default(sin_197);  sin_197 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:204 in program, code: r=r.sin()
        sin_199: "f32[2]" = torch.ops.aten.sin.default(sin_198);  sin_198 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:205 in program, code: r=r.sin()
        sin_200: "f32[2]" = torch.ops.aten.sin.default(sin_199);  sin_199 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:206 in program, code: r=r.sin()
        sin_201: "f32[2]" = torch.ops.aten.sin.default(sin_200);  sin_200 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:207 in program, code: r=r.sin()
        sin_202: "f32[2]" = torch.ops.aten.sin.default(sin_201);  sin_201 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:208 in program, code: r=r.sin()
        sin_203: "f32[2]" = torch.ops.aten.sin.default(sin_202);  sin_202 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:209 in program, code: r=r.sin()
        sin_204: "f32[2]" = torch.ops.aten.sin.default(sin_203);  sin_203 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:210 in program, code: r=r.sin()
        sin_205: "f32[2]" = torch.ops.aten.sin.default(sin_204);  sin_204 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:211 in program, code: r=r.sin()
        sin_206: "f32[2]" = torch.ops.aten.sin.default(sin_205);  sin_205 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:212 in program, code: r=r.sin()
        sin_207: "f32[2]" = torch.ops.aten.sin.default(sin_206);  sin_206 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:213 in program, code: r=r.sin()
        sin_208: "f32[2]" = torch.ops.aten.sin.default(sin_207);  sin_207 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:214 in program, code: r=r.sin()
        sin_209: "f32[2]" = torch.ops.aten.sin.default(sin_208);  sin_208 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:215 in program, code: r=r.sin()
        sin_210: "f32[2]" = torch.ops.aten.sin.default(sin_209);  sin_209 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:216 in program, code: r=r.sin()
        sin_211: "f32[2]" = torch.ops.aten.sin.default(sin_210);  sin_210 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:217 in program, code: r=r.sin()
        sin_212: "f32[2]" = torch.ops.aten.sin.default(sin_211);  sin_211 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:218 in program, code: r=r.sin()
        sin_213: "f32[2]" = torch.ops.aten.sin.default(sin_212);  sin_212 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:219 in program, code: r=r.sin()
        sin_214: "f32[2]" = torch.ops.aten.sin.default(sin_213);  sin_213 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:220 in program, code: r=r.sin()
        sin_215: "f32[2]" = torch.ops.aten.sin.default(sin_214);  sin_214 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:221 in program, code: r=r.sin()+r.cos()
        sin_216: "f32[2]" = torch.ops.aten.sin.default(sin_215)
        cos_6: "f32[2]" = torch.ops.aten.cos.default(sin_215);  sin_215 = None
        add_6: "f32[2]" = torch.ops.aten.add.Tensor(sin_216, cos_6);  sin_216 = cos_6 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:222 in program, code: r=r.sin()
        sin_217: "f32[2]" = torch.ops.aten.sin.default(add_6);  add_6 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:223 in program, code: r=r.sin()
        sin_218: "f32[2]" = torch.ops.aten.sin.default(sin_217);  sin_217 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:224 in program, code: r=r.sin()
        sin_219: "f32[2]" = torch.ops.aten.sin.default(sin_218);  sin_218 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:225 in program, code: r=r.sin()
        sin_220: "f32[2]" = torch.ops.aten.sin.default(sin_219);  sin_219 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:226 in program, code: r=r.sin()
        sin_221: "f32[2]" = torch.ops.aten.sin.default(sin_220);  sin_220 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:227 in program, code: r=r.sin()
        sin_222: "f32[2]" = torch.ops.aten.sin.default(sin_221);  sin_221 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:228 in program, code: r=r.sin()
        sin_223: "f32[2]" = torch.ops.aten.sin.default(sin_222);  sin_222 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:229 in program, code: r=r.sin()
        sin_224: "f32[2]" = torch.ops.aten.sin.default(sin_223);  sin_223 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:230 in program, code: r=r.sin()
        sin_225: "f32[2]" = torch.ops.aten.sin.default(sin_224);  sin_224 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:231 in program, code: r=r.sin()
        sin_226: "f32[2]" = torch.ops.aten.sin.default(sin_225);  sin_225 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:232 in program, code: r=r.sin()
        sin_227: "f32[2]" = torch.ops.aten.sin.default(sin_226);  sin_226 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:233 in program, code: r=r.sin()
        sin_228: "f32[2]" = torch.ops.aten.sin.default(sin_227);  sin_227 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:234 in program, code: r=r.sin()
        sin_229: "f32[2]" = torch.ops.aten.sin.default(sin_228);  sin_228 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:235 in program, code: r=r.sin()
        sin_230: "f32[2]" = torch.ops.aten.sin.default(sin_229);  sin_229 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:236 in program, code: r=r.sin()
        sin_231: "f32[2]" = torch.ops.aten.sin.default(sin_230);  sin_230 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:237 in program, code: r=r.sin()
        sin_232: "f32[2]" = torch.ops.aten.sin.default(sin_231);  sin_231 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:238 in program, code: r=r.sin()
        sin_233: "f32[2]" = torch.ops.aten.sin.default(sin_232);  sin_232 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:239 in program, code: r=r.sin()
        sin_234: "f32[2]" = torch.ops.aten.sin.default(sin_233);  sin_233 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:240 in program, code: r=r.sin()
        sin_235: "f32[2]" = torch.ops.aten.sin.default(sin_234);  sin_234 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:241 in program, code: r=r.sin()
        sin_236: "f32[2]" = torch.ops.aten.sin.default(sin_235);  sin_235 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:242 in program, code: r=r.sin()
        sin_237: "f32[2]" = torch.ops.aten.sin.default(sin_236);  sin_236 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:243 in program, code: r=r.sin()
        sin_238: "f32[2]" = torch.ops.aten.sin.default(sin_237);  sin_237 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:244 in program, code: r=r.sin()
        sin_239: "f32[2]" = torch.ops.aten.sin.default(sin_238);  sin_238 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:245 in program, code: r=r.sin()
        sin_240: "f32[2]" = torch.ops.aten.sin.default(sin_239);  sin_239 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:246 in program, code: r=r.sin()
        sin_241: "f32[2]" = torch.ops.aten.sin.default(sin_240);  sin_240 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:247 in program, code: r=r.sin()
        sin_242: "f32[2]" = torch.ops.aten.sin.default(sin_241);  sin_241 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:248 in program, code: r=r.sin()
        sin_243: "f32[2]" = torch.ops.aten.sin.default(sin_242);  sin_242 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:249 in program, code: r=r.sin()
        sin_244: "f32[2]" = torch.ops.aten.sin.default(sin_243);  sin_243 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:250 in program, code: r=r.sin()
        sin_245: "f32[2]" = torch.ops.aten.sin.default(sin_244);  sin_244 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:251 in program, code: r=r.sin()
        sin_246: "f32[2]" = torch.ops.aten.sin.default(sin_245);  sin_245 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:252 in program, code: r=r.sin()+r.cos()
        sin_247: "f32[2]" = torch.ops.aten.sin.default(sin_246)
        cos_7: "f32[2]" = torch.ops.aten.cos.default(sin_246);  sin_246 = None
        add_7: "f32[2]" = torch.ops.aten.add.Tensor(sin_247, cos_7);  sin_247 = cos_7 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:253 in program, code: r=r.sin()
        sin_248: "f32[2]" = torch.ops.aten.sin.default(add_7);  add_7 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:254 in program, code: r=r.sin()
        sin_249: "f32[2]" = torch.ops.aten.sin.default(sin_248);  sin_248 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:255 in program, code: r=r.sin()
        sin_250: "f32[2]" = torch.ops.aten.sin.default(sin_249);  sin_249 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:256 in program, code: r=r.sin()
        sin_251: "f32[2]" = torch.ops.aten.sin.default(sin_250);  sin_250 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:257 in program, code: r=r.sin()
        sin_252: "f32[2]" = torch.ops.aten.sin.default(sin_251);  sin_251 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:258 in program, code: r=r.sin()
        sin_253: "f32[2]" = torch.ops.aten.sin.default(sin_252);  sin_252 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:259 in program, code: r=r.sin()
        sin_254: "f32[2]" = torch.ops.aten.sin.default(sin_253);  sin_253 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:260 in program, code: r=r.sin()
        sin_255: "f32[2]" = torch.ops.aten.sin.default(sin_254);  sin_254 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:261 in program, code: r=r.sin()
        sin_256: "f32[2]" = torch.ops.aten.sin.default(sin_255);  sin_255 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:262 in program, code: r=r.sin()
        sin_257: "f32[2]" = torch.ops.aten.sin.default(sin_256);  sin_256 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:263 in program, code: r=r.sin()
        sin_258: "f32[2]" = torch.ops.aten.sin.default(sin_257);  sin_257 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:264 in program, code: r=r.sin()
        sin_259: "f32[2]" = torch.ops.aten.sin.default(sin_258);  sin_258 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:265 in program, code: r=r.sin()
        sin_260: "f32[2]" = torch.ops.aten.sin.default(sin_259);  sin_259 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:266 in program, code: r=r.sin()
        sin_261: "f32[2]" = torch.ops.aten.sin.default(sin_260);  sin_260 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:267 in program, code: r=r.sin()
        sin_262: "f32[2]" = torch.ops.aten.sin.default(sin_261);  sin_261 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:268 in program, code: r=r.sin()
        sin_263: "f32[2]" = torch.ops.aten.sin.default(sin_262);  sin_262 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:269 in program, code: r=r.sin()
        sin_264: "f32[2]" = torch.ops.aten.sin.default(sin_263);  sin_263 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:270 in program, code: r=r.sin()
        sin_265: "f32[2]" = torch.ops.aten.sin.default(sin_264);  sin_264 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:271 in program, code: r=r.sin()
        sin_266: "f32[2]" = torch.ops.aten.sin.default(sin_265);  sin_265 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:272 in program, code: r=r.sin()
        sin_267: "f32[2]" = torch.ops.aten.sin.default(sin_266);  sin_266 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:273 in program, code: r=r.sin()
        sin_268: "f32[2]" = torch.ops.aten.sin.default(sin_267);  sin_267 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:274 in program, code: r=r.sin()
        sin_269: "f32[2]" = torch.ops.aten.sin.default(sin_268);  sin_268 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:275 in program, code: r=r.sin()
        sin_270: "f32[2]" = torch.ops.aten.sin.default(sin_269);  sin_269 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:276 in program, code: r=r.sin()
        sin_271: "f32[2]" = torch.ops.aten.sin.default(sin_270);  sin_270 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:277 in program, code: r=r.sin()
        sin_272: "f32[2]" = torch.ops.aten.sin.default(sin_271);  sin_271 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:278 in program, code: r=r.sin()
        sin_273: "f32[2]" = torch.ops.aten.sin.default(sin_272);  sin_272 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:279 in program, code: r=r.sin()
        sin_274: "f32[2]" = torch.ops.aten.sin.default(sin_273);  sin_273 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:280 in program, code: r=r.sin()
        sin_275: "f32[2]" = torch.ops.aten.sin.default(sin_274);  sin_274 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:281 in program, code: r=r.sin()
        sin_276: "f32[2]" = torch.ops.aten.sin.default(sin_275);  sin_275 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:282 in program, code: r=r.sin()
        sin_277: "f32[2]" = torch.ops.aten.sin.default(sin_276);  sin_276 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:283 in program, code: r=r.sin()+r.cos()
        sin_278: "f32[2]" = torch.ops.aten.sin.default(sin_277)
        cos_8: "f32[2]" = torch.ops.aten.cos.default(sin_277);  sin_277 = None
        add_8: "f32[2]" = torch.ops.aten.add.Tensor(sin_278, cos_8);  sin_278 = cos_8 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:284 in program, code: r=r.sin()
        sin_279: "f32[2]" = torch.ops.aten.sin.default(add_8);  add_8 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:285 in program, code: r=r.sin()
        sin_280: "f32[2]" = torch.ops.aten.sin.default(sin_279);  sin_279 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:286 in program, code: r=r.sin()
        sin_281: "f32[2]" = torch.ops.aten.sin.default(sin_280);  sin_280 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:287 in program, code: r=r.sin()
        sin_282: "f32[2]" = torch.ops.aten.sin.default(sin_281);  sin_281 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:288 in program, code: r=r.sin()
        sin_283: "f32[2]" = torch.ops.aten.sin.default(sin_282);  sin_282 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:289 in program, code: r=r.sin()
        sin_284: "f32[2]" = torch.ops.aten.sin.default(sin_283);  sin_283 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:290 in program, code: r=r.sin()
        sin_285: "f32[2]" = torch.ops.aten.sin.default(sin_284);  sin_284 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:291 in program, code: r=r.sin()
        sin_286: "f32[2]" = torch.ops.aten.sin.default(sin_285);  sin_285 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:292 in program, code: r=r.sin()
        sin_287: "f32[2]" = torch.ops.aten.sin.default(sin_286);  sin_286 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:293 in program, code: r=r.sin()
        sin_288: "f32[2]" = torch.ops.aten.sin.default(sin_287);  sin_287 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:294 in program, code: r=r.sin()
        sin_289: "f32[2]" = torch.ops.aten.sin.default(sin_288);  sin_288 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:295 in program, code: r=r.sin()
        sin_290: "f32[2]" = torch.ops.aten.sin.default(sin_289);  sin_289 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:296 in program, code: r=r.sin()
        sin_291: "f32[2]" = torch.ops.aten.sin.default(sin_290);  sin_290 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:297 in program, code: r=r.sin()
        sin_292: "f32[2]" = torch.ops.aten.sin.default(sin_291);  sin_291 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:298 in program, code: r=r.sin()
        sin_293: "f32[2]" = torch.ops.aten.sin.default(sin_292);  sin_292 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:299 in program, code: r=r.sin()
        sin_294: "f32[2]" = torch.ops.aten.sin.default(sin_293);  sin_293 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:300 in program, code: r=r.sin()
        sin_295: "f32[2]" = torch.ops.aten.sin.default(sin_294);  sin_294 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:301 in program, code: r=r.sin()
        sin_296: "f32[2]" = torch.ops.aten.sin.default(sin_295);  sin_295 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:302 in program, code: r=r.sin()
        sin_297: "f32[2]" = torch.ops.aten.sin.default(sin_296);  sin_296 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:303 in program, code: r=r.sin()
        sin_298: "f32[2]" = torch.ops.aten.sin.default(sin_297);  sin_297 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:304 in program, code: r=r.sin()
        sin_299: "f32[2]" = torch.ops.aten.sin.default(sin_298);  sin_298 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:305 in program, code: r=r.sin()
        sin_300: "f32[2]" = torch.ops.aten.sin.default(sin_299);  sin_299 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:306 in program, code: r=r.sin()
        sin_301: "f32[2]" = torch.ops.aten.sin.default(sin_300);  sin_300 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:307 in program, code: r=r.sin()
        sin_302: "f32[2]" = torch.ops.aten.sin.default(sin_301);  sin_301 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:308 in program, code: r=r.sin()
        sin_303: "f32[2]" = torch.ops.aten.sin.default(sin_302);  sin_302 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:309 in program, code: r=r.sin()
        sin_304: "f32[2]" = torch.ops.aten.sin.default(sin_303);  sin_303 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:310 in program, code: r=r.sin()
        sin_305: "f32[2]" = torch.ops.aten.sin.default(sin_304);  sin_304 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:311 in program, code: r=r.sin()
        sin_306: "f32[2]" = torch.ops.aten.sin.default(sin_305);  sin_305 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:312 in program, code: r=r.sin()
        sin_307: "f32[2]" = torch.ops.aten.sin.default(sin_306);  sin_306 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:313 in program, code: r=r.sin()
        sin_308: "f32[2]" = torch.ops.aten.sin.default(sin_307);  sin_307 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:314 in program, code: r=r.sin()+r.cos()
        sin_309: "f32[2]" = torch.ops.aten.sin.default(sin_308)
        cos_9: "f32[2]" = torch.ops.aten.cos.default(sin_308);  sin_308 = None
        add_9: "f32[2]" = torch.ops.aten.add.Tensor(sin_309, cos_9);  sin_309 = cos_9 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:315 in program, code: r=r.sin()
        sin_310: "f32[2]" = torch.ops.aten.sin.default(add_9);  add_9 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:316 in program, code: r=r.sin()
        sin_311: "f32[2]" = torch.ops.aten.sin.default(sin_310);  sin_310 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:317 in program, code: r=r.sin()
        sin_312: "f32[2]" = torch.ops.aten.sin.default(sin_311);  sin_311 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:318 in program, code: r=r.sin()
        sin_313: "f32[2]" = torch.ops.aten.sin.default(sin_312);  sin_312 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:319 in program, code: r=r.sin()
        sin_314: "f32[2]" = torch.ops.aten.sin.default(sin_313);  sin_313 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:320 in program, code: r=r.sin()
        sin_315: "f32[2]" = torch.ops.aten.sin.default(sin_314);  sin_314 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:321 in program, code: r=r.sin()
        sin_316: "f32[2]" = torch.ops.aten.sin.default(sin_315);  sin_315 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:322 in program, code: r=r.sin()
        sin_317: "f32[2]" = torch.ops.aten.sin.default(sin_316);  sin_316 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:323 in program, code: r=r.sin()
        sin_318: "f32[2]" = torch.ops.aten.sin.default(sin_317);  sin_317 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:324 in program, code: r=r.sin()
        sin_319: "f32[2]" = torch.ops.aten.sin.default(sin_318);  sin_318 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:325 in program, code: r=r.sin()
        sin_320: "f32[2]" = torch.ops.aten.sin.default(sin_319);  sin_319 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:326 in program, code: r=r.sin()
        sin_321: "f32[2]" = torch.ops.aten.sin.default(sin_320);  sin_320 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:327 in program, code: r=r.sin()
        sin_322: "f32[2]" = torch.ops.aten.sin.default(sin_321);  sin_321 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:328 in program, code: r=r.sin()
        sin_323: "f32[2]" = torch.ops.aten.sin.default(sin_322);  sin_322 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:329 in program, code: r=r.sin()
        sin_324: "f32[2]" = torch.ops.aten.sin.default(sin_323);  sin_323 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:330 in program, code: r=r.sin()
        sin_325: "f32[2]" = torch.ops.aten.sin.default(sin_324);  sin_324 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:331 in program, code: r=r.sin()
        sin_326: "f32[2]" = torch.ops.aten.sin.default(sin_325);  sin_325 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:332 in program, code: r=r.sin()
        sin_327: "f32[2]" = torch.ops.aten.sin.default(sin_326);  sin_326 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:333 in program, code: r=r.sin()
        sin_328: "f32[2]" = torch.ops.aten.sin.default(sin_327);  sin_327 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:334 in program, code: r=r.sin()
        sin_329: "f32[2]" = torch.ops.aten.sin.default(sin_328);  sin_328 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:335 in program, code: r=r.sin()
        sin_330: "f32[2]" = torch.ops.aten.sin.default(sin_329);  sin_329 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:336 in program, code: r=r.sin()
        sin_331: "f32[2]" = torch.ops.aten.sin.default(sin_330);  sin_330 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:337 in program, code: r=r.sin()
        sin_332: "f32[2]" = torch.ops.aten.sin.default(sin_331);  sin_331 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:338 in program, code: r=r.sin()
        sin_333: "f32[2]" = torch.ops.aten.sin.default(sin_332);  sin_332 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:339 in program, code: r=r.sin()
        sin_334: "f32[2]" = torch.ops.aten.sin.default(sin_333);  sin_333 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:340 in program, code: r=r.sin()
        sin_335: "f32[2]" = torch.ops.aten.sin.default(sin_334);  sin_334 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:341 in program, code: r=r.sin()
        sin_336: "f32[2]" = torch.ops.aten.sin.default(sin_335);  sin_335 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:342 in program, code: r=r.sin()
        sin_337: "f32[2]" = torch.ops.aten.sin.default(sin_336);  sin_336 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:343 in program, code: r=r.sin()
        sin_338: "f32[2]" = torch.ops.aten.sin.default(sin_337);  sin_337 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:344 in program, code: r=r.sin()
        sin_339: "f32[2]" = torch.ops.aten.sin.default(sin_338);  sin_338 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:345 in program, code: r=r.sin()+r.cos()
        sin_340: "f32[2]" = torch.ops.aten.sin.default(sin_339)
        cos_10: "f32[2]" = torch.ops.aten.cos.default(sin_339);  sin_339 = None
        add_10: "f32[2]" = torch.ops.aten.add.Tensor(sin_340, cos_10);  sin_340 = cos_10 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:346 in program, code: r=r.sin()
        sin_341: "f32[2]" = torch.ops.aten.sin.default(add_10);  add_10 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:347 in program, code: r=r.sin()
        sin_342: "f32[2]" = torch.ops.aten.sin.default(sin_341);  sin_341 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:348 in program, code: r=r.sin()
        sin_343: "f32[2]" = torch.ops.aten.sin.default(sin_342);  sin_342 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:349 in program, code: r=r.sin()
        sin_344: "f32[2]" = torch.ops.aten.sin.default(sin_343);  sin_343 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:350 in program, code: r=r.sin()
        sin_345: "f32[2]" = torch.ops.aten.sin.default(sin_344);  sin_344 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:351 in program, code: r=r.sin()
        sin_346: "f32[2]" = torch.ops.aten.sin.default(sin_345);  sin_345 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:352 in program, code: r=r.sin()
        sin_347: "f32[2]" = torch.ops.aten.sin.default(sin_346);  sin_346 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:353 in program, code: r=r.sin()
        sin_348: "f32[2]" = torch.ops.aten.sin.default(sin_347);  sin_347 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:354 in program, code: r=r.sin()
        sin_349: "f32[2]" = torch.ops.aten.sin.default(sin_348);  sin_348 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:355 in program, code: r=r.sin()
        sin_350: "f32[2]" = torch.ops.aten.sin.default(sin_349);  sin_349 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:356 in program, code: r=r.sin()
        sin_351: "f32[2]" = torch.ops.aten.sin.default(sin_350);  sin_350 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:357 in program, code: r=r.sin()
        sin_352: "f32[2]" = torch.ops.aten.sin.default(sin_351);  sin_351 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:358 in program, code: r=r.sin()
        sin_353: "f32[2]" = torch.ops.aten.sin.default(sin_352);  sin_352 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:359 in program, code: r=r.sin()
        sin_354: "f32[2]" = torch.ops.aten.sin.default(sin_353);  sin_353 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:360 in program, code: r=r.sin()
        sin_355: "f32[2]" = torch.ops.aten.sin.default(sin_354);  sin_354 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:361 in program, code: r=r.sin()
        sin_356: "f32[2]" = torch.ops.aten.sin.default(sin_355);  sin_355 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:362 in program, code: r=r.sin()
        sin_357: "f32[2]" = torch.ops.aten.sin.default(sin_356);  sin_356 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:363 in program, code: r=r.sin()
        sin_358: "f32[2]" = torch.ops.aten.sin.default(sin_357);  sin_357 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:364 in program, code: r=r.sin()
        sin_359: "f32[2]" = torch.ops.aten.sin.default(sin_358);  sin_358 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:365 in program, code: r=r.sin()
        sin_360: "f32[2]" = torch.ops.aten.sin.default(sin_359);  sin_359 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:366 in program, code: r=r.sin()
        sin_361: "f32[2]" = torch.ops.aten.sin.default(sin_360);  sin_360 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:367 in program, code: r=r.sin()
        sin_362: "f32[2]" = torch.ops.aten.sin.default(sin_361);  sin_361 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:368 in program, code: r=r.sin()
        sin_363: "f32[2]" = torch.ops.aten.sin.default(sin_362);  sin_362 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:369 in program, code: r=r.sin()
        sin_364: "f32[2]" = torch.ops.aten.sin.default(sin_363);  sin_363 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:370 in program, code: r=r.sin()
        sin_365: "f32[2]" = torch.ops.aten.sin.default(sin_364);  sin_364 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:371 in program, code: r=r.sin()
        sin_366: "f32[2]" = torch.ops.aten.sin.default(sin_365);  sin_365 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:372 in program, code: r=r.sin()
        sin_367: "f32[2]" = torch.ops.aten.sin.default(sin_366);  sin_366 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:373 in program, code: r=r.sin()
        sin_368: "f32[2]" = torch.ops.aten.sin.default(sin_367);  sin_367 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:374 in program, code: r=r.sin()
        sin_369: "f32[2]" = torch.ops.aten.sin.default(sin_368);  sin_368 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:375 in program, code: r=r.sin()
        sin_370: "f32[2]" = torch.ops.aten.sin.default(sin_369);  sin_369 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:376 in program, code: r=r.sin()+r.cos()
        sin_371: "f32[2]" = torch.ops.aten.sin.default(sin_370)
        cos_11: "f32[2]" = torch.ops.aten.cos.default(sin_370);  sin_370 = None
        add_11: "f32[2]" = torch.ops.aten.add.Tensor(sin_371, cos_11);  sin_371 = cos_11 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:377 in program, code: r=r.sin()
        sin_372: "f32[2]" = torch.ops.aten.sin.default(add_11);  add_11 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:378 in program, code: r=r.sin()
        sin_373: "f32[2]" = torch.ops.aten.sin.default(sin_372);  sin_372 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:379 in program, code: r=r.sin()
        sin_374: "f32[2]" = torch.ops.aten.sin.default(sin_373);  sin_373 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:380 in program, code: r=r.sin()
        sin_375: "f32[2]" = torch.ops.aten.sin.default(sin_374);  sin_374 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:381 in program, code: r=r.sin()
        sin_376: "f32[2]" = torch.ops.aten.sin.default(sin_375);  sin_375 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:382 in program, code: r=r.sin()
        sin_377: "f32[2]" = torch.ops.aten.sin.default(sin_376);  sin_376 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:383 in program, code: r=r.sin()
        sin_378: "f32[2]" = torch.ops.aten.sin.default(sin_377);  sin_377 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:384 in program, code: r=r.sin()
        sin_379: "f32[2]" = torch.ops.aten.sin.default(sin_378);  sin_378 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:385 in program, code: r=r.sin()
        sin_380: "f32[2]" = torch.ops.aten.sin.default(sin_379);  sin_379 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:386 in program, code: r=r.sin()
        sin_381: "f32[2]" = torch.ops.aten.sin.default(sin_380);  sin_380 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:387 in program, code: r=r.sin()
        sin_382: "f32[2]" = torch.ops.aten.sin.default(sin_381);  sin_381 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:388 in program, code: r=r.sin()
        sin_383: "f32[2]" = torch.ops.aten.sin.default(sin_382);  sin_382 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:389 in program, code: r=r.sin()
        sin_384: "f32[2]" = torch.ops.aten.sin.default(sin_383);  sin_383 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:390 in program, code: r=r.sin()
        sin_385: "f32[2]" = torch.ops.aten.sin.default(sin_384);  sin_384 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:391 in program, code: r=r.sin()
        sin_386: "f32[2]" = torch.ops.aten.sin.default(sin_385);  sin_385 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:392 in program, code: r=r.sin()
        sin_387: "f32[2]" = torch.ops.aten.sin.default(sin_386);  sin_386 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:393 in program, code: r=r.sin()
        sin_388: "f32[2]" = torch.ops.aten.sin.default(sin_387);  sin_387 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:394 in program, code: r=r.sin()
        sin_389: "f32[2]" = torch.ops.aten.sin.default(sin_388);  sin_388 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:395 in program, code: r=r.sin()
        sin_390: "f32[2]" = torch.ops.aten.sin.default(sin_389);  sin_389 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:396 in program, code: r=r.sin()
        sin_391: "f32[2]" = torch.ops.aten.sin.default(sin_390);  sin_390 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:397 in program, code: r=r.sin()
        sin_392: "f32[2]" = torch.ops.aten.sin.default(sin_391);  sin_391 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:398 in program, code: r=r.sin()
        sin_393: "f32[2]" = torch.ops.aten.sin.default(sin_392);  sin_392 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:399 in program, code: r=r.sin()
        sin_394: "f32[2]" = torch.ops.aten.sin.default(sin_393);  sin_393 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:400 in program, code: r=r.sin()
        sin_395: "f32[2]" = torch.ops.aten.sin.default(sin_394);  sin_394 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:401 in program, code: r=r.sin()
        sin_396: "f32[2]" = torch.ops.aten.sin.default(sin_395);  sin_395 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:402 in program, code: r=r.sin()
        sin_397: "f32[2]" = torch.ops.aten.sin.default(sin_396);  sin_396 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:403 in program, code: r=r.sin()
        sin_398: "f32[2]" = torch.ops.aten.sin.default(sin_397);  sin_397 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:404 in program, code: r=r.sin()
        sin_399: "f32[2]" = torch.ops.aten.sin.default(sin_398);  sin_398 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:405 in program, code: r=r.sin()
        sin_400: "f32[2]" = torch.ops.aten.sin.default(sin_399);  sin_399 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:406 in program, code: r=r.sin()
        sin_401: "f32[2]" = torch.ops.aten.sin.default(sin_400);  sin_400 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:407 in program, code: r=r.sin()+r.cos()
        sin_402: "f32[2]" = torch.ops.aten.sin.default(sin_401)
        cos_12: "f32[2]" = torch.ops.aten.cos.default(sin_401);  sin_401 = None
        add_12: "f32[2]" = torch.ops.aten.add.Tensor(sin_402, cos_12);  sin_402 = cos_12 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:408 in program, code: r=r.sin()
        sin_403: "f32[2]" = torch.ops.aten.sin.default(add_12);  add_12 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:409 in program, code: r=r.sin()
        sin_404: "f32[2]" = torch.ops.aten.sin.default(sin_403);  sin_403 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:410 in program, code: r=r.sin()
        sin_405: "f32[2]" = torch.ops.aten.sin.default(sin_404);  sin_404 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:411 in program, code: r=r.sin()
        sin_406: "f32[2]" = torch.ops.aten.sin.default(sin_405);  sin_405 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:412 in program, code: r=r.sin()
        sin_407: "f32[2]" = torch.ops.aten.sin.default(sin_406);  sin_406 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:413 in program, code: r=r.sin()
        sin_408: "f32[2]" = torch.ops.aten.sin.default(sin_407);  sin_407 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:414 in program, code: r=r.sin()
        sin_409: "f32[2]" = torch.ops.aten.sin.default(sin_408);  sin_408 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:415 in program, code: r=r.sin()
        sin_410: "f32[2]" = torch.ops.aten.sin.default(sin_409);  sin_409 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:416 in program, code: r=r.sin()
        sin_411: "f32[2]" = torch.ops.aten.sin.default(sin_410);  sin_410 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:417 in program, code: r=r.sin()
        sin_412: "f32[2]" = torch.ops.aten.sin.default(sin_411);  sin_411 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:418 in program, code: r=r.sin()
        sin_413: "f32[2]" = torch.ops.aten.sin.default(sin_412);  sin_412 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:419 in program, code: r=r.sin()
        sin_414: "f32[2]" = torch.ops.aten.sin.default(sin_413);  sin_413 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:420 in program, code: r=r.sin()
        sin_415: "f32[2]" = torch.ops.aten.sin.default(sin_414);  sin_414 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:421 in program, code: r=r.sin()
        sin_416: "f32[2]" = torch.ops.aten.sin.default(sin_415);  sin_415 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:422 in program, code: r=r.sin()
        sin_417: "f32[2]" = torch.ops.aten.sin.default(sin_416);  sin_416 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:423 in program, code: r=r.sin()
        sin_418: "f32[2]" = torch.ops.aten.sin.default(sin_417);  sin_417 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:424 in program, code: r=r.sin()
        sin_419: "f32[2]" = torch.ops.aten.sin.default(sin_418);  sin_418 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:425 in program, code: r=r.sin()
        sin_420: "f32[2]" = torch.ops.aten.sin.default(sin_419);  sin_419 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:426 in program, code: r=r.sin()
        sin_421: "f32[2]" = torch.ops.aten.sin.default(sin_420);  sin_420 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:427 in program, code: r=r.sin()
        sin_422: "f32[2]" = torch.ops.aten.sin.default(sin_421);  sin_421 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:428 in program, code: r=r.sin()
        sin_423: "f32[2]" = torch.ops.aten.sin.default(sin_422);  sin_422 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:429 in program, code: r=r.sin()
        sin_424: "f32[2]" = torch.ops.aten.sin.default(sin_423);  sin_423 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:430 in program, code: r=r.sin()
        sin_425: "f32[2]" = torch.ops.aten.sin.default(sin_424);  sin_424 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:431 in program, code: r=r.sin()
        sin_426: "f32[2]" = torch.ops.aten.sin.default(sin_425);  sin_425 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:432 in program, code: r=r.sin()
        sin_427: "f32[2]" = torch.ops.aten.sin.default(sin_426);  sin_426 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:433 in program, code: r=r.sin()
        sin_428: "f32[2]" = torch.ops.aten.sin.default(sin_427);  sin_427 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:434 in program, code: r=r.sin()
        sin_429: "f32[2]" = torch.ops.aten.sin.default(sin_428);  sin_428 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:435 in program, code: r=r.sin()
        sin_430: "f32[2]" = torch.ops.aten.sin.default(sin_429);  sin_429 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:436 in program, code: r=r.sin()
        sin_431: "f32[2]" = torch.ops.aten.sin.default(sin_430);  sin_430 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:437 in program, code: r=r.sin()
        sin_432: "f32[2]" = torch.ops.aten.sin.default(sin_431);  sin_431 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:438 in program, code: r=r.sin()+r.cos()
        sin_433: "f32[2]" = torch.ops.aten.sin.default(sin_432)
        cos_13: "f32[2]" = torch.ops.aten.cos.default(sin_432);  sin_432 = None
        add_13: "f32[2]" = torch.ops.aten.add.Tensor(sin_433, cos_13);  sin_433 = cos_13 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:439 in program, code: r=r.sin()
        sin_434: "f32[2]" = torch.ops.aten.sin.default(add_13);  add_13 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:440 in program, code: r=r.sin()
        sin_435: "f32[2]" = torch.ops.aten.sin.default(sin_434);  sin_434 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:441 in program, code: r=r.sin()
        sin_436: "f32[2]" = torch.ops.aten.sin.default(sin_435);  sin_435 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:442 in program, code: r=r.sin()
        sin_437: "f32[2]" = torch.ops.aten.sin.default(sin_436);  sin_436 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:443 in program, code: r=r.sin()
        sin_438: "f32[2]" = torch.ops.aten.sin.default(sin_437);  sin_437 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:444 in program, code: r=r.sin()
        sin_439: "f32[2]" = torch.ops.aten.sin.default(sin_438);  sin_438 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:445 in program, code: r=r.sin()
        sin_440: "f32[2]" = torch.ops.aten.sin.default(sin_439);  sin_439 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:446 in program, code: r=r.sin()
        sin_441: "f32[2]" = torch.ops.aten.sin.default(sin_440);  sin_440 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:447 in program, code: r=r.sin()
        sin_442: "f32[2]" = torch.ops.aten.sin.default(sin_441);  sin_441 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:448 in program, code: r=r.sin()
        sin_443: "f32[2]" = torch.ops.aten.sin.default(sin_442);  sin_442 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:449 in program, code: r=r.sin()
        sin_444: "f32[2]" = torch.ops.aten.sin.default(sin_443);  sin_443 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:450 in program, code: r=r.sin()
        sin_445: "f32[2]" = torch.ops.aten.sin.default(sin_444);  sin_444 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:451 in program, code: r=r.sin()
        sin_446: "f32[2]" = torch.ops.aten.sin.default(sin_445);  sin_445 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:452 in program, code: r=r.sin()
        sin_447: "f32[2]" = torch.ops.aten.sin.default(sin_446);  sin_446 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:453 in program, code: r=r.sin()
        sin_448: "f32[2]" = torch.ops.aten.sin.default(sin_447);  sin_447 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:454 in program, code: r=r.sin()
        sin_449: "f32[2]" = torch.ops.aten.sin.default(sin_448);  sin_448 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:455 in program, code: r=r.sin()
        sin_450: "f32[2]" = torch.ops.aten.sin.default(sin_449);  sin_449 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:456 in program, code: r=r.sin()
        sin_451: "f32[2]" = torch.ops.aten.sin.default(sin_450);  sin_450 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:457 in program, code: r=r.sin()
        sin_452: "f32[2]" = torch.ops.aten.sin.default(sin_451);  sin_451 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:458 in program, code: r=r.sin()
        sin_453: "f32[2]" = torch.ops.aten.sin.default(sin_452);  sin_452 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:459 in program, code: r=r.sin()
        sin_454: "f32[2]" = torch.ops.aten.sin.default(sin_453);  sin_453 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:460 in program, code: r=r.sin()
        sin_455: "f32[2]" = torch.ops.aten.sin.default(sin_454);  sin_454 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:461 in program, code: r=r.sin()
        sin_456: "f32[2]" = torch.ops.aten.sin.default(sin_455);  sin_455 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:462 in program, code: r=r.sin()
        sin_457: "f32[2]" = torch.ops.aten.sin.default(sin_456);  sin_456 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:463 in program, code: r=r.sin()
        sin_458: "f32[2]" = torch.ops.aten.sin.default(sin_457);  sin_457 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:464 in program, code: r=r.sin()
        sin_459: "f32[2]" = torch.ops.aten.sin.default(sin_458);  sin_458 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:465 in program, code: r=r.sin()
        sin_460: "f32[2]" = torch.ops.aten.sin.default(sin_459);  sin_459 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:466 in program, code: r=r.sin()
        sin_461: "f32[2]" = torch.ops.aten.sin.default(sin_460);  sin_460 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:467 in program, code: r=r.sin()
        sin_462: "f32[2]" = torch.ops.aten.sin.default(sin_461);  sin_461 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:468 in program, code: r=r.sin()
        sin_463: "f32[2]" = torch.ops.aten.sin.default(sin_462);  sin_462 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:469 in program, code: r=r.sin()+r.cos()
        sin_464: "f32[2]" = torch.ops.aten.sin.default(sin_463)
        cos_14: "f32[2]" = torch.ops.aten.cos.default(sin_463);  sin_463 = None
        add_14: "f32[2]" = torch.ops.aten.add.Tensor(sin_464, cos_14);  sin_464 = cos_14 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:470 in program, code: r=r.sin()
        sin_465: "f32[2]" = torch.ops.aten.sin.default(add_14);  add_14 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:471 in program, code: r=r.sin()
        sin_466: "f32[2]" = torch.ops.aten.sin.default(sin_465);  sin_465 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:472 in program, code: r=r.sin()
        sin_467: "f32[2]" = torch.ops.aten.sin.default(sin_466);  sin_466 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:473 in program, code: r=r.sin()
        sin_468: "f32[2]" = torch.ops.aten.sin.default(sin_467);  sin_467 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:474 in program, code: r=r.sin()
        sin_469: "f32[2]" = torch.ops.aten.sin.default(sin_468);  sin_468 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:475 in program, code: r=r.sin()
        sin_470: "f32[2]" = torch.ops.aten.sin.default(sin_469);  sin_469 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:476 in program, code: r=r.sin()
        sin_471: "f32[2]" = torch.ops.aten.sin.default(sin_470);  sin_470 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:477 in program, code: r=r.sin()
        sin_472: "f32[2]" = torch.ops.aten.sin.default(sin_471);  sin_471 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:478 in program, code: r=r.sin()
        sin_473: "f32[2]" = torch.ops.aten.sin.default(sin_472);  sin_472 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:479 in program, code: r=r.sin()
        sin_474: "f32[2]" = torch.ops.aten.sin.default(sin_473);  sin_473 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:480 in program, code: r=r.sin()
        sin_475: "f32[2]" = torch.ops.aten.sin.default(sin_474);  sin_474 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:481 in program, code: r=r.sin()
        sin_476: "f32[2]" = torch.ops.aten.sin.default(sin_475);  sin_475 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:482 in program, code: r=r.sin()
        sin_477: "f32[2]" = torch.ops.aten.sin.default(sin_476);  sin_476 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:483 in program, code: r=r.sin()
        sin_478: "f32[2]" = torch.ops.aten.sin.default(sin_477);  sin_477 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:484 in program, code: r=r.sin()
        sin_479: "f32[2]" = torch.ops.aten.sin.default(sin_478);  sin_478 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:485 in program, code: r=r.sin()
        sin_480: "f32[2]" = torch.ops.aten.sin.default(sin_479);  sin_479 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:486 in program, code: r=r.sin()
        sin_481: "f32[2]" = torch.ops.aten.sin.default(sin_480);  sin_480 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:487 in program, code: r=r.sin()
        sin_482: "f32[2]" = torch.ops.aten.sin.default(sin_481);  sin_481 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:488 in program, code: r=r.sin()
        sin_483: "f32[2]" = torch.ops.aten.sin.default(sin_482);  sin_482 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:489 in program, code: r=r.sin()
        sin_484: "f32[2]" = torch.ops.aten.sin.default(sin_483);  sin_483 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:490 in program, code: r=r.sin()
        sin_485: "f32[2]" = torch.ops.aten.sin.default(sin_484);  sin_484 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:491 in program, code: r=r.sin()
        sin_486: "f32[2]" = torch.ops.aten.sin.default(sin_485);  sin_485 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:492 in program, code: r=r.sin()
        sin_487: "f32[2]" = torch.ops.aten.sin.default(sin_486);  sin_486 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:493 in program, code: r=r.sin()
        sin_488: "f32[2]" = torch.ops.aten.sin.default(sin_487);  sin_487 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:494 in program, code: r=r.sin()
        sin_489: "f32[2]" = torch.ops.aten.sin.default(sin_488);  sin_488 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:495 in program, code: r=r.sin()
        sin_490: "f32[2]" = torch.ops.aten.sin.default(sin_489);  sin_489 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:496 in program, code: r=r.sin()
        sin_491: "f32[2]" = torch.ops.aten.sin.default(sin_490);  sin_490 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:497 in program, code: r=r.sin()
        sin_492: "f32[2]" = torch.ops.aten.sin.default(sin_491);  sin_491 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:498 in program, code: r=r.sin()
        sin_493: "f32[2]" = torch.ops.aten.sin.default(sin_492);  sin_492 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:499 in program, code: r=r.sin()
        sin_494: "f32[2]" = torch.ops.aten.sin.default(sin_493);  sin_493 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:500 in program, code: r=r.sin()+r.cos()
        sin_495: "f32[2]" = torch.ops.aten.sin.default(sin_494)
        cos_15: "f32[2]" = torch.ops.aten.cos.default(sin_494);  sin_494 = None
        add_15: "f32[2]" = torch.ops.aten.add.Tensor(sin_495, cos_15);  sin_495 = cos_15 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:501 in program, code: r=r.sin()
        sin_496: "f32[2]" = torch.ops.aten.sin.default(add_15);  add_15 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:502 in program, code: r=r.sin()
        sin_497: "f32[2]" = torch.ops.aten.sin.default(sin_496);  sin_496 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:503 in program, code: r=r.sin()
        sin_498: "f32[2]" = torch.ops.aten.sin.default(sin_497);  sin_497 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:504 in program, code: r=r.sin()
        sin_499: "f32[2]" = torch.ops.aten.sin.default(sin_498);  sin_498 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:505 in program, code: r=r.sin()
        sin_500: "f32[2]" = torch.ops.aten.sin.default(sin_499);  sin_499 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:506 in program, code: r=r.sin()
        sin_501: "f32[2]" = torch.ops.aten.sin.default(sin_500);  sin_500 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:507 in program, code: r=r.sin()
        sin_502: "f32[2]" = torch.ops.aten.sin.default(sin_501);  sin_501 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:508 in program, code: r=r.sin()
        sin_503: "f32[2]" = torch.ops.aten.sin.default(sin_502);  sin_502 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:509 in program, code: r=r.sin()
        sin_504: "f32[2]" = torch.ops.aten.sin.default(sin_503);  sin_503 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:510 in program, code: r=r.sin()
        sin_505: "f32[2]" = torch.ops.aten.sin.default(sin_504);  sin_504 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:511 in program, code: r=r.sin()
        sin_506: "f32[2]" = torch.ops.aten.sin.default(sin_505);  sin_505 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:512 in program, code: r=r.sin()
        sin_507: "f32[2]" = torch.ops.aten.sin.default(sin_506);  sin_506 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:513 in program, code: r=r.sin()
        sin_508: "f32[2]" = torch.ops.aten.sin.default(sin_507);  sin_507 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:514 in program, code: r=r.sin()
        sin_509: "f32[2]" = torch.ops.aten.sin.default(sin_508);  sin_508 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:515 in program, code: r=r.sin()
        sin_510: "f32[2]" = torch.ops.aten.sin.default(sin_509);  sin_509 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:516 in program, code: r=r.sin()
        sin_511: "f32[2]" = torch.ops.aten.sin.default(sin_510);  sin_510 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:517 in program, code: r=r.sin()
        sin_512: "f32[2]" = torch.ops.aten.sin.default(sin_511);  sin_511 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:518 in program, code: r=r.sin()
        sin_513: "f32[2]" = torch.ops.aten.sin.default(sin_512);  sin_512 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:519 in program, code: r=r.sin()
        sin_514: "f32[2]" = torch.ops.aten.sin.default(sin_513);  sin_513 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:520 in program, code: r=r.sin()
        sin_515: "f32[2]" = torch.ops.aten.sin.default(sin_514);  sin_514 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:521 in program, code: r=r.sin()
        sin_516: "f32[2]" = torch.ops.aten.sin.default(sin_515);  sin_515 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:522 in program, code: r=r.sin()
        sin_517: "f32[2]" = torch.ops.aten.sin.default(sin_516);  sin_516 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:523 in program, code: r=r.sin()
        sin_518: "f32[2]" = torch.ops.aten.sin.default(sin_517);  sin_517 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:524 in program, code: r=r.sin()
        sin_519: "f32[2]" = torch.ops.aten.sin.default(sin_518);  sin_518 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:525 in program, code: r=r.sin()
        sin_520: "f32[2]" = torch.ops.aten.sin.default(sin_519);  sin_519 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:526 in program, code: r=r.sin()
        sin_521: "f32[2]" = torch.ops.aten.sin.default(sin_520);  sin_520 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:527 in program, code: r=r.sin()
        sin_522: "f32[2]" = torch.ops.aten.sin.default(sin_521);  sin_521 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:528 in program, code: r=r.sin()
        sin_523: "f32[2]" = torch.ops.aten.sin.default(sin_522);  sin_522 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:529 in program, code: r=r.sin()
        sin_524: "f32[2]" = torch.ops.aten.sin.default(sin_523);  sin_523 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:530 in program, code: r=r.sin()
        sin_525: "f32[2]" = torch.ops.aten.sin.default(sin_524);  sin_524 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:531 in program, code: r=r.sin()+r.cos()
        sin_526: "f32[2]" = torch.ops.aten.sin.default(sin_525)
        cos_16: "f32[2]" = torch.ops.aten.cos.default(sin_525);  sin_525 = None
        add_16: "f32[2]" = torch.ops.aten.add.Tensor(sin_526, cos_16);  sin_526 = cos_16 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:532 in program, code: r=r.sin()
        sin_527: "f32[2]" = torch.ops.aten.sin.default(add_16);  add_16 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:533 in program, code: r=r.sin()
        sin_528: "f32[2]" = torch.ops.aten.sin.default(sin_527);  sin_527 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:534 in program, code: r=r.sin()
        sin_529: "f32[2]" = torch.ops.aten.sin.default(sin_528);  sin_528 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:535 in program, code: r=r.sin()
        sin_530: "f32[2]" = torch.ops.aten.sin.default(sin_529);  sin_529 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:536 in program, code: r=r.sin()
        sin_531: "f32[2]" = torch.ops.aten.sin.default(sin_530);  sin_530 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:537 in program, code: r=r.sin()
        sin_532: "f32[2]" = torch.ops.aten.sin.default(sin_531);  sin_531 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:538 in program, code: r=r.sin()
        sin_533: "f32[2]" = torch.ops.aten.sin.default(sin_532);  sin_532 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:539 in program, code: r=r.sin()
        sin_534: "f32[2]" = torch.ops.aten.sin.default(sin_533);  sin_533 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:540 in program, code: r=r.sin()
        sin_535: "f32[2]" = torch.ops.aten.sin.default(sin_534);  sin_534 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:541 in program, code: r=r.sin()
        sin_536: "f32[2]" = torch.ops.aten.sin.default(sin_535);  sin_535 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:542 in program, code: r=r.sin()
        sin_537: "f32[2]" = torch.ops.aten.sin.default(sin_536);  sin_536 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:543 in program, code: r=r.sin()
        sin_538: "f32[2]" = torch.ops.aten.sin.default(sin_537);  sin_537 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:544 in program, code: r=r.sin()
        sin_539: "f32[2]" = torch.ops.aten.sin.default(sin_538);  sin_538 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:545 in program, code: r=r.sin()
        sin_540: "f32[2]" = torch.ops.aten.sin.default(sin_539);  sin_539 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:546 in program, code: r=r.sin()
        sin_541: "f32[2]" = torch.ops.aten.sin.default(sin_540);  sin_540 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:547 in program, code: r=r.sin()
        sin_542: "f32[2]" = torch.ops.aten.sin.default(sin_541);  sin_541 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:548 in program, code: r=r.sin()
        sin_543: "f32[2]" = torch.ops.aten.sin.default(sin_542);  sin_542 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:549 in program, code: r=r.sin()
        sin_544: "f32[2]" = torch.ops.aten.sin.default(sin_543);  sin_543 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:550 in program, code: r=r.sin()
        sin_545: "f32[2]" = torch.ops.aten.sin.default(sin_544);  sin_544 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:551 in program, code: r=r.sin()
        sin_546: "f32[2]" = torch.ops.aten.sin.default(sin_545);  sin_545 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:552 in program, code: r=r.sin()
        sin_547: "f32[2]" = torch.ops.aten.sin.default(sin_546);  sin_546 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:553 in program, code: r=r.sin()
        sin_548: "f32[2]" = torch.ops.aten.sin.default(sin_547);  sin_547 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:554 in program, code: r=r.sin()
        sin_549: "f32[2]" = torch.ops.aten.sin.default(sin_548);  sin_548 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:555 in program, code: r=r.sin()
        sin_550: "f32[2]" = torch.ops.aten.sin.default(sin_549);  sin_549 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:556 in program, code: r=r.sin()
        sin_551: "f32[2]" = torch.ops.aten.sin.default(sin_550);  sin_550 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:557 in program, code: r=r.sin()
        sin_552: "f32[2]" = torch.ops.aten.sin.default(sin_551);  sin_551 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:558 in program, code: r=r.sin()
        sin_553: "f32[2]" = torch.ops.aten.sin.default(sin_552);  sin_552 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:559 in program, code: r=r.sin()
        sin_554: "f32[2]" = torch.ops.aten.sin.default(sin_553);  sin_553 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:560 in program, code: r=r.sin()
        sin_555: "f32[2]" = torch.ops.aten.sin.default(sin_554);  sin_554 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:561 in program, code: r=r.sin()
        sin_556: "f32[2]" = torch.ops.aten.sin.default(sin_555);  sin_555 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:562 in program, code: r=r.sin()+r.cos()
        sin_557: "f32[2]" = torch.ops.aten.sin.default(sin_556)
        cos_17: "f32[2]" = torch.ops.aten.cos.default(sin_556);  sin_556 = None
        add_17: "f32[2]" = torch.ops.aten.add.Tensor(sin_557, cos_17);  sin_557 = cos_17 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:563 in program, code: r=r.sin()
        sin_558: "f32[2]" = torch.ops.aten.sin.default(add_17);  add_17 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:564 in program, code: r=r.sin()
        sin_559: "f32[2]" = torch.ops.aten.sin.default(sin_558);  sin_558 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:565 in program, code: r=r.sin()
        sin_560: "f32[2]" = torch.ops.aten.sin.default(sin_559);  sin_559 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:566 in program, code: r=r.sin()
        sin_561: "f32[2]" = torch.ops.aten.sin.default(sin_560);  sin_560 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:567 in program, code: r=r.sin()
        sin_562: "f32[2]" = torch.ops.aten.sin.default(sin_561);  sin_561 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:568 in program, code: r=r.sin()
        sin_563: "f32[2]" = torch.ops.aten.sin.default(sin_562);  sin_562 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:569 in program, code: r=r.sin()
        sin_564: "f32[2]" = torch.ops.aten.sin.default(sin_563);  sin_563 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:570 in program, code: r=r.sin()
        sin_565: "f32[2]" = torch.ops.aten.sin.default(sin_564);  sin_564 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:571 in program, code: r=r.sin()
        sin_566: "f32[2]" = torch.ops.aten.sin.default(sin_565);  sin_565 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:572 in program, code: r=r.sin()
        sin_567: "f32[2]" = torch.ops.aten.sin.default(sin_566);  sin_566 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:573 in program, code: r=r.sin()
        sin_568: "f32[2]" = torch.ops.aten.sin.default(sin_567);  sin_567 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:574 in program, code: r=r.sin()
        sin_569: "f32[2]" = torch.ops.aten.sin.default(sin_568);  sin_568 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:575 in program, code: r=r.sin()
        sin_570: "f32[2]" = torch.ops.aten.sin.default(sin_569);  sin_569 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:576 in program, code: r=r.sin()
        sin_571: "f32[2]" = torch.ops.aten.sin.default(sin_570);  sin_570 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:577 in program, code: r=r.sin()
        sin_572: "f32[2]" = torch.ops.aten.sin.default(sin_571);  sin_571 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:578 in program, code: r=r.sin()
        sin_573: "f32[2]" = torch.ops.aten.sin.default(sin_572);  sin_572 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:579 in program, code: r=r.sin()
        sin_574: "f32[2]" = torch.ops.aten.sin.default(sin_573);  sin_573 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:580 in program, code: r=r.sin()
        sin_575: "f32[2]" = torch.ops.aten.sin.default(sin_574);  sin_574 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:581 in program, code: r=r.sin()
        sin_576: "f32[2]" = torch.ops.aten.sin.default(sin_575);  sin_575 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:582 in program, code: r=r.sin()
        sin_577: "f32[2]" = torch.ops.aten.sin.default(sin_576);  sin_576 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:583 in program, code: r=r.sin()
        sin_578: "f32[2]" = torch.ops.aten.sin.default(sin_577);  sin_577 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:584 in program, code: r=r.sin()
        sin_579: "f32[2]" = torch.ops.aten.sin.default(sin_578);  sin_578 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:585 in program, code: r=r.sin()
        sin_580: "f32[2]" = torch.ops.aten.sin.default(sin_579);  sin_579 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:586 in program, code: r=r.sin()
        sin_581: "f32[2]" = torch.ops.aten.sin.default(sin_580);  sin_580 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:587 in program, code: r=r.sin()
        sin_582: "f32[2]" = torch.ops.aten.sin.default(sin_581);  sin_581 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:588 in program, code: r=r.sin()
        sin_583: "f32[2]" = torch.ops.aten.sin.default(sin_582);  sin_582 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:589 in program, code: r=r.sin()
        sin_584: "f32[2]" = torch.ops.aten.sin.default(sin_583);  sin_583 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:590 in program, code: r=r.sin()
        sin_585: "f32[2]" = torch.ops.aten.sin.default(sin_584);  sin_584 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:591 in program, code: r=r.sin()
        sin_586: "f32[2]" = torch.ops.aten.sin.default(sin_585);  sin_585 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:592 in program, code: r=r.sin()
        sin_587: "f32[2]" = torch.ops.aten.sin.default(sin_586);  sin_586 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:593 in program, code: r=r.sin()+r.cos()
        sin_588: "f32[2]" = torch.ops.aten.sin.default(sin_587)
        cos_18: "f32[2]" = torch.ops.aten.cos.default(sin_587);  sin_587 = None
        add_18: "f32[2]" = torch.ops.aten.add.Tensor(sin_588, cos_18);  sin_588 = cos_18 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:594 in program, code: r=r.sin()
        sin_589: "f32[2]" = torch.ops.aten.sin.default(add_18);  add_18 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:595 in program, code: r=r.sin()
        sin_590: "f32[2]" = torch.ops.aten.sin.default(sin_589);  sin_589 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:596 in program, code: r=r.sin()
        sin_591: "f32[2]" = torch.ops.aten.sin.default(sin_590);  sin_590 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:597 in program, code: r=r.sin()
        sin_592: "f32[2]" = torch.ops.aten.sin.default(sin_591);  sin_591 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:598 in program, code: r=r.sin()
        sin_593: "f32[2]" = torch.ops.aten.sin.default(sin_592);  sin_592 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:599 in program, code: r=r.sin()
        sin_594: "f32[2]" = torch.ops.aten.sin.default(sin_593);  sin_593 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:600 in program, code: r=r.sin()
        sin_595: "f32[2]" = torch.ops.aten.sin.default(sin_594);  sin_594 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:601 in program, code: r=r.sin()
        sin_596: "f32[2]" = torch.ops.aten.sin.default(sin_595);  sin_595 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:602 in program, code: r=r.sin()
        sin_597: "f32[2]" = torch.ops.aten.sin.default(sin_596);  sin_596 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:603 in program, code: r=r.sin()
        sin_598: "f32[2]" = torch.ops.aten.sin.default(sin_597);  sin_597 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:604 in program, code: r=r.sin()
        sin_599: "f32[2]" = torch.ops.aten.sin.default(sin_598);  sin_598 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:605 in program, code: r=r.sin()
        sin_600: "f32[2]" = torch.ops.aten.sin.default(sin_599);  sin_599 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:606 in program, code: r=r.sin()
        sin_601: "f32[2]" = torch.ops.aten.sin.default(sin_600);  sin_600 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:607 in program, code: r=r.sin()
        sin_602: "f32[2]" = torch.ops.aten.sin.default(sin_601);  sin_601 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:608 in program, code: r=r.sin()
        sin_603: "f32[2]" = torch.ops.aten.sin.default(sin_602);  sin_602 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:609 in program, code: r=r.sin()
        sin_604: "f32[2]" = torch.ops.aten.sin.default(sin_603);  sin_603 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:610 in program, code: r=r.sin()
        sin_605: "f32[2]" = torch.ops.aten.sin.default(sin_604);  sin_604 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:611 in program, code: r=r.sin()
        sin_606: "f32[2]" = torch.ops.aten.sin.default(sin_605);  sin_605 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:612 in program, code: r=r.sin()
        sin_607: "f32[2]" = torch.ops.aten.sin.default(sin_606);  sin_606 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:613 in program, code: r=r.sin()
        sin_608: "f32[2]" = torch.ops.aten.sin.default(sin_607);  sin_607 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:614 in program, code: r=r.sin()
        sin_609: "f32[2]" = torch.ops.aten.sin.default(sin_608);  sin_608 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:615 in program, code: r=r.sin()
        sin_610: "f32[2]" = torch.ops.aten.sin.default(sin_609);  sin_609 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:616 in program, code: r=r.sin()
        sin_611: "f32[2]" = torch.ops.aten.sin.default(sin_610);  sin_610 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:617 in program, code: r=r.sin()
        sin_612: "f32[2]" = torch.ops.aten.sin.default(sin_611);  sin_611 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:618 in program, code: r=r.sin()
        sin_613: "f32[2]" = torch.ops.aten.sin.default(sin_612);  sin_612 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:619 in program, code: r=r.sin()
        sin_614: "f32[2]" = torch.ops.aten.sin.default(sin_613);  sin_613 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:620 in program, code: r=r.sin()
        sin_615: "f32[2]" = torch.ops.aten.sin.default(sin_614);  sin_614 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:621 in program, code: r=r.sin()
        sin_616: "f32[2]" = torch.ops.aten.sin.default(sin_615);  sin_615 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:622 in program, code: r=r.sin()
        sin_617: "f32[2]" = torch.ops.aten.sin.default(sin_616);  sin_616 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:623 in program, code: r=r.sin()
        sin_618: "f32[2]" = torch.ops.aten.sin.default(sin_617);  sin_617 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:624 in program, code: r=r.sin()+r.cos()
        sin_619: "f32[2]" = torch.ops.aten.sin.default(sin_618)
        cos_19: "f32[2]" = torch.ops.aten.cos.default(sin_618);  sin_618 = None
        add_19: "f32[2]" = torch.ops.aten.add.Tensor(sin_619, cos_19);  sin_619 = cos_19 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:625 in program, code: r=r.sin()
        sin_620: "f32[2]" = torch.ops.aten.sin.default(add_19);  add_19 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:626 in program, code: r=r.sin()
        sin_621: "f32[2]" = torch.ops.aten.sin.default(sin_620);  sin_620 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:627 in program, code: r=r.sin()
        sin_622: "f32[2]" = torch.ops.aten.sin.default(sin_621);  sin_621 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:628 in program, code: r=r.sin()
        sin_623: "f32[2]" = torch.ops.aten.sin.default(sin_622);  sin_622 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:629 in program, code: r=r.sin()
        sin_624: "f32[2]" = torch.ops.aten.sin.default(sin_623);  sin_623 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:630 in program, code: r=r.sin()
        sin_625: "f32[2]" = torch.ops.aten.sin.default(sin_624);  sin_624 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:631 in program, code: r=r.sin()
        sin_626: "f32[2]" = torch.ops.aten.sin.default(sin_625);  sin_625 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:632 in program, code: r=r.sin()
        sin_627: "f32[2]" = torch.ops.aten.sin.default(sin_626);  sin_626 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:633 in program, code: r=r.sin()
        sin_628: "f32[2]" = torch.ops.aten.sin.default(sin_627);  sin_627 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:634 in program, code: r=r.sin()
        sin_629: "f32[2]" = torch.ops.aten.sin.default(sin_628);  sin_628 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:635 in program, code: r=r.sin()
        sin_630: "f32[2]" = torch.ops.aten.sin.default(sin_629);  sin_629 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:636 in program, code: r=r.sin()
        sin_631: "f32[2]" = torch.ops.aten.sin.default(sin_630);  sin_630 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:637 in program, code: r=r.sin()
        sin_632: "f32[2]" = torch.ops.aten.sin.default(sin_631);  sin_631 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:638 in program, code: r=r.sin()
        sin_633: "f32[2]" = torch.ops.aten.sin.default(sin_632);  sin_632 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:639 in program, code: r=r.sin()
        sin_634: "f32[2]" = torch.ops.aten.sin.default(sin_633);  sin_633 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:640 in program, code: r=r.sin()
        sin_635: "f32[2]" = torch.ops.aten.sin.default(sin_634);  sin_634 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:641 in program, code: r=r.sin()
        sin_636: "f32[2]" = torch.ops.aten.sin.default(sin_635);  sin_635 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:642 in program, code: r=r.sin()
        sin_637: "f32[2]" = torch.ops.aten.sin.default(sin_636);  sin_636 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:643 in program, code: r=r.sin()
        sin_638: "f32[2]" = torch.ops.aten.sin.default(sin_637);  sin_637 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:644 in program, code: r=r.sin()
        sin_639: "f32[2]" = torch.ops.aten.sin.default(sin_638);  sin_638 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:645 in program, code: r=r.sin()
        sin_640: "f32[2]" = torch.ops.aten.sin.default(sin_639);  sin_639 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:646 in program, code: r=r.sin()
        sin_641: "f32[2]" = torch.ops.aten.sin.default(sin_640);  sin_640 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:647 in program, code: r=r.sin()
        sin_642: "f32[2]" = torch.ops.aten.sin.default(sin_641);  sin_641 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:648 in program, code: r=r.sin()
        sin_643: "f32[2]" = torch.ops.aten.sin.default(sin_642);  sin_642 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:649 in program, code: r=r.sin()
        sin_644: "f32[2]" = torch.ops.aten.sin.default(sin_643);  sin_643 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:650 in program, code: r=r.sin()
        sin_645: "f32[2]" = torch.ops.aten.sin.default(sin_644);  sin_644 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:651 in program, code: r=r.sin()
        sin_646: "f32[2]" = torch.ops.aten.sin.default(sin_645);  sin_645 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:652 in program, code: r=r.sin()
        sin_647: "f32[2]" = torch.ops.aten.sin.default(sin_646);  sin_646 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:653 in program, code: r=r.sin()
        sin_648: "f32[2]" = torch.ops.aten.sin.default(sin_647);  sin_647 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:654 in program, code: r=r.sin()
        sin_649: "f32[2]" = torch.ops.aten.sin.default(sin_648);  sin_648 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:655 in program, code: r=r.sin()+r.cos()
        sin_650: "f32[2]" = torch.ops.aten.sin.default(sin_649)
        cos_20: "f32[2]" = torch.ops.aten.cos.default(sin_649);  sin_649 = None
        add_20: "f32[2]" = torch.ops.aten.add.Tensor(sin_650, cos_20);  sin_650 = cos_20 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:656 in program, code: r=r.sin()
        sin_651: "f32[2]" = torch.ops.aten.sin.default(add_20);  add_20 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:657 in program, code: r=r.sin()
        sin_652: "f32[2]" = torch.ops.aten.sin.default(sin_651);  sin_651 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:658 in program, code: r=r.sin()
        sin_653: "f32[2]" = torch.ops.aten.sin.default(sin_652);  sin_652 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:659 in program, code: r=r.sin()
        sin_654: "f32[2]" = torch.ops.aten.sin.default(sin_653);  sin_653 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:660 in program, code: r=r.sin()
        sin_655: "f32[2]" = torch.ops.aten.sin.default(sin_654);  sin_654 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:661 in program, code: r=r.sin()
        sin_656: "f32[2]" = torch.ops.aten.sin.default(sin_655);  sin_655 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:662 in program, code: r=r.sin()
        sin_657: "f32[2]" = torch.ops.aten.sin.default(sin_656);  sin_656 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:663 in program, code: r=r.sin()
        sin_658: "f32[2]" = torch.ops.aten.sin.default(sin_657);  sin_657 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:664 in program, code: r=r.sin()
        sin_659: "f32[2]" = torch.ops.aten.sin.default(sin_658);  sin_658 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:665 in program, code: r=r.sin()
        sin_660: "f32[2]" = torch.ops.aten.sin.default(sin_659);  sin_659 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:666 in program, code: r=r.sin()
        sin_661: "f32[2]" = torch.ops.aten.sin.default(sin_660);  sin_660 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:667 in program, code: r=r.sin()
        sin_662: "f32[2]" = torch.ops.aten.sin.default(sin_661);  sin_661 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:668 in program, code: r=r.sin()
        sin_663: "f32[2]" = torch.ops.aten.sin.default(sin_662);  sin_662 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:669 in program, code: r=r.sin()
        sin_664: "f32[2]" = torch.ops.aten.sin.default(sin_663);  sin_663 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:670 in program, code: r=r.sin()
        sin_665: "f32[2]" = torch.ops.aten.sin.default(sin_664);  sin_664 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:671 in program, code: r=r.sin()
        sin_666: "f32[2]" = torch.ops.aten.sin.default(sin_665);  sin_665 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:672 in program, code: r=r.sin()
        sin_667: "f32[2]" = torch.ops.aten.sin.default(sin_666);  sin_666 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:673 in program, code: r=r.sin()
        sin_668: "f32[2]" = torch.ops.aten.sin.default(sin_667);  sin_667 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:674 in program, code: r=r.sin()
        sin_669: "f32[2]" = torch.ops.aten.sin.default(sin_668);  sin_668 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:675 in program, code: r=r.sin()
        sin_670: "f32[2]" = torch.ops.aten.sin.default(sin_669);  sin_669 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:676 in program, code: r=r.sin()
        sin_671: "f32[2]" = torch.ops.aten.sin.default(sin_670);  sin_670 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:677 in program, code: r=r.sin()
        sin_672: "f32[2]" = torch.ops.aten.sin.default(sin_671);  sin_671 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:678 in program, code: r=r.sin()
        sin_673: "f32[2]" = torch.ops.aten.sin.default(sin_672);  sin_672 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:679 in program, code: r=r.sin()
        sin_674: "f32[2]" = torch.ops.aten.sin.default(sin_673);  sin_673 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:680 in program, code: r=r.sin()
        sin_675: "f32[2]" = torch.ops.aten.sin.default(sin_674);  sin_674 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:681 in program, code: r=r.sin()
        sin_676: "f32[2]" = torch.ops.aten.sin.default(sin_675);  sin_675 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:682 in program, code: r=r.sin()
        sin_677: "f32[2]" = torch.ops.aten.sin.default(sin_676);  sin_676 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:683 in program, code: r=r.sin()
        sin_678: "f32[2]" = torch.ops.aten.sin.default(sin_677);  sin_677 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:684 in program, code: r=r.sin()
        sin_679: "f32[2]" = torch.ops.aten.sin.default(sin_678);  sin_678 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:685 in program, code: r=r.sin()
        sin_680: "f32[2]" = torch.ops.aten.sin.default(sin_679);  sin_679 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:686 in program, code: r=r.sin()+r.cos()
        sin_681: "f32[2]" = torch.ops.aten.sin.default(sin_680)
        cos_21: "f32[2]" = torch.ops.aten.cos.default(sin_680);  sin_680 = None
        add_21: "f32[2]" = torch.ops.aten.add.Tensor(sin_681, cos_21);  sin_681 = cos_21 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:687 in program, code: r=r.sin()
        sin_682: "f32[2]" = torch.ops.aten.sin.default(add_21);  add_21 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:688 in program, code: r=r.sin()
        sin_683: "f32[2]" = torch.ops.aten.sin.default(sin_682);  sin_682 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:689 in program, code: r=r.sin()
        sin_684: "f32[2]" = torch.ops.aten.sin.default(sin_683);  sin_683 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:690 in program, code: r=r.sin()
        sin_685: "f32[2]" = torch.ops.aten.sin.default(sin_684);  sin_684 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:691 in program, code: r=r.sin()
        sin_686: "f32[2]" = torch.ops.aten.sin.default(sin_685);  sin_685 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:692 in program, code: r=r.sin()
        sin_687: "f32[2]" = torch.ops.aten.sin.default(sin_686);  sin_686 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:693 in program, code: r=r.sin()
        sin_688: "f32[2]" = torch.ops.aten.sin.default(sin_687);  sin_687 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:694 in program, code: r=r.sin()
        sin_689: "f32[2]" = torch.ops.aten.sin.default(sin_688);  sin_688 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:695 in program, code: r=r.sin()
        sin_690: "f32[2]" = torch.ops.aten.sin.default(sin_689);  sin_689 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:696 in program, code: r=r.sin()
        sin_691: "f32[2]" = torch.ops.aten.sin.default(sin_690);  sin_690 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:697 in program, code: r=r.sin()
        sin_692: "f32[2]" = torch.ops.aten.sin.default(sin_691);  sin_691 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:698 in program, code: r=r.sin()
        sin_693: "f32[2]" = torch.ops.aten.sin.default(sin_692);  sin_692 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:699 in program, code: r=r.sin()
        sin_694: "f32[2]" = torch.ops.aten.sin.default(sin_693);  sin_693 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:700 in program, code: r=r.sin()
        sin_695: "f32[2]" = torch.ops.aten.sin.default(sin_694);  sin_694 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:701 in program, code: r=r.sin()
        sin_696: "f32[2]" = torch.ops.aten.sin.default(sin_695);  sin_695 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:702 in program, code: r=r.sin()
        sin_697: "f32[2]" = torch.ops.aten.sin.default(sin_696);  sin_696 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:703 in program, code: r=r.sin()
        sin_698: "f32[2]" = torch.ops.aten.sin.default(sin_697);  sin_697 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:704 in program, code: r=r.sin()
        sin_699: "f32[2]" = torch.ops.aten.sin.default(sin_698);  sin_698 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:705 in program, code: r=r.sin()
        sin_700: "f32[2]" = torch.ops.aten.sin.default(sin_699);  sin_699 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:706 in program, code: r=r.sin()
        sin_701: "f32[2]" = torch.ops.aten.sin.default(sin_700);  sin_700 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:707 in program, code: r=r.sin()
        sin_702: "f32[2]" = torch.ops.aten.sin.default(sin_701);  sin_701 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:708 in program, code: r=r.sin()
        sin_703: "f32[2]" = torch.ops.aten.sin.default(sin_702);  sin_702 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:709 in program, code: r=r.sin()
        sin_704: "f32[2]" = torch.ops.aten.sin.default(sin_703);  sin_703 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:710 in program, code: r=r.sin()
        sin_705: "f32[2]" = torch.ops.aten.sin.default(sin_704);  sin_704 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:711 in program, code: r=r.sin()
        sin_706: "f32[2]" = torch.ops.aten.sin.default(sin_705);  sin_705 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:712 in program, code: r=r.sin()
        sin_707: "f32[2]" = torch.ops.aten.sin.default(sin_706);  sin_706 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:713 in program, code: r=r.sin()
        sin_708: "f32[2]" = torch.ops.aten.sin.default(sin_707);  sin_707 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:714 in program, code: r=r.sin()
        sin_709: "f32[2]" = torch.ops.aten.sin.default(sin_708);  sin_708 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:715 in program, code: r=r.sin()
        sin_710: "f32[2]" = torch.ops.aten.sin.default(sin_709);  sin_709 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:716 in program, code: r=r.sin()
        sin_711: "f32[2]" = torch.ops.aten.sin.default(sin_710);  sin_710 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:717 in program, code: r=r.sin()+r.cos()
        sin_712: "f32[2]" = torch.ops.aten.sin.default(sin_711)
        cos_22: "f32[2]" = torch.ops.aten.cos.default(sin_711);  sin_711 = None
        add_22: "f32[2]" = torch.ops.aten.add.Tensor(sin_712, cos_22);  sin_712 = cos_22 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:718 in program, code: r=r.sin()
        sin_713: "f32[2]" = torch.ops.aten.sin.default(add_22);  add_22 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:719 in program, code: r=r.sin()
        sin_714: "f32[2]" = torch.ops.aten.sin.default(sin_713);  sin_713 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:720 in program, code: r=r.sin()
        sin_715: "f32[2]" = torch.ops.aten.sin.default(sin_714);  sin_714 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:721 in program, code: r=r.sin()
        sin_716: "f32[2]" = torch.ops.aten.sin.default(sin_715);  sin_715 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:722 in program, code: r=r.sin()
        sin_717: "f32[2]" = torch.ops.aten.sin.default(sin_716);  sin_716 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:723 in program, code: r=r.sin()
        sin_718: "f32[2]" = torch.ops.aten.sin.default(sin_717);  sin_717 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:724 in program, code: r=r.sin()
        sin_719: "f32[2]" = torch.ops.aten.sin.default(sin_718);  sin_718 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:725 in program, code: r=r.sin()
        sin_720: "f32[2]" = torch.ops.aten.sin.default(sin_719);  sin_719 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:726 in program, code: r=r.sin()
        sin_721: "f32[2]" = torch.ops.aten.sin.default(sin_720);  sin_720 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:727 in program, code: r=r.sin()
        sin_722: "f32[2]" = torch.ops.aten.sin.default(sin_721);  sin_721 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:728 in program, code: r=r.sin()
        sin_723: "f32[2]" = torch.ops.aten.sin.default(sin_722);  sin_722 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:729 in program, code: r=r.sin()
        sin_724: "f32[2]" = torch.ops.aten.sin.default(sin_723);  sin_723 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:730 in program, code: r=r.sin()
        sin_725: "f32[2]" = torch.ops.aten.sin.default(sin_724);  sin_724 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:731 in program, code: r=r.sin()
        sin_726: "f32[2]" = torch.ops.aten.sin.default(sin_725);  sin_725 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:732 in program, code: r=r.sin()
        sin_727: "f32[2]" = torch.ops.aten.sin.default(sin_726);  sin_726 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:733 in program, code: r=r.sin()
        sin_728: "f32[2]" = torch.ops.aten.sin.default(sin_727);  sin_727 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:734 in program, code: r=r.sin()
        sin_729: "f32[2]" = torch.ops.aten.sin.default(sin_728);  sin_728 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:735 in program, code: r=r.sin()
        sin_730: "f32[2]" = torch.ops.aten.sin.default(sin_729);  sin_729 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:736 in program, code: r=r.sin()
        sin_731: "f32[2]" = torch.ops.aten.sin.default(sin_730);  sin_730 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:737 in program, code: r=r.sin()
        sin_732: "f32[2]" = torch.ops.aten.sin.default(sin_731);  sin_731 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:738 in program, code: r=r.sin()
        sin_733: "f32[2]" = torch.ops.aten.sin.default(sin_732);  sin_732 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:739 in program, code: r=r.sin()
        sin_734: "f32[2]" = torch.ops.aten.sin.default(sin_733);  sin_733 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:740 in program, code: r=r.sin()
        sin_735: "f32[2]" = torch.ops.aten.sin.default(sin_734);  sin_734 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:741 in program, code: r=r.sin()
        sin_736: "f32[2]" = torch.ops.aten.sin.default(sin_735);  sin_735 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:742 in program, code: r=r.sin()
        sin_737: "f32[2]" = torch.ops.aten.sin.default(sin_736);  sin_736 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:743 in program, code: r=r.sin()
        sin_738: "f32[2]" = torch.ops.aten.sin.default(sin_737);  sin_737 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:744 in program, code: r=r.sin()
        sin_739: "f32[2]" = torch.ops.aten.sin.default(sin_738);  sin_738 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:745 in program, code: r=r.sin()
        sin_740: "f32[2]" = torch.ops.aten.sin.default(sin_739);  sin_739 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:746 in program, code: r=r.sin()
        sin_741: "f32[2]" = torch.ops.aten.sin.default(sin_740);  sin_740 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:747 in program, code: r=r.sin()
        sin_742: "f32[2]" = torch.ops.aten.sin.default(sin_741);  sin_741 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:748 in program, code: r=r.sin()+r.cos()
        sin_743: "f32[2]" = torch.ops.aten.sin.default(sin_742)
        cos_23: "f32[2]" = torch.ops.aten.cos.default(sin_742);  sin_742 = None
        add_23: "f32[2]" = torch.ops.aten.add.Tensor(sin_743, cos_23);  sin_743 = cos_23 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:749 in program, code: r=r.sin()
        sin_744: "f32[2]" = torch.ops.aten.sin.default(add_23);  add_23 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:750 in program, code: r=r.sin()
        sin_745: "f32[2]" = torch.ops.aten.sin.default(sin_744);  sin_744 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:751 in program, code: r=r.sin()
        sin_746: "f32[2]" = torch.ops.aten.sin.default(sin_745);  sin_745 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:752 in program, code: r=r.sin()
        sin_747: "f32[2]" = torch.ops.aten.sin.default(sin_746);  sin_746 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:753 in program, code: r=r.sin()
        sin_748: "f32[2]" = torch.ops.aten.sin.default(sin_747);  sin_747 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:754 in program, code: r=r.sin()
        sin_749: "f32[2]" = torch.ops.aten.sin.default(sin_748);  sin_748 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:755 in program, code: r=r.sin()
        sin_750: "f32[2]" = torch.ops.aten.sin.default(sin_749);  sin_749 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:756 in program, code: r=r.sin()
        sin_751: "f32[2]" = torch.ops.aten.sin.default(sin_750);  sin_750 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:757 in program, code: r=r.sin()
        sin_752: "f32[2]" = torch.ops.aten.sin.default(sin_751);  sin_751 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:758 in program, code: r=r.sin()
        sin_753: "f32[2]" = torch.ops.aten.sin.default(sin_752);  sin_752 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:759 in program, code: r=r.sin()
        sin_754: "f32[2]" = torch.ops.aten.sin.default(sin_753);  sin_753 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:760 in program, code: r=r.sin()
        sin_755: "f32[2]" = torch.ops.aten.sin.default(sin_754);  sin_754 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:761 in program, code: r=r.sin()
        sin_756: "f32[2]" = torch.ops.aten.sin.default(sin_755);  sin_755 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:762 in program, code: r=r.sin()
        sin_757: "f32[2]" = torch.ops.aten.sin.default(sin_756);  sin_756 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:763 in program, code: r=r.sin()
        sin_758: "f32[2]" = torch.ops.aten.sin.default(sin_757);  sin_757 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:764 in program, code: r=r.sin()
        sin_759: "f32[2]" = torch.ops.aten.sin.default(sin_758);  sin_758 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:765 in program, code: r=r.sin()
        sin_760: "f32[2]" = torch.ops.aten.sin.default(sin_759);  sin_759 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:766 in program, code: r=r.sin()
        sin_761: "f32[2]" = torch.ops.aten.sin.default(sin_760);  sin_760 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:767 in program, code: r=r.sin()
        sin_762: "f32[2]" = torch.ops.aten.sin.default(sin_761);  sin_761 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:768 in program, code: r=r.sin()
        sin_763: "f32[2]" = torch.ops.aten.sin.default(sin_762);  sin_762 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:769 in program, code: r=r.sin()
        sin_764: "f32[2]" = torch.ops.aten.sin.default(sin_763);  sin_763 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:770 in program, code: r=r.sin()
        sin_765: "f32[2]" = torch.ops.aten.sin.default(sin_764);  sin_764 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:771 in program, code: r=r.sin()
        sin_766: "f32[2]" = torch.ops.aten.sin.default(sin_765);  sin_765 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:772 in program, code: r=r.sin()
        sin_767: "f32[2]" = torch.ops.aten.sin.default(sin_766);  sin_766 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:773 in program, code: r=r.sin()
        sin_768: "f32[2]" = torch.ops.aten.sin.default(sin_767);  sin_767 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:774 in program, code: r=r.sin()
        sin_769: "f32[2]" = torch.ops.aten.sin.default(sin_768);  sin_768 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:775 in program, code: r=r.sin()
        sin_770: "f32[2]" = torch.ops.aten.sin.default(sin_769);  sin_769 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:776 in program, code: r=r.sin()
        sin_771: "f32[2]" = torch.ops.aten.sin.default(sin_770);  sin_770 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:777 in program, code: r=r.sin()
        sin_772: "f32[2]" = torch.ops.aten.sin.default(sin_771);  sin_771 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:778 in program, code: r=r.sin()
        sin_773: "f32[2]" = torch.ops.aten.sin.default(sin_772);  sin_772 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:779 in program, code: r=r.sin()+r.cos()
        sin_774: "f32[2]" = torch.ops.aten.sin.default(sin_773)
        cos_24: "f32[2]" = torch.ops.aten.cos.default(sin_773);  sin_773 = None
        add_24: "f32[2]" = torch.ops.aten.add.Tensor(sin_774, cos_24);  sin_774 = cos_24 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:780 in program, code: r=r.sin()
        sin_775: "f32[2]" = torch.ops.aten.sin.default(add_24);  add_24 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:781 in program, code: r=r.sin()
        sin_776: "f32[2]" = torch.ops.aten.sin.default(sin_775);  sin_775 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:782 in program, code: r=r.sin()
        sin_777: "f32[2]" = torch.ops.aten.sin.default(sin_776);  sin_776 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:783 in program, code: r=r.sin()
        sin_778: "f32[2]" = torch.ops.aten.sin.default(sin_777);  sin_777 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:784 in program, code: r=r.sin()
        sin_779: "f32[2]" = torch.ops.aten.sin.default(sin_778);  sin_778 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:785 in program, code: r=r.sin()
        sin_780: "f32[2]" = torch.ops.aten.sin.default(sin_779);  sin_779 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:786 in program, code: r=r.sin()
        sin_781: "f32[2]" = torch.ops.aten.sin.default(sin_780);  sin_780 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:787 in program, code: r=r.sin()
        sin_782: "f32[2]" = torch.ops.aten.sin.default(sin_781);  sin_781 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:788 in program, code: r=r.sin()
        sin_783: "f32[2]" = torch.ops.aten.sin.default(sin_782);  sin_782 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:789 in program, code: r=r.sin()
        sin_784: "f32[2]" = torch.ops.aten.sin.default(sin_783);  sin_783 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:790 in program, code: r=r.sin()
        sin_785: "f32[2]" = torch.ops.aten.sin.default(sin_784);  sin_784 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:791 in program, code: r=r.sin()
        sin_786: "f32[2]" = torch.ops.aten.sin.default(sin_785);  sin_785 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:792 in program, code: r=r.sin()
        sin_787: "f32[2]" = torch.ops.aten.sin.default(sin_786);  sin_786 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:793 in program, code: r=r.sin()
        sin_788: "f32[2]" = torch.ops.aten.sin.default(sin_787);  sin_787 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:794 in program, code: r=r.sin()
        sin_789: "f32[2]" = torch.ops.aten.sin.default(sin_788);  sin_788 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:795 in program, code: r=r.sin()
        sin_790: "f32[2]" = torch.ops.aten.sin.default(sin_789);  sin_789 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:796 in program, code: r=r.sin()
        sin_791: "f32[2]" = torch.ops.aten.sin.default(sin_790);  sin_790 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:797 in program, code: r=r.sin()
        sin_792: "f32[2]" = torch.ops.aten.sin.default(sin_791);  sin_791 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:798 in program, code: r=r.sin()
        sin_793: "f32[2]" = torch.ops.aten.sin.default(sin_792);  sin_792 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:799 in program, code: r=r.sin()
        sin_794: "f32[2]" = torch.ops.aten.sin.default(sin_793);  sin_793 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:800 in program, code: r=r.sin()
        sin_795: "f32[2]" = torch.ops.aten.sin.default(sin_794);  sin_794 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:801 in program, code: r=r.sin()
        sin_796: "f32[2]" = torch.ops.aten.sin.default(sin_795);  sin_795 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:802 in program, code: r=r.sin()
        sin_797: "f32[2]" = torch.ops.aten.sin.default(sin_796);  sin_796 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:803 in program, code: r=r.sin()
        sin_798: "f32[2]" = torch.ops.aten.sin.default(sin_797);  sin_797 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:804 in program, code: r=r.sin()
        sin_799: "f32[2]" = torch.ops.aten.sin.default(sin_798);  sin_798 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:805 in program, code: r=r.sin()
        sin_800: "f32[2]" = torch.ops.aten.sin.default(sin_799);  sin_799 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:806 in program, code: r=r.sin()
        sin_801: "f32[2]" = torch.ops.aten.sin.default(sin_800);  sin_800 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:807 in program, code: r=r.sin()
        sin_802: "f32[2]" = torch.ops.aten.sin.default(sin_801);  sin_801 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:808 in program, code: r=r.sin()
        sin_803: "f32[2]" = torch.ops.aten.sin.default(sin_802);  sin_802 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:809 in program, code: r=r.sin()
        sin_804: "f32[2]" = torch.ops.aten.sin.default(sin_803);  sin_803 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:810 in program, code: r=r.sin()+r.cos()
        sin_805: "f32[2]" = torch.ops.aten.sin.default(sin_804)
        cos_25: "f32[2]" = torch.ops.aten.cos.default(sin_804);  sin_804 = None
        add_25: "f32[2]" = torch.ops.aten.add.Tensor(sin_805, cos_25);  sin_805 = cos_25 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:811 in program, code: r=r.sin()
        sin_806: "f32[2]" = torch.ops.aten.sin.default(add_25);  add_25 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:812 in program, code: r=r.sin()
        sin_807: "f32[2]" = torch.ops.aten.sin.default(sin_806);  sin_806 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:813 in program, code: r=r.sin()
        sin_808: "f32[2]" = torch.ops.aten.sin.default(sin_807);  sin_807 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:814 in program, code: r=r.sin()
        sin_809: "f32[2]" = torch.ops.aten.sin.default(sin_808);  sin_808 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:815 in program, code: r=r.sin()
        sin_810: "f32[2]" = torch.ops.aten.sin.default(sin_809);  sin_809 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:816 in program, code: r=r.sin()
        sin_811: "f32[2]" = torch.ops.aten.sin.default(sin_810);  sin_810 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:817 in program, code: r=r.sin()
        sin_812: "f32[2]" = torch.ops.aten.sin.default(sin_811);  sin_811 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:818 in program, code: r=r.sin()
        sin_813: "f32[2]" = torch.ops.aten.sin.default(sin_812);  sin_812 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:819 in program, code: r=r.sin()
        sin_814: "f32[2]" = torch.ops.aten.sin.default(sin_813);  sin_813 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:820 in program, code: r=r.sin()
        sin_815: "f32[2]" = torch.ops.aten.sin.default(sin_814);  sin_814 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:821 in program, code: r=r.sin()
        sin_816: "f32[2]" = torch.ops.aten.sin.default(sin_815);  sin_815 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:822 in program, code: r=r.sin()
        sin_817: "f32[2]" = torch.ops.aten.sin.default(sin_816);  sin_816 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:823 in program, code: r=r.sin()
        sin_818: "f32[2]" = torch.ops.aten.sin.default(sin_817);  sin_817 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:824 in program, code: r=r.sin()
        sin_819: "f32[2]" = torch.ops.aten.sin.default(sin_818);  sin_818 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:825 in program, code: r=r.sin()
        sin_820: "f32[2]" = torch.ops.aten.sin.default(sin_819);  sin_819 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:826 in program, code: r=r.sin()
        sin_821: "f32[2]" = torch.ops.aten.sin.default(sin_820);  sin_820 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:827 in program, code: r=r.sin()
        sin_822: "f32[2]" = torch.ops.aten.sin.default(sin_821);  sin_821 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:828 in program, code: r=r.sin()
        sin_823: "f32[2]" = torch.ops.aten.sin.default(sin_822);  sin_822 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:829 in program, code: r=r.sin()
        sin_824: "f32[2]" = torch.ops.aten.sin.default(sin_823);  sin_823 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:830 in program, code: r=r.sin()
        sin_825: "f32[2]" = torch.ops.aten.sin.default(sin_824);  sin_824 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:831 in program, code: r=r.sin()
        sin_826: "f32[2]" = torch.ops.aten.sin.default(sin_825);  sin_825 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:832 in program, code: r=r.sin()
        sin_827: "f32[2]" = torch.ops.aten.sin.default(sin_826);  sin_826 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:833 in program, code: r=r.sin()
        sin_828: "f32[2]" = torch.ops.aten.sin.default(sin_827);  sin_827 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:834 in program, code: r=r.sin()
        sin_829: "f32[2]" = torch.ops.aten.sin.default(sin_828);  sin_828 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:835 in program, code: r=r.sin()
        sin_830: "f32[2]" = torch.ops.aten.sin.default(sin_829);  sin_829 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:836 in program, code: r=r.sin()
        sin_831: "f32[2]" = torch.ops.aten.sin.default(sin_830);  sin_830 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:837 in program, code: r=r.sin()
        sin_832: "f32[2]" = torch.ops.aten.sin.default(sin_831);  sin_831 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:838 in program, code: r=r.sin()
        sin_833: "f32[2]" = torch.ops.aten.sin.default(sin_832);  sin_832 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:839 in program, code: r=r.sin()
        sin_834: "f32[2]" = torch.ops.aten.sin.default(sin_833);  sin_833 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:840 in program, code: r=r.sin()
        sin_835: "f32[2]" = torch.ops.aten.sin.default(sin_834);  sin_834 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:841 in program, code: r=r.sin()+r.cos()
        sin_836: "f32[2]" = torch.ops.aten.sin.default(sin_835)
        cos_26: "f32[2]" = torch.ops.aten.cos.default(sin_835);  sin_835 = None
        add_26: "f32[2]" = torch.ops.aten.add.Tensor(sin_836, cos_26);  sin_836 = cos_26 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:842 in program, code: r=r.sin()
        sin_837: "f32[2]" = torch.ops.aten.sin.default(add_26);  add_26 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:843 in program, code: r=r.sin()
        sin_838: "f32[2]" = torch.ops.aten.sin.default(sin_837);  sin_837 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:844 in program, code: r=r.sin()
        sin_839: "f32[2]" = torch.ops.aten.sin.default(sin_838);  sin_838 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:845 in program, code: r=r.sin()
        sin_840: "f32[2]" = torch.ops.aten.sin.default(sin_839);  sin_839 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:846 in program, code: r=r.sin()
        sin_841: "f32[2]" = torch.ops.aten.sin.default(sin_840);  sin_840 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:847 in program, code: r=r.sin()
        sin_842: "f32[2]" = torch.ops.aten.sin.default(sin_841);  sin_841 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:848 in program, code: r=r.sin()
        sin_843: "f32[2]" = torch.ops.aten.sin.default(sin_842);  sin_842 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:849 in program, code: r=r.sin()
        sin_844: "f32[2]" = torch.ops.aten.sin.default(sin_843);  sin_843 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:850 in program, code: r=r.sin()
        sin_845: "f32[2]" = torch.ops.aten.sin.default(sin_844);  sin_844 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:851 in program, code: r=r.sin()
        sin_846: "f32[2]" = torch.ops.aten.sin.default(sin_845);  sin_845 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:852 in program, code: r=r.sin()
        sin_847: "f32[2]" = torch.ops.aten.sin.default(sin_846);  sin_846 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:853 in program, code: r=r.sin()
        sin_848: "f32[2]" = torch.ops.aten.sin.default(sin_847);  sin_847 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:854 in program, code: r=r.sin()
        sin_849: "f32[2]" = torch.ops.aten.sin.default(sin_848);  sin_848 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:855 in program, code: r=r.sin()
        sin_850: "f32[2]" = torch.ops.aten.sin.default(sin_849);  sin_849 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:856 in program, code: r=r.sin()
        sin_851: "f32[2]" = torch.ops.aten.sin.default(sin_850);  sin_850 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:857 in program, code: r=r.sin()
        sin_852: "f32[2]" = torch.ops.aten.sin.default(sin_851);  sin_851 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:858 in program, code: r=r.sin()
        sin_853: "f32[2]" = torch.ops.aten.sin.default(sin_852);  sin_852 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:859 in program, code: r=r.sin()
        sin_854: "f32[2]" = torch.ops.aten.sin.default(sin_853);  sin_853 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:860 in program, code: r=r.sin()
        sin_855: "f32[2]" = torch.ops.aten.sin.default(sin_854);  sin_854 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:861 in program, code: r=r.sin()
        sin_856: "f32[2]" = torch.ops.aten.sin.default(sin_855);  sin_855 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:862 in program, code: r=r.sin()
        sin_857: "f32[2]" = torch.ops.aten.sin.default(sin_856);  sin_856 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:863 in program, code: r=r.sin()
        sin_858: "f32[2]" = torch.ops.aten.sin.default(sin_857);  sin_857 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:864 in program, code: r=r.sin()
        sin_859: "f32[2]" = torch.ops.aten.sin.default(sin_858);  sin_858 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:865 in program, code: r=r.sin()
        sin_860: "f32[2]" = torch.ops.aten.sin.default(sin_859);  sin_859 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:866 in program, code: r=r.sin()
        sin_861: "f32[2]" = torch.ops.aten.sin.default(sin_860);  sin_860 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:867 in program, code: r=r.sin()
        sin_862: "f32[2]" = torch.ops.aten.sin.default(sin_861);  sin_861 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:868 in program, code: r=r.sin()
        sin_863: "f32[2]" = torch.ops.aten.sin.default(sin_862);  sin_862 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:869 in program, code: r=r.sin()
        sin_864: "f32[2]" = torch.ops.aten.sin.default(sin_863);  sin_863 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:870 in program, code: r=r.sin()
        sin_865: "f32[2]" = torch.ops.aten.sin.default(sin_864);  sin_864 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:871 in program, code: r=r.sin()
        sin_866: "f32[2]" = torch.ops.aten.sin.default(sin_865);  sin_865 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:872 in program, code: r=r.sin()+r.cos()
        sin_867: "f32[2]" = torch.ops.aten.sin.default(sin_866)
        cos_27: "f32[2]" = torch.ops.aten.cos.default(sin_866);  sin_866 = None
        add_27: "f32[2]" = torch.ops.aten.add.Tensor(sin_867, cos_27);  sin_867 = cos_27 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:873 in program, code: r=r.sin()
        sin_868: "f32[2]" = torch.ops.aten.sin.default(add_27);  add_27 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:874 in program, code: r=r.sin()
        sin_869: "f32[2]" = torch.ops.aten.sin.default(sin_868);  sin_868 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:875 in program, code: r=r.sin()
        sin_870: "f32[2]" = torch.ops.aten.sin.default(sin_869);  sin_869 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:876 in program, code: r=r.sin()
        sin_871: "f32[2]" = torch.ops.aten.sin.default(sin_870);  sin_870 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:877 in program, code: r=r.sin()
        sin_872: "f32[2]" = torch.ops.aten.sin.default(sin_871);  sin_871 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:878 in program, code: r=r.sin()
        sin_873: "f32[2]" = torch.ops.aten.sin.default(sin_872);  sin_872 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:879 in program, code: r=r.sin()
        sin_874: "f32[2]" = torch.ops.aten.sin.default(sin_873);  sin_873 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:880 in program, code: r=r.sin()
        sin_875: "f32[2]" = torch.ops.aten.sin.default(sin_874);  sin_874 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:881 in program, code: r=r.sin()
        sin_876: "f32[2]" = torch.ops.aten.sin.default(sin_875);  sin_875 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:882 in program, code: r=r.sin()
        sin_877: "f32[2]" = torch.ops.aten.sin.default(sin_876);  sin_876 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:883 in program, code: r=r.sin()
        sin_878: "f32[2]" = torch.ops.aten.sin.default(sin_877);  sin_877 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:884 in program, code: r=r.sin()
        sin_879: "f32[2]" = torch.ops.aten.sin.default(sin_878);  sin_878 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:885 in program, code: r=r.sin()
        sin_880: "f32[2]" = torch.ops.aten.sin.default(sin_879);  sin_879 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:886 in program, code: r=r.sin()
        sin_881: "f32[2]" = torch.ops.aten.sin.default(sin_880);  sin_880 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:887 in program, code: r=r.sin()
        sin_882: "f32[2]" = torch.ops.aten.sin.default(sin_881);  sin_881 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:888 in program, code: r=r.sin()
        sin_883: "f32[2]" = torch.ops.aten.sin.default(sin_882);  sin_882 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:889 in program, code: r=r.sin()
        sin_884: "f32[2]" = torch.ops.aten.sin.default(sin_883);  sin_883 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:890 in program, code: r=r.sin()
        sin_885: "f32[2]" = torch.ops.aten.sin.default(sin_884);  sin_884 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:891 in program, code: r=r.sin()
        sin_886: "f32[2]" = torch.ops.aten.sin.default(sin_885);  sin_885 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:892 in program, code: r=r.sin()
        sin_887: "f32[2]" = torch.ops.aten.sin.default(sin_886);  sin_886 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:893 in program, code: r=r.sin()
        sin_888: "f32[2]" = torch.ops.aten.sin.default(sin_887);  sin_887 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:894 in program, code: r=r.sin()
        sin_889: "f32[2]" = torch.ops.aten.sin.default(sin_888);  sin_888 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:895 in program, code: r=r.sin()
        sin_890: "f32[2]" = torch.ops.aten.sin.default(sin_889);  sin_889 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:896 in program, code: r=r.sin()
        sin_891: "f32[2]" = torch.ops.aten.sin.default(sin_890);  sin_890 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:897 in program, code: r=r.sin()
        sin_892: "f32[2]" = torch.ops.aten.sin.default(sin_891);  sin_891 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:898 in program, code: r=r.sin()
        sin_893: "f32[2]" = torch.ops.aten.sin.default(sin_892);  sin_892 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:899 in program, code: r=r.sin()
        sin_894: "f32[2]" = torch.ops.aten.sin.default(sin_893);  sin_893 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:900 in program, code: r=r.sin()
        sin_895: "f32[2]" = torch.ops.aten.sin.default(sin_894);  sin_894 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:901 in program, code: r=r.sin()
        sin_896: "f32[2]" = torch.ops.aten.sin.default(sin_895);  sin_895 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:902 in program, code: r=r.sin()
        sin_897: "f32[2]" = torch.ops.aten.sin.default(sin_896);  sin_896 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:903 in program, code: r=r.sin()+r.cos()
        sin_898: "f32[2]" = torch.ops.aten.sin.default(sin_897)
        cos_28: "f32[2]" = torch.ops.aten.cos.default(sin_897);  sin_897 = None
        add_28: "f32[2]" = torch.ops.aten.add.Tensor(sin_898, cos_28);  sin_898 = cos_28 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:904 in program, code: r=r.sin()
        sin_899: "f32[2]" = torch.ops.aten.sin.default(add_28);  add_28 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:905 in program, code: r=r.sin()
        sin_900: "f32[2]" = torch.ops.aten.sin.default(sin_899);  sin_899 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:906 in program, code: r=r.sin()
        sin_901: "f32[2]" = torch.ops.aten.sin.default(sin_900);  sin_900 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:907 in program, code: r=r.sin()
        sin_902: "f32[2]" = torch.ops.aten.sin.default(sin_901);  sin_901 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:908 in program, code: r=r.sin()
        sin_903: "f32[2]" = torch.ops.aten.sin.default(sin_902);  sin_902 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:909 in program, code: r=r.sin()
        sin_904: "f32[2]" = torch.ops.aten.sin.default(sin_903);  sin_903 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:910 in program, code: r=r.sin()
        sin_905: "f32[2]" = torch.ops.aten.sin.default(sin_904);  sin_904 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:911 in program, code: r=r.sin()
        sin_906: "f32[2]" = torch.ops.aten.sin.default(sin_905);  sin_905 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:912 in program, code: r=r.sin()
        sin_907: "f32[2]" = torch.ops.aten.sin.default(sin_906);  sin_906 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:913 in program, code: r=r.sin()
        sin_908: "f32[2]" = torch.ops.aten.sin.default(sin_907);  sin_907 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:914 in program, code: r=r.sin()
        sin_909: "f32[2]" = torch.ops.aten.sin.default(sin_908);  sin_908 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:915 in program, code: r=r.sin()
        sin_910: "f32[2]" = torch.ops.aten.sin.default(sin_909);  sin_909 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:916 in program, code: r=r.sin()
        sin_911: "f32[2]" = torch.ops.aten.sin.default(sin_910);  sin_910 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:917 in program, code: r=r.sin()
        sin_912: "f32[2]" = torch.ops.aten.sin.default(sin_911);  sin_911 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:918 in program, code: r=r.sin()
        sin_913: "f32[2]" = torch.ops.aten.sin.default(sin_912);  sin_912 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:919 in program, code: r=r.sin()
        sin_914: "f32[2]" = torch.ops.aten.sin.default(sin_913);  sin_913 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:920 in program, code: r=r.sin()
        sin_915: "f32[2]" = torch.ops.aten.sin.default(sin_914);  sin_914 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:921 in program, code: r=r.sin()
        sin_916: "f32[2]" = torch.ops.aten.sin.default(sin_915);  sin_915 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:922 in program, code: r=r.sin()
        sin_917: "f32[2]" = torch.ops.aten.sin.default(sin_916);  sin_916 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:923 in program, code: r=r.sin()
        sin_918: "f32[2]" = torch.ops.aten.sin.default(sin_917);  sin_917 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:924 in program, code: r=r.sin()
        sin_919: "f32[2]" = torch.ops.aten.sin.default(sin_918);  sin_918 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:925 in program, code: r=r.sin()
        sin_920: "f32[2]" = torch.ops.aten.sin.default(sin_919);  sin_919 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:926 in program, code: r=r.sin()
        sin_921: "f32[2]" = torch.ops.aten.sin.default(sin_920);  sin_920 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:927 in program, code: r=r.sin()
        sin_922: "f32[2]" = torch.ops.aten.sin.default(sin_921);  sin_921 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:928 in program, code: r=r.sin()
        sin_923: "f32[2]" = torch.ops.aten.sin.default(sin_922);  sin_922 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:929 in program, code: r=r.sin()
        sin_924: "f32[2]" = torch.ops.aten.sin.default(sin_923);  sin_923 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:930 in program, code: r=r.sin()
        sin_925: "f32[2]" = torch.ops.aten.sin.default(sin_924);  sin_924 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:931 in program, code: r=r.sin()
        sin_926: "f32[2]" = torch.ops.aten.sin.default(sin_925);  sin_925 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:932 in program, code: r=r.sin()
        sin_927: "f32[2]" = torch.ops.aten.sin.default(sin_926);  sin_926 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:933 in program, code: r=r.sin()
        sin_928: "f32[2]" = torch.ops.aten.sin.default(sin_927);  sin_927 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:934 in program, code: r=r.sin()+r.cos()
        sin_929: "f32[2]" = torch.ops.aten.sin.default(sin_928)
        cos_29: "f32[2]" = torch.ops.aten.cos.default(sin_928);  sin_928 = None
        add_29: "f32[2]" = torch.ops.aten.add.Tensor(sin_929, cos_29);  sin_929 = cos_29 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:935 in program, code: r=r.sin()
        sin_930: "f32[2]" = torch.ops.aten.sin.default(add_29);  add_29 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:936 in program, code: r=r.sin()
        sin_931: "f32[2]" = torch.ops.aten.sin.default(sin_930);  sin_930 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:937 in program, code: r=r.sin()
        sin_932: "f32[2]" = torch.ops.aten.sin.default(sin_931);  sin_931 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:938 in program, code: r=r.sin()
        sin_933: "f32[2]" = torch.ops.aten.sin.default(sin_932);  sin_932 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:939 in program, code: r=r.sin()
        sin_934: "f32[2]" = torch.ops.aten.sin.default(sin_933);  sin_933 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:940 in program, code: r=r.sin()
        sin_935: "f32[2]" = torch.ops.aten.sin.default(sin_934);  sin_934 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:941 in program, code: r=r.sin()
        sin_936: "f32[2]" = torch.ops.aten.sin.default(sin_935);  sin_935 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:942 in program, code: r=r.sin()
        sin_937: "f32[2]" = torch.ops.aten.sin.default(sin_936);  sin_936 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:943 in program, code: r=r.sin()
        sin_938: "f32[2]" = torch.ops.aten.sin.default(sin_937);  sin_937 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:944 in program, code: r=r.sin()
        sin_939: "f32[2]" = torch.ops.aten.sin.default(sin_938);  sin_938 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:945 in program, code: r=r.sin()
        sin_940: "f32[2]" = torch.ops.aten.sin.default(sin_939);  sin_939 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:946 in program, code: r=r.sin()
        sin_941: "f32[2]" = torch.ops.aten.sin.default(sin_940);  sin_940 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:947 in program, code: r=r.sin()
        sin_942: "f32[2]" = torch.ops.aten.sin.default(sin_941);  sin_941 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:948 in program, code: r=r.sin()
        sin_943: "f32[2]" = torch.ops.aten.sin.default(sin_942);  sin_942 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:949 in program, code: r=r.sin()
        sin_944: "f32[2]" = torch.ops.aten.sin.default(sin_943);  sin_943 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:950 in program, code: r=r.sin()
        sin_945: "f32[2]" = torch.ops.aten.sin.default(sin_944);  sin_944 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:951 in program, code: r=r.sin()
        sin_946: "f32[2]" = torch.ops.aten.sin.default(sin_945);  sin_945 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:952 in program, code: r=r.sin()
        sin_947: "f32[2]" = torch.ops.aten.sin.default(sin_946);  sin_946 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:953 in program, code: r=r.sin()
        sin_948: "f32[2]" = torch.ops.aten.sin.default(sin_947);  sin_947 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:954 in program, code: r=r.sin()
        sin_949: "f32[2]" = torch.ops.aten.sin.default(sin_948);  sin_948 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:955 in program, code: r=r.sin()
        sin_950: "f32[2]" = torch.ops.aten.sin.default(sin_949);  sin_949 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:956 in program, code: r=r.sin()
        sin_951: "f32[2]" = torch.ops.aten.sin.default(sin_950);  sin_950 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:957 in program, code: r=r.sin()
        sin_952: "f32[2]" = torch.ops.aten.sin.default(sin_951);  sin_951 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:958 in program, code: r=r.sin()
        sin_953: "f32[2]" = torch.ops.aten.sin.default(sin_952);  sin_952 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:959 in program, code: r=r.sin()
        sin_954: "f32[2]" = torch.ops.aten.sin.default(sin_953);  sin_953 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:960 in program, code: r=r.sin()
        sin_955: "f32[2]" = torch.ops.aten.sin.default(sin_954);  sin_954 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:961 in program, code: r=r.sin()
        sin_956: "f32[2]" = torch.ops.aten.sin.default(sin_955);  sin_955 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:962 in program, code: r=r.sin()
        sin_957: "f32[2]" = torch.ops.aten.sin.default(sin_956);  sin_956 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:963 in program, code: r=r.sin()
        sin_958: "f32[2]" = torch.ops.aten.sin.default(sin_957);  sin_957 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:964 in program, code: r=r.sin()
        sin_959: "f32[2]" = torch.ops.aten.sin.default(sin_958);  sin_958 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:965 in program, code: r=r.sin()+r.cos()
        sin_960: "f32[2]" = torch.ops.aten.sin.default(sin_959)
        cos_30: "f32[2]" = torch.ops.aten.cos.default(sin_959);  sin_959 = None
        add_30: "f32[2]" = torch.ops.aten.add.Tensor(sin_960, cos_30);  sin_960 = cos_30 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:966 in program, code: r=r.sin()
        sin_961: "f32[2]" = torch.ops.aten.sin.default(add_30);  add_30 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:967 in program, code: r=r.sin()
        sin_962: "f32[2]" = torch.ops.aten.sin.default(sin_961);  sin_961 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:968 in program, code: r=r.sin()
        sin_963: "f32[2]" = torch.ops.aten.sin.default(sin_962);  sin_962 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:969 in program, code: r=r.sin()
        sin_964: "f32[2]" = torch.ops.aten.sin.default(sin_963);  sin_963 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:970 in program, code: r=r.sin()
        sin_965: "f32[2]" = torch.ops.aten.sin.default(sin_964);  sin_964 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:971 in program, code: r=r.sin()
        sin_966: "f32[2]" = torch.ops.aten.sin.default(sin_965);  sin_965 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:972 in program, code: r=r.sin()
        sin_967: "f32[2]" = torch.ops.aten.sin.default(sin_966);  sin_966 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:973 in program, code: r=r.sin()
        sin_968: "f32[2]" = torch.ops.aten.sin.default(sin_967);  sin_967 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:974 in program, code: r=r.sin()
        sin_969: "f32[2]" = torch.ops.aten.sin.default(sin_968);  sin_968 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:975 in program, code: r=r.sin()
        sin_970: "f32[2]" = torch.ops.aten.sin.default(sin_969);  sin_969 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:976 in program, code: r=r.sin()
        sin_971: "f32[2]" = torch.ops.aten.sin.default(sin_970);  sin_970 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:977 in program, code: r=r.sin()
        sin_972: "f32[2]" = torch.ops.aten.sin.default(sin_971);  sin_971 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:978 in program, code: r=r.sin()
        sin_973: "f32[2]" = torch.ops.aten.sin.default(sin_972);  sin_972 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:979 in program, code: r=r.sin()
        sin_974: "f32[2]" = torch.ops.aten.sin.default(sin_973);  sin_973 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:980 in program, code: r=r.sin()
        sin_975: "f32[2]" = torch.ops.aten.sin.default(sin_974);  sin_974 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:981 in program, code: r=r.sin()
        sin_976: "f32[2]" = torch.ops.aten.sin.default(sin_975);  sin_975 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:982 in program, code: r=r.sin()
        sin_977: "f32[2]" = torch.ops.aten.sin.default(sin_976);  sin_976 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:983 in program, code: r=r.sin()
        sin_978: "f32[2]" = torch.ops.aten.sin.default(sin_977);  sin_977 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:984 in program, code: r=r.sin()
        sin_979: "f32[2]" = torch.ops.aten.sin.default(sin_978);  sin_978 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:985 in program, code: r=r.sin()
        sin_980: "f32[2]" = torch.ops.aten.sin.default(sin_979);  sin_979 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:986 in program, code: r=r.sin()
        sin_981: "f32[2]" = torch.ops.aten.sin.default(sin_980);  sin_980 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:987 in program, code: r=r.sin()
        sin_982: "f32[2]" = torch.ops.aten.sin.default(sin_981);  sin_981 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:988 in program, code: r=r.sin()
        sin_983: "f32[2]" = torch.ops.aten.sin.default(sin_982);  sin_982 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:989 in program, code: r=r.sin()
        sin_984: "f32[2]" = torch.ops.aten.sin.default(sin_983);  sin_983 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:990 in program, code: r=r.sin()
        sin_985: "f32[2]" = torch.ops.aten.sin.default(sin_984);  sin_984 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:991 in program, code: r=r.sin()
        sin_986: "f32[2]" = torch.ops.aten.sin.default(sin_985);  sin_985 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:992 in program, code: r=r.sin()
        sin_987: "f32[2]" = torch.ops.aten.sin.default(sin_986);  sin_986 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:993 in program, code: r=r.sin()
        sin_988: "f32[2]" = torch.ops.aten.sin.default(sin_987);  sin_987 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:994 in program, code: r=r.sin()
        sin_989: "f32[2]" = torch.ops.aten.sin.default(sin_988);  sin_988 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:995 in program, code: r=r.sin()
        sin_990: "f32[2]" = torch.ops.aten.sin.default(sin_989);  sin_989 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:996 in program, code: r=r.sin()+r.cos()
        sin_991: "f32[2]" = torch.ops.aten.sin.default(sin_990)
        cos_31: "f32[2]" = torch.ops.aten.cos.default(sin_990);  sin_990 = None
        add_31: "f32[2]" = torch.ops.aten.add.Tensor(sin_991, cos_31);  sin_991 = cos_31 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:997 in program, code: r=r.sin()
        sin_992: "f32[2]" = torch.ops.aten.sin.default(add_31);  add_31 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:998 in program, code: r=r.sin()
        sin_993: "f32[2]" = torch.ops.aten.sin.default(sin_992);  sin_992 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:999 in program, code: r=r.sin()
        sin_994: "f32[2]" = torch.ops.aten.sin.default(sin_993);  sin_993 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1000 in program, code: r=r.sin()
        sin_995: "f32[2]" = torch.ops.aten.sin.default(sin_994);  sin_994 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1001 in program, code: r=r.sin()
        sin_996: "f32[2]" = torch.ops.aten.sin.default(sin_995);  sin_995 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1002 in program, code: r=r.sin()
        sin_997: "f32[2]" = torch.ops.aten.sin.default(sin_996);  sin_996 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1003 in program, code: r=r.sin()
        sin_998: "f32[2]" = torch.ops.aten.sin.default(sin_997);  sin_997 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1004 in program, code: r=r.sin()
        sin_999: "f32[2]" = torch.ops.aten.sin.default(sin_998);  sin_998 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1005 in program, code: r=r.sin()
        sin_1000: "f32[2]" = torch.ops.aten.sin.default(sin_999);  sin_999 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1006 in program, code: r=r.sin()
        sin_1001: "f32[2]" = torch.ops.aten.sin.default(sin_1000);  sin_1000 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1007 in program, code: r=r.sin()
        sin_1002: "f32[2]" = torch.ops.aten.sin.default(sin_1001);  sin_1001 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1008 in program, code: r=r.sin()
        sin_1003: "f32[2]" = torch.ops.aten.sin.default(sin_1002);  sin_1002 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1009 in program, code: r=r.sin()
        sin_1004: "f32[2]" = torch.ops.aten.sin.default(sin_1003);  sin_1003 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1010 in program, code: r=r.sin()
        sin_1005: "f32[2]" = torch.ops.aten.sin.default(sin_1004);  sin_1004 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1011 in program, code: r=r.sin()
        sin_1006: "f32[2]" = torch.ops.aten.sin.default(sin_1005);  sin_1005 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1012 in program, code: r=r.sin()
        sin_1007: "f32[2]" = torch.ops.aten.sin.default(sin_1006);  sin_1006 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1013 in program, code: r=r.sin()
        sin_1008: "f32[2]" = torch.ops.aten.sin.default(sin_1007);  sin_1007 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1014 in program, code: r=r.sin()
        sin_1009: "f32[2]" = torch.ops.aten.sin.default(sin_1008);  sin_1008 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1015 in program, code: r=r.sin()
        sin_1010: "f32[2]" = torch.ops.aten.sin.default(sin_1009);  sin_1009 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1016 in program, code: r=r.sin()
        sin_1011: "f32[2]" = torch.ops.aten.sin.default(sin_1010);  sin_1010 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1017 in program, code: r=r.sin()
        sin_1012: "f32[2]" = torch.ops.aten.sin.default(sin_1011);  sin_1011 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1018 in program, code: r=r.sin()
        sin_1013: "f32[2]" = torch.ops.aten.sin.default(sin_1012);  sin_1012 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1019 in program, code: r=r.sin()
        sin_1014: "f32[2]" = torch.ops.aten.sin.default(sin_1013);  sin_1013 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1020 in program, code: r=r.sin()
        sin_1015: "f32[2]" = torch.ops.aten.sin.default(sin_1014);  sin_1014 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1021 in program, code: r=r.sin()
        sin_1016: "f32[2]" = torch.ops.aten.sin.default(sin_1015);  sin_1015 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1022 in program, code: r=r.sin()
        sin_1017: "f32[2]" = torch.ops.aten.sin.default(sin_1016);  sin_1016 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1023 in program, code: r=r.sin()
        sin_1018: "f32[2]" = torch.ops.aten.sin.default(sin_1017);  sin_1017 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1024 in program, code: r=r.sin()
        sin_1019: "f32[2]" = torch.ops.aten.sin.default(sin_1018);  sin_1018 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1025 in program, code: r=r.sin()
        sin_1020: "f32[2]" = torch.ops.aten.sin.default(sin_1019);  sin_1019 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1026 in program, code: r=r.sin()
        sin_1021: "f32[2]" = torch.ops.aten.sin.default(sin_1020);  sin_1020 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1027 in program, code: r=r.sin()+r.cos()
        sin_1022: "f32[2]" = torch.ops.aten.sin.default(sin_1021)
        cos_32: "f32[2]" = torch.ops.aten.cos.default(sin_1021);  sin_1021 = None
        add_32: "f32[2]" = torch.ops.aten.add.Tensor(sin_1022, cos_32);  sin_1022 = cos_32 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1028 in program, code: r=r.sin()
        sin_1023: "f32[2]" = torch.ops.aten.sin.default(add_32);  add_32 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1029 in program, code: r=r.sin()
        sin_1024: "f32[2]" = torch.ops.aten.sin.default(sin_1023);  sin_1023 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1030 in program, code: r=r.sin()
        sin_1025: "f32[2]" = torch.ops.aten.sin.default(sin_1024);  sin_1024 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1031 in program, code: r=r.sin()
        sin_1026: "f32[2]" = torch.ops.aten.sin.default(sin_1025);  sin_1025 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1032 in program, code: r=r.sin()
        sin_1027: "f32[2]" = torch.ops.aten.sin.default(sin_1026);  sin_1026 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1033 in program, code: r=r.sin()
        sin_1028: "f32[2]" = torch.ops.aten.sin.default(sin_1027);  sin_1027 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1034 in program, code: r=r.sin()
        sin_1029: "f32[2]" = torch.ops.aten.sin.default(sin_1028);  sin_1028 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1035 in program, code: r=r.sin()
        sin_1030: "f32[2]" = torch.ops.aten.sin.default(sin_1029);  sin_1029 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1036 in program, code: r=r.sin()
        sin_1031: "f32[2]" = torch.ops.aten.sin.default(sin_1030);  sin_1030 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1037 in program, code: r=r.sin()
        sin_1032: "f32[2]" = torch.ops.aten.sin.default(sin_1031);  sin_1031 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1038 in program, code: r=r.sin()
        sin_1033: "f32[2]" = torch.ops.aten.sin.default(sin_1032);  sin_1032 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1039 in program, code: r=r.sin()
        sin_1034: "f32[2]" = torch.ops.aten.sin.default(sin_1033);  sin_1033 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1040 in program, code: r=r.sin()
        sin_1035: "f32[2]" = torch.ops.aten.sin.default(sin_1034);  sin_1034 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1041 in program, code: r=r.sin()
        sin_1036: "f32[2]" = torch.ops.aten.sin.default(sin_1035);  sin_1035 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1042 in program, code: r=r.sin()
        sin_1037: "f32[2]" = torch.ops.aten.sin.default(sin_1036);  sin_1036 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1043 in program, code: r=r.sin()
        sin_1038: "f32[2]" = torch.ops.aten.sin.default(sin_1037);  sin_1037 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1044 in program, code: r=r.sin()
        sin_1039: "f32[2]" = torch.ops.aten.sin.default(sin_1038);  sin_1038 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1045 in program, code: r=r.sin()
        sin_1040: "f32[2]" = torch.ops.aten.sin.default(sin_1039);  sin_1039 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1046 in program, code: r=r.sin()
        sin_1041: "f32[2]" = torch.ops.aten.sin.default(sin_1040);  sin_1040 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1047 in program, code: r=r.sin()
        sin_1042: "f32[2]" = torch.ops.aten.sin.default(sin_1041);  sin_1041 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1048 in program, code: r=r.sin()
        sin_1043: "f32[2]" = torch.ops.aten.sin.default(sin_1042);  sin_1042 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1049 in program, code: r=r.sin()
        sin_1044: "f32[2]" = torch.ops.aten.sin.default(sin_1043);  sin_1043 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1050 in program, code: r=r.sin()
        sin_1045: "f32[2]" = torch.ops.aten.sin.default(sin_1044);  sin_1044 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1051 in program, code: r=r.sin()
        sin_1046: "f32[2]" = torch.ops.aten.sin.default(sin_1045);  sin_1045 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1052 in program, code: r=r.sin()
        sin_1047: "f32[2]" = torch.ops.aten.sin.default(sin_1046);  sin_1046 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1053 in program, code: r=r.sin()
        sin_1048: "f32[2]" = torch.ops.aten.sin.default(sin_1047);  sin_1047 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1054 in program, code: r=r.sin()
        sin_1049: "f32[2]" = torch.ops.aten.sin.default(sin_1048);  sin_1048 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1055 in program, code: r=r.sin()
        sin_1050: "f32[2]" = torch.ops.aten.sin.default(sin_1049);  sin_1049 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1056 in program, code: r=r.sin()
        sin_1051: "f32[2]" = torch.ops.aten.sin.default(sin_1050);  sin_1050 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1057 in program, code: r=r.sin()
        sin_1052: "f32[2]" = torch.ops.aten.sin.default(sin_1051);  sin_1051 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1058 in program, code: r=r.sin()+r.cos()
        sin_1053: "f32[2]" = torch.ops.aten.sin.default(sin_1052)
        cos_33: "f32[2]" = torch.ops.aten.cos.default(sin_1052);  sin_1052 = None
        add_33: "f32[2]" = torch.ops.aten.add.Tensor(sin_1053, cos_33);  sin_1053 = cos_33 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1059 in program, code: r=r.sin()
        sin_1054: "f32[2]" = torch.ops.aten.sin.default(add_33);  add_33 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1060 in program, code: r=r.sin()
        sin_1055: "f32[2]" = torch.ops.aten.sin.default(sin_1054);  sin_1054 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1061 in program, code: r=r.sin()
        sin_1056: "f32[2]" = torch.ops.aten.sin.default(sin_1055);  sin_1055 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1062 in program, code: r=r.sin()
        sin_1057: "f32[2]" = torch.ops.aten.sin.default(sin_1056);  sin_1056 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1063 in program, code: r=r.sin()
        sin_1058: "f32[2]" = torch.ops.aten.sin.default(sin_1057);  sin_1057 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1064 in program, code: r=r.sin()
        sin_1059: "f32[2]" = torch.ops.aten.sin.default(sin_1058);  sin_1058 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1065 in program, code: r=r.sin()
        sin_1060: "f32[2]" = torch.ops.aten.sin.default(sin_1059);  sin_1059 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1066 in program, code: r=r.sin()
        sin_1061: "f32[2]" = torch.ops.aten.sin.default(sin_1060);  sin_1060 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1067 in program, code: r=r.sin()
        sin_1062: "f32[2]" = torch.ops.aten.sin.default(sin_1061);  sin_1061 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1068 in program, code: r=r.sin()
        sin_1063: "f32[2]" = torch.ops.aten.sin.default(sin_1062);  sin_1062 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1069 in program, code: r=r.sin()
        sin_1064: "f32[2]" = torch.ops.aten.sin.default(sin_1063);  sin_1063 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1070 in program, code: r=r.sin()
        sin_1065: "f32[2]" = torch.ops.aten.sin.default(sin_1064);  sin_1064 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1071 in program, code: r=r.sin()
        sin_1066: "f32[2]" = torch.ops.aten.sin.default(sin_1065);  sin_1065 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1072 in program, code: r=r.sin()
        sin_1067: "f32[2]" = torch.ops.aten.sin.default(sin_1066);  sin_1066 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1073 in program, code: r=r.sin()
        sin_1068: "f32[2]" = torch.ops.aten.sin.default(sin_1067);  sin_1067 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1074 in program, code: r=r.sin()
        sin_1069: "f32[2]" = torch.ops.aten.sin.default(sin_1068);  sin_1068 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1075 in program, code: r=r.sin()
        sin_1070: "f32[2]" = torch.ops.aten.sin.default(sin_1069);  sin_1069 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1076 in program, code: r=r.sin()
        sin_1071: "f32[2]" = torch.ops.aten.sin.default(sin_1070);  sin_1070 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1077 in program, code: r=r.sin()
        sin_1072: "f32[2]" = torch.ops.aten.sin.default(sin_1071);  sin_1071 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1078 in program, code: r=r.sin()
        sin_1073: "f32[2]" = torch.ops.aten.sin.default(sin_1072);  sin_1072 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1079 in program, code: r=r.sin()
        sin_1074: "f32[2]" = torch.ops.aten.sin.default(sin_1073);  sin_1073 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1080 in program, code: r=r.sin()
        sin_1075: "f32[2]" = torch.ops.aten.sin.default(sin_1074);  sin_1074 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1081 in program, code: r=r.sin()
        sin_1076: "f32[2]" = torch.ops.aten.sin.default(sin_1075);  sin_1075 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1082 in program, code: r=r.sin()
        sin_1077: "f32[2]" = torch.ops.aten.sin.default(sin_1076);  sin_1076 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1083 in program, code: r=r.sin()
        sin_1078: "f32[2]" = torch.ops.aten.sin.default(sin_1077);  sin_1077 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1084 in program, code: r=r.sin()
        sin_1079: "f32[2]" = torch.ops.aten.sin.default(sin_1078);  sin_1078 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1085 in program, code: r=r.sin()
        sin_1080: "f32[2]" = torch.ops.aten.sin.default(sin_1079);  sin_1079 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1086 in program, code: r=r.sin()
        sin_1081: "f32[2]" = torch.ops.aten.sin.default(sin_1080);  sin_1080 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1087 in program, code: r=r.sin()
        sin_1082: "f32[2]" = torch.ops.aten.sin.default(sin_1081);  sin_1081 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1088 in program, code: r=r.sin()
        sin_1083: "f32[2]" = torch.ops.aten.sin.default(sin_1082);  sin_1082 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1089 in program, code: r=r.sin()+r.cos()
        sin_1084: "f32[2]" = torch.ops.aten.sin.default(sin_1083)
        cos_34: "f32[2]" = torch.ops.aten.cos.default(sin_1083);  sin_1083 = None
        add_34: "f32[2]" = torch.ops.aten.add.Tensor(sin_1084, cos_34);  sin_1084 = cos_34 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1090 in program, code: r=r.sin()
        sin_1085: "f32[2]" = torch.ops.aten.sin.default(add_34);  add_34 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1091 in program, code: r=r.sin()
        sin_1086: "f32[2]" = torch.ops.aten.sin.default(sin_1085);  sin_1085 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1092 in program, code: r=r.sin()
        sin_1087: "f32[2]" = torch.ops.aten.sin.default(sin_1086);  sin_1086 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1093 in program, code: r=r.sin()
        sin_1088: "f32[2]" = torch.ops.aten.sin.default(sin_1087);  sin_1087 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1094 in program, code: r=r.sin()
        sin_1089: "f32[2]" = torch.ops.aten.sin.default(sin_1088);  sin_1088 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1095 in program, code: r=r.sin()
        sin_1090: "f32[2]" = torch.ops.aten.sin.default(sin_1089);  sin_1089 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1096 in program, code: r=r.sin()
        sin_1091: "f32[2]" = torch.ops.aten.sin.default(sin_1090);  sin_1090 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1097 in program, code: r=r.sin()
        sin_1092: "f32[2]" = torch.ops.aten.sin.default(sin_1091);  sin_1091 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1098 in program, code: r=r.sin()
        sin_1093: "f32[2]" = torch.ops.aten.sin.default(sin_1092);  sin_1092 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1099 in program, code: r=r.sin()
        sin_1094: "f32[2]" = torch.ops.aten.sin.default(sin_1093);  sin_1093 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1100 in program, code: r=r.sin()
        sin_1095: "f32[2]" = torch.ops.aten.sin.default(sin_1094);  sin_1094 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1101 in program, code: r=r.sin()
        sin_1096: "f32[2]" = torch.ops.aten.sin.default(sin_1095);  sin_1095 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1102 in program, code: r=r.sin()
        sin_1097: "f32[2]" = torch.ops.aten.sin.default(sin_1096);  sin_1096 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1103 in program, code: r=r.sin()
        sin_1098: "f32[2]" = torch.ops.aten.sin.default(sin_1097);  sin_1097 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1104 in program, code: r=r.sin()
        sin_1099: "f32[2]" = torch.ops.aten.sin.default(sin_1098);  sin_1098 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1105 in program, code: r=r.sin()
        sin_1100: "f32[2]" = torch.ops.aten.sin.default(sin_1099);  sin_1099 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1106 in program, code: r=r.sin()
        sin_1101: "f32[2]" = torch.ops.aten.sin.default(sin_1100);  sin_1100 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1107 in program, code: r=r.sin()
        sin_1102: "f32[2]" = torch.ops.aten.sin.default(sin_1101);  sin_1101 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1108 in program, code: r=r.sin()
        sin_1103: "f32[2]" = torch.ops.aten.sin.default(sin_1102);  sin_1102 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1109 in program, code: r=r.sin()
        sin_1104: "f32[2]" = torch.ops.aten.sin.default(sin_1103);  sin_1103 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1110 in program, code: r=r.sin()
        sin_1105: "f32[2]" = torch.ops.aten.sin.default(sin_1104);  sin_1104 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1111 in program, code: r=r.sin()
        sin_1106: "f32[2]" = torch.ops.aten.sin.default(sin_1105);  sin_1105 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1112 in program, code: r=r.sin()
        sin_1107: "f32[2]" = torch.ops.aten.sin.default(sin_1106);  sin_1106 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1113 in program, code: r=r.sin()
        sin_1108: "f32[2]" = torch.ops.aten.sin.default(sin_1107);  sin_1107 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1114 in program, code: r=r.sin()
        sin_1109: "f32[2]" = torch.ops.aten.sin.default(sin_1108);  sin_1108 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1115 in program, code: r=r.sin()
        sin_1110: "f32[2]" = torch.ops.aten.sin.default(sin_1109);  sin_1109 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1116 in program, code: r=r.sin()
        sin_1111: "f32[2]" = torch.ops.aten.sin.default(sin_1110);  sin_1110 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1117 in program, code: r=r.sin()
        sin_1112: "f32[2]" = torch.ops.aten.sin.default(sin_1111);  sin_1111 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1118 in program, code: r=r.sin()
        sin_1113: "f32[2]" = torch.ops.aten.sin.default(sin_1112);  sin_1112 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1119 in program, code: r=r.sin()
        sin_1114: "f32[2]" = torch.ops.aten.sin.default(sin_1113);  sin_1113 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1120 in program, code: r=r.sin()+r.cos()
        sin_1115: "f32[2]" = torch.ops.aten.sin.default(sin_1114)
        cos_35: "f32[2]" = torch.ops.aten.cos.default(sin_1114);  sin_1114 = None
        add_35: "f32[2]" = torch.ops.aten.add.Tensor(sin_1115, cos_35);  sin_1115 = cos_35 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1121 in program, code: r=r.sin()
        sin_1116: "f32[2]" = torch.ops.aten.sin.default(add_35);  add_35 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1122 in program, code: r=r.sin()
        sin_1117: "f32[2]" = torch.ops.aten.sin.default(sin_1116);  sin_1116 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1123 in program, code: r=r.sin()
        sin_1118: "f32[2]" = torch.ops.aten.sin.default(sin_1117);  sin_1117 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1124 in program, code: r=r.sin()
        sin_1119: "f32[2]" = torch.ops.aten.sin.default(sin_1118);  sin_1118 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1125 in program, code: r=r.sin()
        sin_1120: "f32[2]" = torch.ops.aten.sin.default(sin_1119);  sin_1119 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1126 in program, code: r=r.sin()
        sin_1121: "f32[2]" = torch.ops.aten.sin.default(sin_1120);  sin_1120 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1127 in program, code: r=r.sin()
        sin_1122: "f32[2]" = torch.ops.aten.sin.default(sin_1121);  sin_1121 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1128 in program, code: r=r.sin()
        sin_1123: "f32[2]" = torch.ops.aten.sin.default(sin_1122);  sin_1122 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1129 in program, code: r=r.sin()
        sin_1124: "f32[2]" = torch.ops.aten.sin.default(sin_1123);  sin_1123 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1130 in program, code: r=r.sin()
        sin_1125: "f32[2]" = torch.ops.aten.sin.default(sin_1124);  sin_1124 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1131 in program, code: r=r.sin()
        sin_1126: "f32[2]" = torch.ops.aten.sin.default(sin_1125);  sin_1125 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1132 in program, code: r=r.sin()
        sin_1127: "f32[2]" = torch.ops.aten.sin.default(sin_1126);  sin_1126 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1133 in program, code: r=r.sin()
        sin_1128: "f32[2]" = torch.ops.aten.sin.default(sin_1127);  sin_1127 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1134 in program, code: r=r.sin()
        sin_1129: "f32[2]" = torch.ops.aten.sin.default(sin_1128);  sin_1128 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1135 in program, code: r=r.sin()
        sin_1130: "f32[2]" = torch.ops.aten.sin.default(sin_1129);  sin_1129 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1136 in program, code: r=r.sin()
        sin_1131: "f32[2]" = torch.ops.aten.sin.default(sin_1130);  sin_1130 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1137 in program, code: r=r.sin()
        sin_1132: "f32[2]" = torch.ops.aten.sin.default(sin_1131);  sin_1131 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1138 in program, code: r=r.sin()
        sin_1133: "f32[2]" = torch.ops.aten.sin.default(sin_1132);  sin_1132 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1139 in program, code: r=r.sin()
        sin_1134: "f32[2]" = torch.ops.aten.sin.default(sin_1133);  sin_1133 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1140 in program, code: r=r.sin()
        sin_1135: "f32[2]" = torch.ops.aten.sin.default(sin_1134);  sin_1134 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1141 in program, code: r=r.sin()
        sin_1136: "f32[2]" = torch.ops.aten.sin.default(sin_1135);  sin_1135 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1142 in program, code: r=r.sin()
        sin_1137: "f32[2]" = torch.ops.aten.sin.default(sin_1136);  sin_1136 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1143 in program, code: r=r.sin()
        sin_1138: "f32[2]" = torch.ops.aten.sin.default(sin_1137);  sin_1137 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1144 in program, code: r=r.sin()
        sin_1139: "f32[2]" = torch.ops.aten.sin.default(sin_1138);  sin_1138 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1145 in program, code: r=r.sin()
        sin_1140: "f32[2]" = torch.ops.aten.sin.default(sin_1139);  sin_1139 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1146 in program, code: r=r.sin()
        sin_1141: "f32[2]" = torch.ops.aten.sin.default(sin_1140);  sin_1140 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1147 in program, code: r=r.sin()
        sin_1142: "f32[2]" = torch.ops.aten.sin.default(sin_1141);  sin_1141 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1148 in program, code: r=r.sin()
        sin_1143: "f32[2]" = torch.ops.aten.sin.default(sin_1142);  sin_1142 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1149 in program, code: r=r.sin()
        sin_1144: "f32[2]" = torch.ops.aten.sin.default(sin_1143);  sin_1143 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1150 in program, code: r=r.sin()
        sin_1145: "f32[2]" = torch.ops.aten.sin.default(sin_1144);  sin_1144 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1151 in program, code: r=r.sin()+r.cos()
        sin_1146: "f32[2]" = torch.ops.aten.sin.default(sin_1145)
        cos_36: "f32[2]" = torch.ops.aten.cos.default(sin_1145);  sin_1145 = None
        add_36: "f32[2]" = torch.ops.aten.add.Tensor(sin_1146, cos_36);  sin_1146 = cos_36 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1152 in program, code: r=r.sin()
        sin_1147: "f32[2]" = torch.ops.aten.sin.default(add_36);  add_36 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1153 in program, code: r=r.sin()
        sin_1148: "f32[2]" = torch.ops.aten.sin.default(sin_1147);  sin_1147 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1154 in program, code: r=r.sin()
        sin_1149: "f32[2]" = torch.ops.aten.sin.default(sin_1148);  sin_1148 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1155 in program, code: r=r.sin()
        sin_1150: "f32[2]" = torch.ops.aten.sin.default(sin_1149);  sin_1149 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1156 in program, code: r=r.sin()
        sin_1151: "f32[2]" = torch.ops.aten.sin.default(sin_1150);  sin_1150 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1157 in program, code: r=r.sin()
        sin_1152: "f32[2]" = torch.ops.aten.sin.default(sin_1151);  sin_1151 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1158 in program, code: r=r.sin()
        sin_1153: "f32[2]" = torch.ops.aten.sin.default(sin_1152);  sin_1152 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1159 in program, code: r=r.sin()
        sin_1154: "f32[2]" = torch.ops.aten.sin.default(sin_1153);  sin_1153 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1160 in program, code: r=r.sin()
        sin_1155: "f32[2]" = torch.ops.aten.sin.default(sin_1154);  sin_1154 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1161 in program, code: r=r.sin()
        sin_1156: "f32[2]" = torch.ops.aten.sin.default(sin_1155);  sin_1155 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1162 in program, code: r=r.sin()
        sin_1157: "f32[2]" = torch.ops.aten.sin.default(sin_1156);  sin_1156 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1163 in program, code: r=r.sin()
        sin_1158: "f32[2]" = torch.ops.aten.sin.default(sin_1157);  sin_1157 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1164 in program, code: r=r.sin()
        sin_1159: "f32[2]" = torch.ops.aten.sin.default(sin_1158);  sin_1158 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1165 in program, code: r=r.sin()
        sin_1160: "f32[2]" = torch.ops.aten.sin.default(sin_1159);  sin_1159 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1166 in program, code: r=r.sin()
        sin_1161: "f32[2]" = torch.ops.aten.sin.default(sin_1160);  sin_1160 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1167 in program, code: r=r.sin()
        sin_1162: "f32[2]" = torch.ops.aten.sin.default(sin_1161);  sin_1161 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1168 in program, code: r=r.sin()
        sin_1163: "f32[2]" = torch.ops.aten.sin.default(sin_1162);  sin_1162 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1169 in program, code: r=r.sin()
        sin_1164: "f32[2]" = torch.ops.aten.sin.default(sin_1163);  sin_1163 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1170 in program, code: r=r.sin()
        sin_1165: "f32[2]" = torch.ops.aten.sin.default(sin_1164);  sin_1164 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1171 in program, code: r=r.sin()
        sin_1166: "f32[2]" = torch.ops.aten.sin.default(sin_1165);  sin_1165 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1172 in program, code: r=r.sin()
        sin_1167: "f32[2]" = torch.ops.aten.sin.default(sin_1166);  sin_1166 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1173 in program, code: r=r.sin()
        sin_1168: "f32[2]" = torch.ops.aten.sin.default(sin_1167);  sin_1167 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1174 in program, code: r=r.sin()
        sin_1169: "f32[2]" = torch.ops.aten.sin.default(sin_1168);  sin_1168 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1175 in program, code: r=r.sin()
        sin_1170: "f32[2]" = torch.ops.aten.sin.default(sin_1169);  sin_1169 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1176 in program, code: r=r.sin()
        sin_1171: "f32[2]" = torch.ops.aten.sin.default(sin_1170);  sin_1170 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1177 in program, code: r=r.sin()
        sin_1172: "f32[2]" = torch.ops.aten.sin.default(sin_1171);  sin_1171 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1178 in program, code: r=r.sin()
        sin_1173: "f32[2]" = torch.ops.aten.sin.default(sin_1172);  sin_1172 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1179 in program, code: r=r.sin()
        sin_1174: "f32[2]" = torch.ops.aten.sin.default(sin_1173);  sin_1173 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1180 in program, code: r=r.sin()
        sin_1175: "f32[2]" = torch.ops.aten.sin.default(sin_1174);  sin_1174 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1181 in program, code: r=r.sin()
        sin_1176: "f32[2]" = torch.ops.aten.sin.default(sin_1175);  sin_1175 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1182 in program, code: r=r.sin()+r.cos()
        sin_1177: "f32[2]" = torch.ops.aten.sin.default(sin_1176)
        cos_37: "f32[2]" = torch.ops.aten.cos.default(sin_1176);  sin_1176 = None
        add_37: "f32[2]" = torch.ops.aten.add.Tensor(sin_1177, cos_37);  sin_1177 = cos_37 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1183 in program, code: r=r.sin()
        sin_1178: "f32[2]" = torch.ops.aten.sin.default(add_37);  add_37 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1184 in program, code: r=r.sin()
        sin_1179: "f32[2]" = torch.ops.aten.sin.default(sin_1178);  sin_1178 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1185 in program, code: r=r.sin()
        sin_1180: "f32[2]" = torch.ops.aten.sin.default(sin_1179);  sin_1179 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1186 in program, code: r=r.sin()
        sin_1181: "f32[2]" = torch.ops.aten.sin.default(sin_1180);  sin_1180 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1187 in program, code: r=r.sin()
        sin_1182: "f32[2]" = torch.ops.aten.sin.default(sin_1181);  sin_1181 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1188 in program, code: r=r.sin()
        sin_1183: "f32[2]" = torch.ops.aten.sin.default(sin_1182);  sin_1182 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1189 in program, code: r=r.sin()
        sin_1184: "f32[2]" = torch.ops.aten.sin.default(sin_1183);  sin_1183 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1190 in program, code: r=r.sin()
        sin_1185: "f32[2]" = torch.ops.aten.sin.default(sin_1184);  sin_1184 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1191 in program, code: r=r.sin()
        sin_1186: "f32[2]" = torch.ops.aten.sin.default(sin_1185);  sin_1185 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1192 in program, code: r=r.sin()
        sin_1187: "f32[2]" = torch.ops.aten.sin.default(sin_1186);  sin_1186 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1193 in program, code: r=r.sin()
        sin_1188: "f32[2]" = torch.ops.aten.sin.default(sin_1187);  sin_1187 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1194 in program, code: r=r.sin()
        sin_1189: "f32[2]" = torch.ops.aten.sin.default(sin_1188);  sin_1188 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1195 in program, code: r=r.sin()
        sin_1190: "f32[2]" = torch.ops.aten.sin.default(sin_1189);  sin_1189 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1196 in program, code: r=r.sin()
        sin_1191: "f32[2]" = torch.ops.aten.sin.default(sin_1190);  sin_1190 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1197 in program, code: r=r.sin()
        sin_1192: "f32[2]" = torch.ops.aten.sin.default(sin_1191);  sin_1191 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1198 in program, code: r=r.sin()
        sin_1193: "f32[2]" = torch.ops.aten.sin.default(sin_1192);  sin_1192 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1199 in program, code: r=r.sin()
        sin_1194: "f32[2]" = torch.ops.aten.sin.default(sin_1193);  sin_1193 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1200 in program, code: r=r.sin()
        sin_1195: "f32[2]" = torch.ops.aten.sin.default(sin_1194);  sin_1194 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1201 in program, code: r=r.sin()
        sin_1196: "f32[2]" = torch.ops.aten.sin.default(sin_1195);  sin_1195 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1202 in program, code: r=r.sin()
        sin_1197: "f32[2]" = torch.ops.aten.sin.default(sin_1196);  sin_1196 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1203 in program, code: r=r.sin()
        sin_1198: "f32[2]" = torch.ops.aten.sin.default(sin_1197);  sin_1197 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1204 in program, code: r=r.sin()
        sin_1199: "f32[2]" = torch.ops.aten.sin.default(sin_1198);  sin_1198 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1205 in program, code: r=r.sin()
        sin_1200: "f32[2]" = torch.ops.aten.sin.default(sin_1199);  sin_1199 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1206 in program, code: r=r.sin()
        sin_1201: "f32[2]" = torch.ops.aten.sin.default(sin_1200);  sin_1200 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1207 in program, code: r=r.sin()
        sin_1202: "f32[2]" = torch.ops.aten.sin.default(sin_1201);  sin_1201 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1208 in program, code: r=r.sin()
        sin_1203: "f32[2]" = torch.ops.aten.sin.default(sin_1202);  sin_1202 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1209 in program, code: r=r.sin()
        sin_1204: "f32[2]" = torch.ops.aten.sin.default(sin_1203);  sin_1203 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1210 in program, code: r=r.sin()
        sin_1205: "f32[2]" = torch.ops.aten.sin.default(sin_1204);  sin_1204 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1211 in program, code: r=r.sin()
        sin_1206: "f32[2]" = torch.ops.aten.sin.default(sin_1205);  sin_1205 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1212 in program, code: r=r.sin()
        sin_1207: "f32[2]" = torch.ops.aten.sin.default(sin_1206);  sin_1206 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1213 in program, code: r=r.sin()+r.cos()
        sin_1208: "f32[2]" = torch.ops.aten.sin.default(sin_1207)
        cos_38: "f32[2]" = torch.ops.aten.cos.default(sin_1207);  sin_1207 = None
        add_38: "f32[2]" = torch.ops.aten.add.Tensor(sin_1208, cos_38);  sin_1208 = cos_38 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1214 in program, code: r=r.sin()
        sin_1209: "f32[2]" = torch.ops.aten.sin.default(add_38);  add_38 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1215 in program, code: r=r.sin()
        sin_1210: "f32[2]" = torch.ops.aten.sin.default(sin_1209);  sin_1209 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1216 in program, code: r=r.sin()
        sin_1211: "f32[2]" = torch.ops.aten.sin.default(sin_1210);  sin_1210 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1217 in program, code: r=r.sin()
        sin_1212: "f32[2]" = torch.ops.aten.sin.default(sin_1211);  sin_1211 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1218 in program, code: r=r.sin()
        sin_1213: "f32[2]" = torch.ops.aten.sin.default(sin_1212);  sin_1212 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1219 in program, code: r=r.sin()
        sin_1214: "f32[2]" = torch.ops.aten.sin.default(sin_1213);  sin_1213 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1220 in program, code: r=r.sin()
        sin_1215: "f32[2]" = torch.ops.aten.sin.default(sin_1214);  sin_1214 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1221 in program, code: r=r.sin()
        sin_1216: "f32[2]" = torch.ops.aten.sin.default(sin_1215);  sin_1215 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1222 in program, code: r=r.sin()
        sin_1217: "f32[2]" = torch.ops.aten.sin.default(sin_1216);  sin_1216 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1223 in program, code: r=r.sin()
        sin_1218: "f32[2]" = torch.ops.aten.sin.default(sin_1217);  sin_1217 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1224 in program, code: r=r.sin()
        sin_1219: "f32[2]" = torch.ops.aten.sin.default(sin_1218);  sin_1218 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1225 in program, code: r=r.sin()
        sin_1220: "f32[2]" = torch.ops.aten.sin.default(sin_1219);  sin_1219 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1226 in program, code: r=r.sin()
        sin_1221: "f32[2]" = torch.ops.aten.sin.default(sin_1220);  sin_1220 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1227 in program, code: r=r.sin()
        sin_1222: "f32[2]" = torch.ops.aten.sin.default(sin_1221);  sin_1221 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1228 in program, code: r=r.sin()
        sin_1223: "f32[2]" = torch.ops.aten.sin.default(sin_1222);  sin_1222 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1229 in program, code: r=r.sin()
        sin_1224: "f32[2]" = torch.ops.aten.sin.default(sin_1223);  sin_1223 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1230 in program, code: r=r.sin()
        sin_1225: "f32[2]" = torch.ops.aten.sin.default(sin_1224);  sin_1224 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1231 in program, code: r=r.sin()
        sin_1226: "f32[2]" = torch.ops.aten.sin.default(sin_1225);  sin_1225 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1232 in program, code: r=r.sin()
        sin_1227: "f32[2]" = torch.ops.aten.sin.default(sin_1226);  sin_1226 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1233 in program, code: r=r.sin()
        sin_1228: "f32[2]" = torch.ops.aten.sin.default(sin_1227);  sin_1227 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1234 in program, code: r=r.sin()
        sin_1229: "f32[2]" = torch.ops.aten.sin.default(sin_1228);  sin_1228 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1235 in program, code: r=r.sin()
        sin_1230: "f32[2]" = torch.ops.aten.sin.default(sin_1229);  sin_1229 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1236 in program, code: r=r.sin()
        sin_1231: "f32[2]" = torch.ops.aten.sin.default(sin_1230);  sin_1230 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1237 in program, code: r=r.sin()
        sin_1232: "f32[2]" = torch.ops.aten.sin.default(sin_1231);  sin_1231 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1238 in program, code: r=r.sin()
        sin_1233: "f32[2]" = torch.ops.aten.sin.default(sin_1232);  sin_1232 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1239 in program, code: r=r.sin()
        sin_1234: "f32[2]" = torch.ops.aten.sin.default(sin_1233);  sin_1233 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1240 in program, code: r=r.sin()
        sin_1235: "f32[2]" = torch.ops.aten.sin.default(sin_1234);  sin_1234 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1241 in program, code: r=r.sin()
        sin_1236: "f32[2]" = torch.ops.aten.sin.default(sin_1235);  sin_1235 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1242 in program, code: r=r.sin()
        sin_1237: "f32[2]" = torch.ops.aten.sin.default(sin_1236);  sin_1236 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1243 in program, code: r=r.sin()
        sin_1238: "f32[2]" = torch.ops.aten.sin.default(sin_1237);  sin_1237 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1244 in program, code: r=r.sin()+r.cos()
        sin_1239: "f32[2]" = torch.ops.aten.sin.default(sin_1238)
        cos_39: "f32[2]" = torch.ops.aten.cos.default(sin_1238);  sin_1238 = None
        add_39: "f32[2]" = torch.ops.aten.add.Tensor(sin_1239, cos_39);  sin_1239 = cos_39 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1245 in program, code: r=r.sin()
        sin_1240: "f32[2]" = torch.ops.aten.sin.default(add_39);  add_39 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1246 in program, code: r=r.sin()
        sin_1241: "f32[2]" = torch.ops.aten.sin.default(sin_1240);  sin_1240 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1247 in program, code: r=r.sin()
        sin_1242: "f32[2]" = torch.ops.aten.sin.default(sin_1241);  sin_1241 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1248 in program, code: r=r.sin()
        sin_1243: "f32[2]" = torch.ops.aten.sin.default(sin_1242);  sin_1242 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1249 in program, code: r=r.sin()
        sin_1244: "f32[2]" = torch.ops.aten.sin.default(sin_1243);  sin_1243 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1250 in program, code: r=r.sin()
        sin_1245: "f32[2]" = torch.ops.aten.sin.default(sin_1244);  sin_1244 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1251 in program, code: r=r.sin()
        sin_1246: "f32[2]" = torch.ops.aten.sin.default(sin_1245);  sin_1245 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1252 in program, code: r=r.sin()
        sin_1247: "f32[2]" = torch.ops.aten.sin.default(sin_1246);  sin_1246 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1253 in program, code: r=r.sin()
        sin_1248: "f32[2]" = torch.ops.aten.sin.default(sin_1247);  sin_1247 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1254 in program, code: r=r.sin()
        sin_1249: "f32[2]" = torch.ops.aten.sin.default(sin_1248);  sin_1248 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1255 in program, code: r=r.sin()
        sin_1250: "f32[2]" = torch.ops.aten.sin.default(sin_1249);  sin_1249 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1256 in program, code: r=r.sin()
        sin_1251: "f32[2]" = torch.ops.aten.sin.default(sin_1250);  sin_1250 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1257 in program, code: r=r.sin()
        sin_1252: "f32[2]" = torch.ops.aten.sin.default(sin_1251);  sin_1251 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1258 in program, code: r=r.sin()
        sin_1253: "f32[2]" = torch.ops.aten.sin.default(sin_1252);  sin_1252 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1259 in program, code: r=r.sin()
        sin_1254: "f32[2]" = torch.ops.aten.sin.default(sin_1253);  sin_1253 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1260 in program, code: r=r.sin()
        sin_1255: "f32[2]" = torch.ops.aten.sin.default(sin_1254);  sin_1254 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1261 in program, code: r=r.sin()
        sin_1256: "f32[2]" = torch.ops.aten.sin.default(sin_1255);  sin_1255 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1262 in program, code: r=r.sin()
        sin_1257: "f32[2]" = torch.ops.aten.sin.default(sin_1256);  sin_1256 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1263 in program, code: r=r.sin()
        sin_1258: "f32[2]" = torch.ops.aten.sin.default(sin_1257);  sin_1257 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1264 in program, code: r=r.sin()
        sin_1259: "f32[2]" = torch.ops.aten.sin.default(sin_1258);  sin_1258 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1265 in program, code: r=r.sin()
        sin_1260: "f32[2]" = torch.ops.aten.sin.default(sin_1259);  sin_1259 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1266 in program, code: r=r.sin()
        sin_1261: "f32[2]" = torch.ops.aten.sin.default(sin_1260);  sin_1260 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1267 in program, code: r=r.sin()
        sin_1262: "f32[2]" = torch.ops.aten.sin.default(sin_1261);  sin_1261 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1268 in program, code: r=r.sin()
        sin_1263: "f32[2]" = torch.ops.aten.sin.default(sin_1262);  sin_1262 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1269 in program, code: r=r.sin()
        sin_1264: "f32[2]" = torch.ops.aten.sin.default(sin_1263);  sin_1263 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1270 in program, code: r=r.sin()
        sin_1265: "f32[2]" = torch.ops.aten.sin.default(sin_1264);  sin_1264 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1271 in program, code: r=r.sin()
        sin_1266: "f32[2]" = torch.ops.aten.sin.default(sin_1265);  sin_1265 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1272 in program, code: r=r.sin()
        sin_1267: "f32[2]" = torch.ops.aten.sin.default(sin_1266);  sin_1266 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1273 in program, code: r=r.sin()
        sin_1268: "f32[2]" = torch.ops.aten.sin.default(sin_1267);  sin_1267 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1274 in program, code: r=r.sin()
        sin_1269: "f32[2]" = torch.ops.aten.sin.default(sin_1268);  sin_1268 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1275 in program, code: r=r.sin()+r.cos()
        sin_1270: "f32[2]" = torch.ops.aten.sin.default(sin_1269)
        cos_40: "f32[2]" = torch.ops.aten.cos.default(sin_1269);  sin_1269 = None
        add_40: "f32[2]" = torch.ops.aten.add.Tensor(sin_1270, cos_40);  sin_1270 = cos_40 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1276 in program, code: r=r.sin()
        sin_1271: "f32[2]" = torch.ops.aten.sin.default(add_40);  add_40 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1277 in program, code: r=r.sin()
        sin_1272: "f32[2]" = torch.ops.aten.sin.default(sin_1271);  sin_1271 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1278 in program, code: r=r.sin()
        sin_1273: "f32[2]" = torch.ops.aten.sin.default(sin_1272);  sin_1272 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1279 in program, code: r=r.sin()
        sin_1274: "f32[2]" = torch.ops.aten.sin.default(sin_1273);  sin_1273 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1280 in program, code: r=r.sin()
        sin_1275: "f32[2]" = torch.ops.aten.sin.default(sin_1274);  sin_1274 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1281 in program, code: r=r.sin()
        sin_1276: "f32[2]" = torch.ops.aten.sin.default(sin_1275);  sin_1275 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1282 in program, code: r=r.sin()
        sin_1277: "f32[2]" = torch.ops.aten.sin.default(sin_1276);  sin_1276 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1283 in program, code: r=r.sin()
        sin_1278: "f32[2]" = torch.ops.aten.sin.default(sin_1277);  sin_1277 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1284 in program, code: r=r.sin()
        sin_1279: "f32[2]" = torch.ops.aten.sin.default(sin_1278);  sin_1278 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1285 in program, code: r=r.sin()
        sin_1280: "f32[2]" = torch.ops.aten.sin.default(sin_1279);  sin_1279 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1286 in program, code: r=r.sin()
        sin_1281: "f32[2]" = torch.ops.aten.sin.default(sin_1280);  sin_1280 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1287 in program, code: r=r.sin()
        sin_1282: "f32[2]" = torch.ops.aten.sin.default(sin_1281);  sin_1281 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1288 in program, code: r=r.sin()
        sin_1283: "f32[2]" = torch.ops.aten.sin.default(sin_1282);  sin_1282 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1289 in program, code: r=r.sin()
        sin_1284: "f32[2]" = torch.ops.aten.sin.default(sin_1283);  sin_1283 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1290 in program, code: r=r.sin()
        sin_1285: "f32[2]" = torch.ops.aten.sin.default(sin_1284);  sin_1284 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1291 in program, code: r=r.sin()
        sin_1286: "f32[2]" = torch.ops.aten.sin.default(sin_1285);  sin_1285 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1292 in program, code: r=r.sin()
        sin_1287: "f32[2]" = torch.ops.aten.sin.default(sin_1286);  sin_1286 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1293 in program, code: r=r.sin()
        sin_1288: "f32[2]" = torch.ops.aten.sin.default(sin_1287);  sin_1287 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1294 in program, code: r=r.sin()
        sin_1289: "f32[2]" = torch.ops.aten.sin.default(sin_1288);  sin_1288 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1295 in program, code: r=r.sin()
        sin_1290: "f32[2]" = torch.ops.aten.sin.default(sin_1289);  sin_1289 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1296 in program, code: r=r.sin()
        sin_1291: "f32[2]" = torch.ops.aten.sin.default(sin_1290);  sin_1290 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1297 in program, code: r=r.sin()
        sin_1292: "f32[2]" = torch.ops.aten.sin.default(sin_1291);  sin_1291 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1298 in program, code: r=r.sin()
        sin_1293: "f32[2]" = torch.ops.aten.sin.default(sin_1292);  sin_1292 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1299 in program, code: r=r.sin()
        sin_1294: "f32[2]" = torch.ops.aten.sin.default(sin_1293);  sin_1293 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1300 in program, code: r=r.sin()
        sin_1295: "f32[2]" = torch.ops.aten.sin.default(sin_1294);  sin_1294 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1301 in program, code: r=r.sin()
        sin_1296: "f32[2]" = torch.ops.aten.sin.default(sin_1295);  sin_1295 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1302 in program, code: r=r.sin()
        sin_1297: "f32[2]" = torch.ops.aten.sin.default(sin_1296);  sin_1296 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1303 in program, code: r=r.sin()
        sin_1298: "f32[2]" = torch.ops.aten.sin.default(sin_1297);  sin_1297 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1304 in program, code: r=r.sin()
        sin_1299: "f32[2]" = torch.ops.aten.sin.default(sin_1298);  sin_1298 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1305 in program, code: r=r.sin()
        sin_1300: "f32[2]" = torch.ops.aten.sin.default(sin_1299);  sin_1299 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1306 in program, code: r=r.sin()+r.cos()
        sin_1301: "f32[2]" = torch.ops.aten.sin.default(sin_1300)
        cos_41: "f32[2]" = torch.ops.aten.cos.default(sin_1300);  sin_1300 = None
        add_41: "f32[2]" = torch.ops.aten.add.Tensor(sin_1301, cos_41);  sin_1301 = cos_41 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1307 in program, code: r=r.sin()
        sin_1302: "f32[2]" = torch.ops.aten.sin.default(add_41);  add_41 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1308 in program, code: r=r.sin()
        sin_1303: "f32[2]" = torch.ops.aten.sin.default(sin_1302);  sin_1302 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1309 in program, code: r=r.sin()
        sin_1304: "f32[2]" = torch.ops.aten.sin.default(sin_1303);  sin_1303 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1310 in program, code: r=r.sin()
        sin_1305: "f32[2]" = torch.ops.aten.sin.default(sin_1304);  sin_1304 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1311 in program, code: r=r.sin()
        sin_1306: "f32[2]" = torch.ops.aten.sin.default(sin_1305);  sin_1305 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1312 in program, code: r=r.sin()
        sin_1307: "f32[2]" = torch.ops.aten.sin.default(sin_1306);  sin_1306 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1313 in program, code: r=r.sin()
        sin_1308: "f32[2]" = torch.ops.aten.sin.default(sin_1307);  sin_1307 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1314 in program, code: r=r.sin()
        sin_1309: "f32[2]" = torch.ops.aten.sin.default(sin_1308);  sin_1308 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1315 in program, code: r=r.sin()
        sin_1310: "f32[2]" = torch.ops.aten.sin.default(sin_1309);  sin_1309 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1316 in program, code: r=r.sin()
        sin_1311: "f32[2]" = torch.ops.aten.sin.default(sin_1310);  sin_1310 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1317 in program, code: r=r.sin()
        sin_1312: "f32[2]" = torch.ops.aten.sin.default(sin_1311);  sin_1311 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1318 in program, code: r=r.sin()
        sin_1313: "f32[2]" = torch.ops.aten.sin.default(sin_1312);  sin_1312 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1319 in program, code: r=r.sin()
        sin_1314: "f32[2]" = torch.ops.aten.sin.default(sin_1313);  sin_1313 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1320 in program, code: r=r.sin()
        sin_1315: "f32[2]" = torch.ops.aten.sin.default(sin_1314);  sin_1314 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1321 in program, code: r=r.sin()
        sin_1316: "f32[2]" = torch.ops.aten.sin.default(sin_1315);  sin_1315 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1322 in program, code: r=r.sin()
        sin_1317: "f32[2]" = torch.ops.aten.sin.default(sin_1316);  sin_1316 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1323 in program, code: r=r.sin()
        sin_1318: "f32[2]" = torch.ops.aten.sin.default(sin_1317);  sin_1317 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1324 in program, code: r=r.sin()
        sin_1319: "f32[2]" = torch.ops.aten.sin.default(sin_1318);  sin_1318 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1325 in program, code: r=r.sin()
        sin_1320: "f32[2]" = torch.ops.aten.sin.default(sin_1319);  sin_1319 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1326 in program, code: r=r.sin()
        sin_1321: "f32[2]" = torch.ops.aten.sin.default(sin_1320);  sin_1320 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1327 in program, code: r=r.sin()
        sin_1322: "f32[2]" = torch.ops.aten.sin.default(sin_1321);  sin_1321 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1328 in program, code: r=r.sin()
        sin_1323: "f32[2]" = torch.ops.aten.sin.default(sin_1322);  sin_1322 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1329 in program, code: r=r.sin()
        sin_1324: "f32[2]" = torch.ops.aten.sin.default(sin_1323);  sin_1323 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1330 in program, code: r=r.sin()
        sin_1325: "f32[2]" = torch.ops.aten.sin.default(sin_1324);  sin_1324 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1331 in program, code: r=r.sin()
        sin_1326: "f32[2]" = torch.ops.aten.sin.default(sin_1325);  sin_1325 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1332 in program, code: r=r.sin()
        sin_1327: "f32[2]" = torch.ops.aten.sin.default(sin_1326);  sin_1326 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1333 in program, code: r=r.sin()
        sin_1328: "f32[2]" = torch.ops.aten.sin.default(sin_1327);  sin_1327 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1334 in program, code: r=r.sin()
        sin_1329: "f32[2]" = torch.ops.aten.sin.default(sin_1328);  sin_1328 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1335 in program, code: r=r.sin()
        sin_1330: "f32[2]" = torch.ops.aten.sin.default(sin_1329);  sin_1329 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1336 in program, code: r=r.sin()
        sin_1331: "f32[2]" = torch.ops.aten.sin.default(sin_1330);  sin_1330 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1337 in program, code: r=r.sin()+r.cos()
        sin_1332: "f32[2]" = torch.ops.aten.sin.default(sin_1331)
        cos_42: "f32[2]" = torch.ops.aten.cos.default(sin_1331);  sin_1331 = None
        add_42: "f32[2]" = torch.ops.aten.add.Tensor(sin_1332, cos_42);  sin_1332 = cos_42 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1338 in program, code: r=r.sin()
        sin_1333: "f32[2]" = torch.ops.aten.sin.default(add_42);  add_42 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1339 in program, code: r=r.sin()
        sin_1334: "f32[2]" = torch.ops.aten.sin.default(sin_1333);  sin_1333 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1340 in program, code: r=r.sin()
        sin_1335: "f32[2]" = torch.ops.aten.sin.default(sin_1334);  sin_1334 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1341 in program, code: r=r.sin()
        sin_1336: "f32[2]" = torch.ops.aten.sin.default(sin_1335);  sin_1335 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1342 in program, code: r=r.sin()
        sin_1337: "f32[2]" = torch.ops.aten.sin.default(sin_1336);  sin_1336 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1343 in program, code: r=r.sin()
        sin_1338: "f32[2]" = torch.ops.aten.sin.default(sin_1337);  sin_1337 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1344 in program, code: r=r.sin()
        sin_1339: "f32[2]" = torch.ops.aten.sin.default(sin_1338);  sin_1338 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1345 in program, code: r=r.sin()
        sin_1340: "f32[2]" = torch.ops.aten.sin.default(sin_1339);  sin_1339 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1346 in program, code: r=r.sin()
        sin_1341: "f32[2]" = torch.ops.aten.sin.default(sin_1340);  sin_1340 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1347 in program, code: r=r.sin()
        sin_1342: "f32[2]" = torch.ops.aten.sin.default(sin_1341);  sin_1341 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1348 in program, code: r=r.sin()
        sin_1343: "f32[2]" = torch.ops.aten.sin.default(sin_1342);  sin_1342 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1349 in program, code: r=r.sin()
        sin_1344: "f32[2]" = torch.ops.aten.sin.default(sin_1343);  sin_1343 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1350 in program, code: r=r.sin()
        sin_1345: "f32[2]" = torch.ops.aten.sin.default(sin_1344);  sin_1344 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1351 in program, code: r=r.sin()
        sin_1346: "f32[2]" = torch.ops.aten.sin.default(sin_1345);  sin_1345 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1352 in program, code: r=r.sin()
        sin_1347: "f32[2]" = torch.ops.aten.sin.default(sin_1346);  sin_1346 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1353 in program, code: r=r.sin()
        sin_1348: "f32[2]" = torch.ops.aten.sin.default(sin_1347);  sin_1347 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1354 in program, code: r=r.sin()
        sin_1349: "f32[2]" = torch.ops.aten.sin.default(sin_1348);  sin_1348 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1355 in program, code: r=r.sin()
        sin_1350: "f32[2]" = torch.ops.aten.sin.default(sin_1349);  sin_1349 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1356 in program, code: r=r.sin()
        sin_1351: "f32[2]" = torch.ops.aten.sin.default(sin_1350);  sin_1350 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1357 in program, code: r=r.sin()
        sin_1352: "f32[2]" = torch.ops.aten.sin.default(sin_1351);  sin_1351 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1358 in program, code: r=r.sin()
        sin_1353: "f32[2]" = torch.ops.aten.sin.default(sin_1352);  sin_1352 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1359 in program, code: r=r.sin()
        sin_1354: "f32[2]" = torch.ops.aten.sin.default(sin_1353);  sin_1353 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1360 in program, code: r=r.sin()
        sin_1355: "f32[2]" = torch.ops.aten.sin.default(sin_1354);  sin_1354 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1361 in program, code: r=r.sin()
        sin_1356: "f32[2]" = torch.ops.aten.sin.default(sin_1355);  sin_1355 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1362 in program, code: r=r.sin()
        sin_1357: "f32[2]" = torch.ops.aten.sin.default(sin_1356);  sin_1356 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1363 in program, code: r=r.sin()
        sin_1358: "f32[2]" = torch.ops.aten.sin.default(sin_1357);  sin_1357 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1364 in program, code: r=r.sin()
        sin_1359: "f32[2]" = torch.ops.aten.sin.default(sin_1358);  sin_1358 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1365 in program, code: r=r.sin()
        sin_1360: "f32[2]" = torch.ops.aten.sin.default(sin_1359);  sin_1359 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1366 in program, code: r=r.sin()
        sin_1361: "f32[2]" = torch.ops.aten.sin.default(sin_1360);  sin_1360 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1367 in program, code: r=r.sin()
        sin_1362: "f32[2]" = torch.ops.aten.sin.default(sin_1361);  sin_1361 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1368 in program, code: r=r.sin()+r.cos()
        sin_1363: "f32[2]" = torch.ops.aten.sin.default(sin_1362)
        cos_43: "f32[2]" = torch.ops.aten.cos.default(sin_1362);  sin_1362 = None
        add_43: "f32[2]" = torch.ops.aten.add.Tensor(sin_1363, cos_43);  sin_1363 = cos_43 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1369 in program, code: r=r.sin()
        sin_1364: "f32[2]" = torch.ops.aten.sin.default(add_43);  add_43 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1370 in program, code: r=r.sin()
        sin_1365: "f32[2]" = torch.ops.aten.sin.default(sin_1364);  sin_1364 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1371 in program, code: r=r.sin()
        sin_1366: "f32[2]" = torch.ops.aten.sin.default(sin_1365);  sin_1365 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1372 in program, code: r=r.sin()
        sin_1367: "f32[2]" = torch.ops.aten.sin.default(sin_1366);  sin_1366 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1373 in program, code: r=r.sin()
        sin_1368: "f32[2]" = torch.ops.aten.sin.default(sin_1367);  sin_1367 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1374 in program, code: r=r.sin()
        sin_1369: "f32[2]" = torch.ops.aten.sin.default(sin_1368);  sin_1368 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1375 in program, code: r=r.sin()
        sin_1370: "f32[2]" = torch.ops.aten.sin.default(sin_1369);  sin_1369 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1376 in program, code: r=r.sin()
        sin_1371: "f32[2]" = torch.ops.aten.sin.default(sin_1370);  sin_1370 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1377 in program, code: r=r.sin()
        sin_1372: "f32[2]" = torch.ops.aten.sin.default(sin_1371);  sin_1371 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1378 in program, code: r=r.sin()
        sin_1373: "f32[2]" = torch.ops.aten.sin.default(sin_1372);  sin_1372 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1379 in program, code: r=r.sin()
        sin_1374: "f32[2]" = torch.ops.aten.sin.default(sin_1373);  sin_1373 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1380 in program, code: r=r.sin()
        sin_1375: "f32[2]" = torch.ops.aten.sin.default(sin_1374);  sin_1374 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1381 in program, code: r=r.sin()
        sin_1376: "f32[2]" = torch.ops.aten.sin.default(sin_1375);  sin_1375 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1382 in program, code: r=r.sin()
        sin_1377: "f32[2]" = torch.ops.aten.sin.default(sin_1376);  sin_1376 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1383 in program, code: r=r.sin()
        sin_1378: "f32[2]" = torch.ops.aten.sin.default(sin_1377);  sin_1377 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1384 in program, code: r=r.sin()
        sin_1379: "f32[2]" = torch.ops.aten.sin.default(sin_1378);  sin_1378 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1385 in program, code: r=r.sin()
        sin_1380: "f32[2]" = torch.ops.aten.sin.default(sin_1379);  sin_1379 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1386 in program, code: r=r.sin()
        sin_1381: "f32[2]" = torch.ops.aten.sin.default(sin_1380);  sin_1380 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1387 in program, code: r=r.sin()
        sin_1382: "f32[2]" = torch.ops.aten.sin.default(sin_1381);  sin_1381 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1388 in program, code: r=r.sin()
        sin_1383: "f32[2]" = torch.ops.aten.sin.default(sin_1382);  sin_1382 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1389 in program, code: r=r.sin()
        sin_1384: "f32[2]" = torch.ops.aten.sin.default(sin_1383);  sin_1383 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1390 in program, code: r=r.sin()
        sin_1385: "f32[2]" = torch.ops.aten.sin.default(sin_1384);  sin_1384 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1391 in program, code: r=r.sin()
        sin_1386: "f32[2]" = torch.ops.aten.sin.default(sin_1385);  sin_1385 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1392 in program, code: r=r.sin()
        sin_1387: "f32[2]" = torch.ops.aten.sin.default(sin_1386);  sin_1386 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1393 in program, code: r=r.sin()
        sin_1388: "f32[2]" = torch.ops.aten.sin.default(sin_1387);  sin_1387 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1394 in program, code: r=r.sin()
        sin_1389: "f32[2]" = torch.ops.aten.sin.default(sin_1388);  sin_1388 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1395 in program, code: r=r.sin()
        sin_1390: "f32[2]" = torch.ops.aten.sin.default(sin_1389);  sin_1389 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1396 in program, code: r=r.sin()
        sin_1391: "f32[2]" = torch.ops.aten.sin.default(sin_1390);  sin_1390 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1397 in program, code: r=r.sin()
        sin_1392: "f32[2]" = torch.ops.aten.sin.default(sin_1391);  sin_1391 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1398 in program, code: r=r.sin()
        sin_1393: "f32[2]" = torch.ops.aten.sin.default(sin_1392);  sin_1392 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1399 in program, code: r=r.sin()+r.cos()
        sin_1394: "f32[2]" = torch.ops.aten.sin.default(sin_1393)
        cos_44: "f32[2]" = torch.ops.aten.cos.default(sin_1393);  sin_1393 = None
        add_44: "f32[2]" = torch.ops.aten.add.Tensor(sin_1394, cos_44);  sin_1394 = cos_44 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1400 in program, code: r=r.sin()
        sin_1395: "f32[2]" = torch.ops.aten.sin.default(add_44);  add_44 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1401 in program, code: r=r.sin()
        sin_1396: "f32[2]" = torch.ops.aten.sin.default(sin_1395);  sin_1395 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1402 in program, code: r=r.sin()
        sin_1397: "f32[2]" = torch.ops.aten.sin.default(sin_1396);  sin_1396 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1403 in program, code: r=r.sin()
        sin_1398: "f32[2]" = torch.ops.aten.sin.default(sin_1397);  sin_1397 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1404 in program, code: r=r.sin()
        sin_1399: "f32[2]" = torch.ops.aten.sin.default(sin_1398);  sin_1398 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1405 in program, code: r=r.sin()
        sin_1400: "f32[2]" = torch.ops.aten.sin.default(sin_1399);  sin_1399 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1406 in program, code: r=r.sin()
        sin_1401: "f32[2]" = torch.ops.aten.sin.default(sin_1400);  sin_1400 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1407 in program, code: r=r.sin()
        sin_1402: "f32[2]" = torch.ops.aten.sin.default(sin_1401);  sin_1401 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1408 in program, code: r=r.sin()
        sin_1403: "f32[2]" = torch.ops.aten.sin.default(sin_1402);  sin_1402 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1409 in program, code: r=r.sin()
        sin_1404: "f32[2]" = torch.ops.aten.sin.default(sin_1403);  sin_1403 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1410 in program, code: r=r.sin()
        sin_1405: "f32[2]" = torch.ops.aten.sin.default(sin_1404);  sin_1404 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1411 in program, code: r=r.sin()
        sin_1406: "f32[2]" = torch.ops.aten.sin.default(sin_1405);  sin_1405 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1412 in program, code: r=r.sin()
        sin_1407: "f32[2]" = torch.ops.aten.sin.default(sin_1406);  sin_1406 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1413 in program, code: r=r.sin()
        sin_1408: "f32[2]" = torch.ops.aten.sin.default(sin_1407);  sin_1407 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1414 in program, code: r=r.sin()
        sin_1409: "f32[2]" = torch.ops.aten.sin.default(sin_1408);  sin_1408 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1415 in program, code: r=r.sin()
        sin_1410: "f32[2]" = torch.ops.aten.sin.default(sin_1409);  sin_1409 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1416 in program, code: r=r.sin()
        sin_1411: "f32[2]" = torch.ops.aten.sin.default(sin_1410);  sin_1410 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1417 in program, code: r=r.sin()
        sin_1412: "f32[2]" = torch.ops.aten.sin.default(sin_1411);  sin_1411 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1418 in program, code: r=r.sin()
        sin_1413: "f32[2]" = torch.ops.aten.sin.default(sin_1412);  sin_1412 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1419 in program, code: r=r.sin()
        sin_1414: "f32[2]" = torch.ops.aten.sin.default(sin_1413);  sin_1413 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1420 in program, code: r=r.sin()
        sin_1415: "f32[2]" = torch.ops.aten.sin.default(sin_1414);  sin_1414 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1421 in program, code: r=r.sin()
        sin_1416: "f32[2]" = torch.ops.aten.sin.default(sin_1415);  sin_1415 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1422 in program, code: r=r.sin()
        sin_1417: "f32[2]" = torch.ops.aten.sin.default(sin_1416);  sin_1416 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1423 in program, code: r=r.sin()
        sin_1418: "f32[2]" = torch.ops.aten.sin.default(sin_1417);  sin_1417 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1424 in program, code: r=r.sin()
        sin_1419: "f32[2]" = torch.ops.aten.sin.default(sin_1418);  sin_1418 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1425 in program, code: r=r.sin()
        sin_1420: "f32[2]" = torch.ops.aten.sin.default(sin_1419);  sin_1419 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1426 in program, code: r=r.sin()
        sin_1421: "f32[2]" = torch.ops.aten.sin.default(sin_1420);  sin_1420 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1427 in program, code: r=r.sin()
        sin_1422: "f32[2]" = torch.ops.aten.sin.default(sin_1421);  sin_1421 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1428 in program, code: r=r.sin()
        sin_1423: "f32[2]" = torch.ops.aten.sin.default(sin_1422);  sin_1422 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1429 in program, code: r=r.sin()
        sin_1424: "f32[2]" = torch.ops.aten.sin.default(sin_1423);  sin_1423 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1430 in program, code: r=r.sin()+r.cos()
        sin_1425: "f32[2]" = torch.ops.aten.sin.default(sin_1424)
        cos_45: "f32[2]" = torch.ops.aten.cos.default(sin_1424);  sin_1424 = None
        add_45: "f32[2]" = torch.ops.aten.add.Tensor(sin_1425, cos_45);  sin_1425 = cos_45 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1431 in program, code: r=r.sin()
        sin_1426: "f32[2]" = torch.ops.aten.sin.default(add_45);  add_45 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1432 in program, code: r=r.sin()
        sin_1427: "f32[2]" = torch.ops.aten.sin.default(sin_1426);  sin_1426 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1433 in program, code: r=r.sin()
        sin_1428: "f32[2]" = torch.ops.aten.sin.default(sin_1427);  sin_1427 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1434 in program, code: r=r.sin()
        sin_1429: "f32[2]" = torch.ops.aten.sin.default(sin_1428);  sin_1428 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1435 in program, code: r=r.sin()
        sin_1430: "f32[2]" = torch.ops.aten.sin.default(sin_1429);  sin_1429 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1436 in program, code: r=r.sin()
        sin_1431: "f32[2]" = torch.ops.aten.sin.default(sin_1430);  sin_1430 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1437 in program, code: r=r.sin()
        sin_1432: "f32[2]" = torch.ops.aten.sin.default(sin_1431);  sin_1431 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1438 in program, code: r=r.sin()
        sin_1433: "f32[2]" = torch.ops.aten.sin.default(sin_1432);  sin_1432 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1439 in program, code: r=r.sin()
        sin_1434: "f32[2]" = torch.ops.aten.sin.default(sin_1433);  sin_1433 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1440 in program, code: r=r.sin()
        sin_1435: "f32[2]" = torch.ops.aten.sin.default(sin_1434);  sin_1434 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1441 in program, code: r=r.sin()
        sin_1436: "f32[2]" = torch.ops.aten.sin.default(sin_1435);  sin_1435 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1442 in program, code: r=r.sin()
        sin_1437: "f32[2]" = torch.ops.aten.sin.default(sin_1436);  sin_1436 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1443 in program, code: r=r.sin()
        sin_1438: "f32[2]" = torch.ops.aten.sin.default(sin_1437);  sin_1437 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1444 in program, code: r=r.sin()
        sin_1439: "f32[2]" = torch.ops.aten.sin.default(sin_1438);  sin_1438 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1445 in program, code: r=r.sin()
        sin_1440: "f32[2]" = torch.ops.aten.sin.default(sin_1439);  sin_1439 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1446 in program, code: r=r.sin()
        sin_1441: "f32[2]" = torch.ops.aten.sin.default(sin_1440);  sin_1440 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1447 in program, code: r=r.sin()
        sin_1442: "f32[2]" = torch.ops.aten.sin.default(sin_1441);  sin_1441 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1448 in program, code: r=r.sin()
        sin_1443: "f32[2]" = torch.ops.aten.sin.default(sin_1442);  sin_1442 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1449 in program, code: r=r.sin()
        sin_1444: "f32[2]" = torch.ops.aten.sin.default(sin_1443);  sin_1443 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1450 in program, code: r=r.sin()
        sin_1445: "f32[2]" = torch.ops.aten.sin.default(sin_1444);  sin_1444 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1451 in program, code: r=r.sin()
        sin_1446: "f32[2]" = torch.ops.aten.sin.default(sin_1445);  sin_1445 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1452 in program, code: r=r.sin()
        sin_1447: "f32[2]" = torch.ops.aten.sin.default(sin_1446);  sin_1446 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1453 in program, code: r=r.sin()
        sin_1448: "f32[2]" = torch.ops.aten.sin.default(sin_1447);  sin_1447 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1454 in program, code: r=r.sin()
        sin_1449: "f32[2]" = torch.ops.aten.sin.default(sin_1448);  sin_1448 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1455 in program, code: r=r.sin()
        sin_1450: "f32[2]" = torch.ops.aten.sin.default(sin_1449);  sin_1449 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1456 in program, code: r=r.sin()
        sin_1451: "f32[2]" = torch.ops.aten.sin.default(sin_1450);  sin_1450 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1457 in program, code: r=r.sin()
        sin_1452: "f32[2]" = torch.ops.aten.sin.default(sin_1451);  sin_1451 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1458 in program, code: r=r.sin()
        sin_1453: "f32[2]" = torch.ops.aten.sin.default(sin_1452);  sin_1452 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1459 in program, code: r=r.sin()
        sin_1454: "f32[2]" = torch.ops.aten.sin.default(sin_1453);  sin_1453 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1460 in program, code: r=r.sin()
        sin_1455: "f32[2]" = torch.ops.aten.sin.default(sin_1454);  sin_1454 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1461 in program, code: r=r.sin()+r.cos()
        sin_1456: "f32[2]" = torch.ops.aten.sin.default(sin_1455)
        cos_46: "f32[2]" = torch.ops.aten.cos.default(sin_1455);  sin_1455 = None
        add_46: "f32[2]" = torch.ops.aten.add.Tensor(sin_1456, cos_46);  sin_1456 = cos_46 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1462 in program, code: r=r.sin()
        sin_1457: "f32[2]" = torch.ops.aten.sin.default(add_46);  add_46 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1463 in program, code: r=r.sin()
        sin_1458: "f32[2]" = torch.ops.aten.sin.default(sin_1457);  sin_1457 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1464 in program, code: r=r.sin()
        sin_1459: "f32[2]" = torch.ops.aten.sin.default(sin_1458);  sin_1458 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1465 in program, code: r=r.sin()
        sin_1460: "f32[2]" = torch.ops.aten.sin.default(sin_1459);  sin_1459 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1466 in program, code: r=r.sin()
        sin_1461: "f32[2]" = torch.ops.aten.sin.default(sin_1460);  sin_1460 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1467 in program, code: r=r.sin()
        sin_1462: "f32[2]" = torch.ops.aten.sin.default(sin_1461);  sin_1461 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1468 in program, code: r=r.sin()
        sin_1463: "f32[2]" = torch.ops.aten.sin.default(sin_1462);  sin_1462 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1469 in program, code: r=r.sin()
        sin_1464: "f32[2]" = torch.ops.aten.sin.default(sin_1463);  sin_1463 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1470 in program, code: r=r.sin()
        sin_1465: "f32[2]" = torch.ops.aten.sin.default(sin_1464);  sin_1464 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1471 in program, code: r=r.sin()
        sin_1466: "f32[2]" = torch.ops.aten.sin.default(sin_1465);  sin_1465 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1472 in program, code: r=r.sin()
        sin_1467: "f32[2]" = torch.ops.aten.sin.default(sin_1466);  sin_1466 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1473 in program, code: r=r.sin()
        sin_1468: "f32[2]" = torch.ops.aten.sin.default(sin_1467);  sin_1467 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1474 in program, code: r=r.sin()
        sin_1469: "f32[2]" = torch.ops.aten.sin.default(sin_1468);  sin_1468 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1475 in program, code: r=r.sin()
        sin_1470: "f32[2]" = torch.ops.aten.sin.default(sin_1469);  sin_1469 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1476 in program, code: r=r.sin()
        sin_1471: "f32[2]" = torch.ops.aten.sin.default(sin_1470);  sin_1470 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1477 in program, code: r=r.sin()
        sin_1472: "f32[2]" = torch.ops.aten.sin.default(sin_1471);  sin_1471 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1478 in program, code: r=r.sin()
        sin_1473: "f32[2]" = torch.ops.aten.sin.default(sin_1472);  sin_1472 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1479 in program, code: r=r.sin()
        sin_1474: "f32[2]" = torch.ops.aten.sin.default(sin_1473);  sin_1473 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1480 in program, code: r=r.sin()
        sin_1475: "f32[2]" = torch.ops.aten.sin.default(sin_1474);  sin_1474 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1481 in program, code: r=r.sin()
        sin_1476: "f32[2]" = torch.ops.aten.sin.default(sin_1475);  sin_1475 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1482 in program, code: r=r.sin()
        sin_1477: "f32[2]" = torch.ops.aten.sin.default(sin_1476);  sin_1476 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1483 in program, code: r=r.sin()
        sin_1478: "f32[2]" = torch.ops.aten.sin.default(sin_1477);  sin_1477 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1484 in program, code: r=r.sin()
        sin_1479: "f32[2]" = torch.ops.aten.sin.default(sin_1478);  sin_1478 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1485 in program, code: r=r.sin()
        sin_1480: "f32[2]" = torch.ops.aten.sin.default(sin_1479);  sin_1479 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1486 in program, code: r=r.sin()
        sin_1481: "f32[2]" = torch.ops.aten.sin.default(sin_1480);  sin_1480 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1487 in program, code: r=r.sin()
        sin_1482: "f32[2]" = torch.ops.aten.sin.default(sin_1481);  sin_1481 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1488 in program, code: r=r.sin()
        sin_1483: "f32[2]" = torch.ops.aten.sin.default(sin_1482);  sin_1482 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1489 in program, code: r=r.sin()
        sin_1484: "f32[2]" = torch.ops.aten.sin.default(sin_1483);  sin_1483 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1490 in program, code: r=r.sin()
        sin_1485: "f32[2]" = torch.ops.aten.sin.default(sin_1484);  sin_1484 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1491 in program, code: r=r.sin()
        sin_1486: "f32[2]" = torch.ops.aten.sin.default(sin_1485);  sin_1485 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1492 in program, code: r=r.sin()+r.cos()
        sin_1487: "f32[2]" = torch.ops.aten.sin.default(sin_1486)
        cos_47: "f32[2]" = torch.ops.aten.cos.default(sin_1486);  sin_1486 = None
        add_47: "f32[2]" = torch.ops.aten.add.Tensor(sin_1487, cos_47);  sin_1487 = cos_47 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1493 in program, code: r=r.sin()
        sin_1488: "f32[2]" = torch.ops.aten.sin.default(add_47);  add_47 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1494 in program, code: r=r.sin()
        sin_1489: "f32[2]" = torch.ops.aten.sin.default(sin_1488);  sin_1488 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1495 in program, code: r=r.sin()
        sin_1490: "f32[2]" = torch.ops.aten.sin.default(sin_1489);  sin_1489 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1496 in program, code: r=r.sin()
        sin_1491: "f32[2]" = torch.ops.aten.sin.default(sin_1490);  sin_1490 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1497 in program, code: r=r.sin()
        sin_1492: "f32[2]" = torch.ops.aten.sin.default(sin_1491);  sin_1491 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1498 in program, code: r=r.sin()
        sin_1493: "f32[2]" = torch.ops.aten.sin.default(sin_1492);  sin_1492 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1499 in program, code: r=r.sin()
        sin_1494: "f32[2]" = torch.ops.aten.sin.default(sin_1493);  sin_1493 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1500 in program, code: r=r.sin()
        sin_1495: "f32[2]" = torch.ops.aten.sin.default(sin_1494);  sin_1494 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1501 in program, code: r=r.sin()
        sin_1496: "f32[2]" = torch.ops.aten.sin.default(sin_1495);  sin_1495 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1502 in program, code: r=r.sin()
        sin_1497: "f32[2]" = torch.ops.aten.sin.default(sin_1496);  sin_1496 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1503 in program, code: r=r.sin()
        sin_1498: "f32[2]" = torch.ops.aten.sin.default(sin_1497);  sin_1497 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1504 in program, code: r=r.sin()
        sin_1499: "f32[2]" = torch.ops.aten.sin.default(sin_1498);  sin_1498 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1505 in program, code: r=r.sin()
        sin_1500: "f32[2]" = torch.ops.aten.sin.default(sin_1499);  sin_1499 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1506 in program, code: r=r.sin()
        sin_1501: "f32[2]" = torch.ops.aten.sin.default(sin_1500);  sin_1500 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1507 in program, code: r=r.sin()
        sin_1502: "f32[2]" = torch.ops.aten.sin.default(sin_1501);  sin_1501 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1508 in program, code: r=r.sin()
        sin_1503: "f32[2]" = torch.ops.aten.sin.default(sin_1502);  sin_1502 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1509 in program, code: r=r.sin()
        sin_1504: "f32[2]" = torch.ops.aten.sin.default(sin_1503);  sin_1503 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1510 in program, code: r=r.sin()
        sin_1505: "f32[2]" = torch.ops.aten.sin.default(sin_1504);  sin_1504 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1511 in program, code: r=r.sin()
        sin_1506: "f32[2]" = torch.ops.aten.sin.default(sin_1505);  sin_1505 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1512 in program, code: r=r.sin()
        sin_1507: "f32[2]" = torch.ops.aten.sin.default(sin_1506);  sin_1506 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1513 in program, code: r=r.sin()
        sin_1508: "f32[2]" = torch.ops.aten.sin.default(sin_1507);  sin_1507 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1514 in program, code: r=r.sin()
        sin_1509: "f32[2]" = torch.ops.aten.sin.default(sin_1508);  sin_1508 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1515 in program, code: r=r.sin()
        sin_1510: "f32[2]" = torch.ops.aten.sin.default(sin_1509);  sin_1509 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1516 in program, code: r=r.sin()
        sin_1511: "f32[2]" = torch.ops.aten.sin.default(sin_1510);  sin_1510 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1517 in program, code: r=r.sin()
        sin_1512: "f32[2]" = torch.ops.aten.sin.default(sin_1511);  sin_1511 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1518 in program, code: r=r.sin()
        sin_1513: "f32[2]" = torch.ops.aten.sin.default(sin_1512);  sin_1512 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1519 in program, code: r=r.sin()
        sin_1514: "f32[2]" = torch.ops.aten.sin.default(sin_1513);  sin_1513 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1520 in program, code: r=r.sin()
        sin_1515: "f32[2]" = torch.ops.aten.sin.default(sin_1514);  sin_1514 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1521 in program, code: r=r.sin()
        sin_1516: "f32[2]" = torch.ops.aten.sin.default(sin_1515);  sin_1515 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1522 in program, code: r=r.sin()
        sin_1517: "f32[2]" = torch.ops.aten.sin.default(sin_1516);  sin_1516 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1523 in program, code: r=r.sin()+r.cos()
        sin_1518: "f32[2]" = torch.ops.aten.sin.default(sin_1517)
        cos_48: "f32[2]" = torch.ops.aten.cos.default(sin_1517);  sin_1517 = None
        add_48: "f32[2]" = torch.ops.aten.add.Tensor(sin_1518, cos_48);  sin_1518 = cos_48 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1524 in program, code: r=r.sin()
        sin_1519: "f32[2]" = torch.ops.aten.sin.default(add_48);  add_48 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1525 in program, code: r=r.sin()
        sin_1520: "f32[2]" = torch.ops.aten.sin.default(sin_1519);  sin_1519 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1526 in program, code: r=r.sin()
        sin_1521: "f32[2]" = torch.ops.aten.sin.default(sin_1520);  sin_1520 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1527 in program, code: r=r.sin()
        sin_1522: "f32[2]" = torch.ops.aten.sin.default(sin_1521);  sin_1521 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1528 in program, code: r=r.sin()
        sin_1523: "f32[2]" = torch.ops.aten.sin.default(sin_1522);  sin_1522 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1529 in program, code: r=r.sin()
        sin_1524: "f32[2]" = torch.ops.aten.sin.default(sin_1523);  sin_1523 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1530 in program, code: r=r.sin()
        sin_1525: "f32[2]" = torch.ops.aten.sin.default(sin_1524);  sin_1524 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1531 in program, code: r=r.sin()
        sin_1526: "f32[2]" = torch.ops.aten.sin.default(sin_1525);  sin_1525 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1532 in program, code: r=r.sin()
        sin_1527: "f32[2]" = torch.ops.aten.sin.default(sin_1526);  sin_1526 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1533 in program, code: r=r.sin()
        sin_1528: "f32[2]" = torch.ops.aten.sin.default(sin_1527);  sin_1527 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1534 in program, code: r=r.sin()
        sin_1529: "f32[2]" = torch.ops.aten.sin.default(sin_1528);  sin_1528 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1535 in program, code: r=r.sin()
        sin_1530: "f32[2]" = torch.ops.aten.sin.default(sin_1529);  sin_1529 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1536 in program, code: r=r.sin()
        sin_1531: "f32[2]" = torch.ops.aten.sin.default(sin_1530);  sin_1530 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1537 in program, code: r=r.sin()
        sin_1532: "f32[2]" = torch.ops.aten.sin.default(sin_1531);  sin_1531 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1538 in program, code: r=r.sin()
        sin_1533: "f32[2]" = torch.ops.aten.sin.default(sin_1532);  sin_1532 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1539 in program, code: r=r.sin()
        sin_1534: "f32[2]" = torch.ops.aten.sin.default(sin_1533);  sin_1533 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1540 in program, code: r=r.sin()
        sin_1535: "f32[2]" = torch.ops.aten.sin.default(sin_1534);  sin_1534 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1541 in program, code: r=r.sin()
        sin_1536: "f32[2]" = torch.ops.aten.sin.default(sin_1535);  sin_1535 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1542 in program, code: r=r.sin()
        sin_1537: "f32[2]" = torch.ops.aten.sin.default(sin_1536);  sin_1536 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1543 in program, code: r=r.sin()
        sin_1538: "f32[2]" = torch.ops.aten.sin.default(sin_1537);  sin_1537 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1544 in program, code: r=r.sin()
        sin_1539: "f32[2]" = torch.ops.aten.sin.default(sin_1538);  sin_1538 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1545 in program, code: r=r.sin()
        sin_1540: "f32[2]" = torch.ops.aten.sin.default(sin_1539);  sin_1539 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1546 in program, code: r=r.sin()
        sin_1541: "f32[2]" = torch.ops.aten.sin.default(sin_1540);  sin_1540 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1547 in program, code: r=r.sin()
        sin_1542: "f32[2]" = torch.ops.aten.sin.default(sin_1541);  sin_1541 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1548 in program, code: r=r.sin()
        sin_1543: "f32[2]" = torch.ops.aten.sin.default(sin_1542);  sin_1542 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1549 in program, code: r=r.sin()
        sin_1544: "f32[2]" = torch.ops.aten.sin.default(sin_1543);  sin_1543 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1550 in program, code: r=r.sin()
        sin_1545: "f32[2]" = torch.ops.aten.sin.default(sin_1544);  sin_1544 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1551 in program, code: r=r.sin()
        sin_1546: "f32[2]" = torch.ops.aten.sin.default(sin_1545);  sin_1545 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1552 in program, code: r=r.sin()
        sin_1547: "f32[2]" = torch.ops.aten.sin.default(sin_1546);  sin_1546 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1553 in program, code: r=r.sin()
        sin_1548: "f32[2]" = torch.ops.aten.sin.default(sin_1547);  sin_1547 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1554 in program, code: r=r.sin()+r.cos()
        sin_1549: "f32[2]" = torch.ops.aten.sin.default(sin_1548)
        cos_49: "f32[2]" = torch.ops.aten.cos.default(sin_1548);  sin_1548 = None
        add_49: "f32[2]" = torch.ops.aten.add.Tensor(sin_1549, cos_49);  sin_1549 = cos_49 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1555 in program, code: r=r.sin()
        sin_1550: "f32[2]" = torch.ops.aten.sin.default(add_49);  add_49 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1556 in program, code: r=r.sin()
        sin_1551: "f32[2]" = torch.ops.aten.sin.default(sin_1550);  sin_1550 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1557 in program, code: r=r.sin()
        sin_1552: "f32[2]" = torch.ops.aten.sin.default(sin_1551);  sin_1551 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1558 in program, code: r=r.sin()
        sin_1553: "f32[2]" = torch.ops.aten.sin.default(sin_1552);  sin_1552 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1559 in program, code: r=r.sin()
        sin_1554: "f32[2]" = torch.ops.aten.sin.default(sin_1553);  sin_1553 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1560 in program, code: r=r.sin()
        sin_1555: "f32[2]" = torch.ops.aten.sin.default(sin_1554);  sin_1554 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1561 in program, code: r=r.sin()
        sin_1556: "f32[2]" = torch.ops.aten.sin.default(sin_1555);  sin_1555 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1562 in program, code: r=r.sin()
        sin_1557: "f32[2]" = torch.ops.aten.sin.default(sin_1556);  sin_1556 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1563 in program, code: r=r.sin()
        sin_1558: "f32[2]" = torch.ops.aten.sin.default(sin_1557);  sin_1557 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1564 in program, code: r=r.sin()
        sin_1559: "f32[2]" = torch.ops.aten.sin.default(sin_1558);  sin_1558 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1565 in program, code: r=r.sin()
        sin_1560: "f32[2]" = torch.ops.aten.sin.default(sin_1559);  sin_1559 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1566 in program, code: r=r.sin()
        sin_1561: "f32[2]" = torch.ops.aten.sin.default(sin_1560);  sin_1560 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1567 in program, code: r=r.sin()
        sin_1562: "f32[2]" = torch.ops.aten.sin.default(sin_1561);  sin_1561 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1568 in program, code: r=r.sin()
        sin_1563: "f32[2]" = torch.ops.aten.sin.default(sin_1562);  sin_1562 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1569 in program, code: r=r.sin()
        sin_1564: "f32[2]" = torch.ops.aten.sin.default(sin_1563);  sin_1563 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1570 in program, code: r=r.sin()
        sin_1565: "f32[2]" = torch.ops.aten.sin.default(sin_1564);  sin_1564 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1571 in program, code: r=r.sin()
        sin_1566: "f32[2]" = torch.ops.aten.sin.default(sin_1565);  sin_1565 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1572 in program, code: r=r.sin()
        sin_1567: "f32[2]" = torch.ops.aten.sin.default(sin_1566);  sin_1566 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1573 in program, code: r=r.sin()
        sin_1568: "f32[2]" = torch.ops.aten.sin.default(sin_1567);  sin_1567 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1574 in program, code: r=r.sin()
        sin_1569: "f32[2]" = torch.ops.aten.sin.default(sin_1568);  sin_1568 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1575 in program, code: r=r.sin()
        sin_1570: "f32[2]" = torch.ops.aten.sin.default(sin_1569);  sin_1569 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1576 in program, code: r=r.sin()
        sin_1571: "f32[2]" = torch.ops.aten.sin.default(sin_1570);  sin_1570 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1577 in program, code: r=r.sin()
        sin_1572: "f32[2]" = torch.ops.aten.sin.default(sin_1571);  sin_1571 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1578 in program, code: r=r.sin()
        sin_1573: "f32[2]" = torch.ops.aten.sin.default(sin_1572);  sin_1572 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1579 in program, code: r=r.sin()
        sin_1574: "f32[2]" = torch.ops.aten.sin.default(sin_1573);  sin_1573 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1580 in program, code: r=r.sin()
        sin_1575: "f32[2]" = torch.ops.aten.sin.default(sin_1574);  sin_1574 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1581 in program, code: r=r.sin()
        sin_1576: "f32[2]" = torch.ops.aten.sin.default(sin_1575);  sin_1575 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1582 in program, code: r=r.sin()
        sin_1577: "f32[2]" = torch.ops.aten.sin.default(sin_1576);  sin_1576 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1583 in program, code: r=r.sin()
        sin_1578: "f32[2]" = torch.ops.aten.sin.default(sin_1577);  sin_1577 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1584 in program, code: r=r.sin()
        sin_1579: "f32[2]" = torch.ops.aten.sin.default(sin_1578);  sin_1578 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1585 in program, code: r=r.sin()+r.cos()
        sin_1580: "f32[2]" = torch.ops.aten.sin.default(sin_1579)
        cos_50: "f32[2]" = torch.ops.aten.cos.default(sin_1579);  sin_1579 = None
        add_50: "f32[2]" = torch.ops.aten.add.Tensor(sin_1580, cos_50);  sin_1580 = cos_50 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1586 in program, code: r=r.sin()
        sin_1581: "f32[2]" = torch.ops.aten.sin.default(add_50);  add_50 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1587 in program, code: r=r.sin()
        sin_1582: "f32[2]" = torch.ops.aten.sin.default(sin_1581);  sin_1581 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1588 in program, code: r=r.sin()
        sin_1583: "f32[2]" = torch.ops.aten.sin.default(sin_1582);  sin_1582 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1589 in program, code: r=r.sin()
        sin_1584: "f32[2]" = torch.ops.aten.sin.default(sin_1583);  sin_1583 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1590 in program, code: r=r.sin()
        sin_1585: "f32[2]" = torch.ops.aten.sin.default(sin_1584);  sin_1584 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1591 in program, code: r=r.sin()
        sin_1586: "f32[2]" = torch.ops.aten.sin.default(sin_1585);  sin_1585 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1592 in program, code: r=r.sin()
        sin_1587: "f32[2]" = torch.ops.aten.sin.default(sin_1586);  sin_1586 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1593 in program, code: r=r.sin()
        sin_1588: "f32[2]" = torch.ops.aten.sin.default(sin_1587);  sin_1587 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1594 in program, code: r=r.sin()
        sin_1589: "f32[2]" = torch.ops.aten.sin.default(sin_1588);  sin_1588 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1595 in program, code: r=r.sin()
        sin_1590: "f32[2]" = torch.ops.aten.sin.default(sin_1589);  sin_1589 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1596 in program, code: r=r.sin()
        sin_1591: "f32[2]" = torch.ops.aten.sin.default(sin_1590);  sin_1590 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1597 in program, code: r=r.sin()
        sin_1592: "f32[2]" = torch.ops.aten.sin.default(sin_1591);  sin_1591 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1598 in program, code: r=r.sin()
        sin_1593: "f32[2]" = torch.ops.aten.sin.default(sin_1592);  sin_1592 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1599 in program, code: r=r.sin()
        sin_1594: "f32[2]" = torch.ops.aten.sin.default(sin_1593);  sin_1593 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1600 in program, code: r=r.sin()
        sin_1595: "f32[2]" = torch.ops.aten.sin.default(sin_1594);  sin_1594 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1601 in program, code: r=r.sin()
        sin_1596: "f32[2]" = torch.ops.aten.sin.default(sin_1595);  sin_1595 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1602 in program, code: r=r.sin()
        sin_1597: "f32[2]" = torch.ops.aten.sin.default(sin_1596);  sin_1596 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1603 in program, code: r=r.sin()
        sin_1598: "f32[2]" = torch.ops.aten.sin.default(sin_1597);  sin_1597 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1604 in program, code: r=r.sin()
        sin_1599: "f32[2]" = torch.ops.aten.sin.default(sin_1598);  sin_1598 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1605 in program, code: r=r.sin()
        sin_1600: "f32[2]" = torch.ops.aten.sin.default(sin_1599);  sin_1599 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1606 in program, code: r=r.sin()
        sin_1601: "f32[2]" = torch.ops.aten.sin.default(sin_1600);  sin_1600 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1607 in program, code: r=r.sin()
        sin_1602: "f32[2]" = torch.ops.aten.sin.default(sin_1601);  sin_1601 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1608 in program, code: r=r.sin()
        sin_1603: "f32[2]" = torch.ops.aten.sin.default(sin_1602);  sin_1602 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1609 in program, code: r=r.sin()
        sin_1604: "f32[2]" = torch.ops.aten.sin.default(sin_1603);  sin_1603 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1610 in program, code: r=r.sin()
        sin_1605: "f32[2]" = torch.ops.aten.sin.default(sin_1604);  sin_1604 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1611 in program, code: r=r.sin()
        sin_1606: "f32[2]" = torch.ops.aten.sin.default(sin_1605);  sin_1605 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1612 in program, code: r=r.sin()
        sin_1607: "f32[2]" = torch.ops.aten.sin.default(sin_1606);  sin_1606 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1613 in program, code: r=r.sin()
        sin_1608: "f32[2]" = torch.ops.aten.sin.default(sin_1607);  sin_1607 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1614 in program, code: r=r.sin()
        sin_1609: "f32[2]" = torch.ops.aten.sin.default(sin_1608);  sin_1608 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1615 in program, code: r=r.sin()
        sin_1610: "f32[2]" = torch.ops.aten.sin.default(sin_1609);  sin_1609 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1616 in program, code: r=r.sin()+r.cos()
        sin_1611: "f32[2]" = torch.ops.aten.sin.default(sin_1610)
        cos_51: "f32[2]" = torch.ops.aten.cos.default(sin_1610);  sin_1610 = None
        add_51: "f32[2]" = torch.ops.aten.add.Tensor(sin_1611, cos_51);  sin_1611 = cos_51 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1617 in program, code: r=r.sin()
        sin_1612: "f32[2]" = torch.ops.aten.sin.default(add_51);  add_51 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1618 in program, code: r=r.sin()
        sin_1613: "f32[2]" = torch.ops.aten.sin.default(sin_1612);  sin_1612 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1619 in program, code: r=r.sin()
        sin_1614: "f32[2]" = torch.ops.aten.sin.default(sin_1613);  sin_1613 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1620 in program, code: r=r.sin()
        sin_1615: "f32[2]" = torch.ops.aten.sin.default(sin_1614);  sin_1614 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1621 in program, code: r=r.sin()
        sin_1616: "f32[2]" = torch.ops.aten.sin.default(sin_1615);  sin_1615 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1622 in program, code: r=r.sin()
        sin_1617: "f32[2]" = torch.ops.aten.sin.default(sin_1616);  sin_1616 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1623 in program, code: r=r.sin()
        sin_1618: "f32[2]" = torch.ops.aten.sin.default(sin_1617);  sin_1617 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1624 in program, code: r=r.sin()
        sin_1619: "f32[2]" = torch.ops.aten.sin.default(sin_1618);  sin_1618 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1625 in program, code: r=r.sin()
        sin_1620: "f32[2]" = torch.ops.aten.sin.default(sin_1619);  sin_1619 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1626 in program, code: r=r.sin()
        sin_1621: "f32[2]" = torch.ops.aten.sin.default(sin_1620);  sin_1620 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1627 in program, code: r=r.sin()
        sin_1622: "f32[2]" = torch.ops.aten.sin.default(sin_1621);  sin_1621 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1628 in program, code: r=r.sin()
        sin_1623: "f32[2]" = torch.ops.aten.sin.default(sin_1622);  sin_1622 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1629 in program, code: r=r.sin()
        sin_1624: "f32[2]" = torch.ops.aten.sin.default(sin_1623);  sin_1623 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1630 in program, code: r=r.sin()
        sin_1625: "f32[2]" = torch.ops.aten.sin.default(sin_1624);  sin_1624 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1631 in program, code: r=r.sin()
        sin_1626: "f32[2]" = torch.ops.aten.sin.default(sin_1625);  sin_1625 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1632 in program, code: r=r.sin()
        sin_1627: "f32[2]" = torch.ops.aten.sin.default(sin_1626);  sin_1626 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1633 in program, code: r=r.sin()
        sin_1628: "f32[2]" = torch.ops.aten.sin.default(sin_1627);  sin_1627 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1634 in program, code: r=r.sin()
        sin_1629: "f32[2]" = torch.ops.aten.sin.default(sin_1628);  sin_1628 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1635 in program, code: r=r.sin()
        sin_1630: "f32[2]" = torch.ops.aten.sin.default(sin_1629);  sin_1629 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1636 in program, code: r=r.sin()
        sin_1631: "f32[2]" = torch.ops.aten.sin.default(sin_1630);  sin_1630 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1637 in program, code: r=r.sin()
        sin_1632: "f32[2]" = torch.ops.aten.sin.default(sin_1631);  sin_1631 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1638 in program, code: r=r.sin()
        sin_1633: "f32[2]" = torch.ops.aten.sin.default(sin_1632);  sin_1632 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1639 in program, code: r=r.sin()
        sin_1634: "f32[2]" = torch.ops.aten.sin.default(sin_1633);  sin_1633 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1640 in program, code: r=r.sin()
        sin_1635: "f32[2]" = torch.ops.aten.sin.default(sin_1634);  sin_1634 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1641 in program, code: r=r.sin()
        sin_1636: "f32[2]" = torch.ops.aten.sin.default(sin_1635);  sin_1635 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1642 in program, code: r=r.sin()
        sin_1637: "f32[2]" = torch.ops.aten.sin.default(sin_1636);  sin_1636 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1643 in program, code: r=r.sin()
        sin_1638: "f32[2]" = torch.ops.aten.sin.default(sin_1637);  sin_1637 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1644 in program, code: r=r.sin()
        sin_1639: "f32[2]" = torch.ops.aten.sin.default(sin_1638);  sin_1638 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1645 in program, code: r=r.sin()
        sin_1640: "f32[2]" = torch.ops.aten.sin.default(sin_1639);  sin_1639 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1646 in program, code: r=r.sin()
        sin_1641: "f32[2]" = torch.ops.aten.sin.default(sin_1640);  sin_1640 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1647 in program, code: r=r.sin()+r.cos()
        sin_1642: "f32[2]" = torch.ops.aten.sin.default(sin_1641)
        cos_52: "f32[2]" = torch.ops.aten.cos.default(sin_1641);  sin_1641 = None
        add_52: "f32[2]" = torch.ops.aten.add.Tensor(sin_1642, cos_52);  sin_1642 = cos_52 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1648 in program, code: r=r.sin()
        sin_1643: "f32[2]" = torch.ops.aten.sin.default(add_52);  add_52 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1649 in program, code: r=r.sin()
        sin_1644: "f32[2]" = torch.ops.aten.sin.default(sin_1643);  sin_1643 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1650 in program, code: r=r.sin()
        sin_1645: "f32[2]" = torch.ops.aten.sin.default(sin_1644);  sin_1644 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1651 in program, code: r=r.sin()
        sin_1646: "f32[2]" = torch.ops.aten.sin.default(sin_1645);  sin_1645 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1652 in program, code: r=r.sin()
        sin_1647: "f32[2]" = torch.ops.aten.sin.default(sin_1646);  sin_1646 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1653 in program, code: r=r.sin()
        sin_1648: "f32[2]" = torch.ops.aten.sin.default(sin_1647);  sin_1647 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1654 in program, code: r=r.sin()
        sin_1649: "f32[2]" = torch.ops.aten.sin.default(sin_1648);  sin_1648 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1655 in program, code: r=r.sin()
        sin_1650: "f32[2]" = torch.ops.aten.sin.default(sin_1649);  sin_1649 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1656 in program, code: r=r.sin()
        sin_1651: "f32[2]" = torch.ops.aten.sin.default(sin_1650);  sin_1650 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1657 in program, code: r=r.sin()
        sin_1652: "f32[2]" = torch.ops.aten.sin.default(sin_1651);  sin_1651 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1658 in program, code: r=r.sin()
        sin_1653: "f32[2]" = torch.ops.aten.sin.default(sin_1652);  sin_1652 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1659 in program, code: r=r.sin()
        sin_1654: "f32[2]" = torch.ops.aten.sin.default(sin_1653);  sin_1653 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1660 in program, code: r=r.sin()
        sin_1655: "f32[2]" = torch.ops.aten.sin.default(sin_1654);  sin_1654 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1661 in program, code: r=r.sin()
        sin_1656: "f32[2]" = torch.ops.aten.sin.default(sin_1655);  sin_1655 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1662 in program, code: r=r.sin()
        sin_1657: "f32[2]" = torch.ops.aten.sin.default(sin_1656);  sin_1656 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1663 in program, code: r=r.sin()
        sin_1658: "f32[2]" = torch.ops.aten.sin.default(sin_1657);  sin_1657 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1664 in program, code: r=r.sin()
        sin_1659: "f32[2]" = torch.ops.aten.sin.default(sin_1658);  sin_1658 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1665 in program, code: r=r.sin()
        sin_1660: "f32[2]" = torch.ops.aten.sin.default(sin_1659);  sin_1659 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1666 in program, code: r=r.sin()
        sin_1661: "f32[2]" = torch.ops.aten.sin.default(sin_1660);  sin_1660 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1667 in program, code: r=r.sin()
        sin_1662: "f32[2]" = torch.ops.aten.sin.default(sin_1661);  sin_1661 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1668 in program, code: r=r.sin()
        sin_1663: "f32[2]" = torch.ops.aten.sin.default(sin_1662);  sin_1662 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1669 in program, code: r=r.sin()
        sin_1664: "f32[2]" = torch.ops.aten.sin.default(sin_1663);  sin_1663 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1670 in program, code: r=r.sin()
        sin_1665: "f32[2]" = torch.ops.aten.sin.default(sin_1664);  sin_1664 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1671 in program, code: r=r.sin()
        sin_1666: "f32[2]" = torch.ops.aten.sin.default(sin_1665);  sin_1665 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1672 in program, code: r=r.sin()
        sin_1667: "f32[2]" = torch.ops.aten.sin.default(sin_1666);  sin_1666 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1673 in program, code: r=r.sin()
        sin_1668: "f32[2]" = torch.ops.aten.sin.default(sin_1667);  sin_1667 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1674 in program, code: r=r.sin()
        sin_1669: "f32[2]" = torch.ops.aten.sin.default(sin_1668);  sin_1668 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1675 in program, code: r=r.sin()
        sin_1670: "f32[2]" = torch.ops.aten.sin.default(sin_1669);  sin_1669 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1676 in program, code: r=r.sin()
        sin_1671: "f32[2]" = torch.ops.aten.sin.default(sin_1670);  sin_1670 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1677 in program, code: r=r.sin()
        sin_1672: "f32[2]" = torch.ops.aten.sin.default(sin_1671);  sin_1671 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1678 in program, code: r=r.sin()+r.cos()
        sin_1673: "f32[2]" = torch.ops.aten.sin.default(sin_1672)
        cos_53: "f32[2]" = torch.ops.aten.cos.default(sin_1672);  sin_1672 = None
        add_53: "f32[2]" = torch.ops.aten.add.Tensor(sin_1673, cos_53);  sin_1673 = cos_53 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1679 in program, code: r=r.sin()
        sin_1674: "f32[2]" = torch.ops.aten.sin.default(add_53);  add_53 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1680 in program, code: r=r.sin()
        sin_1675: "f32[2]" = torch.ops.aten.sin.default(sin_1674);  sin_1674 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1681 in program, code: r=r.sin()
        sin_1676: "f32[2]" = torch.ops.aten.sin.default(sin_1675);  sin_1675 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1682 in program, code: r=r.sin()
        sin_1677: "f32[2]" = torch.ops.aten.sin.default(sin_1676);  sin_1676 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1683 in program, code: r=r.sin()
        sin_1678: "f32[2]" = torch.ops.aten.sin.default(sin_1677);  sin_1677 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1684 in program, code: r=r.sin()
        sin_1679: "f32[2]" = torch.ops.aten.sin.default(sin_1678);  sin_1678 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1685 in program, code: r=r.sin()
        sin_1680: "f32[2]" = torch.ops.aten.sin.default(sin_1679);  sin_1679 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1686 in program, code: r=r.sin()
        sin_1681: "f32[2]" = torch.ops.aten.sin.default(sin_1680);  sin_1680 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1687 in program, code: r=r.sin()
        sin_1682: "f32[2]" = torch.ops.aten.sin.default(sin_1681);  sin_1681 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1688 in program, code: r=r.sin()
        sin_1683: "f32[2]" = torch.ops.aten.sin.default(sin_1682);  sin_1682 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1689 in program, code: r=r.sin()
        sin_1684: "f32[2]" = torch.ops.aten.sin.default(sin_1683);  sin_1683 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1690 in program, code: r=r.sin()
        sin_1685: "f32[2]" = torch.ops.aten.sin.default(sin_1684);  sin_1684 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1691 in program, code: r=r.sin()
        sin_1686: "f32[2]" = torch.ops.aten.sin.default(sin_1685);  sin_1685 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1692 in program, code: r=r.sin()
        sin_1687: "f32[2]" = torch.ops.aten.sin.default(sin_1686);  sin_1686 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1693 in program, code: r=r.sin()
        sin_1688: "f32[2]" = torch.ops.aten.sin.default(sin_1687);  sin_1687 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1694 in program, code: r=r.sin()
        sin_1689: "f32[2]" = torch.ops.aten.sin.default(sin_1688);  sin_1688 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1695 in program, code: r=r.sin()
        sin_1690: "f32[2]" = torch.ops.aten.sin.default(sin_1689);  sin_1689 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1696 in program, code: r=r.sin()
        sin_1691: "f32[2]" = torch.ops.aten.sin.default(sin_1690);  sin_1690 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1697 in program, code: r=r.sin()
        sin_1692: "f32[2]" = torch.ops.aten.sin.default(sin_1691);  sin_1691 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1698 in program, code: r=r.sin()
        sin_1693: "f32[2]" = torch.ops.aten.sin.default(sin_1692);  sin_1692 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1699 in program, code: r=r.sin()
        sin_1694: "f32[2]" = torch.ops.aten.sin.default(sin_1693);  sin_1693 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1700 in program, code: r=r.sin()
        sin_1695: "f32[2]" = torch.ops.aten.sin.default(sin_1694);  sin_1694 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1701 in program, code: r=r.sin()
        sin_1696: "f32[2]" = torch.ops.aten.sin.default(sin_1695);  sin_1695 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1702 in program, code: r=r.sin()
        sin_1697: "f32[2]" = torch.ops.aten.sin.default(sin_1696);  sin_1696 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1703 in program, code: r=r.sin()
        sin_1698: "f32[2]" = torch.ops.aten.sin.default(sin_1697);  sin_1697 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1704 in program, code: r=r.sin()
        sin_1699: "f32[2]" = torch.ops.aten.sin.default(sin_1698);  sin_1698 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1705 in program, code: r=r.sin()
        sin_1700: "f32[2]" = torch.ops.aten.sin.default(sin_1699);  sin_1699 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1706 in program, code: r=r.sin()
        sin_1701: "f32[2]" = torch.ops.aten.sin.default(sin_1700);  sin_1700 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1707 in program, code: r=r.sin()
        sin_1702: "f32[2]" = torch.ops.aten.sin.default(sin_1701);  sin_1701 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1708 in program, code: r=r.sin()
        sin_1703: "f32[2]" = torch.ops.aten.sin.default(sin_1702);  sin_1702 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1709 in program, code: r=r.sin()+r.cos()
        sin_1704: "f32[2]" = torch.ops.aten.sin.default(sin_1703)
        cos_54: "f32[2]" = torch.ops.aten.cos.default(sin_1703);  sin_1703 = None
        add_54: "f32[2]" = torch.ops.aten.add.Tensor(sin_1704, cos_54);  sin_1704 = cos_54 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1710 in program, code: r=r.sin()
        sin_1705: "f32[2]" = torch.ops.aten.sin.default(add_54);  add_54 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1711 in program, code: r=r.sin()
        sin_1706: "f32[2]" = torch.ops.aten.sin.default(sin_1705);  sin_1705 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1712 in program, code: r=r.sin()
        sin_1707: "f32[2]" = torch.ops.aten.sin.default(sin_1706);  sin_1706 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1713 in program, code: r=r.sin()
        sin_1708: "f32[2]" = torch.ops.aten.sin.default(sin_1707);  sin_1707 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1714 in program, code: r=r.sin()
        sin_1709: "f32[2]" = torch.ops.aten.sin.default(sin_1708);  sin_1708 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1715 in program, code: r=r.sin()
        sin_1710: "f32[2]" = torch.ops.aten.sin.default(sin_1709);  sin_1709 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1716 in program, code: r=r.sin()
        sin_1711: "f32[2]" = torch.ops.aten.sin.default(sin_1710);  sin_1710 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1717 in program, code: r=r.sin()
        sin_1712: "f32[2]" = torch.ops.aten.sin.default(sin_1711);  sin_1711 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1718 in program, code: r=r.sin()
        sin_1713: "f32[2]" = torch.ops.aten.sin.default(sin_1712);  sin_1712 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1719 in program, code: r=r.sin()
        sin_1714: "f32[2]" = torch.ops.aten.sin.default(sin_1713);  sin_1713 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1720 in program, code: r=r.sin()
        sin_1715: "f32[2]" = torch.ops.aten.sin.default(sin_1714);  sin_1714 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1721 in program, code: r=r.sin()
        sin_1716: "f32[2]" = torch.ops.aten.sin.default(sin_1715);  sin_1715 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1722 in program, code: r=r.sin()
        sin_1717: "f32[2]" = torch.ops.aten.sin.default(sin_1716);  sin_1716 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1723 in program, code: r=r.sin()
        sin_1718: "f32[2]" = torch.ops.aten.sin.default(sin_1717);  sin_1717 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1724 in program, code: r=r.sin()
        sin_1719: "f32[2]" = torch.ops.aten.sin.default(sin_1718);  sin_1718 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1725 in program, code: r=r.sin()
        sin_1720: "f32[2]" = torch.ops.aten.sin.default(sin_1719);  sin_1719 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1726 in program, code: r=r.sin()
        sin_1721: "f32[2]" = torch.ops.aten.sin.default(sin_1720);  sin_1720 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1727 in program, code: r=r.sin()
        sin_1722: "f32[2]" = torch.ops.aten.sin.default(sin_1721);  sin_1721 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1728 in program, code: r=r.sin()
        sin_1723: "f32[2]" = torch.ops.aten.sin.default(sin_1722);  sin_1722 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1729 in program, code: r=r.sin()
        sin_1724: "f32[2]" = torch.ops.aten.sin.default(sin_1723);  sin_1723 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1730 in program, code: r=r.sin()
        sin_1725: "f32[2]" = torch.ops.aten.sin.default(sin_1724);  sin_1724 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1731 in program, code: r=r.sin()
        sin_1726: "f32[2]" = torch.ops.aten.sin.default(sin_1725);  sin_1725 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1732 in program, code: r=r.sin()
        sin_1727: "f32[2]" = torch.ops.aten.sin.default(sin_1726);  sin_1726 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1733 in program, code: r=r.sin()
        sin_1728: "f32[2]" = torch.ops.aten.sin.default(sin_1727);  sin_1727 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1734 in program, code: r=r.sin()
        sin_1729: "f32[2]" = torch.ops.aten.sin.default(sin_1728);  sin_1728 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1735 in program, code: r=r.sin()
        sin_1730: "f32[2]" = torch.ops.aten.sin.default(sin_1729);  sin_1729 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1736 in program, code: r=r.sin()
        sin_1731: "f32[2]" = torch.ops.aten.sin.default(sin_1730);  sin_1730 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1737 in program, code: r=r.sin()
        sin_1732: "f32[2]" = torch.ops.aten.sin.default(sin_1731);  sin_1731 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1738 in program, code: r=r.sin()
        sin_1733: "f32[2]" = torch.ops.aten.sin.default(sin_1732);  sin_1732 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1739 in program, code: r=r.sin()
        sin_1734: "f32[2]" = torch.ops.aten.sin.default(sin_1733);  sin_1733 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1740 in program, code: r=r.sin()+r.cos()
        sin_1735: "f32[2]" = torch.ops.aten.sin.default(sin_1734)
        cos_55: "f32[2]" = torch.ops.aten.cos.default(sin_1734);  sin_1734 = None
        add_55: "f32[2]" = torch.ops.aten.add.Tensor(sin_1735, cos_55);  sin_1735 = cos_55 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1741 in program, code: r=r.sin()
        sin_1736: "f32[2]" = torch.ops.aten.sin.default(add_55);  add_55 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1742 in program, code: r=r.sin()
        sin_1737: "f32[2]" = torch.ops.aten.sin.default(sin_1736);  sin_1736 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1743 in program, code: r=r.sin()
        sin_1738: "f32[2]" = torch.ops.aten.sin.default(sin_1737);  sin_1737 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1744 in program, code: r=r.sin()
        sin_1739: "f32[2]" = torch.ops.aten.sin.default(sin_1738);  sin_1738 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1745 in program, code: r=r.sin()
        sin_1740: "f32[2]" = torch.ops.aten.sin.default(sin_1739);  sin_1739 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1746 in program, code: r=r.sin()
        sin_1741: "f32[2]" = torch.ops.aten.sin.default(sin_1740);  sin_1740 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1747 in program, code: r=r.sin()
        sin_1742: "f32[2]" = torch.ops.aten.sin.default(sin_1741);  sin_1741 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1748 in program, code: r=r.sin()
        sin_1743: "f32[2]" = torch.ops.aten.sin.default(sin_1742);  sin_1742 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1749 in program, code: r=r.sin()
        sin_1744: "f32[2]" = torch.ops.aten.sin.default(sin_1743);  sin_1743 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1750 in program, code: r=r.sin()
        sin_1745: "f32[2]" = torch.ops.aten.sin.default(sin_1744);  sin_1744 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1751 in program, code: r=r.sin()
        sin_1746: "f32[2]" = torch.ops.aten.sin.default(sin_1745);  sin_1745 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1752 in program, code: r=r.sin()
        sin_1747: "f32[2]" = torch.ops.aten.sin.default(sin_1746);  sin_1746 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1753 in program, code: r=r.sin()
        sin_1748: "f32[2]" = torch.ops.aten.sin.default(sin_1747);  sin_1747 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1754 in program, code: r=r.sin()
        sin_1749: "f32[2]" = torch.ops.aten.sin.default(sin_1748);  sin_1748 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1755 in program, code: r=r.sin()
        sin_1750: "f32[2]" = torch.ops.aten.sin.default(sin_1749);  sin_1749 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1756 in program, code: r=r.sin()
        sin_1751: "f32[2]" = torch.ops.aten.sin.default(sin_1750);  sin_1750 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1757 in program, code: r=r.sin()
        sin_1752: "f32[2]" = torch.ops.aten.sin.default(sin_1751);  sin_1751 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1758 in program, code: r=r.sin()
        sin_1753: "f32[2]" = torch.ops.aten.sin.default(sin_1752);  sin_1752 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1759 in program, code: r=r.sin()
        sin_1754: "f32[2]" = torch.ops.aten.sin.default(sin_1753);  sin_1753 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1760 in program, code: r=r.sin()
        sin_1755: "f32[2]" = torch.ops.aten.sin.default(sin_1754);  sin_1754 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1761 in program, code: r=r.sin()
        sin_1756: "f32[2]" = torch.ops.aten.sin.default(sin_1755);  sin_1755 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1762 in program, code: r=r.sin()
        sin_1757: "f32[2]" = torch.ops.aten.sin.default(sin_1756);  sin_1756 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1763 in program, code: r=r.sin()
        sin_1758: "f32[2]" = torch.ops.aten.sin.default(sin_1757);  sin_1757 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1764 in program, code: r=r.sin()
        sin_1759: "f32[2]" = torch.ops.aten.sin.default(sin_1758);  sin_1758 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1765 in program, code: r=r.sin()
        sin_1760: "f32[2]" = torch.ops.aten.sin.default(sin_1759);  sin_1759 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1766 in program, code: r=r.sin()
        sin_1761: "f32[2]" = torch.ops.aten.sin.default(sin_1760);  sin_1760 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1767 in program, code: r=r.sin()
        sin_1762: "f32[2]" = torch.ops.aten.sin.default(sin_1761);  sin_1761 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1768 in program, code: r=r.sin()
        sin_1763: "f32[2]" = torch.ops.aten.sin.default(sin_1762);  sin_1762 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1769 in program, code: r=r.sin()
        sin_1764: "f32[2]" = torch.ops.aten.sin.default(sin_1763);  sin_1763 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1770 in program, code: r=r.sin()
        sin_1765: "f32[2]" = torch.ops.aten.sin.default(sin_1764);  sin_1764 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1771 in program, code: r=r.sin()+r.cos()
        sin_1766: "f32[2]" = torch.ops.aten.sin.default(sin_1765)
        cos_56: "f32[2]" = torch.ops.aten.cos.default(sin_1765);  sin_1765 = None
        add_56: "f32[2]" = torch.ops.aten.add.Tensor(sin_1766, cos_56);  sin_1766 = cos_56 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1772 in program, code: r=r.sin()
        sin_1767: "f32[2]" = torch.ops.aten.sin.default(add_56);  add_56 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1773 in program, code: r=r.sin()
        sin_1768: "f32[2]" = torch.ops.aten.sin.default(sin_1767);  sin_1767 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1774 in program, code: r=r.sin()
        sin_1769: "f32[2]" = torch.ops.aten.sin.default(sin_1768);  sin_1768 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1775 in program, code: r=r.sin()
        sin_1770: "f32[2]" = torch.ops.aten.sin.default(sin_1769);  sin_1769 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1776 in program, code: r=r.sin()
        sin_1771: "f32[2]" = torch.ops.aten.sin.default(sin_1770);  sin_1770 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1777 in program, code: r=r.sin()
        sin_1772: "f32[2]" = torch.ops.aten.sin.default(sin_1771);  sin_1771 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1778 in program, code: r=r.sin()
        sin_1773: "f32[2]" = torch.ops.aten.sin.default(sin_1772);  sin_1772 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1779 in program, code: r=r.sin()
        sin_1774: "f32[2]" = torch.ops.aten.sin.default(sin_1773);  sin_1773 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1780 in program, code: r=r.sin()
        sin_1775: "f32[2]" = torch.ops.aten.sin.default(sin_1774);  sin_1774 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1781 in program, code: r=r.sin()
        sin_1776: "f32[2]" = torch.ops.aten.sin.default(sin_1775);  sin_1775 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1782 in program, code: r=r.sin()
        sin_1777: "f32[2]" = torch.ops.aten.sin.default(sin_1776);  sin_1776 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1783 in program, code: r=r.sin()
        sin_1778: "f32[2]" = torch.ops.aten.sin.default(sin_1777);  sin_1777 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1784 in program, code: r=r.sin()
        sin_1779: "f32[2]" = torch.ops.aten.sin.default(sin_1778);  sin_1778 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1785 in program, code: r=r.sin()
        sin_1780: "f32[2]" = torch.ops.aten.sin.default(sin_1779);  sin_1779 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1786 in program, code: r=r.sin()
        sin_1781: "f32[2]" = torch.ops.aten.sin.default(sin_1780);  sin_1780 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1787 in program, code: r=r.sin()
        sin_1782: "f32[2]" = torch.ops.aten.sin.default(sin_1781);  sin_1781 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1788 in program, code: r=r.sin()
        sin_1783: "f32[2]" = torch.ops.aten.sin.default(sin_1782);  sin_1782 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1789 in program, code: r=r.sin()
        sin_1784: "f32[2]" = torch.ops.aten.sin.default(sin_1783);  sin_1783 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1790 in program, code: r=r.sin()
        sin_1785: "f32[2]" = torch.ops.aten.sin.default(sin_1784);  sin_1784 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1791 in program, code: r=r.sin()
        sin_1786: "f32[2]" = torch.ops.aten.sin.default(sin_1785);  sin_1785 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1792 in program, code: r=r.sin()
        sin_1787: "f32[2]" = torch.ops.aten.sin.default(sin_1786);  sin_1786 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1793 in program, code: r=r.sin()
        sin_1788: "f32[2]" = torch.ops.aten.sin.default(sin_1787);  sin_1787 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1794 in program, code: r=r.sin()
        sin_1789: "f32[2]" = torch.ops.aten.sin.default(sin_1788);  sin_1788 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1795 in program, code: r=r.sin()
        sin_1790: "f32[2]" = torch.ops.aten.sin.default(sin_1789);  sin_1789 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1796 in program, code: r=r.sin()
        sin_1791: "f32[2]" = torch.ops.aten.sin.default(sin_1790);  sin_1790 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1797 in program, code: r=r.sin()
        sin_1792: "f32[2]" = torch.ops.aten.sin.default(sin_1791);  sin_1791 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1798 in program, code: r=r.sin()
        sin_1793: "f32[2]" = torch.ops.aten.sin.default(sin_1792);  sin_1792 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1799 in program, code: r=r.sin()
        sin_1794: "f32[2]" = torch.ops.aten.sin.default(sin_1793);  sin_1793 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1800 in program, code: r=r.sin()
        sin_1795: "f32[2]" = torch.ops.aten.sin.default(sin_1794);  sin_1794 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1801 in program, code: r=r.sin()
        sin_1796: "f32[2]" = torch.ops.aten.sin.default(sin_1795);  sin_1795 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1802 in program, code: r=r.sin()+r.cos()
        sin_1797: "f32[2]" = torch.ops.aten.sin.default(sin_1796)
        cos_57: "f32[2]" = torch.ops.aten.cos.default(sin_1796);  sin_1796 = None
        add_57: "f32[2]" = torch.ops.aten.add.Tensor(sin_1797, cos_57);  sin_1797 = cos_57 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1803 in program, code: r=r.sin()
        sin_1798: "f32[2]" = torch.ops.aten.sin.default(add_57);  add_57 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1804 in program, code: r=r.sin()
        sin_1799: "f32[2]" = torch.ops.aten.sin.default(sin_1798);  sin_1798 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1805 in program, code: r=r.sin()
        sin_1800: "f32[2]" = torch.ops.aten.sin.default(sin_1799);  sin_1799 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1806 in program, code: r=r.sin()
        sin_1801: "f32[2]" = torch.ops.aten.sin.default(sin_1800);  sin_1800 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1807 in program, code: r=r.sin()
        sin_1802: "f32[2]" = torch.ops.aten.sin.default(sin_1801);  sin_1801 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1808 in program, code: r=r.sin()
        sin_1803: "f32[2]" = torch.ops.aten.sin.default(sin_1802);  sin_1802 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1809 in program, code: r=r.sin()
        sin_1804: "f32[2]" = torch.ops.aten.sin.default(sin_1803);  sin_1803 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1810 in program, code: r=r.sin()
        sin_1805: "f32[2]" = torch.ops.aten.sin.default(sin_1804);  sin_1804 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1811 in program, code: r=r.sin()
        sin_1806: "f32[2]" = torch.ops.aten.sin.default(sin_1805);  sin_1805 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1812 in program, code: r=r.sin()
        sin_1807: "f32[2]" = torch.ops.aten.sin.default(sin_1806);  sin_1806 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1813 in program, code: r=r.sin()
        sin_1808: "f32[2]" = torch.ops.aten.sin.default(sin_1807);  sin_1807 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1814 in program, code: r=r.sin()
        sin_1809: "f32[2]" = torch.ops.aten.sin.default(sin_1808);  sin_1808 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1815 in program, code: r=r.sin()
        sin_1810: "f32[2]" = torch.ops.aten.sin.default(sin_1809);  sin_1809 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1816 in program, code: r=r.sin()
        sin_1811: "f32[2]" = torch.ops.aten.sin.default(sin_1810);  sin_1810 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1817 in program, code: r=r.sin()
        sin_1812: "f32[2]" = torch.ops.aten.sin.default(sin_1811);  sin_1811 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1818 in program, code: r=r.sin()
        sin_1813: "f32[2]" = torch.ops.aten.sin.default(sin_1812);  sin_1812 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1819 in program, code: r=r.sin()
        sin_1814: "f32[2]" = torch.ops.aten.sin.default(sin_1813);  sin_1813 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1820 in program, code: r=r.sin()
        sin_1815: "f32[2]" = torch.ops.aten.sin.default(sin_1814);  sin_1814 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1821 in program, code: r=r.sin()
        sin_1816: "f32[2]" = torch.ops.aten.sin.default(sin_1815);  sin_1815 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1822 in program, code: r=r.sin()
        sin_1817: "f32[2]" = torch.ops.aten.sin.default(sin_1816);  sin_1816 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1823 in program, code: r=r.sin()
        sin_1818: "f32[2]" = torch.ops.aten.sin.default(sin_1817);  sin_1817 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1824 in program, code: r=r.sin()
        sin_1819: "f32[2]" = torch.ops.aten.sin.default(sin_1818);  sin_1818 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1825 in program, code: r=r.sin()
        sin_1820: "f32[2]" = torch.ops.aten.sin.default(sin_1819);  sin_1819 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1826 in program, code: r=r.sin()
        sin_1821: "f32[2]" = torch.ops.aten.sin.default(sin_1820);  sin_1820 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1827 in program, code: r=r.sin()
        sin_1822: "f32[2]" = torch.ops.aten.sin.default(sin_1821);  sin_1821 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1828 in program, code: r=r.sin()
        sin_1823: "f32[2]" = torch.ops.aten.sin.default(sin_1822);  sin_1822 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1829 in program, code: r=r.sin()
        sin_1824: "f32[2]" = torch.ops.aten.sin.default(sin_1823);  sin_1823 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1830 in program, code: r=r.sin()
        sin_1825: "f32[2]" = torch.ops.aten.sin.default(sin_1824);  sin_1824 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1831 in program, code: r=r.sin()
        sin_1826: "f32[2]" = torch.ops.aten.sin.default(sin_1825);  sin_1825 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1832 in program, code: r=r.sin()
        sin_1827: "f32[2]" = torch.ops.aten.sin.default(sin_1826);  sin_1826 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1833 in program, code: r=r.sin()+r.cos()
        sin_1828: "f32[2]" = torch.ops.aten.sin.default(sin_1827)
        cos_58: "f32[2]" = torch.ops.aten.cos.default(sin_1827);  sin_1827 = None
        add_58: "f32[2]" = torch.ops.aten.add.Tensor(sin_1828, cos_58);  sin_1828 = cos_58 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1834 in program, code: r=r.sin()
        sin_1829: "f32[2]" = torch.ops.aten.sin.default(add_58);  add_58 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1835 in program, code: r=r.sin()
        sin_1830: "f32[2]" = torch.ops.aten.sin.default(sin_1829);  sin_1829 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1836 in program, code: r=r.sin()
        sin_1831: "f32[2]" = torch.ops.aten.sin.default(sin_1830);  sin_1830 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1837 in program, code: r=r.sin()
        sin_1832: "f32[2]" = torch.ops.aten.sin.default(sin_1831);  sin_1831 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1838 in program, code: r=r.sin()
        sin_1833: "f32[2]" = torch.ops.aten.sin.default(sin_1832);  sin_1832 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1839 in program, code: r=r.sin()
        sin_1834: "f32[2]" = torch.ops.aten.sin.default(sin_1833);  sin_1833 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1840 in program, code: r=r.sin()
        sin_1835: "f32[2]" = torch.ops.aten.sin.default(sin_1834);  sin_1834 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1841 in program, code: r=r.sin()
        sin_1836: "f32[2]" = torch.ops.aten.sin.default(sin_1835);  sin_1835 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1842 in program, code: r=r.sin()
        sin_1837: "f32[2]" = torch.ops.aten.sin.default(sin_1836);  sin_1836 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1843 in program, code: r=r.sin()
        sin_1838: "f32[2]" = torch.ops.aten.sin.default(sin_1837);  sin_1837 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1844 in program, code: r=r.sin()
        sin_1839: "f32[2]" = torch.ops.aten.sin.default(sin_1838);  sin_1838 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1845 in program, code: r=r.sin()
        sin_1840: "f32[2]" = torch.ops.aten.sin.default(sin_1839);  sin_1839 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1846 in program, code: r=r.sin()
        sin_1841: "f32[2]" = torch.ops.aten.sin.default(sin_1840);  sin_1840 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1847 in program, code: r=r.sin()
        sin_1842: "f32[2]" = torch.ops.aten.sin.default(sin_1841);  sin_1841 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1848 in program, code: r=r.sin()
        sin_1843: "f32[2]" = torch.ops.aten.sin.default(sin_1842);  sin_1842 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1849 in program, code: r=r.sin()
        sin_1844: "f32[2]" = torch.ops.aten.sin.default(sin_1843);  sin_1843 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1850 in program, code: r=r.sin()
        sin_1845: "f32[2]" = torch.ops.aten.sin.default(sin_1844);  sin_1844 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1851 in program, code: r=r.sin()
        sin_1846: "f32[2]" = torch.ops.aten.sin.default(sin_1845);  sin_1845 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1852 in program, code: r=r.sin()
        sin_1847: "f32[2]" = torch.ops.aten.sin.default(sin_1846);  sin_1846 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1853 in program, code: r=r.sin()
        sin_1848: "f32[2]" = torch.ops.aten.sin.default(sin_1847);  sin_1847 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1854 in program, code: r=r.sin()
        sin_1849: "f32[2]" = torch.ops.aten.sin.default(sin_1848);  sin_1848 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1855 in program, code: r=r.sin()
        sin_1850: "f32[2]" = torch.ops.aten.sin.default(sin_1849);  sin_1849 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1856 in program, code: r=r.sin()
        sin_1851: "f32[2]" = torch.ops.aten.sin.default(sin_1850);  sin_1850 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1857 in program, code: r=r.sin()
        sin_1852: "f32[2]" = torch.ops.aten.sin.default(sin_1851);  sin_1851 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1858 in program, code: r=r.sin()
        sin_1853: "f32[2]" = torch.ops.aten.sin.default(sin_1852);  sin_1852 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1859 in program, code: r=r.sin()
        sin_1854: "f32[2]" = torch.ops.aten.sin.default(sin_1853);  sin_1853 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1860 in program, code: r=r.sin()
        sin_1855: "f32[2]" = torch.ops.aten.sin.default(sin_1854);  sin_1854 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1861 in program, code: r=r.sin()
        sin_1856: "f32[2]" = torch.ops.aten.sin.default(sin_1855);  sin_1855 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1862 in program, code: r=r.sin()
        sin_1857: "f32[2]" = torch.ops.aten.sin.default(sin_1856);  sin_1856 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1863 in program, code: r=r.sin()
        sin_1858: "f32[2]" = torch.ops.aten.sin.default(sin_1857);  sin_1857 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1864 in program, code: r=r.sin()+r.cos()
        sin_1859: "f32[2]" = torch.ops.aten.sin.default(sin_1858)
        cos_59: "f32[2]" = torch.ops.aten.cos.default(sin_1858);  sin_1858 = None
        add_59: "f32[2]" = torch.ops.aten.add.Tensor(sin_1859, cos_59);  sin_1859 = cos_59 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1865 in program, code: r=r.sin()
        sin_1860: "f32[2]" = torch.ops.aten.sin.default(add_59);  add_59 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1866 in program, code: r=r.sin()
        sin_1861: "f32[2]" = torch.ops.aten.sin.default(sin_1860);  sin_1860 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1867 in program, code: r=r.sin()
        sin_1862: "f32[2]" = torch.ops.aten.sin.default(sin_1861);  sin_1861 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1868 in program, code: r=r.sin()
        sin_1863: "f32[2]" = torch.ops.aten.sin.default(sin_1862);  sin_1862 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1869 in program, code: r=r.sin()
        sin_1864: "f32[2]" = torch.ops.aten.sin.default(sin_1863);  sin_1863 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1870 in program, code: r=r.sin()
        sin_1865: "f32[2]" = torch.ops.aten.sin.default(sin_1864);  sin_1864 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1871 in program, code: r=r.sin()
        sin_1866: "f32[2]" = torch.ops.aten.sin.default(sin_1865);  sin_1865 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1872 in program, code: r=r.sin()
        sin_1867: "f32[2]" = torch.ops.aten.sin.default(sin_1866);  sin_1866 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1873 in program, code: r=r.sin()
        sin_1868: "f32[2]" = torch.ops.aten.sin.default(sin_1867);  sin_1867 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1874 in program, code: r=r.sin()
        sin_1869: "f32[2]" = torch.ops.aten.sin.default(sin_1868);  sin_1868 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1875 in program, code: r=r.sin()
        sin_1870: "f32[2]" = torch.ops.aten.sin.default(sin_1869);  sin_1869 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1876 in program, code: r=r.sin()
        sin_1871: "f32[2]" = torch.ops.aten.sin.default(sin_1870);  sin_1870 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1877 in program, code: r=r.sin()
        sin_1872: "f32[2]" = torch.ops.aten.sin.default(sin_1871);  sin_1871 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1878 in program, code: r=r.sin()
        sin_1873: "f32[2]" = torch.ops.aten.sin.default(sin_1872);  sin_1872 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1879 in program, code: r=r.sin()
        sin_1874: "f32[2]" = torch.ops.aten.sin.default(sin_1873);  sin_1873 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1880 in program, code: r=r.sin()
        sin_1875: "f32[2]" = torch.ops.aten.sin.default(sin_1874);  sin_1874 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1881 in program, code: r=r.sin()
        sin_1876: "f32[2]" = torch.ops.aten.sin.default(sin_1875);  sin_1875 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1882 in program, code: r=r.sin()
        sin_1877: "f32[2]" = torch.ops.aten.sin.default(sin_1876);  sin_1876 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1883 in program, code: r=r.sin()
        sin_1878: "f32[2]" = torch.ops.aten.sin.default(sin_1877);  sin_1877 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1884 in program, code: r=r.sin()
        sin_1879: "f32[2]" = torch.ops.aten.sin.default(sin_1878);  sin_1878 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1885 in program, code: r=r.sin()
        sin_1880: "f32[2]" = torch.ops.aten.sin.default(sin_1879);  sin_1879 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1886 in program, code: r=r.sin()
        sin_1881: "f32[2]" = torch.ops.aten.sin.default(sin_1880);  sin_1880 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1887 in program, code: r=r.sin()
        sin_1882: "f32[2]" = torch.ops.aten.sin.default(sin_1881);  sin_1881 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1888 in program, code: r=r.sin()
        sin_1883: "f32[2]" = torch.ops.aten.sin.default(sin_1882);  sin_1882 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1889 in program, code: r=r.sin()
        sin_1884: "f32[2]" = torch.ops.aten.sin.default(sin_1883);  sin_1883 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1890 in program, code: r=r.sin()
        sin_1885: "f32[2]" = torch.ops.aten.sin.default(sin_1884);  sin_1884 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1891 in program, code: r=r.sin()
        sin_1886: "f32[2]" = torch.ops.aten.sin.default(sin_1885);  sin_1885 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1892 in program, code: r=r.sin()
        sin_1887: "f32[2]" = torch.ops.aten.sin.default(sin_1886);  sin_1886 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1893 in program, code: r=r.sin()
        sin_1888: "f32[2]" = torch.ops.aten.sin.default(sin_1887);  sin_1887 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1894 in program, code: r=r.sin()
        sin_1889: "f32[2]" = torch.ops.aten.sin.default(sin_1888);  sin_1888 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1895 in program, code: r=r.sin()+r.cos()
        sin_1890: "f32[2]" = torch.ops.aten.sin.default(sin_1889)
        cos_60: "f32[2]" = torch.ops.aten.cos.default(sin_1889);  sin_1889 = None
        add_60: "f32[2]" = torch.ops.aten.add.Tensor(sin_1890, cos_60);  sin_1890 = cos_60 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1896 in program, code: r=r.sin()
        sin_1891: "f32[2]" = torch.ops.aten.sin.default(add_60);  add_60 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1897 in program, code: r=r.sin()
        sin_1892: "f32[2]" = torch.ops.aten.sin.default(sin_1891);  sin_1891 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1898 in program, code: r=r.sin()
        sin_1893: "f32[2]" = torch.ops.aten.sin.default(sin_1892);  sin_1892 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1899 in program, code: r=r.sin()
        sin_1894: "f32[2]" = torch.ops.aten.sin.default(sin_1893);  sin_1893 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1900 in program, code: r=r.sin()
        sin_1895: "f32[2]" = torch.ops.aten.sin.default(sin_1894);  sin_1894 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1901 in program, code: r=r.sin()
        sin_1896: "f32[2]" = torch.ops.aten.sin.default(sin_1895);  sin_1895 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1902 in program, code: r=r.sin()
        sin_1897: "f32[2]" = torch.ops.aten.sin.default(sin_1896);  sin_1896 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1903 in program, code: r=r.sin()
        sin_1898: "f32[2]" = torch.ops.aten.sin.default(sin_1897);  sin_1897 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1904 in program, code: r=r.sin()
        sin_1899: "f32[2]" = torch.ops.aten.sin.default(sin_1898);  sin_1898 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1905 in program, code: r=r.sin()
        sin_1900: "f32[2]" = torch.ops.aten.sin.default(sin_1899);  sin_1899 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1906 in program, code: r=r.sin()
        sin_1901: "f32[2]" = torch.ops.aten.sin.default(sin_1900);  sin_1900 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1907 in program, code: r=r.sin()
        sin_1902: "f32[2]" = torch.ops.aten.sin.default(sin_1901);  sin_1901 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1908 in program, code: r=r.sin()
        sin_1903: "f32[2]" = torch.ops.aten.sin.default(sin_1902);  sin_1902 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1909 in program, code: r=r.sin()
        sin_1904: "f32[2]" = torch.ops.aten.sin.default(sin_1903);  sin_1903 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1910 in program, code: r=r.sin()
        sin_1905: "f32[2]" = torch.ops.aten.sin.default(sin_1904);  sin_1904 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1911 in program, code: r=r.sin()
        sin_1906: "f32[2]" = torch.ops.aten.sin.default(sin_1905);  sin_1905 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1912 in program, code: r=r.sin()
        sin_1907: "f32[2]" = torch.ops.aten.sin.default(sin_1906);  sin_1906 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1913 in program, code: r=r.sin()
        sin_1908: "f32[2]" = torch.ops.aten.sin.default(sin_1907);  sin_1907 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1914 in program, code: r=r.sin()
        sin_1909: "f32[2]" = torch.ops.aten.sin.default(sin_1908);  sin_1908 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1915 in program, code: r=r.sin()
        sin_1910: "f32[2]" = torch.ops.aten.sin.default(sin_1909);  sin_1909 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1916 in program, code: r=r.sin()
        sin_1911: "f32[2]" = torch.ops.aten.sin.default(sin_1910);  sin_1910 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1917 in program, code: r=r.sin()
        sin_1912: "f32[2]" = torch.ops.aten.sin.default(sin_1911);  sin_1911 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1918 in program, code: r=r.sin()
        sin_1913: "f32[2]" = torch.ops.aten.sin.default(sin_1912);  sin_1912 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1919 in program, code: r=r.sin()
        sin_1914: "f32[2]" = torch.ops.aten.sin.default(sin_1913);  sin_1913 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1920 in program, code: r=r.sin()
        sin_1915: "f32[2]" = torch.ops.aten.sin.default(sin_1914);  sin_1914 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1921 in program, code: r=r.sin()
        sin_1916: "f32[2]" = torch.ops.aten.sin.default(sin_1915);  sin_1915 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1922 in program, code: r=r.sin()
        sin_1917: "f32[2]" = torch.ops.aten.sin.default(sin_1916);  sin_1916 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1923 in program, code: r=r.sin()
        sin_1918: "f32[2]" = torch.ops.aten.sin.default(sin_1917);  sin_1917 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1924 in program, code: r=r.sin()
        sin_1919: "f32[2]" = torch.ops.aten.sin.default(sin_1918);  sin_1918 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1925 in program, code: r=r.sin()
        sin_1920: "f32[2]" = torch.ops.aten.sin.default(sin_1919);  sin_1919 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1926 in program, code: r=r.sin()+r.cos()
        sin_1921: "f32[2]" = torch.ops.aten.sin.default(sin_1920)
        cos_61: "f32[2]" = torch.ops.aten.cos.default(sin_1920);  sin_1920 = None
        add_61: "f32[2]" = torch.ops.aten.add.Tensor(sin_1921, cos_61);  sin_1921 = cos_61 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1927 in program, code: r=r.sin()
        sin_1922: "f32[2]" = torch.ops.aten.sin.default(add_61);  add_61 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1928 in program, code: r=r.sin()
        sin_1923: "f32[2]" = torch.ops.aten.sin.default(sin_1922);  sin_1922 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1929 in program, code: r=r.sin()
        sin_1924: "f32[2]" = torch.ops.aten.sin.default(sin_1923);  sin_1923 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1930 in program, code: r=r.sin()
        sin_1925: "f32[2]" = torch.ops.aten.sin.default(sin_1924);  sin_1924 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1931 in program, code: r=r.sin()
        sin_1926: "f32[2]" = torch.ops.aten.sin.default(sin_1925);  sin_1925 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1932 in program, code: r=r.sin()
        sin_1927: "f32[2]" = torch.ops.aten.sin.default(sin_1926);  sin_1926 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1933 in program, code: r=r.sin()
        sin_1928: "f32[2]" = torch.ops.aten.sin.default(sin_1927);  sin_1927 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1934 in program, code: r=r.sin()
        sin_1929: "f32[2]" = torch.ops.aten.sin.default(sin_1928);  sin_1928 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1935 in program, code: r=r.sin()
        sin_1930: "f32[2]" = torch.ops.aten.sin.default(sin_1929);  sin_1929 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1936 in program, code: r=r.sin()
        sin_1931: "f32[2]" = torch.ops.aten.sin.default(sin_1930);  sin_1930 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1937 in program, code: r=r.sin()
        sin_1932: "f32[2]" = torch.ops.aten.sin.default(sin_1931);  sin_1931 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1938 in program, code: r=r.sin()
        sin_1933: "f32[2]" = torch.ops.aten.sin.default(sin_1932);  sin_1932 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1939 in program, code: r=r.sin()
        sin_1934: "f32[2]" = torch.ops.aten.sin.default(sin_1933);  sin_1933 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1940 in program, code: r=r.sin()
        sin_1935: "f32[2]" = torch.ops.aten.sin.default(sin_1934);  sin_1934 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1941 in program, code: r=r.sin()
        sin_1936: "f32[2]" = torch.ops.aten.sin.default(sin_1935);  sin_1935 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1942 in program, code: r=r.sin()
        sin_1937: "f32[2]" = torch.ops.aten.sin.default(sin_1936);  sin_1936 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1943 in program, code: r=r.sin()
        sin_1938: "f32[2]" = torch.ops.aten.sin.default(sin_1937);  sin_1937 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1944 in program, code: r=r.sin()
        sin_1939: "f32[2]" = torch.ops.aten.sin.default(sin_1938);  sin_1938 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1945 in program, code: r=r.sin()
        sin_1940: "f32[2]" = torch.ops.aten.sin.default(sin_1939);  sin_1939 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1946 in program, code: r=r.sin()
        sin_1941: "f32[2]" = torch.ops.aten.sin.default(sin_1940);  sin_1940 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1947 in program, code: r=r.sin()
        sin_1942: "f32[2]" = torch.ops.aten.sin.default(sin_1941);  sin_1941 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1948 in program, code: r=r.sin()
        sin_1943: "f32[2]" = torch.ops.aten.sin.default(sin_1942);  sin_1942 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1949 in program, code: r=r.sin()
        sin_1944: "f32[2]" = torch.ops.aten.sin.default(sin_1943);  sin_1943 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1950 in program, code: r=r.sin()
        sin_1945: "f32[2]" = torch.ops.aten.sin.default(sin_1944);  sin_1944 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1951 in program, code: r=r.sin()
        sin_1946: "f32[2]" = torch.ops.aten.sin.default(sin_1945);  sin_1945 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1952 in program, code: r=r.sin()
        sin_1947: "f32[2]" = torch.ops.aten.sin.default(sin_1946);  sin_1946 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1953 in program, code: r=r.sin()
        sin_1948: "f32[2]" = torch.ops.aten.sin.default(sin_1947);  sin_1947 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1954 in program, code: r=r.sin()
        sin_1949: "f32[2]" = torch.ops.aten.sin.default(sin_1948);  sin_1948 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1955 in program, code: r=r.sin()
        sin_1950: "f32[2]" = torch.ops.aten.sin.default(sin_1949);  sin_1949 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1956 in program, code: r=r.sin()
        sin_1951: "f32[2]" = torch.ops.aten.sin.default(sin_1950);  sin_1950 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1957 in program, code: r=r.sin()+r.cos()
        sin_1952: "f32[2]" = torch.ops.aten.sin.default(sin_1951)
        cos_62: "f32[2]" = torch.ops.aten.cos.default(sin_1951);  sin_1951 = None
        add_62: "f32[2]" = torch.ops.aten.add.Tensor(sin_1952, cos_62);  sin_1952 = cos_62 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1958 in program, code: r=r.sin()
        sin_1953: "f32[2]" = torch.ops.aten.sin.default(add_62);  add_62 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1959 in program, code: r=r.sin()
        sin_1954: "f32[2]" = torch.ops.aten.sin.default(sin_1953);  sin_1953 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1960 in program, code: r=r.sin()
        sin_1955: "f32[2]" = torch.ops.aten.sin.default(sin_1954);  sin_1954 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1961 in program, code: r=r.sin()
        sin_1956: "f32[2]" = torch.ops.aten.sin.default(sin_1955);  sin_1955 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1962 in program, code: r=r.sin()
        sin_1957: "f32[2]" = torch.ops.aten.sin.default(sin_1956);  sin_1956 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1963 in program, code: r=r.sin()
        sin_1958: "f32[2]" = torch.ops.aten.sin.default(sin_1957);  sin_1957 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1964 in program, code: r=r.sin()
        sin_1959: "f32[2]" = torch.ops.aten.sin.default(sin_1958);  sin_1958 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1965 in program, code: r=r.sin()
        sin_1960: "f32[2]" = torch.ops.aten.sin.default(sin_1959);  sin_1959 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1966 in program, code: r=r.sin()
        sin_1961: "f32[2]" = torch.ops.aten.sin.default(sin_1960);  sin_1960 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1967 in program, code: r=r.sin()
        sin_1962: "f32[2]" = torch.ops.aten.sin.default(sin_1961);  sin_1961 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1968 in program, code: r=r.sin()
        sin_1963: "f32[2]" = torch.ops.aten.sin.default(sin_1962);  sin_1962 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1969 in program, code: r=r.sin()
        sin_1964: "f32[2]" = torch.ops.aten.sin.default(sin_1963);  sin_1963 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1970 in program, code: r=r.sin()
        sin_1965: "f32[2]" = torch.ops.aten.sin.default(sin_1964);  sin_1964 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1971 in program, code: r=r.sin()
        sin_1966: "f32[2]" = torch.ops.aten.sin.default(sin_1965);  sin_1965 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1972 in program, code: r=r.sin()
        sin_1967: "f32[2]" = torch.ops.aten.sin.default(sin_1966);  sin_1966 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1973 in program, code: r=r.sin()
        sin_1968: "f32[2]" = torch.ops.aten.sin.default(sin_1967);  sin_1967 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1974 in program, code: r=r.sin()
        sin_1969: "f32[2]" = torch.ops.aten.sin.default(sin_1968);  sin_1968 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1975 in program, code: r=r.sin()
        sin_1970: "f32[2]" = torch.ops.aten.sin.default(sin_1969);  sin_1969 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1976 in program, code: r=r.sin()
        sin_1971: "f32[2]" = torch.ops.aten.sin.default(sin_1970);  sin_1970 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1977 in program, code: r=r.sin()
        sin_1972: "f32[2]" = torch.ops.aten.sin.default(sin_1971);  sin_1971 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1978 in program, code: r=r.sin()
        sin_1973: "f32[2]" = torch.ops.aten.sin.default(sin_1972);  sin_1972 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1979 in program, code: r=r.sin()
        sin_1974: "f32[2]" = torch.ops.aten.sin.default(sin_1973);  sin_1973 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1980 in program, code: r=r.sin()
        sin_1975: "f32[2]" = torch.ops.aten.sin.default(sin_1974);  sin_1974 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1981 in program, code: r=r.sin()
        sin_1976: "f32[2]" = torch.ops.aten.sin.default(sin_1975);  sin_1975 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1982 in program, code: r=r.sin()
        sin_1977: "f32[2]" = torch.ops.aten.sin.default(sin_1976);  sin_1976 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1983 in program, code: r=r.sin()
        sin_1978: "f32[2]" = torch.ops.aten.sin.default(sin_1977);  sin_1977 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1984 in program, code: r=r.sin()
        sin_1979: "f32[2]" = torch.ops.aten.sin.default(sin_1978);  sin_1978 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1985 in program, code: r=r.sin()
        sin_1980: "f32[2]" = torch.ops.aten.sin.default(sin_1979);  sin_1979 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1986 in program, code: r=r.sin()
        sin_1981: "f32[2]" = torch.ops.aten.sin.default(sin_1980);  sin_1980 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1987 in program, code: r=r.sin()
        sin_1982: "f32[2]" = torch.ops.aten.sin.default(sin_1981);  sin_1981 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1988 in program, code: r=r.sin()+r.cos()
        sin_1983: "f32[2]" = torch.ops.aten.sin.default(sin_1982)
        cos_63: "f32[2]" = torch.ops.aten.cos.default(sin_1982);  sin_1982 = None
        add_63: "f32[2]" = torch.ops.aten.add.Tensor(sin_1983, cos_63);  sin_1983 = cos_63 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:1989 in program, code: r=r.sin()
        sin_1984: "f32[2]" = torch.ops.aten.sin.default(add_63);  add_63 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-history-repair/order-probe/program_rq.py:3 in program, code: q=p-x
        sub: "f32[2]" = torch.ops.aten.sub.Tensor(mul, arg0_1);  mul = arg0_1 = None
        return (sin_1984, sub)
