from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-nonlinear-repair'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted([*ROOT.glob('src/**/*.rs'),*ROOT.glob('python/torch_rs/**/*.py'),*ROOT.glob('tests/test_compile_pointwise*.py'),ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'pyproject.toml'])
record={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_kind':'uncommitted nonlinear numerical repair; clean-commit refresh required after Burner commit','status_before':subprocess.check_output(['git','status','--porcelain'],text=True),'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},'commands':[]}
env=os.environ.copy()
for key in ('PYTHONPATH','CONDA_PREFIX'):env.pop(key,None)
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(ROOT/'target/tmp'),UV_CACHE_DIR=str(ROOT/'target/cache/uv'),CARGO_HOME=str(ROOT/'target/native-output-checks/cargo-home'),CARGO_TARGET_DIR=str(OUT/'cargo-build'),CARGO_BUILD_JOBS='8',PYO3_PYTHON=str(ROOT/'.venv/bin/python'),CUDA_VISIBLE_DEVICES='0',TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/inductor-final'),TRITON_CACHE_DIR=str(OUT/'cache/triton-final'),CUDA_CACHE_PATH=str(OUT/'cache/cuda-final'),XDG_CACHE_HOME=str(ROOT/'target/cache'),TORCH_RS_STRUCTURED_EVIDENCE=str(OUT/'raw-final'))
record['environment']={k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','TMPDIR','UV_CACHE_DIR','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PYO3_PYTHON','CUDA_VISIBLE_DEVICES','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','TORCH_RS_STRUCTURED_EVIDENCE')}
def run(label,argv,extra=None):
    item={'label':label,'argv':list(map(str,argv)),'environment_overrides':extra or {},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (OUT/(label+'.log')).open('xb') as f:p=subprocess.run(argv,cwd=ROOT,env=env|(extra or {}),stdout=f,stderr=subprocess.STDOUT)
    item.update(exit_code=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());record['commands'].append(item)
    (OUT/'validation-final.json').write_text(json.dumps(record,indent=2)+'\n');print(label,p.returncode,flush=True)
    if p.returncode:sys.exit(p.returncode)
wheel=next((OUT/'wheels-verified').glob('*.whl'));record['wheel']={'path':str(wheel),'sha256':sha(wheel)}
run('install-final',['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'--no-deps','--force-reinstall',str(wheel)])
run('verify-native-final',[str(ROOT/'.venv/bin/python'),'.github/scripts/verify_native_extension.py'])
gpu=['nvidia-smi','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used,memory.total','--format=csv']
run('gpu-before-final',gpu)
run('pointwise-final',[str(ROOT/'.venv/bin/python'),'-m','unittest','discover','-v','-s','tests','-p','test_compile_pointwise*.py'])
run('gpu-after-single-final',gpu)
selectors=['tests.test_compile_pointwise_broadcast.Broadcast.test_device_restoration_on_compile_run_failure_and_module_release','tests.test_compile_pointwise_helpers.HelperHardware.test_two_h100_devices_restore_context_and_share_helper_semantics','tests.test_compile_pointwise_jit.Hardware.test_two_device_restoration_and_module_ownership','tests.test_compile_pointwise_loops.LoopHardware.test_original_ir_unequal_shapes_and_device_restoration','tests.test_compile_pointwise_runtime_scalars.PositionalScalarHardware.test_positional_runtime_parameters_restore_device_on_success_and_failure','tests.test_compile_pointwise_runtime_scalars.RuntimeScalarHardware.test_runtime_parameters_restore_current_device','tests.test_compile_pointwise_structured_outputs.StructuredHardware.test_two_device_restoration_and_wrong_device_failure','tests.test_compile_pointwise_tensor_madd.TensorMadd.test_both_devices_restore_current_device_on_success_failure_and_reset']
run('two-device-final',[str(ROOT/'.venv/bin/python'),'-c',"import sys,unittest;sys.path.insert(0,'tests');unittest.main(module=None)",'-v',*selectors],{'CUDA_VISIBLE_DEVICES':'0,1'})
run('native-final',['cargo','test','--locked','--offline','--release','--lib','pointwise','--','--nocapture','--test-threads=1'],{'CUDA_VISIBLE_DEVICES':'0,1'})
run('gpu-after-two-final',gpu)
run('native-conversion-final',['cargo','test','--locked','--offline','--release','--lib','--features','python-bindings','python_conversion_failure','--','--nocapture'],{'CUDA_VISIBLE_DEVICES':'','LD_LIBRARY_PATH':str(ROOT/'target/python-3.12/lib')})
run('fmt-final',['cargo','fmt','--check'])
for size in (1,13,257):run('runtime-final-'+str(size),[str(ROOT/'.venv/bin/python'),str(OUT/'capture_runtime_final.py'),str(size)])
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
    python=ROOT/('.venv/bin/python' if version=='3.12.12' else 'target/portable-'+version+'/bin/python')
    if version!='3.12.12':run('install-final-'+version,['uv','pip','install','--python',str(python),'--no-deps','--force-reinstall',str(wheel)])
    run('identity-final-'+version,[str(python),'-c',"import sys,torch_rs,pathlib,hashlib,json;print(json.dumps({'version':sys.version,'executable':sys.executable,'package':torch_rs.__file__,'members':{str(p.relative_to(pathlib.Path(torch_rs.__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(torch_rs.__file__).parent.rglob('*') if p.is_file() and p.suffix in ('.py','.so')}},indent=2))"],{'CUDA_VISIBLE_DEVICES':''})
    run('portable-final-'+version,[str(python),'-m','unittest','discover','-v','-s','tests','-p','test_compile_pointwise*.py'],{'CUDA_VISIBLE_DEVICES':''})
assert all(sha(ROOT/p)==digest for p,digest in record['source_sha256'].items())
record['source_unchanged_after']=True
record['status_after']=subprocess.check_output(['git','status','--porcelain'],text=True)
(OUT/'validation-final.json').write_text(json.dumps(record,indent=2)+'\n')
print('FINAL VALIDATION COMPLETE',flush=True)
