from pathlib import Path
import gzip,hashlib,json,tarfile,datetime,subprocess
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-nonlinear-repair'
docs=root/'docs/diagnostics/compile-pointwise-structured-outputs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
validation=json.loads((out/'validation-final.json').read_text())
assert validation['source_unchanged_after']
assert all(c['exit_code']==0 for c in validation['commands'])
assert all(sha(root/p)==h for p,h in validation['source_sha256'].items())
with tarfile.open(out/'reference-cache.tar.gz','w:gz') as archive:
 archive.add(out/'cache',arcname='cache')
items=sorted(p for p in out.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py','.cu','.ptx','.md','.diff'))
items.extend(sorted(p for p in out.iterdir() if p.is_dir() and (p.name.startswith('raw-') or p.name=='contracts')))
raw=docs/'review-nonlinear-regions-raw.tar.gz'
with tarfile.open(raw,'w:gz') as archive:
 for p in items:archive.add(p,arcname=p.name)
measurements={p.name:json.loads(p.read_text()) for p in sorted(out.glob('*-command.json'))}
measurements.update({p.name:json.loads(p.read_text()) for p in [out/'validation-final.json',out/'source-verified.json',*sorted(out.glob('runtime-final-*.json'))]})
with gzip.open(docs/'review-nonlinear-regions-measurements.json.gz','wt') as f:json.dump(measurements,f,indent=2)
retained=[out/'source-verified.tar.gz',out/'reference-cache.tar.gz',out/'structured-review-head.cnfJyh-retained.tar.gz',*sorted(out.glob('wheels-*/*.whl')),raw,docs/'review-nonlinear-regions-measurements.json.gz']
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_kind':'uncommitted nonlinear repair; not clean-commit qualification','canonical_report_root':str(out),'external_archival':'No external writes or cleanup. Burner report-root observer owns archival.','artifacts':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in retained]}
(docs/'review-nonlinear-regions-retention.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'artifacts':len(retained),'raw_bytes':raw.stat().st_size},indent=2))
