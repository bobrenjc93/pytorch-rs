from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-nonlinear-repair'
label,*argv=sys.argv[1:]
env=os.environ.copy()
for k in ('PYTHONPATH','CONDA_PREFIX'):env.pop(k,None)
env.update(PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES=os.environ.get('CUDA_VISIBLE_DEVICES','0'),TMPDIR=str(ROOT/'target/tmp'),TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/inductor'),TRITON_CACHE_DIR=str(OUT/'cache/triton'),CUDA_CACHE_PATH=str(OUT/'cache/cuda'),XDG_CACHE_HOME=str(OUT/'cache/xdg'),TORCH_RS_STRUCTURED_EVIDENCE=str(OUT/('raw-'+label)),CARGO_HOME=str(ROOT/'target/native-output-checks/cargo-home'),CARGO_TARGET_DIR=str(OUT/'cargo-build'),CARGO_BUILD_JOBS='8',PYO3_PYTHON=str(ROOT/'.venv/bin/python'),UV_CACHE_DIR=str(ROOT/'target/cache/uv'))
paths=sorted([*ROOT.glob('src/**/*.rs'),*ROOT.glob('python/torch_rs/**/*.py'),*ROOT.glob('tests/test_compile_pointwise*.py'),ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'pyproject.toml'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],text=True),'argv':argv,'environment':{k:env[k] for k in ('CUDA_VISIBLE_DEVICES','TMPDIR','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','TORCH_RS_STRUCTURED_EVIDENCE','PYTHONDONTWRITEBYTECODE','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PYO3_PYTHON','UV_CACHE_DIR')},'start':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths}}
with (OUT/(label+'.log')).open('xb') as log:p=subprocess.run(argv,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=p.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_unchanged=all(sha(ROOT/p)==h for p,h in record['source_sha256'].items()))
(OUT/(label+'-command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(label,p.returncode);sys.exit(p.returncode)
