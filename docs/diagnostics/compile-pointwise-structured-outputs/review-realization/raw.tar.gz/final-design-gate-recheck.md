# Independent final design gate: shared-identity recheck

**Judgment: Pass with nonarchitectural suggestions.** The shared canonical Plan resolves the architectural blocker identified in `final-design-gate.md`. No further architecture change is required by this review. This is a source-level design judgment, not successful test execution or release qualification.

The original review is preserved byte-for-byte. Its SHA-256 at this recheck is `994d988ddf211d78bf0d8cf72eb1b9974f258ce5949772d77505f672ef6bc2d5`.

## Rechecked ownership and behavior

`pointwise_regions::Plan` now owns both `Canonical { mapped, nodes }` and the logical regions. `canonical_nodes` is evaluated before realization and scheduling. `Program::build` retains this same object and passes it through `append_region` into every `lowering::region`; the planner's identity map is no longer discarded.

Region lowering now starts from the canonical nodes, replaces imported representatives using `canonical.mapped[id]`, and uses that same map as its alias interpretation for consumer analysis, normalization, and materialization ranks. It does not rerun early alias discovery after import substitution. Tensor-zero markers are recognized from the canonical representation, and imported zero values lose that marker when replaced with an opaque input. This also preserves the intended boundary for constant-valued tensor producers.

For the original witness, duplicate node 3 has canonical identity 2. Once node 2 is imported, node 3 maps to its lowered import instead of independently rebuilding `Mul(0,1)`. Node 4 consequently lowers to `Sub(Import(2), Input(0))`. The finite cancellation example can no longer bypass the rounding boundary through this alias.

The new portable `canonical_duplicate_uses_the_same_rounded_import` regression explicitly checks duplicate products and duplicate consumers, requires the subtraction's operand to be `Operation::Import(2)`, and rejects FMA. The existing constant-import regression remains relevant. The new hardware test `test_canonical_product_alias_preserves_realized_import` extends the large realization/order case with `q=x*y-x`, preserving a distinct original product expression while sharing the canonical product. It compares both output orders against ordinary reference compilation and checks reuse of one native executable, retained prior outputs, finite cancellation, overflow, and underflow cases. I inspected these tests but did not run them.

Canonical numerical identity remains separate from allocation identity. Region roots retain original output IDs; `append_region` still exports/stores each original root into its canonical Graph output slot even when several roots share a lowered scalar register. This repair does not put Python topology into the Graph cache key, introduce a second executable path, or change the one-kernel launch ABI.

## Resulting architecture and alternative

The recommended architecture remains one immutable Python ResultSpec, one native canonical graph interpretation, native realization/scheduling, the existing region-local numerical lowering expressed as typed scalar operations, and one invocation-owned instruction stream executed by the graph-keyed kernel. The added Canonical/Plan boundary earns its cost by eliminating two incompatible interpretations of SSA identity. It implements the single-source-of-truth repair recommended in the first review.

The strongest simpler alternative remains a directly generated SSA kernel controlled by runtime flags. For these constraints, flags alone cannot represent changing operands, region-local CSE/normalization, and recomputation in multiple regions. Supporting those cases becomes an instruction representation or substantial source duplication. There is no demonstrated simpler alternative that also preserves up to 64 outputs and their observable permutations, existing numerics, one physical kernel, and the fixed executable-cache identity. The present VM direction is acceptable; a separate static fast path or topology-specific module cache is not needed to close this issue.

## Nonarchitectural suggestions and qualification boundary

- Keep precise upstream source/version pointers for the reference scheduling thresholds and tie-breaking rules. These remain a version-sensitive compatibility obligation.
- Measure per-call planning, instruction upload, and global scratch costs separately. The always-built diagnostic listing is a candidate for a small follow-up optimization. The 64 MiB scratch cap does not include host listings or the device instruction buffer.
- Complete the pending portable and real-GPU validation, including the newly added duplicate-product case, before claiming the implementation fixes the public counterexamples. Preserve the original strict numerical assertions and original review artifact. Formatting or test execution still in progress does not alter this architecture judgment.

No builds, tests, GPU calls, implementation edits, or external writes were performed during this recheck. This separate document is the only new artifact written.

## Source snapshot

The following hashes identify the source content inspected at document creation; a concurrently completed formatter may change hashes without changing the reviewed architecture:

- `src/pointwise_regions.rs`: `3a3818b2d1785015a6d40528aa4e9a07f8db2ec25fc1e65d2d6c9113a42220b1`
- `src/pointwise_lowering.rs`: `a4b2df8dca28a0441e7b5460907f62a26a8ed850e4309445e2c3a0b725d5c77b`
- `src/pointwise_program.rs`: `e07896d10eb3009a956c0df5b106715a5f36311e104065cb99a4eff797ceed79`
- `tests/test_compile_pointwise_structured_outputs.py`: `ad97a5e54a75e3a7a09842e375b04ef3807fab5441aaf5771791b9653d600afb`
