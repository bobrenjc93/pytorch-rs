"""Package byte-exact development evidence; never relabel a run's provenance."""
from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-realization-repair'
doc=root/'docs/diagnostics/compile-pointwise-structured-outputs/review-realization'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_gzip(p,data):
 with p.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as stream:stream.write(data)
records=[json.loads(p.read_text()) for p in sorted(out.glob('*.command.json'))]
final_labels=['native-4','clippy-5','fmt-final','wheel-build-4','pointwise-4','two-device-4','conversion-4','runtime-4','verify-extension-4','interpreter-identities']+['portable-4-'+v for v in ('312','3.10.19','3.11.15','3.13.13','3.14.5')]
by_label={record['label']:record for record in records}
for label in final_labels:
 assert by_label[label]['exit_code']==0 and by_label[label]['source_unchanged'],label
source=json.loads((out/'final-source-sha256.json').read_text())
for path,digest in source.items():assert sha(root/path)==digest,path
for path,digest in by_label['wheel-build-4']['source_before'].items():assert source[str(Path(path).relative_to(root))]==digest,path
write_gzip(doc/'measurements.json.gz',(json.dumps(records,indent=2)+'\n').encode())
# Build/cache/wheel identities stay in the canonical report root; compact raw
# logs, numerical results, native source/PTX/plans are checked in as well.
selected=[p for p in out.rglob('*') if p.is_file() and
 (len(p.relative_to(out).parts)==1 or p.relative_to(out).parts[0] in ('raw','constant-facts'))
 and p.name not in ('source-snapshot.tar.gz','retention-manifest.json.gz','reviewer-original.tar.gz') and not p.name.startswith('package-evidence')]
manifest={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(selected)}
with tarfile.open(doc/'raw.tar.gz','x:gz') as archive:
 seen={}
 for p in sorted(selected):
  name=str(p.relative_to(out));digest=manifest[name]['sha256']
  if digest in seen:
   info=archive.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;archive.addfile(info)
  else:
   archive.add(p,arcname=name,recursive=False);seen[digest]=name
# Verify every packaged byte by reading it from the gzip/tar again.
with tarfile.open(doc/'raw.tar.gz','r:gz') as archive:
 for member in archive:
  assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==manifest[member.name]['sha256'],member.name
write_gzip(doc/'raw-manifest.json.gz',(json.dumps(manifest,indent=2)+'\n').encode())
all_files=[p for p in out.rglob('*') if p.is_file() and p.relative_to(out).parts[0]!='cargo-build' and p.name!='retention-manifest.json.gz' and not p.name.startswith('package-evidence')]
retained={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(all_files)}
write_gzip(out/'retention-manifest.json.gz',(json.dumps(retained,indent=2)+'\n').encode())
old=json.loads((out/'historical-artifacts-sha256.json').read_text())
for name,digest in old.items():assert sha(Path(name))==digest,name
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_state':'uncommitted development repair; not clean qualification','root':str(root),'report_root':str(out),'final_checks':final_labels,'final_wheel_source_matches_snapshot':True,'historical_files_unchanged':len(old),'raw_files_verified':len(manifest),'retained_files':len(retained),'artifacts':{str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(doc.glob('*.gz'))},'retention_manifest_sha256':sha(out/'retention-manifest.json.gz')}
(doc/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
