# Independent final design gate

**Judgment: Needs redesign.** The execution strategy is coherent under the verified constraints, but the boundary between canonical scheduling and original-SSA lowering loses the identity information required to enforce realization. One shared canonical identity representation must survive that boundary before this design can pass.

This is an independent, read-only architecture review of the current uncommitted implementation, including `src/pointwise_program.rs`. I read repository `AGENTS.md`, the approved structured-output design at `/tmp/burner-approved-default-compile.UA2M6I/structured-outputs-design-final.md`, the changed production paths, and the associated test changes. I applied the Moduler design skill. I did not edit implementation, run builds/tests/GPU work, or inspect execution evidence as proof of correctness. This document is the only artifact written.

## Outcome and constraints

The requested behavior includes the finite cancellation repair for the seven-sine sibling graph and different numerical planning for the 2117-node graph when observable output order changes. Both must hold throughout the existing admitted domain: 4096 original nodes, 64 computed roots, strict existing numerics, one physical native kernel/launch, and one Graph/device/indexing executable-cache entry independent of result topology. Python owns immutable result reconstruction; the original Python body, eager execution, and PyTorch forwarding remain excluded. Admission, ownership, and publication contracts remain in force.

The old assumption that canonical root order alone determines numerics is contradicted by the supplied QR/RQ reference result. A repair must carry observable order as numerical data without changing canonical allocation slots or executable identity.

## Blocking finding: two incompatible identities at the realization boundary

`src/pointwise_regions.rs:50` builds `mapped` by early aliases and expression CSE. The scheduler then uses those canonical representatives: output roots are mapped at lines 570–572, and region imports name realized representative roots at lines 590–594. The returned `Region` contains only original root/import IDs. The canonical map is discarded at the end of planning.

`src/pointwise_program.rs:312` passes the original Graph and those import IDs into `lowering::region`. At `src/pointwise_lowering.rs:801–806`, region lowering clones the original Graph and replaces only each exact imported node with an opaque Input. It then independently normalizes that modified graph. An original SSA alias of an imported representative still contains its original arithmetic. The replacement has destroyed the equivalence that would otherwise let the local CSE map it to the imported value.

A minimal interface witness is:

```text
0 = Input(0)
1 = Input(1)
2 = Mul(0, 1)
3 = Mul(0, 1)       # scheduler maps 3 to canonical representative 2
4 = Sub(3, 0)

consumer region: roots=[4], imports=[2]
```

The scheduler's identity says node 4 reads imported node 2. Current region lowering instead changes node 2 to an Input, leaves node 3 as Mul, and contracts node 4 into an FMA. With float32 x=1e10 and y=1.0000001192092896, reading the realized product requires subtraction yielding 1024; recomputing and contracting yields 1192.0928955078125. `Program::validate` cannot detect this: both instruction streams have valid register dataflow and output coverage.

This is a source-derived witness to the planner/lowering interface defect, **not a claim that this five-node graph alone causes the public scheduler to create those two regions**, and not a newly executed end-to-end GPU counterexample. Large admitted graphs already create inter-region imports; duplicate SSA expressions are admitted and explicitly supported. The interface currently lacks a way to enforce its rounding contract for those aliases. The existing duplicate-computation test only checks roots in a region without imports (`pointwise_regions.rs`, `identical_computations_keep_original_output_roots`), while the opaque-product test uses the exact imported ID. Neither covers the conjunction.

The necessary repair is one canonicalization owner and one persistent map from original SSA IDs to canonical values. Scheduling and region lowering must consume that same identity representation. Every use whose canonical identity is imported must resolve to the opaque import before normalization; original output identities must remain a separate mapping to distinct allocation slots. Carrying the map is a small enabling refactor, but changes the architecture's data contract, so this is not a nonarchitectural suggestion. Do not add a second best-effort alias detector after imports have changed the graph.

## Architecture assessment and strongest simpler alternative

The current broader direction is justified:

- `ResultSpec.output_order` records first observable occurrences while `Graph.outputs` remains canonical. The Python cache still keys native executors by Graph/device/indexing and passes order only to `run`. This assigns Python topology to the frontend and numerical consequences to native planning.
- Logical realization regions are not physical launches. `Operation` replaces string expressions as the existing lowering's output; its disassembly and binary encoding are views of that representation. The kernel executes one bounded instruction stream. The old source-emission path and size-based joint-lowering fallback are replaced rather than retained as parallel numerical engines.
- Opaque imports/exports are the correct abstraction for float32 values crossing regions. Existing contraction and normalization remain the numerical owner. The identity gap above prevents that abstraction from being sound today.
- Register scratch has a fixed 64 MiB cap through worker count and grid-stride execution. Plan and scratch owners are invocation-local. The storage layer retains them across upload and kernel completion, keeps output owners unpublished, and preserves allocation/launch failure handling. Actual indexing still comes from current input shapes, separately from the historical numerical hint.

The strongest simpler candidate is a directly generated SSA kernel with a runtime descriptor selecting region boundaries and contractions. That retains native register arithmetic and avoids per-instruction global scratch traffic. However, a fixed kernel would have to support different remapped operands, local normalization/CSE results, FMA choices, and recomputation across region partitions. Encoding those choices per operation becomes a data-driven scalar interpreter in another form; pre-emitting complete alternatives risks combinatorial source growth with 64 observable roots. Merely masking FMA at original nodes is insufficient when the same producer is recomputed in separate regions. A static source expansion with nested runtime region loops also retains the scheduler and can duplicate lowering/code heavily. I do not find that alternative clearly simpler while preserving all stated constraints.

No change, always-joint lowering, unconditional eager rounding, or independent per-output execution cannot satisfy the supplied counterexamples. Adding output order to the executable key violates the verified cache constraint. Forwarding to the reference compiler violates native ownership. The VM is therefore an acceptable implementation direction, once it receives a sound shared canonical plan. I do not recommend another backend, a small-graph fast path, or a topology-specific module cache.

## Remaining nonblocking costs and validation

1. The scheduler intentionally reproduces version-sensitive reference behavior: locality traversal, operation/read thresholds, stable pair scoring, fusion limits, and peak-memory heuristics. User-requested numerical compatibility makes this necessary domain logic, but exact upstream source/version pointers should accompany these rules. The source comments name upstream concepts without enough provenance to audit changes over time.
2. `Tensor::pointwise_jit` rebuilds the plan on every call, and `Program::build` always builds the textual listing. Each nonempty call uploads instructions, synchronizes, and uses global register scratch. These are material costs, not a demonstrated speed improvement. The documentation acknowledges dispatch/scratch overhead. Avoid optimizing by adding a second numerical implementation; first measure CPU planning and GPU execution separately. Making listing generation diagnostic-only is a smaller follow-up than changing execution architecture.
3. Structural bounds are explicit, but the instruction bound is quadratic in original node count. Scratch alone does not bound total host plan/listing and device instruction memory to 64 MiB. Preserve clear reporting of all those resources when evaluating the maximum admitted graph.

Before a passing gate, add a portable regression proving that a distinct original CSE alias resolves to the same imported value, including output aliases that still require separate allocations. Add an end-to-end admitted graph with a genuine cross-region import and such an alias, checking the strict ordinary-reference numerical result and both return orders on real GPU hardware. Retain the two user counterexamples, maximum-domain tests, current-shape versus historical-hint tests, malformed descriptor tests, and ownership/publication failure tests. The existing new tests target those areas well, but their presence does not resolve the missing canonical identity contract or constitute execution evidence for this review.
