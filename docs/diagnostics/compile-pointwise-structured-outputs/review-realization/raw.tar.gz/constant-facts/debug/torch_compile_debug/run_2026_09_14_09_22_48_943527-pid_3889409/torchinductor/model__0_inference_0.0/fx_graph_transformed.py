class <lambda>(torch.nn.Module):
    def forward(self, arg0_1: "f32[2]", arg1_1: "f32[2]"):
        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py:23 in program, code: p=x*y
        mul_1: "f32[2]" = torch.ops.aten.mul.Tensor(arg0_1, arg1_1);  arg1_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py:24 in program, code: q=p-x
        sub: "f32[2]" = torch.ops.aten.sub.Tensor(mul_1, arg0_1);  arg0_1 = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py:21 in program, code: z=x*0
        full_default: "f32[2]" = torch.ops.aten.full.default([2], 0.0, dtype = torch.float32, layout = torch.strided, device = device(type='cuda', index=0), pin_memory = False)

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py:22 in program, code: one=z+1
        add: "f32[2]" = torch.ops.aten.add.Tensor(full_default, 1);  full_default = None

        # File: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_124bb831/target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py:25 in program, code: r=(p*one).sin()
        mul_2: "f32[2]" = torch.ops.aten.mul.Tensor(mul_1, add);  mul_1 = add = None
        sin: "f32[2]" = torch.ops.aten.sin.default(mul_2);  mul_2 = None
        return (sub, sin)
