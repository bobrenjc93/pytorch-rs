import os, pathlib, json, subprocess, sys, hashlib, time
root=pathlib.Path(__file__).resolve().parent
for part in ('tmp','inductor','triton','cuda','xdg','debug'):
    (root/part).mkdir(exist_ok=True)
for key,val in {'CUDA_VISIBLE_DEVICES':'0','TMPDIR':str(root/'tmp'),'TORCHINDUCTOR_CACHE_DIR':str(root/'inductor'),'TRITON_CACHE_DIR':str(root/'triton'),'CUDA_CACHE_PATH':str(root/'cuda'),'XDG_CACHE_HOME':str(root/'xdg'),'TORCH_COMPILE_DEBUG_DIR':str(root/'debug'),'TORCH_COMPILE_DEBUG':'1','TORCH_LOGS':'output_code','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}.items():os.environ[key]=val
import torch
from torch._inductor import decomposition
from torch._inductor.ops_handler import OpCounterCSE, MockHandler
torch.set_num_threads(1)
def run(args):return subprocess.check_output(args,text=True)
record={'time':time.time(),'command':sys.argv,'cwd':str(pathlib.Path.cwd()),'python':sys.executable,'torch':torch.__version__,'torch_file':torch.__file__,'cuda':torch.version.cuda,'git_head':run(['git','rev-parse','HEAD']).strip(),'git_status':run(['git','status','--porcelain']),'gpu':run(['nvidia-smi','--query-gpu=index,uuid,name,driver_version','--format=csv']),'env':{k:v for k,v in os.environ.items() if k in ('CUDA_VISIBLE_DEVICES','TMPDIR','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','TORCH_COMPILE_DEBUG_DIR')}}
for name in ('joint_graph.py',):
    path=pathlib.Path(torch.__file__).parent/'_inductor/fx_passes'/name
    record[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
record['decompositions']={str(op):str(decomposition.decompositions.get(op)) for op in (torch.ops.aten.relu.default,torch.ops.aten.mul.Tensor,torch.ops.aten.mul.Scalar)}
counter=OpCounterCSE(MockHandler());x=counter.load('x',0);counter.relu(x)
record['load_plus_relu_ops']=counter.getvalue().num_ops
record['literal_ids']={repr(v):counter.constant(v,torch.float32) for v in (1,1.,True,0,0.,False)}
(root/'provenance.json').write_text(json.dumps(record,indent=2))
def program(x,y):
    z=x*0
    one=z+1
    p=x*y
    q=p-x
    r=(p*one).sin()
    return q,r
compiled=torch.compile(program)
x=torch.full((2,),1e10,dtype=torch.float32,device='cuda')
y=torch.full((2,),1.0000001192092896,dtype=torch.float32,device='cuda')
outputs=compiled(x,y);torch.cuda.synchronize()
result={'inputs':[x.cpu().tolist(),y.cpu().tolist()],'outputs':[o.cpu().tolist() for o in outputs],'bits':[o.view(torch.int32).cpu().tolist() for o in outputs]}
(root/'results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
