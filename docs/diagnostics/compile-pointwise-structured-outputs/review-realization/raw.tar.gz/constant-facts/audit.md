# Realization constant-count audit (reference facts only)

Reference: installed PyTorch 2.13.0+cu130. The exact import path, reference
`joint_graph.py` hash, command, dirty candidate source identity, timestamp,
GPU inventory, and cache paths are in `provenance.json`. This is a reference-only
fact probe, not a candidate correctness or performance measurement.

## Initial hypothesis — rejected

Initial source inspection suggested that `UniformValueConstantFolder` would
propagate the peephole replacement `z=x*0` through `one=z+1`, then remove
`p*one` as multiplication by a tensor of ones. If true, this would make the
planner's raw operation count wrong. This hypothesis was reported before the
actual execution order of the pass had been verified. It is not a substantiated
implementation gap and did not result in a constant-analysis code change.

The correction is in `torch/_inductor/constant_folding.py::ConstantFolder.run_node`
(line 194): unknown inputs return `unknown_value` before `_deduce_value`.
`torch/_inductor/fx_passes/joint_graph.py::UniformValueConstantFolder._add_peephole_patterns`
(line 305) records a replacement for integer-zero multiplication but does not
seed the interpreter environment with its value. Consequently `z`, `one`, and
`p*one` remain unknown during that single pass. The replacement is installed
only after the pass completes in `constant_fold_uniform_value` (line 457).

## Verification

Command (all outputs/caches stay in this report directory):

```
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.py > target/default-compile-eval/structured-outputs-realization-repair/constant-facts/probe.log 2>&1
```

The script uses ordinary `torch.compile(program)` without overrides on physical
GPU 0. It evaluates `z=x*0; one=z+1; p=x*y; q=p-x; r=(p*one).sin(); return(q,r)`
with shape `(2,)`, `x=1e10`, and `y=1.0000001192092896`.

The retained `debug/.../fx_graph_transformed.py` contains, in order:

```
full_default = aten.full.default([2], 0.0, dtype=float32, device=cuda:0)
add = aten.add.Tensor(full_default, 1)
mul_2 = aten.mul.Tensor(mul_1, add)
sin = aten.sin.default(mul_2)
```

Thus neither `one=z+1` nor multiplication by `one` is removed at the FX stage.
The later `ir_pre_fusion.txt` has simplified the addition into a constant 1.0;
that later simplification must not be projected backward onto realization's
`Pointwise.inner_fn_opcount`, which uses the original inner function under
`OpCounterCSE(MockHandler())`.

Raw outputs (`results.json`): q `[1024.0, 1024.0]`, r
`[-0.6197595000267029, -0.6197595000267029]`. Raw bits, generated native reference
code, FX, scheduler IR, and compiler caches are retained alongside the log.

The same probe confirms that ReLU and multiply have no entries in the installed
Inductor decomposition table. `OpCounterCSE` counts one load plus ReLU as two
operations. ReLU's `maximum(x, constant(0,int32))` decomposition lives later in
`codegen/common.py::OpDecompositions.relu` (line 960), not the MockHandler used
by realization. Literal constants `1`, `1.0`, `True`, `0`, `0.0`, `False` all
receive distinct MockHandler CSE identifiers even with dtype float32; their
original Python representations are retained by `ir.Constant.make_loader`
(line 4181). Direct scalar multiplication by one is also not removed by
`joint_graph.py::remove_no_ops` (line 91), whose replacement helper requires
all arguments to be FX nodes.

## Planner reference pointers

All paths below are relative to the installed Torch package; no external file
was modified.

- `_inductor/fx_passes/post_grad.py::reorder_for_locality` (828): mutable reverse
  traversal, all-users-seen producer movement, output-argument order.
- `_inductor/ir.py::Loops.inner_fn_opcount` (1059), `has_large_inner_fn` (1081),
  and `num_reads` (1126): CSE expression operation/read counting.
- `_inductor/ops_handler.py::OpCounterCSE` (1096), `MockHandler` (969), and
  `_arg_str` (57): unique operation strings, load counting, scalar kinds.
- `_inductor/graph.py::GraphLowering.run_node` (2031–2140): shared outputs,
  reuse, accumulated reads, and recursion safeguards in execution order.
- `_inductor/ir.py::StorageBox.realize_hint` (10042),
  `has_exceeded_max_reads` (10071), `should_realize_on_reuse` (10094): >30 ops,
  >4 reuse reads, >8 accumulated reads, and nontrivial-index gating.
- `_inductor/choices.py::InductorChoices.can_fuse` (569),
  `can_fuse_horizontal` (649), and `score_fusion` (675): 64-unit cap,
  ten-byte horizontal threshold, shared-byte and proximity priority.
- `_inductor/scheduler.py::Scheduler.get_possible_fusions` (6400),
  `fuse_nodes` (4986), `are_long_distant_nodes` (6606),
  `score_fusion_memory` (8099): stable buffer-group traversal, 64-pair window,
  ten rounds, endpoint distance 64, and read/write overlap.
- `_inductor/scheduler.py::FusedSchedulerNode.fuse` (2626), `init_group_node`
  (2588): fused nodes retain concatenation order; min/max are separate facts.
- `_inductor/scheduler.py::can_fusion_increase_peak_memory` (6501) and
  `_inductor/codegen/wrapper.py::buffer_reuse_key` (115): single-user internal
  storage reuse and the 32-times-shared-bytes guard.
