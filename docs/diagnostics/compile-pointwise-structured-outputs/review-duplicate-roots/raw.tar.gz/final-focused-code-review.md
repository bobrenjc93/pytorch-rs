# Independent focused review: duplicate observable roots

**Verdict: No actionable source-level findings.** The complete current fix addresses the three numerical use-count owners without changing output allocation, ordering, admission, or execution architecture. Runtime verification remains the implementing agent's responsibility; I performed no builds or GPU tests.

Base: `245e91f00aa6e41ed6262b5f40f92ca686ffea38`. Reviewed files: `src/pointwise_lowering.rs` and `tests/test_compile_pointwise_structured_outputs.py`, plus the numerical planner, scalar-program stores, result reconstruction, and strict comparison helpers they depend on.

## Scope and design gate

I applied the Moduler code-review skill. The existing canonical-plan architecture already passed independent design review. This change is a narrow bookkeeping correction: each distinct canonical observable scalar has one numerical output use even when several original SSA roots need separate public output allocations. It adds no persistent representation, owner, API, backend, or cache state; another architectural gate is unnecessary.

I enumerated the skill's focused-review contracts. Moduler module/config/torch-package/training requirements do not apply to this Rust inference compiler. There are no public signature/decorator removals or new Python product abstractions. I inspected the relevant numerical correctness, test coverage, and compatibility concerns within this assigned focused review. Runtime coverage collection and implementation validation were excluded by the task. No further reviewers were spawned and no external paste was written.

## Numerical identity is handled at all relevant stages

- `Lowering::live_uses` now seeds `uses[output] = 1` for the normalized output values. All output seeds are established before the reverse operand walk, so this does not erase any real arithmetic use. Operand multiplicity remains intact, including repeated operands such as `p+p`.
- `consumer_analysis` now seeds each `mapped[output]` once. Its separate pre-normalization canonicalization includes constant and unit-product rewrites, so it does not rely solely on the earlier scheduler CSE. This matters for a root such as `p*1.0` that becomes identical only at this later stage. The subsequent operand-edge accounting and last-consumer selection remain unchanged.
- `Lowering::local_uses` uses a stable seen-output bitmap before `add_use`. This fixes multiple local output seeds without disturbing the existing boolean representation of cross-block exports. The bitmap is local to this analysis, bounded by the already-bounded lowered node count, and preserves first occurrence.

There is no missing fourth count site in `materialization_ranks`: it resolves the shared canonical aliases, visits canonical original nodes once, gives each input one load rank, and assigns each normalized runtime call one completion epoch. This routine determines ordering rather than the number of observable uses. Changing it as part of this repair would introduce an unrelated ordering change.

The native region planner already deduplicates canonical output roots for realization while preserving first-observable order. Keeping that logic separate is correct: roots that merge only during later numeric normalization need the later use-count deduplication introduced here.

## Allocation and ordering remain separate

The fix does not deduplicate `Graph.outputs`, `Region.roots`, `RegionProgram.roots`, or ResultSpec entries. `Program::append_region` still pairs every original root with its lowered result, allocates its export register, and emits the original output-slot store. Equal scalar computations can share a numerical register while distinct computed tensor roots retain separate output owners. Repeated references to the same original root continue to reconstruct the same Tensor object.

The patch does not sort roots or change result traversal, materialization order, Graph identity, device/indexing checks, kernel count, or executable caching. The existing canonical import map remains the source of identity across region boundaries. Therefore it does not reopen the prior import-alias or observable-order defects.

## Regression assessment

The Rust regression exercises exact-expression CSE and a later unit-product rewrite. It checks that lowered output slots remain present, equal values share the lowered root, and the correct positive product contracts. It separately compares consumer-analysis, live-use, and local-use results with and without a duplicate output seed.

The GPU regression covers duplicated positive products, duplicated negative products, both, a product alias created by unit simplification, and a scalar-literal product. Forward, reversed, and nested return forms cover numerical behavior and identity. The return with repeated aliases produces the same distinct computed-root set as the reported `(p,p2,q,r)` case. Shape sizes 1, 13, and 257 exercise scalar-sized and tail work; persistent wrappers see cancellation, overflow, subnormal values, signed zeros, infinities, and NaNs through the unchanged strict comparison helper. Explicit identity/data-pointer checks distinguish separate computed roots from repeated references and verify retained previous results after subsequent calls.

The implementing agent reports that the new GPU regression failed on the baseline before the correction. I did not independently execute or validate that failure log and do not count it as my own test evidence. Completion still requires the new native/GPU regressions and the established pointwise checks on the final source. No additional architecture, evaluator, or unrelated repository-test work follows from this source review.

## Reviewed source hashes

- `src/pointwise_lowering.rs`: `ad5b2678fedc22801953088911ae20c9ba88a004704e78107273c30ce585e0ea`
- `tests/test_compile_pointwise_structured_outputs.py`: `f8d37bf9c36e5f5f573767cc9fcc69a4c41de444266d893fdb817732c85e2b09`
