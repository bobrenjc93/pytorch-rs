from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-duplicate-roots-repair'
wheel=next((out/'wheels').glob('*.whl'))
with zipfile.ZipFile(wheel) as z:
 members={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('torch_rs/') and n.endswith(('.py','.so'))}
records=[]
probe='''import sys,json,hashlib;from pathlib import Path;import torch_rs,torch_rs.torch_rs as b
p=Path(torch_rs.__file__).parent
print(json.dumps(dict(version=sys.version,executable=sys.executable,resolved=str(Path(sys.executable).resolve()),executable_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),package=str(p),extension=b.__file__,members={"torch_rs/"+str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob("*") if f.is_file() and f.suffix in (".py",".so")})))'''
for py in [root/'.venv/bin/python']+[root/f'target/portable-{v}/bin/python' for v in ['3.10.19','3.11.15','3.13.13','3.14.5']]:
 r=json.loads(subprocess.check_output([str(py),'-c',probe],text=True));assert all(r['members'].get(n)==h for n,h in members.items());records.append(r)
(out/'interpreter-identities.json').write_text(json.dumps({'wheel':str(wheel),'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'records':records},indent=2)+'\n')
print('Verified installed wheel members on all five CPython versions')
