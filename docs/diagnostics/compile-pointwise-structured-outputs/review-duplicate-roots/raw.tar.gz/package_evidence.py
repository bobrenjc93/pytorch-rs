"""Retain development checks and immutable originals without relabeling them."""
from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path.cwd();out=root/'target/default-compile-eval/structured-outputs-duplicate-roots-repair'
doc=root/'docs/diagnostics/compile-pointwise-structured-outputs/review-duplicate-roots'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def zipped(p,data):
 with p.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as z:z.write(data)
records=[json.loads(p.read_text()) for p in sorted(out.glob('*.command.json'))]
by_name={r['label']:r for r in records}
required=['native','wheel-build','regression-after','pointwise','two-device','runtime','verify-extension','interpreter-identities','clippy','fmt']+['portable-'+v for v in ('312','3.10.19','3.11.15','3.13.13','3.14.5')]
for label in required:assert by_name[label]['exit_code']==0 and by_name[label]['source_unchanged'],label
assert by_name['regression-before']['exit_code']==1
source=json.loads((out/'source-sha256.json').read_text())
for name,h in source.items():assert sha(root/name)==h,name
for name,h in by_name['wheel-build']['source_before'].items():assert sha(Path(name))==h,name
historical=json.loads((out/'historical-artifacts-sha256.json').read_text())
for name,h in historical.items():assert sha(root/name)==h,name
retained={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file()}
zipped(out/'retention-manifest.json.gz',(json.dumps(retained,indent=2)+'\n').encode())
doc.mkdir()
zipped(doc/'measurements.json.gz',(json.dumps(records,indent=2)+'\n').encode())
selected=[p for p in sorted(out.rglob('*')) if p.is_file() and (len(p.relative_to(out).parts)==1 or p.relative_to(out).parts[0]=='raw') and p.name not in ('source-snapshot.tar.gz','reviewer-original.tar.gz','retention-manifest.json.gz')]
manifest={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected}
with tarfile.open(doc/'raw.tar.gz','x:gz') as a:
 seen={}
 for p in selected:
  name=str(p.relative_to(out));h=manifest[name]['sha256']
  if h in seen:
   info=a.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;a.addfile(info)
  else:a.add(p,arcname=name,recursive=False);seen[h]=name
verified={}
with tarfile.open(doc/'raw.tar.gz','r|gz') as a:
 for m in a:
  if m.islnk():entry=verified[m.linkname]
  else:
   data=a.extractfile(m).read();entry={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  assert entry==manifest[m.name],m.name
  verified[m.name]=entry
zipped(doc/'raw-manifest.json.gz',(json.dumps(manifest,indent=2)+'\n').encode())
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_state':'uncommitted development repair; clean post-commit qualification pending','root':str(root),'required_checks':required,'historical_files_unchanged':len(historical),'raw_files_verified':len(verified),'canonical_retained_files':len(retained),'canonical_report_root':str(out),'retention_manifest_sha256':sha(out/'retention-manifest.json.gz'),'artifacts':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(doc.glob('*.gz'))}}
(doc/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
