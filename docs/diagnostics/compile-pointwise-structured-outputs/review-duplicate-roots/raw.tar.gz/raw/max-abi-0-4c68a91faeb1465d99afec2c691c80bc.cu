// torch_rs typed pointwise scalar program v3; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, float* out3, float* out4, float* out5, float* out6, float* out7, float* out8, float* out9, float* out10, float* out11, float* out12, float* out13, float* out14, float* out15, float* out16, float* out17, float* out18, float* out19, float* out20, float* out21, float* out22, float* out23, float* out24, float* out25, float* out26, float* out27, float* out28, float* out29, float* out30, float* out31, float* out32, float* out33, float* out34, float* out35, float* out36, float* out37, float* out38, float* out39, float* out40, float* out41, float* out42, float* out43, float* out44, float* out45, float* out46, float* out47, float* out48, float* out49, float* out50, float* out51, float* out52, float* out53, float* out54, float* out55, float* out56, float* out57, float* out58, float* out59, float* out60, float* out61, float* out62, float* out63, unsigned long long n, const unsigned int* plan, unsigned long long instruction_count, float* scratch, unsigned long long scratch_stride) {
const unsigned long long worker = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
float* registers = scratch + worker;
#define R(index) registers[(unsigned long long)(index) * scratch_stride]
for (unsigned long long i = worker; i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
for (unsigned long long pc = 0; pc < instruction_count; ++pc) {
const unsigned int* instruction = plan + pc * 6;
const unsigned int opcode = instruction[0], d = instruction[1], a = instruction[2], b = instruction[3], c = instruction[4], flags = instruction[5];
switch (opcode) {
case 0: switch (a) {
case 0: R(d) = x0[i]; break;
default: return; } break;
case 1: { float value; switch (a) {
default: return; } R(d) = flags ? __uint_as_float(__float_as_uint(value) ^ 0x80000000u) : value; break; }
case 2: R(d) = __uint_as_float(a); break;
case 3: R(d) = R(a); break;
case 4: R(d) = __fadd_rn(R(a), R(b)); break;
case 5: R(d) = __fsub_rn(R(a), R(b)); break;
case 6: R(d) = __fmul_rn(R(a), R(b)); break;
case 7: R(d) = __fsub_rn(0.0f, R(a)); break;
case 8: R(d) = __uint_as_float(__float_as_uint(R(a)) ^ 0x80000000u); break;
case 9: R(d) = (R(a) < 0.0f ? 0.0f : R(a)); break;
case 10: R(d) = sinf((__float_as_uint(R(a)) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(R(a)) & 0x80000000u) : R(a)); break;
case 11: R(d) = cosf(R(a)); break;
case 12: R(d) = (float)sin((double)R(a)); break;
case 13: R(d) = (float)cos((double)R(a)); break;
case 14: {
float left = R(a), addend = (flags & 4u) ? 0.0f : R(c);
if (flags & 1u) left = __uint_as_float(__float_as_uint(left) ^ 0x80000000u);
if (flags & 2u) addend = __uint_as_float(__float_as_uint(addend) ^ 0x80000000u);
R(d) = fmaf(left, R(b), addend); break; }
case 15: switch (d) {
case 0: out0[i] = R(a); break;
case 1: out1[i] = R(a); break;
case 2: out2[i] = R(a); break;
case 3: out3[i] = R(a); break;
case 4: out4[i] = R(a); break;
case 5: out5[i] = R(a); break;
case 6: out6[i] = R(a); break;
case 7: out7[i] = R(a); break;
case 8: out8[i] = R(a); break;
case 9: out9[i] = R(a); break;
case 10: out10[i] = R(a); break;
case 11: out11[i] = R(a); break;
case 12: out12[i] = R(a); break;
case 13: out13[i] = R(a); break;
case 14: out14[i] = R(a); break;
case 15: out15[i] = R(a); break;
case 16: out16[i] = R(a); break;
case 17: out17[i] = R(a); break;
case 18: out18[i] = R(a); break;
case 19: out19[i] = R(a); break;
case 20: out20[i] = R(a); break;
case 21: out21[i] = R(a); break;
case 22: out22[i] = R(a); break;
case 23: out23[i] = R(a); break;
case 24: out24[i] = R(a); break;
case 25: out25[i] = R(a); break;
case 26: out26[i] = R(a); break;
case 27: out27[i] = R(a); break;
case 28: out28[i] = R(a); break;
case 29: out29[i] = R(a); break;
case 30: out30[i] = R(a); break;
case 31: out31[i] = R(a); break;
case 32: out32[i] = R(a); break;
case 33: out33[i] = R(a); break;
case 34: out34[i] = R(a); break;
case 35: out35[i] = R(a); break;
case 36: out36[i] = R(a); break;
case 37: out37[i] = R(a); break;
case 38: out38[i] = R(a); break;
case 39: out39[i] = R(a); break;
case 40: out40[i] = R(a); break;
case 41: out41[i] = R(a); break;
case 42: out42[i] = R(a); break;
case 43: out43[i] = R(a); break;
case 44: out44[i] = R(a); break;
case 45: out45[i] = R(a); break;
case 46: out46[i] = R(a); break;
case 47: out47[i] = R(a); break;
case 48: out48[i] = R(a); break;
case 49: out49[i] = R(a); break;
case 50: out50[i] = R(a); break;
case 51: out51[i] = R(a); break;
case 52: out52[i] = R(a); break;
case 53: out53[i] = R(a); break;
case 54: out54[i] = R(a); break;
case 55: out55[i] = R(a); break;
case 56: out56[i] = R(a); break;
case 57: out57[i] = R(a); break;
case 58: out58[i] = R(a); break;
case 59: out59[i] = R(a); break;
case 60: out60[i] = R(a); break;
case 61: out61[i] = R(a); break;
case 62: out62[i] = R(a); break;
case 63: out63[i] = R(a); break;
default: return; } break;
default: return;
}
}
}
#undef R
}
