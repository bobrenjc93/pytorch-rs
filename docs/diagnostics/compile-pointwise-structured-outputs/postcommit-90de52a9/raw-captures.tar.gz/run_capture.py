import datetime, hashlib, json, os, pathlib, shlex, subprocess, sys
ROOT=pathlib.Path.cwd(); OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-90de52a9'
COMMIT='90de52a97559b7596d8d64661904e3db59112d2a'
def query(*args): return subprocess.check_output(args,cwd=ROOT,text=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert query('git','rev-parse','HEAD').strip()==COMMIT
assert query('git','status','--porcelain')==''
tracked=query('git','ls-files','-z').split('\0')[:-1]
record={'commit':COMMIT,'root':str(ROOT),'status_before':query('git','status','--porcelain'),'source_sha256':{p:sha(ROOT/p) for p in tracked},'commands':[]}
env=os.environ.copy()
for k in ('PYTHONPATH','CONDA_PREFIX'):env.pop(k,None)
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(ROOT/'target/tmp'),UV_CACHE_DIR=str(ROOT/'target/cache/uv'),CARGO_HOME=str(ROOT/'target/native-output-checks/cargo-home'),CARGO_TARGET_DIR=str(OUT/'cargo-build'),CARGO_BUILD_JOBS='8',PYO3_PYTHON=str(ROOT/'.venv/bin/python'),TORCHINDUCTOR_CACHE_DIR=str(OUT/'cache/inductor'),TRITON_CACHE_DIR=str(OUT/'cache/triton'),CUDA_CACHE_PATH=str(OUT/'cache/cuda'),XDG_CACHE_HOME=str(OUT/'cache/xdg'),CUDA_VISIBLE_DEVICES='0',TORCH_RS_STRUCTURED_EVIDENCE=str(OUT/'raw'))
record['environment']={k:env[k] for k in env if k in ('PYTHONDONTWRITEBYTECODE','TMPDIR','UV_CACHE_DIR','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PYO3_PYTHON','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','CUDA_CACHE_PATH','XDG_CACHE_HOME','CUDA_VISIBLE_DEVICES','TORCH_RS_STRUCTURED_EVIDENCE')}
record['cache_initially_absent']=not (OUT/'cache').exists()
def save(): (OUT/'measurements.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,extra=None):
    child=env| (extra or {})
    item={'label':label,'argv':list(map(str,args)),'cwd':str(ROOT),'environment_overrides':extra or {},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':label+'.log'}
    with (OUT/item['log']).open('xb') as f: completed=subprocess.run(args,cwd=ROOT,env=child,stdout=f,stderr=subprocess.STDOUT)
    item.update(exit_code=completed.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    record['commands'].append(item);save();print(label,completed.returncode,flush=True)
    if completed.returncode: raise SystemExit(completed.returncode)
GPU=['nvidia-smi','--query-gpu=index,uuid,name,driver_version,compute_cap,utilization.gpu,memory.used,memory.total','--format=csv']
run('gpu-before',GPU)
for label,argv in [('rustc-version',['rustc','--version','--verbose']),('cargo-version',['cargo','--version']),('nvcc-version',['nvcc','--version']),('maturin-version',[str(ROOT/'.venv/bin/maturin'),'--version'])]:run(label,argv)
run('release-build',[str(ROOT/'.venv/bin/maturin'),'build','--release','--locked','--offline','--out',str(OUT/'wheels')])
wheel=next((OUT/'wheels').glob('*.whl'));record['wheel']={'path':str(wheel),'sha256':sha(wheel)};save()
run('install-main',['uv','pip','install','--python',str(ROOT/'.venv/bin/python'),'--no-deps','--force-reinstall',str(wheel)])
run('verify-native-extension',[str(ROOT/'.venv/bin/python'),'.github/scripts/verify_native_extension.py'])
run('pointwise',[str(ROOT/'.venv/bin/python'),'-m','unittest','discover','-v','-s','tests','-p','test_compile_pointwise*.py'])
run('gpu-after-single',GPU)
selectors=['tests.test_compile_pointwise_broadcast.Broadcast.test_device_restoration_on_compile_run_failure_and_module_release','tests.test_compile_pointwise_helpers.HelperHardware.test_two_h100_devices_restore_context_and_share_helper_semantics','tests.test_compile_pointwise_jit.Hardware.test_two_device_restoration_and_module_ownership','tests.test_compile_pointwise_loops.LoopHardware.test_original_ir_unequal_shapes_and_device_restoration','tests.test_compile_pointwise_runtime_scalars.PositionalScalarHardware.test_positional_runtime_parameters_restore_device_on_success_and_failure','tests.test_compile_pointwise_runtime_scalars.RuntimeScalarHardware.test_runtime_parameters_restore_current_device','tests.test_compile_pointwise_structured_outputs.StructuredHardware.test_two_device_restoration_and_wrong_device_failure','tests.test_compile_pointwise_tensor_madd.TensorMadd.test_both_devices_restore_current_device_on_success_failure_and_reset']
run('gpu-before-two',GPU)
run('two-device',[str(ROOT/'.venv/bin/python'),'-c',"import sys, unittest; sys.path.insert(0,'tests'); unittest.main(module=None)",'-v',*selectors],{'CUDA_VISIBLE_DEVICES':'0,1'})
run('native-pointwise',['cargo','test','--locked','--offline','--release','--lib','pointwise','--','--nocapture','--test-threads=1'],{'CUDA_VISIBLE_DEVICES':'0,1'})
run('gpu-after-two',GPU)
run('native-conversion',['cargo','test','--locked','--offline','--release','--lib','--features','python-bindings','python_conversion_failure','--','--nocapture'],{'CUDA_VISIBLE_DEVICES':'','LD_LIBRARY_PATH':str(ROOT/'target/python-3.12/lib')})
for version in ('3.10.19','3.11.15','3.12.12','3.13.13','3.14.5'):
    python=ROOT/('.venv/bin/python' if version=='3.12.12' else 'target/portable-'+version+'/bin/python')
    if version!='3.12.12':run('install-'+version,['uv','pip','install','--python',str(python),'--no-deps','--force-reinstall',str(wheel)])
    run('identity-'+version,[str(python),'-c',"import sys,torch_rs,torch_rs.torch_rs as b,hashlib,json,pathlib; print(json.dumps({'python':sys.version,'executable':sys.executable,'resolved_executable':str(pathlib.Path(sys.executable).resolve()),'package':torch_rs.__file__,'extension':b.__file__,'members':{str(p.relative_to(pathlib.Path(torch_rs.__file__).parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in pathlib.Path(torch_rs.__file__).parent.rglob('*') if p.is_file() and p.suffix in ('.py','.so')}},indent=2))"],{'CUDA_VISIBLE_DEVICES':''})
    run('portable-'+version,[str(python),'-m','unittest','discover','-v','-s','tests','-p','test_compile_pointwise*.py'],{'CUDA_VISIBLE_DEVICES':''})
record['status_after']=query('git','status','--porcelain');assert record['status_after']==''
assert all(sha(ROOT/p)==digest for p,digest in record['source_sha256'].items())
record['source_unchanged_after']=True;save()
print('CAPTURE COMPLETE',flush=True)
