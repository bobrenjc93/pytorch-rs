"""Verify final report links, archives and evidence-only edits."""
from pathlib import Path
import gzip,hashlib,json,re,subprocess,tarfile
ROOT=Path.cwd();OUT=ROOT/'target/default-compile-eval/structured-outputs-postcommit-90de52a9';DOC=ROOT/'docs/diagnostics/compile-pointwise-structured-outputs/postcommit-90de52a9'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
measure=json.loads(gzip.decompress((DOC/'measurements.json.gz').read_bytes()))
assert measure['commit']=='90de52a97559b7596d8d64661904e3db59112d2a'
assert measure['status_before']==measure['status_after']==''
for path,digest in measure['source_sha256'].items():
    if path!='docs/compile-pointwise-jit.md':assert sha(ROOT/path)==digest,path
assert measure['raw_comparisons']==157
assert measure['checks']['pointwise']==dict(total=292,skipped=8,passed=284,seconds=260.978)
assert measure['checks']['two-device']['passed']==8 and measure['checks']['two-device']['skipped']==0
assert measure['checks']['native-pointwise']==dict(passed=41,failed=0)
assert measure['checks']['native-conversion']==dict(passed=1,failed=0)
for name,item in measure['checks'].items():
    if name.startswith('portable-'):assert item['passed']==143 and item['skipped']==149
manifest=json.loads((DOC/'raw-retention-manifest.json').read_text())
with tarfile.open(DOC/'raw-captures.tar.gz') as archive:
    for path,item in manifest['archived_files'].items():assert hashlib.sha256(archive.extractfile(path).read()).hexdigest()==item['sha256']
for path,item in manifest['large_canonical_artifacts'].items():assert sha(ROOT/path)==item['sha256']
prior=json.loads((OUT/'prior-artifacts-before.json').read_text())
assert all(sha(ROOT/p)==digest for p,digest in prior.items())
for p in (ROOT/'docs/compile-pointwise-jit.md',DOC/'README.md'):
    for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
        if not link.startswith(('http:','https:','#')):assert (p.parent/link.split('#')[0]).exists(),link
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert changed==['docs/compile-pointwise-jit.md'],changed
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
assert all(p.startswith('docs/diagnostics/compile-pointwise-structured-outputs/postcommit-90de52a9/') for p in new),new
subprocess.run(['git','diff','--check'],check=True)
result={'commit':measure['commit'],'clean_capture':True,'checks':measure['checks'],'prior_files_unchanged':len(prior),'archived_raw_files_verified':len(manifest['archived_files']),'wheel_sha256':measure['wheel']['sha256'],'tracked_changes':changed,'new_evidence_files':new,'documentation_links_valid':True,'diff_check_passed':True}
(OUT/'final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
