from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,str(Path.cwd()/'tests'))
import test_compile_pointwise_structured_outputs as suite

class Regions(suite.StructuredHardware):
    def test_nonlinear_regions(self):
        bodies=(
            'p=x*y\n q=-p\n r=p.sin()',
            'p=x*x\n q=-p\n r=p.sin()',
            'p=x*y\n q=-p\n r=p.cos()',
            'p=x*y\n q=-p\n r=(p+p).sin()',
            'p=x*y\n q=-p\n r=x.sin()',
            'p=x*y\n q=p+x\n r=p.sin()',
            'p=x*y\n q=-p\n r=p.sin()+q',
        )
        for case,body in enumerate(bodies):
            for order,result in enumerate(('(q,r)','(r,q)','(p,q,r)','r')):
                source='def f(x,y):\n '+body+'\n return '+result
                fn=suite.program(source);compiled=suite.native.compile(fn)
                reference=self.torch.compile(suite.program(source,self.torch))
                for size in (1,2,3,13,257):
                    for history,(left,right) in enumerate(((1e-38,1e-38),(1e-38,-1e-38),(2e38,-2e38),(1e10,1.0000001192092896))):
                        args=[self.upload([v]*size,(size,)) for v in (left,right)]
                        refs=[self.upload([v]*size,(size,),self.torch) for v in (left,right)]
                        for repeat in range(2):
                            with self.subTest(case=case,result=result,size=size,history=history,repeat=repeat):
                                expected=reference(*refs)
                                actual=self.without_replay(fn,compiled,args)
                                self.retain(f'regions-{case}-{order}-{size}-{history}-{repeat}',compiled,actual,expected)
                                self.compare_tree(actual,expected)
                                self.assertEqual(suite.kernel(compiled).ptx.count('.visible .entry'),1)
                    self.assertEqual(len(suite.cache(compiled).executors),1)

result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([Regions('test_nonlinear_regions')]))
sys.exit(not result.wasSuccessful())
