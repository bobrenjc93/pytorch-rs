"""Development diagnostic: retain the admitted partition-sensitive mismatch."""
import json, math, sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
sys.path.insert(0, str(Path.cwd()/'tests'))
import test_compile_pointwise_structured_outputs as suite

class PartitionProbe(suite.StructuredHardware):
    def test_partition_sensitive_zero(self):
        source='def f(x,y):\n p=x*y\n q=-p\n r=p.sin()\n return (q,r)'
        for size in (1,13,257):
            fn=suite.program(source)
            compiled=suite.native.compile(fn)
            reference=self.torch.compile(suite.program(source,self.torch))
            args=[self.upload([1e-38]*size,(size,)) for _ in range(2)]
            refs=[self.upload([1e-38]*size,(size,),self.torch) for _ in range(2)]
            for repeat in range(2):
                with self.subTest(size=size,repeat=repeat):
                    actual=self.without_replay(fn,compiled,args)
                    expected=reference(*refs)
                    self.retain(f'partition-{size}-{repeat}',compiled,actual,expected)
                    print(json.dumps({'size':size,'repeat':repeat,
                        'actual_first':[v.cpu().tolist()[0] for v in actual],
                        'expected_first':[v.cpu().tolist()[0] for v in expected]},allow_nan=True),flush=True)
                    self.compare_tree(actual,expected)

result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([PartitionProbe('test_partition_sensitive_zero')]))
sys.exit(not result.wasSuccessful())
