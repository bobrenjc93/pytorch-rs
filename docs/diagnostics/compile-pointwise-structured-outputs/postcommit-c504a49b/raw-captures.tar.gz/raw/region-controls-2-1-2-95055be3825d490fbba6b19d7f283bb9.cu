// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n, float s0) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
{
const float v2 = s0;
const float v4 = __uint_as_float(0x00000000u);
const float v5 = __fadd_rn(v4, v2);
out0[i] = v5;
}
{
const float v2 = s0;
const float v4 = __uint_as_float(0x00000000u);
const float v5 = __fadd_rn(v4, v2);
const float v6 = __fsub_rn(0.0f, v5);
out1[i] = v6;
}
{
const float v2 = s0;
const float v4 = __uint_as_float(0x00000000u);
const float v5 = __fadd_rn(v4, v2);
const float v7 = sinf((__float_as_uint(v5) & 0x7f800000u) == 0 ? __uint_as_float(__float_as_uint(v5) & 0x80000000u) : v5);
out2[i] = v7;
}
}
}
