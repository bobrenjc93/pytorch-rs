// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fsub_rn(0.0f, v0);
const float v3 = __fsub_rn(0.0f, v1);
const float v4 = __fmul_rn(v2, v3);
const float v5 = __fmul_rn(v0, v1);
const float v6 = fmaf(v2, v3, -v5);
out0[i] = v5;
out1[i] = v6;
}
}
