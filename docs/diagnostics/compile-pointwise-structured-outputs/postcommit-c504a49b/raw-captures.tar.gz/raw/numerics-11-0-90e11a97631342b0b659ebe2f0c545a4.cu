// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, float* out3, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v2 = __fmul_rn(v0, v1);
const float v4 = (-v2);
const float v5 = fmaf(-v0, v1, v0);
const float v6 = fmaf(-v0, v1, -v1);
out0[i] = v2;
out1[i] = v4;
out2[i] = v5;
out3[i] = v6;
}
}
