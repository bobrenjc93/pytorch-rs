// torch_rs typed pointwise SSA v2; float32, no fast math
extern "C" __global__ void torch_rs_pointwise(
const float* x0, const float* x1, float* out0, float* out1, float* out2, unsigned long long n) {
for (unsigned long long i = (unsigned long long)blockIdx.x * blockDim.x + threadIdx.x;
i < n; i += (unsigned long long)blockDim.x * gridDim.x) {
const float v0 = x0[i];
const float v1 = x1[i];
const float v3 = __uint_as_float(0x3f918937u);
const float v4 = __fmul_rn(v0, v3);
const float v6 = __uint_as_float(0xc06da1cbu);
const float v7 = __fmul_rn(v1, v6);
const float v8 = __uint_as_float(0x406da1cbu);
const float v9 = __fmul_rn(v1, v8);
const float v10 = fmaf(-v1, v8, v4);
out0[i] = v4;
out1[i] = v7;
out2[i] = v10;
}
}
