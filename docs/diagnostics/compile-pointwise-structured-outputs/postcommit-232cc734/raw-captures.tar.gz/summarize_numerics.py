from pathlib import Path
import hashlib,json,subprocess
out=Path(__file__).resolve().parent
raw=out/'raw'
records=list(raw.glob('duplicate-products-*.json'))
assert len(records)==720,len(records)
selected=[]
for size in (1,13,257):
 for history in (0,1):
  for repeat in (0,1):
   files=list(raw.glob(f'duplicate-products-0-0-{size}-{history}-{repeat}-*.json'))
   assert len(files)==1
   p=files[0];r=json.loads(p.read_text())
   actual=r['actual'][4]['values'][0];expected=r['expected'][4]['values'][0]
   assert actual==expected,(p,actual,expected)
   for suffix in ('.cu','.ptx','.plan'):assert p.with_suffix(suffix).is_file(),p.with_suffix(suffix)
   selected.append(dict(file=str(p.relative_to(out)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=size,history=history,repeat=repeat,native_r=actual,reference_r=expected))
result=dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),duplicate_product_comparisons=len(records),selected_results=selected)
(out/'numerical-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
