"""Isolated harness tests with a fake compiler; no libNVVM/GPU calls."""

import ctypes as C
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch


SOURCE = Path.cwd() / 'docs/diagnostics/compile-gelu-linked/generate_provider.py'
SPEC = importlib.util.spec_from_file_location('generation_probe', SOURCE)
PROBE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROBE)
ROOT = Path(tempfile.mkdtemp(prefix='gelu-libnvvm-generation-unit.', dir=Path.cwd() / 'target/gelu-linked/tmp'))


class FakeFunction:
    def __init__(self, owner, name):
        self.owner, self.name = owner, name

    def __call__(self, *args):
        return self.owner.invoke(self.name, args)


class FakeCompiler:
    def __init__(self, *, failure=None, compile_status=0, bad_nul=False,
                 bad_size=False, destroy_status=0, destroy_raises=False,
                 null_after_destroy=True, version=(2, 0), failed_create_handle=False):
        self.failure, self.compile_status = failure, compile_status
        self.bad_nul, self.bad_size = bad_nul, bad_size
        self.destroy_status, self.destroy_raises = destroy_status, destroy_raises
        self.null_after_destroy, self.version = null_after_destroy, version
        self.failed_create_handle = failed_create_handle
        self.calls, self.submitted = [], []
        self.text = b'.version 8.7\n.visible.func torch_rs_erf() {}\n'
        self.ptx = self.text + (b'X' if bad_nul else b'\0')
        for name in ('nvvmVersion', 'nvvmIRVersion', 'nvvmCreateProgram',
                     'nvvmDestroyProgram', 'nvvmAddModuleToProgram',
                     'nvvmLazyAddModuleToProgram', 'nvvmCompileProgram',
                     'nvvmGetProgramLogSize', 'nvvmGetProgramLog',
                     'nvvmGetCompiledResultSize', 'nvvmGetCompiledResult'):
            setattr(self, name, FakeFunction(self, name))

    def invoke(self, name, args):
        self.calls.append(name)
        if name == self.failure:
            if name == 'nvvmCreateProgram' and self.failed_create_handle:
                args[0]._obj.value = 456
            return 9
        if name in ('nvvmVersion', 'nvvmIRVersion'):
            values = self.version if name == 'nvvmVersion' else (2, 0, 3, 2)
            for pointer, value in zip(args, values, strict=True):
                pointer._obj.value = value
        elif name == 'nvvmCreateProgram':
            args[0]._obj.value = 123
        elif name == 'nvvmDestroyProgram':
            if self.destroy_raises:
                raise RuntimeError('injected destroy exception')
            if self.null_after_destroy:
                args[0]._obj.value = None
            return self.destroy_status
        elif name in ('nvvmAddModuleToProgram', 'nvvmLazyAddModuleToProgram'):
            self.submitted.append((name, C.string_at(args[1], args[2]), args[3]))
        elif name == 'nvvmCompileProgram':
            assert args[1] == len(PROBE.OPTIONS)
            assert list(args[2]) == [x.encode('ascii') for x in PROBE.OPTIONS]
            return self.compile_status
        elif name == 'nvvmGetProgramLogSize':
            args[1]._obj.value = 1
        elif name == 'nvvmGetProgramLog':
            C.memmove(args[1], b'\0', 1)
        elif name == 'nvvmGetCompiledResultSize':
            args[1]._obj.value = 17 * 1024 * 1024 if self.bad_size else len(self.ptx)
        elif name == 'nvvmGetCompiledResult':
            C.memmove(args[1], self.ptx, len(self.ptx))
        return 0


class GenerationProbeTests(unittest.TestCase):
    def setUp(self):
        self.directory = Path(tempfile.mkdtemp(prefix='case.', dir=ROOT))
        self.wrapper = self.directory / 'wrapper.ll'
        self.bitcode = self.directory / 'library.bc'
        self.wrapper.write_bytes(b'declare float @__nv_erff(float)\n')
        self.bitcode.write_bytes(b'BC\0with\0embedded\0bytes\xff')
        PROBE.save(self.directory / 'declaration.json', {'inputs': []})

    def execute(self, compiler, leg='official-library'):
        with patch.object(PROBE, 'validate_inputs', return_value=[]), \
             patch.object(PROBE, 'WRAPPER', self.wrapper), \
             patch.object(PROBE, 'BITCODE', self.bitcode), \
             patch.object(PROBE.C, 'CDLL', return_value=compiler) as loader:
            result = PROBE.child(self.directory, leg)
        self.assertEqual(loader.call_count, 1)
        report = json.loads((self.directory / leg / 'report.json').read_text())
        return result, report

    def test_official_bytes_options_nul_and_cleanup(self):
        compiler = FakeCompiler()
        result, report = self.execute(compiler)
        self.assertEqual(result, 0)
        self.assertEqual([x[1] for x in compiler.submitted],
                         [self.wrapper.read_bytes(), self.bitcode.read_bytes()])
        self.assertEqual(report['modules'][1]['submittedBytes'], len(self.bitcode.read_bytes()))
        self.assertEqual(report['modules'][1]['submittedSha256'], PROBE.digest(self.bitcode.read_bytes()))
        self.assertEqual((self.directory / 'official-library/provider.ptx').read_bytes(), compiler.text)
        self.assertEqual((self.directory / 'official-library/provider.ptx.api-bytes').read_bytes(), compiler.ptx)
        self.assertNotEqual(report['compilerResult']['apiSha256IncludingNul'],
                            report['compilerResult']['textSha256ExcludingNul'])
        self.assertEqual(compiler.calls[-1], 'nvvmDestroyProgram')
        self.assertTrue(report['programNullAfterDestroy'])

    def test_no_library_rejection_is_retained_not_parity(self):
        compiler = FakeCompiler(compile_status=9)
        result, report = self.execute(compiler, 'no-library')
        self.assertEqual(result, 0)
        self.assertEqual(len(compiler.submitted), 1)
        self.assertEqual(report['compileStatus'], 9)
        self.assertIsNone(report['compilerResult'])
        self.assertNotIn('nvvmGetCompiledResult', compiler.calls)
        self.assertEqual(report['destroyStatus'], 0)

    def test_official_compile_failure_not_hidden(self):
        result, report = self.execute(FakeCompiler(compile_status=9))
        self.assertEqual(result, 0)
        self.assertEqual(report['compileStatus'], 9)
        self.assertIsNone(report['compilerResult'])

    def test_no_library_success_still_has_only_wrapper(self):
        compiler = FakeCompiler()
        result, report = self.execute(compiler, 'no-library')
        self.assertEqual(result, 0)
        self.assertEqual(len(compiler.submitted), 1)
        self.assertEqual(report['compileStatus'], 0)

    def test_failed_module_add_destroys_program(self):
        compiler = FakeCompiler(failure='nvvmLazyAddModuleToProgram')
        result, report = self.execute(compiler)
        self.assertEqual(result, 2)
        self.assertIn('returned 9', report['error'])
        self.assertNotIn('nvvmCompileProgram', compiler.calls)
        self.assertEqual(report['destroyStatus'], 0)

    def test_create_failure_does_not_destroy_uncreated_program(self):
        compiler = FakeCompiler(failure='nvvmCreateProgram')
        result, report = self.execute(compiler)
        self.assertEqual(result, 2)
        self.assertNotIn('nvvmDestroyProgram', compiler.calls)
        self.assertNotIn('destroyStatus', report)

    def test_version_mismatch_stops_before_program_creation(self):
        compiler = FakeCompiler(version=(99, 0))
        result, report = self.execute(compiler)
        self.assertEqual(result, 2)
        self.assertNotIn('nvvmCreateProgram', compiler.calls)
        self.assertIn('Unexpected compiler', report['error'])

    def test_nonnull_failed_create_output_is_not_owned(self):
        compiler = FakeCompiler(failure='nvvmCreateProgram', failed_create_handle=True)
        result, report = self.execute(compiler)
        self.assertEqual(result, 2)
        self.assertNotIn('nvvmDestroyProgram', compiler.calls)
        self.assertNotIn('destroyStatus', report)

    def test_missing_trailing_nul_fails_and_cleans_up(self):
        result, report = self.execute(FakeCompiler(bad_nul=True))
        self.assertEqual(result, 2)
        self.assertIn('trailing NUL', report['error'])
        self.assertEqual(report['destroyStatus'], 0)

    def test_bad_result_size_fails_before_allocation(self):
        compiler = FakeCompiler(bad_size=True)
        result, report = self.execute(compiler)
        self.assertEqual(result, 2)
        self.assertIn('buffer size', report['error'])
        self.assertNotIn('nvvmGetCompiledResult', compiler.calls)
        self.assertEqual(report['destroyStatus'], 0)

    def test_destroy_status_failure_not_success(self):
        result, report = self.execute(FakeCompiler(destroy_status=9))
        self.assertEqual(result, 2)
        self.assertEqual(report['destroyStatus'], 9)

    def test_destroy_exception_not_success(self):
        result, report = self.execute(FakeCompiler(destroy_raises=True))
        self.assertEqual(result, 2)
        self.assertIn('injected destroy exception', report['destroyError'])

    def test_nonnull_after_successful_destroy_is_only_observation(self):
        result, report = self.execute(FakeCompiler(null_after_destroy=False))
        self.assertEqual(result, 0)
        self.assertFalse(report['programNullAfterDestroy'])

    def test_input_declaration_mismatch_before_loading_library(self):
        with patch.object(PROBE.C, 'CDLL') as loader:
            with self.assertRaisesRegex(RuntimeError, 'Declared inputs changed'):
                PROBE.child(self.directory, 'official-library')
        loader.assert_not_called()

    def test_parent_timeout_is_inconclusive_and_pair_is_retained(self):
        outputs = [subprocess.TimeoutExpired(['fake'], 45, output=b'partial', stderr=b'error'),
                   subprocess.CompletedProcess(['fake'], 0, b'control', b'')]
        with patch.object(PROBE, 'NOTES', self.directory), \
             patch.object(PROBE, 'validate_inputs', return_value=[]), \
             patch.object(PROBE.subprocess, 'run', side_effect=outputs):
            result = PROBE.run()
        output = next(self.directory.glob('gelu-libnvvm-generation.*'))
        report = json.loads((output / 'process-report.json').read_text())
        self.assertEqual(result, 2)
        self.assertTrue(report['legs'][0]['timedOut'])
        self.assertEqual(report['legs'][1]['returncode'], 0)
        self.assertFalse(report['experimentProcessesCompleted'])
        self.assertEqual((output / 'official-library.stdout').read_bytes(), b'partial')
        self.assertIn('Requires inspection', report['selectionConclusion'])

    def test_parent_nonzero_process_is_retained(self):
        outputs = [subprocess.CompletedProcess(['fake'], 2, b'', b'failure'),
                   subprocess.CompletedProcess(['fake'], 0, b'', b'')]
        with patch.object(PROBE, 'NOTES', self.directory), \
             patch.object(PROBE, 'validate_inputs', return_value=[]), \
             patch.object(PROBE.subprocess, 'run', side_effect=outputs):
            result = PROBE.run()
        output = next(self.directory.glob('gelu-libnvvm-generation.*'))
        report = json.loads((output / 'process-report.json').read_text())
        self.assertEqual(result, 2)
        self.assertEqual(report['legs'][0]['returncode'], 2)
        self.assertEqual(len(report['legs']), 2)

    def test_parent_spawn_error_is_retained_and_control_attempted(self):
        outputs = [OSError('injected spawn failure'),
                   subprocess.CompletedProcess(['fake'], 0, b'control', b'')]
        with patch.object(PROBE, 'NOTES', self.directory), \
             patch.object(PROBE, 'validate_inputs', return_value=[]), \
             patch.object(PROBE.subprocess, 'run', side_effect=outputs):
            result = PROBE.run()
        output = next(self.directory.glob('gelu-libnvvm-generation.*'))
        report = json.loads((output / 'process-report.json').read_text())
        self.assertEqual(result, 2)
        self.assertIn('injected spawn failure', report['legs'][0]['spawnError'])
        self.assertEqual(report['legs'][1]['returncode'], 0)
        self.assertFalse(report['experimentProcessesCompleted'])


if __name__ == '__main__':
    print('Fake API only; retained test outputs: ' + str(ROOT), flush=True)
    unittest.main(verbosity=2)
