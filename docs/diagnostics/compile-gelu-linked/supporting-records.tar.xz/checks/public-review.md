# Public/eager GELU independent bounded review

Final bounded status: F1 and F2 resolved by the recheck below. Original findings
and their source bindings are retained as review history. This is not a full
qualification, current-clean-commit measurement, or merge approval.
Review performed independently with Moduler orchestrate/design and code-review;
no additional agents, builds, GPU operations, or production edits. The prior
private 44-case audit remains separately bound in review.md and raw-audit.json.

## Actual design judgment

Pass for the actual ownership/design, subject to local fixes and execution
verification. The builtin directly enters native tensor/storage validation and
the existing unary output lifetime owner. A lazy separate eager image preserves
the common eager PTX6/sm50 module. The default frontend expands the exact
functional callable into ordinary SSA arithmetic and private Erf; optional
provider linking remains inside the existing compiled module owner. No public
Erf/Tensor GELU method, keyword extension, new planner, or runtime libNVVM was
introduced. Existing helper global/closure and higher-order-data restrictions
remain unchanged.

No change would preserve unsupported GELU, but the independently verified
private prerequisite now supplies a reason to implement the public surface.
Public eager arithmetic composition would require multiple missing operations;
an opaque compiler GELU node or whole-executor redesign would duplicate or
replace the existing numerical owner. The implemented split is the smallest
coherent route under these constraints. Its extra module/link cost still needs
real performance evidence; source review does not establish no regression.

## F1: reject hostile namespace keys before lookup

At initial review, check_namespace_guard in
python/torch_rs/_compile_pointwise.py calls owner.__dict__.get(name) before
checking all keys are exact strings. A canonical nn/functional module may have
a non-string key with the same hash as the traversed name. Dictionary lookup
can then invoke that object's __eq__, violating the no-user-hook admission
contract and the original design's explicit namespace-key requirement.

Independently reproduced without GPU or package mutation: extracted the actual
function with ast, supplied an exact ModuleType whose dictionary has a hostile
key colliding with 'gelu', and invoked the guard. Its user equality callback
ran and raised RuntimeError('user equality executed'). The expected builtin
was still installed under the actual string key. Exact module type alone is
insufficient.

Fix: reuse the existing native namespace-key checker before every new module
attribute lookup, and test cold/warm hostile keys plus type mutation. Preserve
saved builtin alias independence and avoid adding these checks to unrelated
non-GELU execution. This is a local admission correction, not a redesign.

## F2: complete required public/eager checks

The initial tests/test_compile_gelu.py covers eager scalar/empty/ranked/offset
metadata and retention; compiled direct/nested/affine/mixed forms with shape
histories; builtin identity, arity, namespace aliases and warm rebindings;
helper rejection, graph budget and basic unsupported metadata.

It does not yet establish the original post-private public requirements:
constant-tensor GELU, shared/recomputed/competing products and both observable
output orders, realization-threshold chains, and persistent scalar histories
through one ordinary native/reference wrapper each. The private matrix cannot
stand in for this frontend coverage. Eager subnormal and subclass rejection,
module type/key guards and ordinary eager-without-NVRTC checks also need their
promised execution evidence. These are validation gaps, not observed numerical
failures. Add proportionate tests or a retained public diagnostic rather than
claiming the private prerequisite proves them.

## Resolved local test mismatch

The original active TorchFunctionMode test expected NotImplementedError while
the strict builtin returns TypeError. Reported to author; the intended strict
TypeError behavior was confirmed and the test changed accordingly. No generic
mode dispatch or fallback is needed.

## Other checked boundaries and limits

- The builtin has a positional-only signature and rejects subclasses/modes
  before computation. Native admission rejects CPU, non-float32, gradients
  even under no_grad, and noncontiguous storage. Output construction is fresh,
  canonical contiguous metadata with no autograd owner.
- Package initialization snapshots the real builtin and canonical modules.
  Traversed edges are retained on Lowering and rechecked before executable or
  prepared-cache reuse. Saved builtin aliases do not depend on untraversed
  module attributes. No cross-module-reinitialization singleton guarantee was
  established or required by this review.
- Eager image has three real launch parameters (input/output/count), no unused
  scratch ABI; grid-stride work uses the shared bounds/device/synchronization
  owner. Module lookup failure unloads the pending image; image selection keeps
  common kernels independent of GELU's PTX9/sm75 requirement.
- The unchanged private provider/linking review remains applicable to its bound
  source. Public changes do not turn its numerical matrix into public evidence.
- Packaging is being handled by the author: actual wheel/sdist notice inclusion
  and accurate vendor attribution must be verified before delivery. Existing
  complete official terms should not be duplicated. No legal clearance claimed.

The focused-contract catalogue was enumerated; quality, tests/coverage,
compatibility, claims and kernel ownership concerns were examined in this one
bounded review as requested. No full standalone review wave or broad suite was
run. Runtime, no-NVRTC, performance and packaging results need subsequent checks.

## Source binding at report assembly

Assembled 2026-09-16T07:30:52.277088+00:00.

- `python/torch_rs/_compile_pointwise.py`: `31510d00933f58e5801c1066ccb1c7c91be43a55842bee9427acae5706529174`
- `python/torch_rs/nn/functional.py`: `ff2926cc615db0e9c28edb35fb0c5843db5830c2207f426f7e8e40a177f7bb61`
- `src/cuda.rs`: `8daea2a7d87725cd4f8dce8d062c408bbcbbd5bd7d5d98bc4b41579f509ad32d`
- `src/cuda/jit.rs`: `28119dfb0d0c555f982e90b844802701016ffbc1927c4741ef7c4bd02d351c8f`
- `src/cuda/pointwise.rs`: `d22f34ae688948cee3cc9a65402f1be0e12a845e9841fc9b45066e5961425e7c`
- `src/pointwise_indexing.rs`: `24e1873841b89da50cf6a5b971beb726a7aa19ce73af1bdd57a4993abee80521`
- `src/pointwise_ir.rs`: `97561e9de65b6e434db353973a4236cdf553a9ba36dc3fbab129bce7128a5d00`
- `src/pointwise_lowering.rs`: `83bb37fa3a0e5d587b45e29d40266721343eade806ae553b888ac014ce9cf1cb`
- `src/pointwise_program.rs`: `39ddb4cef369a5be03267ff160c4d0298996b239a5365c1db30fbb02d064f812`
- `src/pointwise_regions.rs`: `e29e80eb364403f7c3f1f5959325605bbac368eb1654b72eb07362b9dc886ee1`
- `src/python_nn_functional.rs`: `01ff3dba915279d4071eff1f0685301b1357b61b7d3b683fcf9ae1ae10f95e94`
- `src/python_pointwise.rs`: `dbb03cb2ef3719da784bbba0f789fc9a07ba22328254cc0833fad37bcdaa8641`
- `src/python_tensor_errors.rs`: `df9189d579706043d3062b61b6da8dcda15a74e633da8c02441ac5221ee0497a`
- `src/storage.rs`: `55a3337088bbe77a3dd556af6ba8c0a1a4de199d2a6a4470f5289b4d4eb33224`
- `src/tensor.rs`: `2b15f7e881fd22ceeebb628e24252a8b3a1c03e9db85b1e978b7f70fce01f355`
- `src/tensor_error.rs`: `508e2e8ed8bde2ec3ec0610c2fab03fb482577abdfee9fb80cc1ee860db3c1b1`
- `src/cuda/link.rs`: `6dbcc20a1314fad22e6c4467cc41bfec51f1bd032f46cdd9e4f37778891f01ae`
- `src/cuda/erf_provider.ll`: `b76c4e50caca289fb0f0de778c3f15905e188274ae9710ee1bf80d3e3a7a7d55`
- `src/cuda/erf_provider.ptx`: `d669b53d4f529a03c40d4b7eda3d0def5437e9a4edc52a130ed2d180075129de`
- `src/cuda/gelu.cu`: `333ab93c6774e4bfc0a18758e10eb74063f4769969c376a50f08a8065eaa243a`
- `src/cuda/gelu.ptx`: `c1b4d980155dd5d9d6a08cf2982e4797ed4271c1147df8bbe276c445e863c4c5`
- `tests/test_compile_gelu.py`: `f65d45c5809864962179c12f335414e201928a2570f1962c8058a6c56429e3d5`

## Final recheck: F1 and F2 resolved

F1 is resolved in the current check_namespace_guard: exact ModuleType is checked
before reading __dict__, and the existing native exact-key check runs before
.get(name). Independently repeated the hostile-key AST fixture against the
corrected function: it raises NotImplementedError for namespace keys with zero
user equality callbacks. Read the actual new cold/warm key and module-type
tests and target/gelu-linked/public-tests-003.log: 15 tests completed OK.
The native Tensor type is not subclassable; tests now check that actual boundary
and reject foreign protocol objects without invoking their hooks.

F2 is resolved for the requested bounded correctness evidence. Read the complete
public_probe.py and independently audited public-attempt-002, rather than
transferring credit from private-Erf success. Each formula gets one ordinary
unconfigured wrapper for its complete history. Eager and compiled matrices are
separate, unchanged between their corresponding native/reference legs. All
five observed process exits are zero and during-capture source manifests are
stable. Native compiled histories include no-body/no-eager-replay assertions.

| Pair | Histories | Calls per leg | History leaves | Timing checks | Total comparisons |
| --- | ---: | ---: | ---: | ---: | ---: |
| Ordinary native eager / reference eager | 7 | 21 | 21 | 12 | 33 |
| Public default native / reference compiled | 46 | 124 | 218 | 18 | 236 |
| Native eager with absent NVRTC / reference eager | 7 | 21 | 21 | 12 | 33 |

Independent verification rehashed/decoded 1,871 raw files (38,496,436 bytes),
checked all 590 retained snapshots with current/prior call IDs, unchanged input
post-state, native output nonaliasing/retention, metadata and current-context /
device-ordinal / allocation-context invariants for nonempty storage. Empty raw
records correctly contain zero bytes and do not invent device-pointer context
queries. Scalar records match the declared history and match across each pair.

All numerical comparisons pass the unchanged tolerance and signed-zero policy.
All three pairs have zero finite-bit differences and zero signed-zero differences.
Compiled outputs have 1,924 NaN-word differences; eager and no-NVRTC outputs have
none. These NaN differences do not imply payload-preserving semantics.

The 46 public formulas include 27 scalar-kind/constant cases, shared and
recomputed GELU, both competing-product output orders, six realization-threshold
chains, shape history, persistent scalar history, all supported namespace
spellings and metadata shapes/offsets. The historical six cancellation inputs
are present in both competing-product cases, including x=5; native/reference
output words match. Both positive and negative smallest subnormal inputs are
present in every namespace case, including ordinary eager and no-NVRTC.
Per-witness words and audit counts are retained in public-raw-audit.json.

The no-NVRTC leg records an intentionally absent explicit NVRTC override and no
libnvrtc mapping. It completes ordinary eager GELU plus the unrelated eager
control. This is an actual deployment check, not inference from source alone.
Timing records contain five warmups, 17 synchronized unprofiled samples and
changed-input checks. First-call numbers are per wrapper and may inherit prior
process cache warmup. This one-order diagnostic is non-scoring; it does not
replace fixed performance evaluation or establish no-regression performance.

### Packaging check

Independently opened the wheel in packaging-check.json and verified SHA256
6f162a0946ee7a0806bdd1fe9f335247b25e505e01574939918af6fdbac18347.
Its metadata declares `MIT AND LicenseRef-NVIDIA-CUDA`; all five listed license /
notice members match repository bytes and all 60 packaged Python files match
current Python sources. This resolves the checked wheel notice-inclusion gap.
No sdist was independently inspected and no legal clearance is inferred.

### Exact limits and final binding

The public capture is bound to probe SHA256
2a2c379799f24fd1c7866e4b4ec6dc47293a9459ff43c3eb3940cb6cd5d7812a,
recorded code commit 1bc7add2f6144ad6bd52343659926090d152985c with a dirty
implementation diff, and loaded extension SHA256
25a16e5a405f18bff3d84f2ac4d0327b0bc240338b0c94e382f591d67fde025c.
It is development correctness evidence, not a final clean-commit capture.

Current source hashes differ from captured hashes in src/cuda/link.rs,
src/cuda/pointwise.rs, src/pointwise_indexing.rs, src/pointwise_program.rs and
src/python_nn_functional.rs after the author's subsequent lint changes.
The finite measured result remains attributed to its recorded bytes; it is
not relabeled as measuring the newer files. Burner-owned final committed
captures and normal independent qualification remain outstanding.

No additional GPU/build/compiler execution was performed in this recheck.

Recheck assembled 2026-09-16T07:40:23.383615+00:00.
Current frontend SHA256: 31510d00933f58e5801c1066ccb1c7c91be43a55842bee9427acae5706529174.
Current tests SHA256: a392a8e8d7ba87e2af35d694cba4b14f4335657cec865d0922c6511017244afd.
