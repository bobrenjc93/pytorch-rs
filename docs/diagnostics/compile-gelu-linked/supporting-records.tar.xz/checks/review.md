# Bounded private-Erf source and generation audit

Judgment: no actionable source defect found within the requested private
prerequisite scope. This is not numerical acceptance, a complete implementation
review, deployment approval, or permission to proceed to public/eager GELU.
The actual 44-formula GPU result remains a separate gate.

I applied the narrow factual/design-prerequisite allowance in Moduler's
orchestrate/code-review skill. I independently read the actual changes, provider,
generator and current probe, the approved direct-libNVVM proposal/design gate,
its implementation review, and native-repair instructions. I did not author
these implementations. I ran no compiler, build, framework, GPU or test suite.
Python sources were syntax-checked with ast.parse; generation records and
inputs were independently rehashed. Only this local report was written.

## Source findings

- The source and optional dependency are emitted together. Dependency discovery
  reuses canonical_nodes and the existing locality/liveness traversal, including
  integer-zero erasure. The external declaration and ERF bytecode case appear
  only for a live canonical Erf. Original graph validation and actual-shape
  admission remain separate; reachable Erf rejects unequal actual input shapes.
- Non-Erf emitted text remains on its existing branch; NVRTC arithmetic options
  and explicit loader selection are unchanged. Relocatable compilation and
  lazy v2 linker symbols are conditional. This is a source observation, not a
  measured non-Erf performance or deployment certificate.
- The private unary node participates in existing operand, CSE, call-rank,
  numerical-region and bytecode owners. No alternate planner, interpreter,
  cache, public callable or tensor method was added. Existing tests gain
  assertions for live/dead/constant Erf dependencies and invalid operands.
- One Pending owns successful link state. PTX validation requires exactly one
  final NUL, mutable copies survive each cuLinkAddData call, and completed cubin
  storage survives module loading. A function-lookup error unloads its module;
  the pending state drops on later failures. Existing Kernel owns successful
  module lifetime. No cubin copy is retained. Failure fixtures cover absent
  symbols, malformed/missing-NUL/unsupported PTX, unresolved dependency,
  missing function and repeated success, but I have not run those fixtures.

## Independent generation checks

Receipt: target/gelu-linked/generation/gelu-libnvvm-generation.6ypv7wzk.
Its declaration and both API/process reports were read, and every declared
input hash matches the current file. The original 389-byte wrapper is unchanged
(b76c4e50caca289fb0f0de778c3f15905e188274ae9710ee1bf80d3e3a7a7d55).
The official leg records exact submission of the complete 473,728-byte library
(1fc1bc8d4131d5a59a91fc26f4908886e231f842c9e83ae951979ff3df82bdb5)
through nvvmLazyAddModuleToProgram, using the declared six options and pinned
libNVVM. Both compile/destroy statuses and observed process exits are zero.

The official output is 1,544 bytes, SHA256
 d669b53d4f529a03c40d4b7eda3d0def5437e9a4edc52a130ed2d180075129de,
identical to src/cuda/erf_provider.ptx. It defines the visible float32 provider
without unresolved calls. The 741-byte no-library output retains __nv_erff as
an external call. Both API outputs equal their text file plus exactly one NUL;
both compiler logs are empty text with one-NUL API buffers. This distinguishes
actual library submission from the earlier ineffective directory selection.
It establishes this generation pair only, not driver linking or GPU math.

## Diagnostic protocol

The revised probe pins and reuses the historical fixtures and comparison
function, with 44 cases, 113 calls, 335 leaves and all six specified cancellation
inputs. Each reference case creates exactly one ordinary fw.compile wrapper
outside its full history; no reset, run_and_get_code or compile override is
present. Cache observation is passive and explicitly not a selected-executable
certificate. Native execution uses the actual compile/prepare/run entry points.

Raw storage is copied directly with synchronized driver DtoH operations;
finite bits, signed-zero differences and NaN payload limits are distinguished.
Records include post-call inputs, pointers and retained outputs named with both
current/prior call IDs. Current native outputs must be fresh, while reference
aliasing is observed without an inappropriate freshness assertion. The loaded
native extension is checked against process mappings and confined to the
worktree. Provider/executor identities, source stability, runtimes, physical
GPU inventory, times and child exits are recorded. These are source-level
protocol observations; execution/report integrity still requires raw audit.

## Remaining actionable delivery check

The complete official vendor terms already exist at
 docs/diagnostics/compile-gelu-vendor/notices/requested-CUDA11.8-LICENSE.txt,
with verified SHA256 b9ee12782ca117b887588d99ae1b8c24deb59105e05417fe28ffbd7a55896dd1.
Do not duplicate that file. If the private prerequisite survives and generated
vendor math remains in production, add a concise attribution/provenance pointer
and verify that the distributable wheel/source package actually includes
applicable notices. Current pyproject.toml declares MIT and has no explicit
vendor-notice inclusion. That packaging check is not a blocker to running the
private prerequisite and must not be mistaken for legal clearance.

If the actual-planner prerequisite fails, retain its precise negative evidence
and stop broad public/eager implementation, as the approved contract requires.

## Inspected source identities

Audit assembled 2026-09-16T07:22:07.251618+00:00.

- `src/cuda/jit.rs`: `28119dfb0d0c555f982e90b844802701016ffbc1927c4741ef7c4bd02d351c8f`
- `src/cuda/link.rs`: `6dbcc20a1314fad22e6c4467cc41bfec51f1bd032f46cdd9e4f37778891f01ae`
- `src/pointwise_ir.rs`: `97561e9de65b6e434db353973a4236cdf553a9ba36dc3fbab129bce7128a5d00`
- `src/pointwise_indexing.rs`: `24e1873841b89da50cf6a5b971beb726a7aa19ce73af1bdd57a4993abee80521`
- `src/pointwise_lowering.rs`: `83bb37fa3a0e5d587b45e29d40266721343eade806ae553b888ac014ce9cf1cb`
- `src/pointwise_regions.rs`: `e29e80eb364403f7c3f1f5959325605bbac368eb1654b72eb07362b9dc886ee1`
- `src/pointwise_program.rs`: `39ddb4cef369a5be03267ff160c4d0298996b239a5365c1db30fbb02d064f812`
- `src/python_pointwise.rs`: `dbb03cb2ef3719da784bbba0f789fc9a07ba22328254cc0833fad37bcdaa8641`
- `src/cuda/erf_provider.ll`: `b76c4e50caca289fb0f0de778c3f15905e188274ae9710ee1bf80d3e3a7a7d55`
- `src/cuda/erf_provider.ptx`: `d669b53d4f529a03c40d4b7eda3d0def5437e9a4edc52a130ed2d180075129de`
- `docs/diagnostics/compile-gelu-linked/generate_provider.py`: `f5803bfc59a03b2e013dd1ad8c3abca226b01a6a5a0463232f52261ffd474db7`
- `docs/diagnostics/compile-gelu-linked/probe.py`: `28396cb73c4c03cee71a0d01782f22d2db78d1f16af9fe33f1371ac0540bd518`
- `tests/test_compile_pointwise_erf.py`: `812e0bb5a3bb3ab3f6ae24568dd25ad02385d9196cb6df32152472ae7646fd84`

## Follow-up: capture-context correction and actual private matrix

This follow-up supersedes the earlier capture-protocol assessment for the old
probe; the original source-only review did not catch its assumption that every
CUDA allocation has an allocation context suitable for pushing. Attempt 001 is
retained in full. Its native report has 44 case errors, zero captured calls,
and process exit 1: cuCtxPushCurrent_v2 returned status 1 during input capture,
before any private executor was invoked. This is a diagnostic failure, not a
failed numerical comparison and not an observation that native GELU works.

I separately reviewed the complete correction. Probe SHA256 is now
 f5f99ceb9ea941fbcc7c46a840374f4482c4fa94ccc8ad9033c98ada32f32e4f.
It no longer changes the context stack. It checks a non-null current context,
current device and pointer device ordinal both zero, device memory type, and
an allocation context either null or equal to current. It synchronizes/copies
under that current context and checks the context afterward. The original
allocation context is retained separately. This is consistent with the actual
native pool allocation evidence: all native allocation-context observations
are null, while each leg has one stable non-null active context. No numerical
policy, fixture, compiler or production operation changed in this correction.
The saved attempt-002 probe and both source manifests bind exactly these bytes.

Independent read-only raw audit of target/gelu-linked/attempt-002:

- Both process receipts report exit 0. Both reports contain all 44 cases and
  113 calls, with stable during-capture source manifests equal across legs.
- Independently rehashed and decoded all 1,842 raw input/output/retention files
  (888,864 bytes). Checked raw words, hexadecimal float records, metadata,
  input immutability, output freshness for native execution, 704 retained
  snapshots and their current/prior filenames and preserved pointers/bytes.
- Independently applied the existing 1e-6 + 1e-5*abs(reference) numerical rule,
  equal-NaN rule and signed-zero rule over 335 leaves / 44,012 elements:
  zero acceptance failures, zero finite-bit differences, zero signed-zero
  differences. All 1,924 differing words are NaNs; payload/sign equality is
  outside the declared numerical contract. This reproduces comparison.json.
- Verified the actually mapped native extension record and its then-current
  file hash 6160845a0f4a194ef08575ed9de02e99128a9725c197a50ee3ead5d692940bd1,
  all nine retained provider/generation inputs, 45 executor PTX files, and
  180 selected reference-cache records. Each cache history has 113 entries.
- Native records identify NVRTC 13.0 with compute_90, existing arithmetic flags
  and conditional RDC; both runtime API versions are 13000. Both legs name
  H100 physical GPU0 UUID GPU-8f8e55a5-a9eb-eb79-bc43-807a19bcb1c1 and driver
  580.82.07. These are inspected recorded measurements, not fresh GPU probes.

Native process interval: 2026-09-16 07:23:30.706466–07:23:34.950011 UTC.
Reference process interval: 07:23:44.059800–07:24:18.440877 UTC.
The original comparison was recorded at 07:24:27.395602 UTC.
Audit counts and report hashes are saved in target/gelu-linked/raw-audit.json.

Conclusion: this exact private planner/provider matrix satisfies its unchanged
numerical prerequisite. It does not prove integrated public-default compiled
GELU, eager GELU, public histories, packaging, performance, or merge readiness.
Public implementation changes made after this capture are not covered by this
result. No new GPU/compiler execution or library loading occurred in this audit.

Follow-up assembled 2026-09-16T07:25:29.671653+00:00.
