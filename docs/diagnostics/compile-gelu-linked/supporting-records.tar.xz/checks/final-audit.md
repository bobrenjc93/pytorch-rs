# Final bounded GELU audit

No new actionable production-source concern found in the final small delta.
Earlier F1 namespace admission and F2 public-verification findings remain
resolved as documented in public-review.md. This is not a full qualification,
clean-commit capture or merge approval.

The cfg changes in Storage::cuda_gelu_float32 and Tensor::gelu_cuda narrow those
crate-private Python bridge layers to python-bindings. Their sole production
caller is the Python bridge; direct CUDA storage/kernel tests retain their own
test configuration. This does not narrow the promised Python GELU surface or
remove the underlying CUDA storage tests. The inspected lint changes are local
attributes/comments/test conversions. README's one license line accurately
routes original-code versus generated-vendor terms without changing the managed
progress section.

Read the final 15-test log: 15 tests, OK. Read clippy-default-final.log: successful
default dev-profile completion. These are existing execution records; I did not
execute a test, build, compiler or GPU operation in this audit.

## Fixed-corpus diagnostic interpretation

Independently parsed fixed-diagnostic.json: public-default-compile-v2,
framework.compile(program), diagnostic=true, valid=false. It contains all 112
cells, including 56 CUDA cells, and six reference/candidate process reports
(CPU pair plus both CUDA orders). There are 22 passing overall cells and 22
passing CUDA cells. Both CUDA GELU variants pass; both CPU GELU variants remain
unsupported. No cell was removed from the denominator.

Reported diagnostic aggregations are coverage 21.0 and CUDA performance
33.53607211176525. These are unqualified diagnostic numbers, not official scores
or evidence that the rejection threshold has been cleared. The dirty source
identity and valid=false flag must remain visible. The official unchanged
coverage/performance commands still require a clean final code commit.
Read-only git comparison found no changes to scripts, benchmarks or .github
against accepted main 60202557b4f110d07777f585e804ab5f55e1ff7b.

## Source distribution notices

Independently rehashed the sdist archive named by sdist-check.json:
5af9e79e3527827b35f8790cb881b968803eee45f03580b797f5c7b24ebc2334.
All nine listed generated-source/PTX/notice/license members match both their
recorded hashes and current repository bytes. This complements the earlier
independent wheel check (five included license/notice files, proper license
expression, matching Python sources). It is packaging evidence, not legal
clearance or an sdist rebuild test.

## Remaining mandatory validation and attribution

- Burner-owned clean-commit public/eager/no-NVRTC captures are still pending.
  Public-attempt-002 remains attributed to its actual pre-lint dirty code and
  loaded binary; it must not be relabeled as a clean/final-head measurement.
- The unchanged official fixed coverage and CUDA-performance evaluations,
  independent final review, full normal qualification and exact-head CI remain
  delivery gates. The completed --diagnostic run cannot replace them.
- Current bounded evidence supports this H100 implementation only. No claim of
  performance acceptance, other-GPU deployment certification, general PyTorch
  parity or merge approval follows.

I found no additional prerequisite requiring new implementation beyond those
existing final lifecycle gates. Compact evidence documentation is being prepared
by the author and was not yet present for a final archive/index integrity audit.

Assembled 2026-09-16T07:47:08.709020+00:00.

- `src/storage.rs`: `e12f6df00955c040cb8b6e4f0474c9ef2133153ffc52e3667cdc6510f92b2ce3`
- `src/tensor.rs`: `5c4dad4f584c2400ff8c8d6d995914bd83dae3fc44132abe286fb4f96cb19a08`
- `python/torch_rs/_compile_pointwise.py`: `31510d00933f58e5801c1066ccb1c7c91be43a55842bee9427acae5706529174`
- `tests/test_compile_gelu.py`: `a392a8e8d7ba87e2af35d694cba4b14f4335657cec865d0922c6511017244afd`
- `target/gelu-linked/fixed-diagnostic.json`: `7712d80bd2a9bfe3257a6a0898ba717707000e527898e761f60aa685bf74cea3`
- `target/gelu-linked/public-tests-final.log`: `eeef8b05acaf8d890cd23d2e368f29da240b2f74f75157c50558879bc6da0501`
- `target/gelu-linked/clippy-default-final.log`: `6d2073d91eaadfa19ff716ec86c5ebe6073a68d56e35616faa3a3854afcf4a63`
- `target/gelu-linked/sdist-check.json`: `662e0b7c234ea58ea54950dca4cdb60a229486ee0a38544cbf1f686c10027408`
