# AOT ID: ['57_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_6ada2b33/target/gelu-linked/public-attempt-002/reference-compiled/TORCHINDUCTOR_CACHE_DIR/sj/csj5xulu7mxixhoycmef6ydnuispcgqlr5ahqdudtpyomft2elon.py
# Topologically Sorted Source Nodes: [v, v_1, v_2, v_3, v_4, v_5, v_6, v_7, v_8, v_9, v_10, v_11, v_12, v_13, v_14, v_15, v_16, v_17, v_18, v_19, v_20, v_21, v_22, v_23, v_24, v_25, v_26, v_27, v_28, v_29, v_30, v_31, v_32, v_33, v_34, v_35, v_36, v_37, v_38, v_39, v_40, v_41, v_42, v_43, v_44, v_45, v_46, v_47, v_48, v_49, v_50, v_51, v_52, v_53, v_54, v_55, v_56, v_57, v_58, v_59, v_60, v_61, v_62, v_63, v_64, v_65, v_66, v_67, v_68, v_69, v_70, v_71, v_72, v_73, v_74, v_75, v_76, v_77, v_78, v_79, v_80, v_81, v_82, v_83, v_84, v_85, v_86, v_87, v_88, v_89, v_90, v_91, v_92, v_93, v_94, v_95, v_96, v_97, v_98, v_99, v_100, v_101, g, mul, add], Original ATen: [aten.sin, aten.gelu, aten.mul, aten.add]
# Source node to ATen node mapping:
#   add => add_209
#   g => add_204, erf, mul_102, mul_103, mul_104
#   mul => mul_106
#   v => sin
#   v_1 => sin_1
#   v_10 => sin_10
#   v_100 => sin_100
#   v_101 => sin_101
#   v_11 => sin_11
#   v_12 => sin_12
#   v_13 => sin_13
#   v_14 => sin_14
#   v_15 => sin_15
#   v_16 => sin_16
#   v_17 => sin_17
#   v_18 => sin_18
#   v_19 => sin_19
#   v_2 => sin_2
#   v_20 => sin_20
#   v_21 => sin_21
#   v_22 => sin_22
#   v_23 => sin_23
#   v_24 => sin_24
#   v_25 => sin_25
#   v_26 => sin_26
#   v_27 => sin_27
#   v_28 => sin_28
#   v_29 => sin_29
#   v_3 => sin_3
#   v_30 => sin_30
#   v_31 => sin_31
#   v_32 => sin_32
#   v_33 => sin_33
#   v_34 => sin_34
#   v_35 => sin_35
#   v_36 => sin_36
#   v_37 => sin_37
#   v_38 => sin_38
#   v_39 => sin_39
#   v_4 => sin_4
#   v_40 => sin_40
#   v_41 => sin_41
#   v_42 => sin_42
#   v_43 => sin_43
#   v_44 => sin_44
#   v_45 => sin_45
#   v_46 => sin_46
#   v_47 => sin_47
#   v_48 => sin_48
#   v_49 => sin_49
#   v_5 => sin_5
#   v_50 => sin_50
#   v_51 => sin_51
#   v_52 => sin_52
#   v_53 => sin_53
#   v_54 => sin_54
#   v_55 => sin_55
#   v_56 => sin_56
#   v_57 => sin_57
#   v_58 => sin_58
#   v_59 => sin_59
#   v_6 => sin_6
#   v_60 => sin_60
#   v_61 => sin_61
#   v_62 => sin_62
#   v_63 => sin_63
#   v_64 => sin_64
#   v_65 => sin_65
#   v_66 => sin_66
#   v_67 => sin_67
#   v_68 => sin_68
#   v_69 => sin_69
#   v_7 => sin_7
#   v_70 => sin_70
#   v_71 => sin_71
#   v_72 => sin_72
#   v_73 => sin_73
#   v_74 => sin_74
#   v_75 => sin_75
#   v_76 => sin_76
#   v_77 => sin_77
#   v_78 => sin_78
#   v_79 => sin_79
#   v_8 => sin_8
#   v_80 => sin_80
#   v_81 => sin_81
#   v_82 => sin_82
#   v_83 => sin_83
#   v_84 => sin_84
#   v_85 => sin_85
#   v_86 => sin_86
#   v_87 => sin_87
#   v_88 => sin_88
#   v_89 => sin_89
#   v_9 => sin_9
#   v_90 => sin_90
#   v_91 => sin_91
#   v_92 => sin_92
#   v_93 => sin_93
#   v_94 => sin_94
#   v_95 => sin_95
#   v_96 => sin_96
#   v_97 => sin_97
#   v_98 => sin_98
#   v_99 => sin_99
# Graph fragment:
#   %arg1_1 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %sin_99 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=sin_99]
#   %mul_104 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=mul_104]
#   %sin : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%arg1_1,), kwargs = {})
#   %sin_1 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin,), kwargs = {})
#   %sin_2 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_1,), kwargs = {})
#   %sin_3 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_2,), kwargs = {})
#   %sin_4 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_3,), kwargs = {})
#   %sin_5 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_4,), kwargs = {})
#   %sin_6 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_5,), kwargs = {})
#   %sin_7 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_6,), kwargs = {})
#   %sin_8 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_7,), kwargs = {})
#   %sin_9 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_8,), kwargs = {})
#   %sin_10 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_9,), kwargs = {})
#   %sin_11 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_10,), kwargs = {})
#   %sin_12 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_11,), kwargs = {})
#   %sin_13 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_12,), kwargs = {})
#   %sin_14 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_13,), kwargs = {})
#   %sin_15 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_14,), kwargs = {})
#   %sin_16 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_15,), kwargs = {})
#   %sin_17 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_16,), kwargs = {})
#   %sin_18 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_17,), kwargs = {})
#   %sin_19 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_18,), kwargs = {})
#   %sin_20 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_19,), kwargs = {})
#   %sin_21 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_20,), kwargs = {})
#   %sin_22 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_21,), kwargs = {})
#   %sin_23 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_22,), kwargs = {})
#   %sin_24 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_23,), kwargs = {})
#   %sin_25 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_24,), kwargs = {})
#   %sin_26 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_25,), kwargs = {})
#   %sin_27 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_26,), kwargs = {})
#   %sin_28 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_27,), kwargs = {})
#   %sin_29 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_28,), kwargs = {})
#   %sin_30 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_29,), kwargs = {})
#   %sin_31 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_30,), kwargs = {})
#   %sin_32 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_31,), kwargs = {})
#   %sin_33 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_32,), kwargs = {})
#   %sin_34 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_33,), kwargs = {})
#   %sin_35 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_34,), kwargs = {})
#   %sin_36 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_35,), kwargs = {})
#   %sin_37 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_36,), kwargs = {})
#   %sin_38 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_37,), kwargs = {})
#   %sin_39 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_38,), kwargs = {})
#   %sin_40 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_39,), kwargs = {})
#   %sin_41 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_40,), kwargs = {})
#   %sin_42 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_41,), kwargs = {})
#   %sin_43 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_42,), kwargs = {})
#   %sin_44 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_43,), kwargs = {})
#   %sin_45 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_44,), kwargs = {})
#   %sin_46 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_45,), kwargs = {})
#   %sin_47 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_46,), kwargs = {})
#   %sin_48 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_47,), kwargs = {})
#   %sin_49 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_48,), kwargs = {})
#   %sin_50 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_49,), kwargs = {})
#   %sin_51 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_50,), kwargs = {})
#   %sin_52 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_51,), kwargs = {})
#   %sin_53 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_52,), kwargs = {})
#   %sin_54 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_53,), kwargs = {})
#   %sin_55 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_54,), kwargs = {})
#   %sin_56 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_55,), kwargs = {})
#   %sin_57 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_56,), kwargs = {})
#   %sin_58 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_57,), kwargs = {})
#   %sin_59 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_58,), kwargs = {})
#   %sin_60 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_59,), kwargs = {})
#   %sin_61 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_60,), kwargs = {})
#   %sin_62 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_61,), kwargs = {})
#   %sin_63 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_62,), kwargs = {})
#   %sin_64 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_63,), kwargs = {})
#   %sin_65 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_64,), kwargs = {})
#   %sin_66 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_65,), kwargs = {})
#   %sin_67 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_66,), kwargs = {})
#   %sin_68 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_67,), kwargs = {})
#   %sin_69 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_68,), kwargs = {})
#   %sin_70 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_69,), kwargs = {})
#   %sin_71 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_70,), kwargs = {})
#   %sin_72 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_71,), kwargs = {})
#   %sin_73 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_72,), kwargs = {})
#   %sin_74 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_73,), kwargs = {})
#   %sin_75 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_74,), kwargs = {})
#   %sin_76 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_75,), kwargs = {})
#   %sin_77 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_76,), kwargs = {})
#   %sin_78 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_77,), kwargs = {})
#   %sin_79 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_78,), kwargs = {})
#   %sin_80 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_79,), kwargs = {})
#   %sin_81 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_80,), kwargs = {})
#   %sin_82 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_81,), kwargs = {})
#   %sin_83 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_82,), kwargs = {})
#   %sin_84 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_83,), kwargs = {})
#   %sin_85 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_84,), kwargs = {})
#   %sin_86 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_85,), kwargs = {})
#   %sin_87 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_86,), kwargs = {})
#   %sin_88 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_87,), kwargs = {})
#   %sin_89 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_88,), kwargs = {})
#   %sin_90 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_89,), kwargs = {})
#   %sin_91 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_90,), kwargs = {})
#   %sin_92 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_91,), kwargs = {})
#   %sin_93 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_92,), kwargs = {})
#   %sin_94 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_93,), kwargs = {})
#   %sin_95 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_94,), kwargs = {})
#   %sin_96 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_95,), kwargs = {})
#   %sin_97 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_96,), kwargs = {})
#   %sin_98 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_97,), kwargs = {})
#   %sin_99 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_98,), kwargs = {})
#   %sin_100 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_99,), kwargs = {})
#   %sin_101 : Tensor "f32[s77][1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.sin.default](args = (%sin_100,), kwargs = {})
#   %mul_102 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_101, 0.5), kwargs = {})
#   %mul_103 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_101, 0.7071067811865476), kwargs = {})
#   %erf : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.erf.default](args = (%mul_103,), kwargs = {})
#   %add_204 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%erf, 1), kwargs = {})
#   %mul_104 : Tensor "f32[s77][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_102, %add_204), kwargs = {})
#   %mul_106 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_101, %sin_101), kwargs = {})
#   %add_209 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_104, %mul_106), kwargs = {})
#   return %sin_99,%mul_104,%add_209
triton_poi_fused_add_gelu_mul_sin_0 = async_compile.triton('triton_poi_fused_add_gelu_mul_sin_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_gelu_mul_sin_0', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_gelu_mul_sin_0(in_out_ptr0, in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl_math.sin(tmp0)
    tmp2 = tl_math.sin(tmp1)
    tmp3 = tl_math.sin(tmp2)
    tmp4 = tl_math.sin(tmp3)
    tmp5 = tl_math.sin(tmp4)
    tmp6 = tl_math.sin(tmp5)
    tmp7 = tl_math.sin(tmp6)
    tmp8 = tl_math.sin(tmp7)
    tmp9 = tl_math.sin(tmp8)
    tmp10 = tl_math.sin(tmp9)
    tmp11 = tl_math.sin(tmp10)
    tmp12 = tl_math.sin(tmp11)
    tmp13 = tl_math.sin(tmp12)
    tmp14 = tl_math.sin(tmp13)
    tmp15 = tl_math.sin(tmp14)
    tmp16 = tl_math.sin(tmp15)
    tmp17 = tl_math.sin(tmp16)
    tmp18 = tl_math.sin(tmp17)
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl_math.sin(tmp19)
    tmp21 = tl_math.sin(tmp20)
    tmp22 = tl_math.sin(tmp21)
    tmp23 = tl_math.sin(tmp22)
    tmp24 = tl_math.sin(tmp23)
    tmp25 = tl_math.sin(tmp24)
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl_math.sin(tmp26)
    tmp28 = tl_math.sin(tmp27)
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl_math.sin(tmp29)
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl_math.sin(tmp31)
    tmp33 = tl_math.sin(tmp32)
    tmp34 = tl_math.sin(tmp33)
    tmp35 = tl_math.sin(tmp34)
    tmp36 = tl_math.sin(tmp35)
    tmp37 = tl_math.sin(tmp36)
    tmp38 = tl_math.sin(tmp37)
    tmp39 = tl_math.sin(tmp38)
    tmp40 = tl_math.sin(tmp39)
    tmp41 = tl_math.sin(tmp40)
    tmp42 = tl_math.sin(tmp41)
    tmp43 = tl_math.sin(tmp42)
    tmp44 = tl_math.sin(tmp43)
    tmp45 = tl_math.sin(tmp44)
    tmp46 = tl_math.sin(tmp45)
    tmp47 = tl_math.sin(tmp46)
    tmp48 = tl_math.sin(tmp47)
    tmp49 = tl_math.sin(tmp48)
    tmp50 = tl_math.sin(tmp49)
    tmp51 = tl_math.sin(tmp50)
    tmp52 = tl_math.sin(tmp51)
    tmp53 = tl_math.sin(tmp52)
    tmp54 = tl_math.sin(tmp53)
    tmp55 = tl_math.sin(tmp54)
    tmp56 = tl_math.sin(tmp55)
    tmp57 = tl_math.sin(tmp56)
    tmp58 = tl_math.sin(tmp57)
    tmp59 = tl_math.sin(tmp58)
    tmp60 = tl_math.sin(tmp59)
    tmp61 = tl_math.sin(tmp60)
    tmp62 = tl_math.sin(tmp61)
    tmp63 = tl_math.sin(tmp62)
    tmp64 = tl_math.sin(tmp63)
    tmp65 = tl_math.sin(tmp64)
    tmp66 = tl_math.sin(tmp65)
    tmp67 = tl_math.sin(tmp66)
    tmp68 = tl_math.sin(tmp67)
    tmp69 = tl_math.sin(tmp68)
    tmp70 = tl_math.sin(tmp69)
    tmp71 = tl_math.sin(tmp70)
    tmp72 = tl_math.sin(tmp71)
    tmp73 = tl_math.sin(tmp72)
    tmp74 = tl_math.sin(tmp73)
    tmp75 = tl_math.sin(tmp74)
    tmp76 = tl_math.sin(tmp75)
    tmp77 = tl_math.sin(tmp76)
    tmp78 = tl_math.sin(tmp77)
    tmp79 = tl_math.sin(tmp78)
    tmp80 = tl_math.sin(tmp79)
    tmp81 = tl_math.sin(tmp80)
    tmp82 = tl_math.sin(tmp81)
    tmp83 = tl_math.sin(tmp82)
    tmp84 = tl_math.sin(tmp83)
    tmp85 = tl_math.sin(tmp84)
    tmp86 = tl_math.sin(tmp85)
    tmp87 = tl_math.sin(tmp86)
    tmp88 = tl_math.sin(tmp87)
    tmp89 = tl_math.sin(tmp88)
    tmp90 = tl_math.sin(tmp89)
    tmp91 = tl_math.sin(tmp90)
    tmp92 = tl_math.sin(tmp91)
    tmp93 = tl_math.sin(tmp92)
    tmp94 = tl_math.sin(tmp93)
    tmp95 = tl_math.sin(tmp94)
    tmp96 = tl_math.sin(tmp95)
    tmp97 = tl_math.sin(tmp96)
    tmp98 = tl_math.sin(tmp97)
    tmp99 = tl_math.sin(tmp98)
    tmp100 = tl_math.sin(tmp99)
    tmp101 = tl_math.sin(tmp100)
    tmp102 = tl_math.sin(tmp101)
    tmp103 = tl.full([1], 0.5, tl.float32)
    tmp104 = tmp102 * tmp103
    tmp105 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp106 = tmp102 * tmp105
    tmp107 = libdevice.erf(tmp106)
    tmp108 = tl.full([1], 1.0, tl.float32)
    tmp109 = tmp107 + tmp108
    tmp110 = tmp104 * tmp109
    tmp111 = tmp102 * tmp102
    tmp112 = tmp110 + tmp111
    tl.store(out_ptr0 + (x0), tmp110, xmask)
    tl.store(in_out_ptr0 + (x0), tmp112, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        s77 = arg0_1
        assert_size_stride(arg1_1, (s77, ), (1, ), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((s77, ), (1, ), torch.float32)
            buf1 = empty_strided_cuda((s77, ), (1, ), torch.float32)
            buf2 = buf0; del buf0  # reuse
            # Topologically Sorted Source Nodes: [v, v_1, v_2, v_3, v_4, v_5, v_6, v_7, v_8, v_9, v_10, v_11, v_12, v_13, v_14, v_15, v_16, v_17, v_18, v_19, v_20, v_21, v_22, v_23, v_24, v_25, v_26, v_27, v_28, v_29, v_30, v_31, v_32, v_33, v_34, v_35, v_36, v_37, v_38, v_39, v_40, v_41, v_42, v_43, v_44, v_45, v_46, v_47, v_48, v_49, v_50, v_51, v_52, v_53, v_54, v_55, v_56, v_57, v_58, v_59, v_60, v_61, v_62, v_63, v_64, v_65, v_66, v_67, v_68, v_69, v_70, v_71, v_72, v_73, v_74, v_75, v_76, v_77, v_78, v_79, v_80, v_81, v_82, v_83, v_84, v_85, v_86, v_87, v_88, v_89, v_90, v_91, v_92, v_93, v_94, v_95, v_96, v_97, v_98, v_99, v_100, v_101, g, mul, add], Original ATen: [aten.sin, aten.gelu, aten.mul, aten.add]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_add_gelu_mul_sin_0.run(buf2, arg1_1, buf1, s77, stream=raw_stream0)
            del arg1_1
        return (buf1, buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 2
    arg1_1 = rand_strided((2, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
