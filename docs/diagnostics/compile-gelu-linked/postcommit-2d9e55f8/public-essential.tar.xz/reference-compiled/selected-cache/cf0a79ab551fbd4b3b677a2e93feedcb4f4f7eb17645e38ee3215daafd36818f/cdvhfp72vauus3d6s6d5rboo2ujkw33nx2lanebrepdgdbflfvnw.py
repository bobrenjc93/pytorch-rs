# AOT ID: ['54_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /data/users/bobren/a/pytorch-rs-burner/.burner/worktrees/agent_6ada2b33/target/gelu-linked/postcommit-2d9e55f8/public/reference-compiled/TORCHINDUCTOR_CACHE_DIR/42/c42inheetzey4nepislbohqeqxu4qsuzk36ri76g7hqvmnjy4j5j.py
# Topologically Sorted Source Nodes: [v, v_1, v_2, v_3, v_4, v_5, v_6, v_7, v_8, v_9, v_10, v_11, v_12, v_13, v_14, v_15, v_16, v_17, v_18, v_19, v_20, v_21, v_22, v_23, v_24, v_25, v_26, v_27, v_28, v_29, v_30, v_31, g, mul, add], Original ATen: [aten.sin, aten.gelu, aten.mul, aten.add]
# Source node to ATen node mapping:
#   add => add_69
#   g => add_64, erf, mul_32, mul_33, mul_34
#   mul => mul_36
#   v => sin
#   v_1 => sin_1
#   v_10 => sin_10
#   v_11 => sin_11
#   v_12 => sin_12
#   v_13 => sin_13
#   v_14 => sin_14
#   v_15 => sin_15
#   v_16 => sin_16
#   v_17 => sin_17
#   v_18 => sin_18
#   v_19 => sin_19
#   v_2 => sin_2
#   v_20 => sin_20
#   v_21 => sin_21
#   v_22 => sin_22
#   v_23 => sin_23
#   v_24 => sin_24
#   v_25 => sin_25
#   v_26 => sin_26
#   v_27 => sin_27
#   v_28 => sin_28
#   v_29 => sin_29
#   v_3 => sin_3
#   v_30 => sin_30
#   v_31 => sin_31
#   v_4 => sin_4
#   v_5 => sin_5
#   v_6 => sin_6
#   v_7 => sin_7
#   v_8 => sin_8
#   v_9 => sin_9
# Graph fragment:
#   %arg1_1 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=arg1_1]
#   %sin_31 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=sin_31]
#   %mul_34 : Tensor "f32[s77][1]cuda:0" = PlaceHolder[target=mul_34]
#   %sin : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%arg1_1,), kwargs = {})
#   %sin_1 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin,), kwargs = {})
#   %sin_2 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_1,), kwargs = {})
#   %sin_3 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_2,), kwargs = {})
#   %sin_4 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_3,), kwargs = {})
#   %sin_5 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_4,), kwargs = {})
#   %sin_6 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_5,), kwargs = {})
#   %sin_7 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_6,), kwargs = {})
#   %sin_8 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_7,), kwargs = {})
#   %sin_9 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_8,), kwargs = {})
#   %sin_10 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_9,), kwargs = {})
#   %sin_11 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_10,), kwargs = {})
#   %sin_12 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_11,), kwargs = {})
#   %sin_13 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_12,), kwargs = {})
#   %sin_14 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_13,), kwargs = {})
#   %sin_15 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_14,), kwargs = {})
#   %sin_16 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_15,), kwargs = {})
#   %sin_17 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_16,), kwargs = {})
#   %sin_18 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_17,), kwargs = {})
#   %sin_19 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_18,), kwargs = {})
#   %sin_20 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_19,), kwargs = {})
#   %sin_21 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_20,), kwargs = {})
#   %sin_22 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_21,), kwargs = {})
#   %sin_23 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_22,), kwargs = {})
#   %sin_24 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_23,), kwargs = {})
#   %sin_25 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_24,), kwargs = {})
#   %sin_26 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_25,), kwargs = {})
#   %sin_27 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_26,), kwargs = {})
#   %sin_28 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_27,), kwargs = {})
#   %sin_29 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_28,), kwargs = {})
#   %sin_30 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%sin_29,), kwargs = {})
#   %sin_31 : Tensor "f32[s77][1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.sin.default](args = (%sin_30,), kwargs = {})
#   %mul_32 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_31, 0.5), kwargs = {})
#   %mul_33 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_31, 0.7071067811865476), kwargs = {})
#   %erf : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.erf.default](args = (%mul_33,), kwargs = {})
#   %add_64 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%erf, 1), kwargs = {})
#   %mul_34 : Tensor "f32[s77][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_32, %add_64), kwargs = {})
#   %mul_36 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%sin_31, %sin_31), kwargs = {})
#   %add_69 : Tensor "f32[s77][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_34, %mul_36), kwargs = {})
#   return %sin_31,%mul_34,%add_69
triton_poi_fused_add_gelu_mul_sin_0 = async_compile.triton('triton_poi_fused_add_gelu_mul_sin_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_gelu_mul_sin_0', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 10}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_gelu_mul_sin_0(in_out_ptr0, in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask)
    tmp1 = tl_math.sin(tmp0)
    tmp2 = tl_math.sin(tmp1)
    tmp3 = tl_math.sin(tmp2)
    tmp4 = tl_math.sin(tmp3)
    tmp5 = tl_math.sin(tmp4)
    tmp6 = tl_math.sin(tmp5)
    tmp7 = tl_math.sin(tmp6)
    tmp8 = tl_math.sin(tmp7)
    tmp9 = tl_math.sin(tmp8)
    tmp10 = tl_math.sin(tmp9)
    tmp11 = tl_math.sin(tmp10)
    tmp12 = tl_math.sin(tmp11)
    tmp13 = tl_math.sin(tmp12)
    tmp14 = tl_math.sin(tmp13)
    tmp15 = tl_math.sin(tmp14)
    tmp16 = tl_math.sin(tmp15)
    tmp17 = tl_math.sin(tmp16)
    tmp18 = tl_math.sin(tmp17)
    tmp19 = tl_math.sin(tmp18)
    tmp20 = tl_math.sin(tmp19)
    tmp21 = tl_math.sin(tmp20)
    tmp22 = tl_math.sin(tmp21)
    tmp23 = tl_math.sin(tmp22)
    tmp24 = tl_math.sin(tmp23)
    tmp25 = tl_math.sin(tmp24)
    tmp26 = tl_math.sin(tmp25)
    tmp27 = tl_math.sin(tmp26)
    tmp28 = tl_math.sin(tmp27)
    tmp29 = tl_math.sin(tmp28)
    tmp30 = tl_math.sin(tmp29)
    tmp31 = tl_math.sin(tmp30)
    tmp32 = tl_math.sin(tmp31)
    tmp33 = tl.full([1], 0.5, tl.float32)
    tmp34 = tmp32 * tmp33
    tmp35 = tl.full([1], 0.7071067811865476, tl.float32)
    tmp36 = tmp32 * tmp35
    tmp37 = libdevice.erf(tmp36)
    tmp38 = tl.full([1], 1.0, tl.float32)
    tmp39 = tmp37 + tmp38
    tmp40 = tmp34 * tmp39
    tmp41 = tmp32 * tmp32
    tmp42 = tmp40 + tmp41
    tl.store(out_ptr0 + (x0), tmp40, xmask)
    tl.store(in_out_ptr0 + (x0), tmp42, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1 = args
        args.clear()
        s77 = arg0_1
        assert_size_stride(arg1_1, (s77, ), (1, ), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg1_1 = copy_if_misaligned(arg1_1)
            buf0 = empty_strided_cuda((s77, ), (1, ), torch.float32)
            buf1 = empty_strided_cuda((s77, ), (1, ), torch.float32)
            buf2 = buf0; del buf0  # reuse
            # Topologically Sorted Source Nodes: [v, v_1, v_2, v_3, v_4, v_5, v_6, v_7, v_8, v_9, v_10, v_11, v_12, v_13, v_14, v_15, v_16, v_17, v_18, v_19, v_20, v_21, v_22, v_23, v_24, v_25, v_26, v_27, v_28, v_29, v_30, v_31, g, mul, add], Original ATen: [aten.sin, aten.gelu, aten.mul, aten.add]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_add_gelu_mul_sin_0.run(buf2, arg1_1, buf1, s77, stream=raw_stream0)
            del arg1_1
        return (buf1, buf2, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = 2
    arg1_1 = rand_strided((2, ), (1, ), device='cuda:0', dtype=torch.float32)
    return [arg0_1, arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
