"""Instrumented development attribution only; not public-call performance evidence."""
import sys,pathlib,importlib.util,cProfile,pstats,json,ctypes,hashlib,time,importlib.abc
root=pathlib.Path.cwd(); spec=importlib.util.spec_from_file_location('diagnostic',root/'scripts/diagnose_compile_full_call.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,name,path=None,target=None):
  if name=='torch' or name.startswith('torch.'):raise ImportError('native only')
sys.meta_path.insert(0,Block())
import torch_rs as fw
from torch_rs import _compile_trace
runtime=ctypes.CDLL(__import__('os').environ['TORCH_RS_CUDART'])
trace='--trace' in sys.argv
cases=[]
for fn in (d.affine,d.polynomial,d.nested,d.views):
 for shape in ((257,),(13,29)):
  compiled=fw.compile(fn); warm=d.inputs(fw,fn,shape,0)
  for _ in range(5): compiled(*warm)
  for mode in ('reused','fresh'):
   args=[d.inputs(fw,fn,shape,i) for i in range(200)] if mode=='fresh' else [warm]*200
   profiler=cProfile.Profile(); sync_ns=[]
   if trace:d.checked(runtime,'cudaProfilerStart')
   for a in args:
    if not trace:profiler.enable()
    result=compiled(*a)
    if not trace:profiler.disable()
    start=time.perf_counter_ns();d.checked(runtime,'cudaDeviceSynchronize');sync_ns.append(time.perf_counter_ns()-start)
   if trace:d.checked(runtime,'cudaProfilerStop')
   if not trace:
    file=root/f'target/profiled-call/evidence/{fn.__name__}-{len(shape)}-{mode}.prof';profiler.dump_stats(file)
    stats=pstats.Stats(profiler); entries=[]
    for (filename,line,name),(primitive,calls,own,total,callers) in stats.stats.items():entries.append({'file':filename,'line':line,'name':name,'calls':calls,'own_seconds':own,'cumulative_seconds':total})
    cases.append({'program':fn.__name__,'shape':shape,'mode':mode,'calls':200,'total_instrumented_seconds':stats.total_tt,'entries':sorted(entries,key=lambda x:-x['cumulative_seconds']),'post_call_sync_ns':sync_ns})
report={'purpose':__doc__,'argv':sys.argv,'timestamp_ns':time.time_ns(),'python':sys.executable,'extension':_compile_trace._native.__file__,'extension_sha256':hashlib.sha256(pathlib.Path(_compile_trace._native.__file__).read_bytes()).hexdigest(),'device':d.device_info(runtime),'cases':cases}
(root/f'target/profiled-call/evidence/{"trace" if trace else "profile"}.json').write_text(json.dumps(report,indent=2)+'\n')
