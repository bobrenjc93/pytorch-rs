set -euo pipefail
source target/full-call/env.sh
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/profiled-call/evidence"
set -x
for pair in native-first:torch_rs reference-second:torch reference-first:torch native-second:torch_rs; do
 label="shape-${pair%:*}"; framework="${pair#*:}"
 export CUDA_CACHE_PATH="$PWD/target/profiled-call/cache/$label/cuda" TORCHINDUCTOR_CACHE_DIR="$PWD/target/profiled-call/cache/$label/inductor" TRITON_CACHE_DIR="$PWD/target/profiled-call/cache/$label/triton"
 options=()
 if [ "$framework" = torch_rs ]; then
  wheels=("$PWD/target/profiled-call/shape-wheels/"*.whl)
  options=(--import-dir "$PWD/target/profiled-call/shape-imports" --wheel "${wheels[0]}")
 fi
 "$PYO3_PYTHON" -B -I scripts/diagnose_compile_full_call.py --framework "$framework" --label "$label" --source-root "$PWD" --source-commit c48b91880e7379d952839c74eaf1d2fe97cdd1aa+uncommitted-shape-guards --output "$BURNER_EVALUATION_ARTIFACT_DIR/$label.json" "${options[@]}" > "$BURNER_EVALUATION_ARTIFACT_DIR/$label.log" 2>&1
done
