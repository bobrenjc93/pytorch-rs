"""Callback-free batching of the existing default compiler method guards."""
import unittest
from unittest.mock import patch
import torch_rs as native
from torch_rs import _compile_pointwise as frontend
from torch_rs import torch_rs as bridge


class MethodBindingGuards(unittest.TestCase):
    def test_current_recipe_and_private_export(self):
        self.assertIsNone(bridge._pointwise_method_binding_mismatch(frontend._METHOD_GUARDS, frontend._MISSING))
        self.assertNotIn('_pointwise_method_binding_mismatch', native.__all__)

    def test_identity_missing_and_first_mismatch_order(self):
        class A:
            value = object()
        missing = object()
        query = bridge._pointwise_method_binding_mismatch
        guards = ((A, (('absent', missing), ('value', A.value))),)
        self.assertIsNone(query(guards, missing))
        A.absent = None
        A.value = None
        self.assertEqual(query(guards, missing), 'absent')
        del A.absent
        self.assertEqual(query(guards, missing), 'value')

    def test_no_descriptor_equality_or_metaclass_callbacks(self):
        calls = []
        class Descriptor:
            def __get__(self, *args):
                calls.append('descriptor')
                raise AssertionError
            def __eq__(self, other):
                calls.append('equality')
                raise AssertionError
        class Meta(type):
            def __getattribute__(self, name):
                calls.append('metaclass')
                raise AssertionError
        class A:
            value = Descriptor()
        class B(metaclass=Meta):
            pass
        missing = object()
        query = bridge._pointwise_method_binding_mismatch
        self.assertIsNone(query(((A, (('value', A.__dict__['value']),)),), missing))
        self.assertEqual(query(((A, (('value', object()),)),), missing), 'value')
        with self.assertRaises(TypeError):
            query(((B, ()),), missing)
        self.assertEqual(calls, [])

    def test_malformed_exact_types_rejected_without_container_hooks(self):
        class Tuple(tuple):
            def __iter__(self): raise AssertionError('iteration')
        class String(str):
            def __hash__(self): raise AssertionError('hash')
        class A: pass
        for guards in (Tuple(), [], ((A, []),), ((A, (Tuple(('x', None)),)),),
                       ((A, ((String('x'), None),)),), ((A, (('x',),)),), ((object(), ()),)):
            with self.subTest(type=type(guards)), self.assertRaises(TypeError):
                bridge._pointwise_method_binding_mismatch(guards, object())

    def test_unused_method_patch_still_rejects_and_recovers(self):
        # CPU is deliberate: method checks precede device admission, no GPU needed.
        def f(x): return x + 1.0
        compiled = native.compile(f)
        x = native.tensor([1.0])
        with patch.object(native.Tensor, 'cos', object()):
            with self.assertRaisesRegex(NotImplementedError, 'patched Tensor operation binding: cos'):
                compiled(x)
        with self.assertRaisesRegex(NotImplementedError, 'default backend does not compile CPU'):
            compiled(x)
        self.assertFalse(compiled._torch_rs_pointwise_cache.graphs)
        self.assertFalse(compiled._torch_rs_pointwise_cache.executors)
        self.assertFalse(compiled._torch_rs_pointwise_cache.prepared)


if __name__ == '__main__':
    unittest.main()
