"""Development only: L's containment/build recipe, uncommitted T snapshot."""
from common import *
import io, shutil, tarfile, zipfile, sys
assert not (OUT/'development-started.json').exists()
e=envbase()
save(OUT/'development-started.json',dict(timestamp=now(),state=state(),resources=resources(),final_capture=False,reason='Burner owns the semantic commit; no T commit exists yet. No ordinary timings.'))
run('dev-compiler-preflight',[sys.executable,'-B',OUT/'compiler_preflight.py'],env=e)
paths=['Cargo.toml','Cargo.lock','src','python','pyproject.toml','rust-toolchain.toml','uv.lock','README.md','LICENSE','AGENTS.md','tests','scripts','.github']
tracked=git('ls-tree','-r','--name-only','HEAD').decode().splitlines()
paths += [n for n in tracked if n.startswith('docs/') and n.endswith('.py')]
s=OUT/'exports/T';s.mkdir(parents=True)
b=git('-c','core.attributesFile=/dev/null','archive','HEAD','--',*paths)
(OUT/'exports/C-source.tar').write_bytes(b)
with tarfile.open(fileobj=io.BytesIO(b)) as t:t.extractall(s,filter='data')
for top in ('python','src','tests'):
 for p in (ROOT/top).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:
   dest=s/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
patch=git('diff','HEAD','--binary');(OUT/'development.patch').write_bytes(patch)
save(OUT/'exports/T-manifest.json',dict(commit=None,base_commit=REFS['C'],development_snapshot=True,patch_sha256=sha(OUT/'development.patch'),files={str(p.relative_to(s)):sha(p) for p in sorted(s.rglob('*')) if p.is_file()}))
for tag,original in [('312',Path('/usr/local/fbcode/platform010')),('314',Path('/home/bobren/.local/share/uv/python/cpython-3.14.5-linux-x86_64-gnu'))]:
 resources()
 d=OUT/tag/'T';s=d/'source';shutil.copytree(OUT/'exports/T',s)
 shutil.copy2(OUT/'exports/T-manifest.json',d/'source-manifest.json')
 dest=s/'target/interpreters'/tag
 if tag=='312':
  (dest/'bin').mkdir(parents=True);(dest/'lib').mkdir()
  shutil.copy2(original/'bin/python3.12',dest/'bin/python3.12')
  shutil.copytree(original/'lib/python3.12',dest/'lib/python3.12',ignore=shutil.ignore_patterns('site-packages','__pycache__'))
  shutil.copytree(original/'include/python3.12',dest/'include/python3.12')
  for p in (original/'lib').glob('libpython3.12*'):shutil.copy2(p,dest/'lib'/p.name)
 else:shutil.copytree(original,dest,ignore=shutil.ignore_patterns('site-packages','__pycache__'))
 minor='3.12' if tag=='312' else '3.14';py=dest/'bin'/('python'+minor)
 identity=json.loads(run('dev-'+tag+'-interpreter',[py,'-c','import sys,sysconfig,json; from pathlib import Path; print(json.dumps({"version":sys.version,"executable":sys.executable,"resolved_executable":str(Path(sys.executable).resolve()),"prefix":sys.prefix,"paths":sysconfig.get_paths(),"flags":repr(sys.flags)},indent=2)); assert sys.version_info[:3] == '+repr((3,12,14) if tag=='312' else (3,14,5))]))
 save(d/'interpreter.json',dict(original=str(original),root=str(dest),executable=str(py),sha256=sha(py),identity=identity,files={str(p.relative_to(dest)):sha(p) for p in sorted(dest.rglob('*')) if p.is_file()}))
 for parent in s.parents:
  for n in ('.cargo/config','.cargo/config.toml'):assert not (parent/n).exists(),str(parent/n)
 v=s/'target/venv';e=envbase();e.update(UV_PROJECT_ENVIRONMENT=str(v))
 run('dev-'+tag+'-venv',['uv','--no-config','venv','--python',py,v],env=e)
 run('dev-'+tag+'-dependencies',['uv','--no-config','sync','--locked','--python',v/'bin/python','--no-install-project','--group','dev','--group','reference'],cwd=s,env=e)
 runtime=v/('lib/python'+minor+'/site-packages/nvidia/cu13/lib/libcudart.so.13')
 command=[v/'bin/python','-I','-B',OUT/'layout_probe.py',s,s/'target/layout-probe',d/'layout-probe-input.json']
 save(d/'layout-probe-input.json',dict(command=list(map(str,command)),source=str(s),runtime_path=str(runtime.resolve()),runtime_sha256=sha(runtime),gpu_uuid=GPU))
 e.update(VIRTUAL_ENV=str(v),TORCH_RS_VERIFY_VIRTUALENV=str(v),TORCH_RS_CUDART=str(runtime),TORCH_RS_NVRTC=str(runtime.parent/'libnvrtc.so.13'),LD_LIBRARY_PATH=str(runtime.parent))
 run('dev-'+tag+'-layout-gpu-before',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
 try:run('dev-'+tag+'-layout-probe',command,cwd=s,env=e)
 finally:run('dev-'+tag+'-layout-gpu-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
save(OUT/'development-setup-complete.json',dict(timestamp=now()))
