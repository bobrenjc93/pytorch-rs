"""Fresh release development builds; no frozen capture or timing phases."""
from common import *
import shutil,zipfile,sys
assert (OUT/'development-setup-complete.json').exists()
assert not (OUT/'development-build3-started.json').exists()
save(OUT/'development-build3-started.json',dict(timestamp=now(),state=state()))
# Refresh author-owned source after setup; inventory this development snapshot.
for tag in ('312','314'):
 d=OUT/tag/'T';s=d/'source'
 for top in ('python','src','tests'):
  for p in (ROOT/top).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts:
    dest=s/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 m=json.loads((d/'source-manifest.json').read_text())
 m['files'].update({str(p.relative_to(s)):sha(p) for top in ('src','python','tests') for p in (s/top).rglob('*') if p.is_file() and '__pycache__' not in p.parts})
 save(d/'source-manifest.json',m)
for tag,minor in [('312','3.12'),('314','3.14')]:
 resources()
 d=OUT/tag/'T';s=d/'source';v=s/'target/venv';e=envbase()
 e.update(VIRTUAL_ENV=str(v),PYO3_PYTHON=str(v/'bin/python'),TORCH_RS_VERIFY_VIRTUALENV=str(v),CARGO_TARGET_DIR=str(d/'cargo-target'),UV_PROJECT_ENVIRONMENT=str(v))
 label='dev3-'+tag
 if tag=='312':
  run('dev3-cargo-fetch',['cargo','fetch','--locked'],cwd=s,env=e)
  run('dev3-rustfmt',['cargo','fmt','--check'],cwd=s,env=e)
  run('dev3-cargo-check',['cargo','check','--locked','--offline','--features','extension-module'],cwd=s,env=e)
 run(label+'-compiler-preflight',[v/'bin/python',OUT/'compiler_preflight.py',label],cwd=s,env=e)
 run(label+'-build-gpu-before',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
 queued=time.time()
 try:run(label+'-build-lock',[v/'bin/python',s/'scripts/run_with_unix_lock.py',OUT/'release-build.lock','--',v/'bin/python',OUT/'build.py',label,s,v,str(queued)],cwd=s,env=e)
 finally:run(label+'-build-gpu-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
 wheel,=(d/'wheels').glob('*.whl');manifest=json.loads((d/'source-manifest.json').read_text())
 assert all(sha(s/n)==h for n,h in manifest['files'].items())
 with zipfile.ZipFile(wheel) as z:
  pys=[n for n in z.namelist() if n.endswith('.py')]
  for n in pys:assert z.read(n)==(s/'python'/n).read_bytes(),n
  native,=[n for n in z.namelist() if n.endswith('.so')]
  native_hash=hashlib.sha256(z.read(native)).hexdigest()
  payload={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
 binding=dict(commit=None,development_snapshot=True,wheel=str(wheel),wheel_sha256=sha(wheel),wheel_payload=payload,native_member=native,native_sha256=native_hash,source_manifest=str(d/'source-manifest.json'))
 run(label+'-install',['uv','--no-config','pip','install','--python',v/'bin/python','--no-deps',wheel],cwd=s,env=e)
 site=v/('lib/python'+minor+'/site-packages');installed=site/native
 assert sha(installed)==native_hash
 binding['installed_payload']={str(p.relative_to(site)):sha(p) for p in sorted((site/'torch_rs').rglob('*')) if p.is_file()}
 for n in pys:assert binding['installed_payload'][n]==payload[n]
 save(OUT/tag/'bindings.json',{'T':binding})
 run(label+'-native-verifier',[v/'bin/python',s/'.github/scripts/verify_native_extension.py'],cwd=s,env=e)
save(OUT/'development-build3-complete.json',dict(timestamp=now()))
