"""Four development correctness phases. No performance phase is enabled."""
from common import *
import sys,traceback
assert (OUT/'development-build4-complete.json').exists()
assert not (OUT/'development-tests-started.json').exists()
save(OUT/'development-tests-started.json',dict(timestamp=now(),state=state(),final_capture=False))
def env(tag):
 d=OUT/tag/'T';s=d/'source';v=s/'target/venv';lib=v/('lib/python'+('3.12' if tag=='312' else '3.14')+'/site-packages/nvidia/cu13/lib');e=envbase()
 e.update(VIRTUAL_ENV=str(v),PYO3_PYTHON=str(v/'bin/python'),TORCH_RS_VERIFY_VIRTUALENV=str(v),CARGO_TARGET_DIR=str(d/'cargo-target'),UV_PROJECT_ENVIRONMENT=str(v),TORCH_RS_CUDART=str(lib/'libcudart.so.13'),TORCH_RS_NVRTC=str(lib/'libnvrtc.so.13'),LD_LIBRARY_PATH=str(lib))
 return s,v,e
for tag in ('312','314'):
 s,v,e=env(tag)
 run('dev-'+tag+'-inventory',[v/'bin/python',OUT/'inventory.py',s,OUT/tag/'expected-inventory.json'],cwd=s,env=e)
a=json.loads((OUT/'312/expected-inventory.json').read_text());b=json.loads((OUT/'314/expected-inventory.json').read_text());assert a==b
old=json.loads((OUT/'R-test-expectations.json').read_text())['pointwise']['test_ids'];new=a['pointwise']['test_ids']
removed=[n for n in old if n not in new];added=[n for n in new if n not in old]
old_spy='test_compile_pointwise_warm_overhead.WarmOverhead.test_each_invocation_reads_two_namespaces_and_every_identity'
new_spy='test_compile_pointwise_warm_overhead.WarmOverhead.test_each_invocation_delegates_complete_inventory_to_native_helper'
assert removed==[old_spy],removed
assert len(added)==7 and new_spy in added,added
assert all(n==new_spy or n.startswith('test_compile_pointwise_method_guards.') for n in added)
assert [new_spy if n==old_spy else n for n in old]==[n for n in new if n not in added or n==new_spy]
save(OUT/'inventory-delta.json',dict(removed=removed,added=added,old_count=len(old),candidate_count=len(new),imported_ids=[n for n in new if n.startswith('tests.')]))
save(OUT/'development-test-source-binding.json',dict(timestamp=now(),state=state(),inventories={tag:sha(OUT/tag/'expected-inventory.json') for tag in ('312','314')},scripts={p.name:sha(p) for p in sorted(OUT.glob('*.py'))}))
failures=[]
for tag,version in [('312','3.12.14'),('314','3.14.5')]:
 for phase in ('pointwise','owner'):
  resources();s,v,e=env(tag);d=OUT/tag/'development'/phase;d.mkdir(parents=True)
  label='dev-'+tag+'-'+phase
  run(label+'-gpu-before',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
  try:run(label,[v/'bin/python',OUT/'development_process.py',s,v,phase,d/'result.json','T',version],cwd=s,env=e,phase=dict(directory=str(d),phase=phase,leg='T',version=version))
  except Exception:
   failures.append(dict(tag=tag,phase=phase,error=traceback.format_exc()))
   save(OUT/'development-test-failures.json',failures)
  finally:run(label+'-gpu-after',['nvidia-smi','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'],env=e)
save(OUT/'development-tests-complete.json',dict(timestamp=now(),failures=failures,final_capture=False))
assert not failures,failures
