"""Verify the actual child environment; never change PATH or compiler selection."""
from common import *
import shutil,sys,re
label=sys.argv[1] if len(sys.argv)>1 else 'initial'
e=dict(os.environ)
expected=envbase()
for k in ('CCACHE_DISABLE','CCACHE_DIR','CCACHE_TEMPDIR','CCACHE_CONFIGPATH'):
 assert e[k]==expected[k],(k,e.get(k),expected[k])
assert set(k for k in e if k.startswith('CCACHE_'))=={'CCACHE_DISABLE','CCACHE_DIR','CCACHE_TEMPDIR','CCACHE_CONFIGPATH'}
assert Path(e['CCACHE_CONFIGPATH']).read_bytes()==b''
for k in ('CCACHE_DIR','CCACHE_TEMPDIR','CCACHE_CONFIGPATH'):assert Path(e[k]).resolve().is_relative_to(OUT)
config=run(label+'-ccache-config',['ccache','--show-config'],env=e)
settings={}
for line in config.splitlines():
 m=re.match(r'\([^)]*\)\s+(\w+)\s*=\s*(.*)',line)
 if m:settings[m[1]]=m[2]
assert settings['disable']=='true',settings
assert settings['cache_dir']==e['CCACHE_DIR'] and settings['temporary_dir']==e['CCACHE_TEMPDIR']
metadata={'environment':selectors(e),'effective_config':settings,'config_sha256':sha(e['CCACHE_CONFIGPATH']),'tools':{}}
for name in ('cc','c++','ccache'):
 path=Path(shutil.which(name,path=e['PATH']));real=path.resolve()
 record=dict(path=str(path),resolved=str(real),sha256=sha(real),version=run(label+'-'+name.replace('+','p')+'-version',[str(path),'--version'],env=e))
 if name!='ccache' and real==Path(shutil.which('ccache',path=e['PATH'])).resolve():
  candidates=[Path(d)/name for d in e['PATH'].split(os.pathsep)]
  underlying=next(p for p in candidates if p.is_file() and os.access(p,os.X_OK) and p.resolve()!=real)
  record['underlying']=dict(path=str(underlying),resolved=str(underlying.resolve()),sha256=sha(underlying.resolve()),version=run(label+'-'+name.replace('+','p')+'-underlying-version',[str(underlying),'--version'],env=e))
 metadata['tools'][name]=record
save(OUT/('compiler-preflight.json' if label=='initial' else 'receipts/'+label+'-compiler-identity.json'),metadata)
print(json.dumps(metadata,indent=2))
