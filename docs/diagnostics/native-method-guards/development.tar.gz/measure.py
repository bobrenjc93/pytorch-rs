"""Non-scoring paired public-call publication diagnostic; run from worktree root.

Uses the installed verified release wheel, one GPU, and a fresh process per leg.
All tensor creation and readback are outside synchronized individual call timings.
"""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

import numpy as np
import torch
import torch_rs as native
from torch_rs import _compile_pointwise as frontend


def workload(kind, count):
    # Helper code is an ordinary guarded dependency. Distinct ignored literal
    # constants give eight logical histories with identical tensor work.
    helpers = []
    expression = '-x' if kind == 'numerical' else 'x.view(-1)'
    for index in range(count):
        namespace = {}
        exec(f'def helper(x):\n marker={index}\n return {expression}', namespace)
        helpers.append(namespace['helper'])
    bindings = {'helper': helpers[0]}
    exec('def f(before,x,after):\n return helper(x)', bindings)
    return native.compile(bindings['f']), bindings, helpers


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(*args):
    return subprocess.check_output(args, text=True).strip()


def inventory():
    return command('nvidia-smi', '--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used', '--format=csv')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert os.environ['CUDA_VISIBLE_DEVICES'] == '0'
    torch.set_num_threads(1)
    torch.manual_seed(20260919)
    rng = np.random.default_rng(20260919)
    values = rng.uniform(-1., 1., 257).astype(np.float32)
    x = native.tensor(values.tolist()).to('cuda:0')
    unused = native.ones(257).to('cuda:0')
    # Imports, device initialization and input allocations precede measurement.
    torch.cuda.synchronize()
    samples, warmups = 201, 31
    result = {'label': args.label, 'diagnostic_sha256': sha(__file__), 'samples': samples, 'warmups': warmups,
              'calls_per_sample': 1, 'seed': 20260919, 'gpu_before': inventory(),
              'python': sys.version, 'torch': torch.__version__, 'torch_cuda': torch.version.cuda,
              'platform': platform.platform(), 'cpu': command('lscpu'),
              'rustc': command('rustc', '-Vv'), 'nvcc': command('nvcc', '--version'),
              'package': native.__file__, 'extension': native.torch_rs.__file__,
              'extension_sha256': sha(native.torch_rs.__file__),
              'frontend_sha256': sha(frontend.__file__),
              'state_sha256': sha(frontend._state.__file__),
              'driver_version': torch._C._cuda_getDriverVersion() if hasattr(torch._C, '_cuda_getDriverVersion') else None,
              'environment': {k: os.environ.get(k) for k in ('CUDA_VISIBLE_DEVICES','TORCH_RS_CUDART','OMP_NUM_THREADS','MKL_NUM_THREADS','CUDA_CACHE_PATH')},
              'cells': []}
    for kind in ('numerical', 'alias'):
        for history in (2, 8):
            for mode in ('newest', 'logical', 'abi'):
                compiled, bindings, helpers = workload(kind, history)
                for helper in helpers:
                    bindings['helper'] = helper
                    compiled(False, x, False)
                abis = [(False, x, False), (False, x, unused), (unused, x, False),
                        (False, x, x), (x, x, False)][:min(history, 5)]
                if mode == 'abi':
                    for call in abis:
                        compiled(*call)
                state = compiled._torch_rs_pointwise_cache
                assert len(state.graphs) == history
                selected = next(reversed(state.graphs.values()))
                assert len(selected.lowerings) == (len(abis) if mode == 'abi' else 1)
                calls = [(False, x, False)]
                if mode == 'logical':
                    calls = [(False, x, False), (False, x, False)]
                elif mode == 'abi':
                    calls = [abis[0], abis[-1]]
                timings, checksums = [], []
                for step in range(warmups + samples):
                    call = calls[step % len(calls)]
                    if mode == 'logical':
                        bindings['helper'] = helpers[0 if step % 2 == 0 else -1]
                    torch.cuda.synchronize()
                    start = time.perf_counter_ns()
                    output = compiled(*call)
                    torch.cuda.synchronize()
                    elapsed = time.perf_counter_ns() - start
                    actual = np.asarray(output.cpu().tolist(), dtype=np.float32).reshape(-1)
                    np.testing.assert_array_equal(actual.view(np.uint32),
                                                  (-values if kind == 'numerical' else values).view(np.uint32))
                    assert tuple(output.shape) == tuple(call[1].shape)
                    assert (output.data_ptr() == call[1].data_ptr()) == (kind == 'alias')
                    if step >= warmups:
                        timings.append(elapsed)
                        checksums.append(float(actual.sum(dtype=np.float64)))
                # Verify the intended steady-state retained sizes, not merely labels.
                assert len(state.graphs) == history
                assert len(next(reversed(state.graphs.values())).lowerings) == (len(abis) if mode == 'abi' else 1)
                result['cells'].append({'workload': kind, 'history': history, 'mode': mode,
                    'graphs': len(state.graphs), 'lowerings': len(next(reversed(state.graphs.values())).lowerings),
                    'executors': len(state.executors), 'prepared': len(state.prepared),
                    'samples_ns': timings, 'checksums': checksums,
                    'median_ns': statistics.median(timings), 'mean_ns': statistics.mean(timings),
                    'stdev_ns': statistics.stdev(timings), 'p10_ns': float(np.percentile(timings,10)),
                    'p90_ns': float(np.percentile(timings,90)), 'min_ns': min(timings), 'max_ns': max(timings)})
    result['gpu_after'] = inventory()
    result['mapped_cuda_libraries'] = sorted(set(line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if any(lib in line for lib in ('libcuda.', 'libcudart.', 'libnvrtc.'))))
    versions = {}
    for path in result['mapped_cuda_libraries']:
        library = ctypes.CDLL(path)
        if 'libcudart.' in path:
            value = ctypes.c_int()
            assert library.cudaRuntimeGetVersion(ctypes.byref(value)) == 0
            versions[path] = value.value
        elif 'libnvrtc.' in path:
            major, minor = ctypes.c_int(), ctypes.c_int()
            assert library.nvrtcVersion(ctypes.byref(major), ctypes.byref(minor)) == 0
            versions[path] = [major.value, minor.value]
    result['loaded_cuda_versions'] = versions
    args.output.write_text(json.dumps(result, indent=2)+'\n')


if __name__ == '__main__':
    main()
