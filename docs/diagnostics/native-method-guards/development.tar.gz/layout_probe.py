"""Setup-only entry-boundary probe; never calls history or imports a project wheel."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,sysconfig,traceback
source,directory,input_path=map(Path,sys.argv[1:])
cache_names=('CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME','TMPDIR','TORCH_HOME')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(directory/name).write_text(json.dumps(value,indent=2)+'\n')
def observation():return dict(pid=os.getpid(),ppid=os.getppid(),command=[sys.executable,*sys.argv],version=sys.version,executable=sys.executable,resolved_executable=str(Path(sys.executable).resolve()),prefix=str(Path(sys.prefix).resolve()),stdlib=sysconfig.get_path('stdlib'),flags=repr(sys.flags),cache_selectors={n:os.environ.get(n) for n in cache_names},ccache={n:v for n,v in os.environ.items() if n.startswith('CCACHE_')})
assert not directory.exists()
directory.mkdir(parents=True)
record=dict(success=False,input_sha256=sha(input_path),script_sha256=sha(__file__),command=[sys.executable,*sys.argv])
save('process-before.json',observation())
try:
 spec=importlib.util.spec_from_file_location('unchanged_gpu_dispatch',source/'docs/diagnostics/compile-pointwise-positional/warm-dispatch/gpu-dispatch.py')
 diagnostic=importlib.util.module_from_spec(spec);spec.loader.exec_module(diagnostic)
 record.update(diagnostic_path=str(Path(spec.origin).resolve()),diagnostic_sha256=sha(spec.origin),diagnostic_ROOT=str(diagnostic.ROOT))
 assert diagnostic.ROOT==source
 assert sys.flags.isolated and sys.dont_write_bytecode
 assert os.environ['CUDA_VISIBLE_DEVICES']=='0' and os.environ['CCACHE_DISABLE']=='1'
 diagnostic.environment(diagnostic.ROOT,directory)
 sync=diagnostic.CudaSynchronizer()
 record['runtime']=sync.metadata
 expected=json.loads(input_path.read_text())
 assert sync.metadata['path']==expected['runtime_path'] and sync.metadata['sha256']==expected['runtime_sha256'] and sync.metadata['version']//1000==13
 record['gpu_uuid']=expected['gpu_uuid']
 record['gpu_snapshot']=diagnostic.gpu_identity(expected['gpu_uuid'])
 record['loaded_runtime']=diagnostic.runtime_identity()
 assert len(record['loaded_runtime'])==1 and record['loaded_runtime'][0]['path']==sync.metadata['path']
 record['success']=True
except BaseException:
 record['error']=traceback.format_exc()
 raise
finally:
 save('process-after.json',observation())
 save('result.json',record)
 print(json.dumps(record,indent=2),flush=True)
