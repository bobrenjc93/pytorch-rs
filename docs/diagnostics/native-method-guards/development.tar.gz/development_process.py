"""Fresh process; unchanged verifier plus exact source/interpreter/payload binding."""
from pathlib import Path
import ctypes,hashlib,json,os,runpy,sys,unittest
from common import sha,save,GPU,DRIVER_SHA,OUT,selectors
from development_validation import validate_result
actual_command=[sys.executable,*sys.argv]
source,venv,phase,output,label,version=sys.argv[1:]
source,venv,output=map(Path,(source,venv,output))
assert sys.flags.optimize==0 and not sys.flags.dev_mode and not sys.warnoptions
assert '.'.join(map(str,sys.version_info[:3]))==version
assert Path(sys.prefix).resolve()==venv.resolve()
assert Path(sys.executable).resolve()==source/'target/interpreters'/('312' if version=='3.12.14' else '314')/'bin'/('python'+version[:4])
assert venv==source/'target/venv'
runpy.run_path(str(source/'.github/scripts/verify_native_extension.py'))['verify']()
import torch,torch_rs as native
assert torch.__version__=='2.13.0+cu130',torch.__version__
assert torch.cuda.is_available() and torch.cuda.device_count()==1
assert os.environ['CUDA_VISIBLE_DEVICES']=='0'
torch.set_num_threads(1);torch.set_num_interop_threads(1);native.set_num_threads(1)
assert torch.get_num_threads()==native.get_num_threads()==torch.get_num_interop_threads()==1
assert Path(torch.__file__).resolve().is_relative_to(venv)
assert sha(OUT/'measure.py')==DRIVER_SHA
tag='312' if version=='3.12.14' else '314'
expected=json.loads((OUT/tag/'bindings.json').read_text())[label[0]]
manifest_path=OUT/tag/label[0]/'source-manifest.json'
source_manifest=json.loads(manifest_path.read_text())
assert source_manifest['commit']==expected['commit']
assert all(sha(source/n)==h for n,h in source_manifest['files'].items())
assert sha(Path(sys.executable).resolve())==json.loads((OUT/tag/label[0]/'interpreter.json').read_text())['sha256']

def verify_payload():
    assert sha(native.torch_rs.__file__)==expected['native_sha256']
    for p in (source/'python').rglob('*.py'):
        installed=venv/f'lib/python{sys.version_info.major}.{sys.version_info.minor}/site-packages'/p.relative_to(source/'python')
        assert sha(p)==sha(installed),(p,installed)
verify_payload()
cache_names=('CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME','TMPDIR')
environment=selectors(dict(os.environ))
for n in cache_names:assert Path(environment[n]).resolve().is_relative_to(OUT)
metadata=dict(birth_stat=Path('/proc/self/stat').read_text().split(') ')[1].split()[19],affinity=sorted(os.sched_getaffinity(0)),pid=os.getpid(),ppid=os.getppid(),version=sys.version,executable=sys.executable,interpreter_sha256=sha(Path(sys.executable).resolve()),prefix=sys.prefix,resolved_executable=str(Path(sys.executable).resolve()),stdlib=__import__('sysconfig').get_path('stdlib'),native_threads=native.get_num_threads(),torch_threads=torch.get_num_threads(),torch_interop_threads=torch.get_num_interop_threads(),torch_path=torch.__file__,native_path=native.torch_rs.__file__,native_sha256=sha(native.torch_rs.__file__),flags=repr(sys.flags),gpu_uuid=str(torch.cuda.get_device_properties(0).uuid),gpu_name=torch.cuda.get_device_name(0),environment=environment,cache_selectors={n:os.environ[n] for n in cache_names})
assert metadata['gpu_uuid'].replace('GPU-','')==GPU.replace('GPU-','')
save(output.parent/'process-before.json',metadata)
sys.path.insert(0,str(source))  # Test modules only; torch_rs must remain the installed wheel.
assert label=='T' and phase in ('pointwise','owner')
if True:
    loader=unittest.TestLoader()
    if phase=='pointwise':suite=loader.discover(str(source/'tests'),pattern='test_compile_pointwise*.py')
    elif phase=='owner':suite=loader.loadTestsFromName('tests.test_program_identity_compiler_failures')
    def test_ids(group):
        for test in group:
            if isinstance(test,unittest.TestSuite):yield from test_ids(test)
            else:yield test.id()
    ids=list(test_ids(suite))
    inventory=({str(p.relative_to(source)):sha(p) for p in sorted((source/'tests').glob('test_compile_pointwise*.py'))}
               if phase=='pointwise' else {('tests/test_program_identity_compiler_failures.py' if phase=='owner' else 'contract_tests.py'):
                    sha(source/'tests/test_program_identity_compiler_failures.py' if phase=='owner' else OUT/'contract_tests.py')})
    ids_path=output.parent/'test-ids.txt'
    ids_path.write_text('\n'.join(ids)+'\n')
    collection=dict(phase=phase,source_inventory=inventory,test_ids=ids,test_ids_sha256=sha(ids_path),countTestCases=suite.countTestCases(),loader_errors=list(loader.errors))
    save(output.parent/'collection-before.json',collection)
    expected_collection=json.loads((OUT/tag/'expected-inventory.json').read_text())[phase]
    assert all(collection[k]==v for k,v in expected_collection.items()), 'discovery changed since inventory'
    class RecordingResult(unittest.TextTestResult):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.executed_ids=[]
            self.passing_ids=[]
        def startTest(self,test):
            self.executed_ids.append(test.id())
            super().startTest(test)
        def addSuccess(self,test):
            self.passing_ids.append(test.id())
            super().addSuccess(test)
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordingResult).run(suite)
    save(output,dict(phase=phase,collection=collection,executed_ids=result.executed_ids,passing_ids=result.passing_ids,testsRun=result.testsRun,successful=result.wasSuccessful(),skips=[(t.id(),reason) for t,reason in result.skipped],failures=[(t.id(),trace) for t,trace in result.failures],errors=[(t.id(),trace) for t,trace in result.errors],expectedFailures=[(t.id(),trace) for t,trace in result.expectedFailures],unexpectedSuccesses=[t.id() for t in result.unexpectedSuccesses]))
    assert result.wasSuccessful(),f'{phase} failed; no timing is eligible'
paths=sorted(set(line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if any(lib in line for lib in ('libcuda.','libcudart.','libnvrtc.'))))
metadata['loaded_libraries']={p:dict(sha256=sha(p),bytes=Path(p).stat().st_size) for p in paths}
metadata['loaded_cuda_versions']={}
for path in paths:
    library=ctypes.CDLL(path)
    if 'libcudart.' in path:
        value=ctypes.c_int();assert library.cudaRuntimeGetVersion(ctypes.byref(value))==0
        metadata['loaded_cuda_versions'][path]=value.value
    elif 'libnvrtc.' in path:
        major,minor=ctypes.c_int(),ctypes.c_int();assert library.nvrtcVersion(ctypes.byref(major),ctypes.byref(minor))==0
        metadata['loaded_cuda_versions'][path]=[major.value,minor.value]
metadata['threads_after']={'native':native.get_num_threads(),'torch':torch.get_num_threads(),'torch_interop':torch.get_num_interop_threads()}
assert all(v==1 for v in metadata['threads_after'].values())
metadata['environment']=selectors(dict(os.environ))
metadata['cache_selectors']={n:os.environ[n] for n in cache_names}
assert metadata['cache_selectors']=={n:environment[n] for n in cache_names}
assert all(sha(source/n)==h for n,h in source_manifest['files'].items())
verify_payload()
metadata['expected_identity']=dict(expected,source_manifest_sha256=sha(manifest_path),interpreter_sha256=metadata['interpreter_sha256'])
save(output.parent/'process-after.json',metadata)
files=validate_result(output,phase,label)
files.update({str((output.parent/n).relative_to(OUT)):sha(output.parent/n) for n in ('process-before.json','process-after.json')})
save(output.parent/'post-verification-success.json',dict(success=True,command=actual_command,phase=phase,leg=label,version=version,files=files,expected_identity=metadata['expected_identity'],threads_after=metadata['threads_after']))
