# Development recipe adaptations

The two supplied L SHA256 values were verified before reading/copying recipe text.
Only script text and ID/skip expectations were reused; no sibling environment,
wheel, native artifact, interpreter copy, or cache was used. Original interpreter
installations were copied read-only into each source tree before venv creation.

`recipe-changes.patch` records exact old/new script differences. The `L-*.txt`
files preserve the corresponding originals. This is a **development adaptation**,
not the requested final committed-source C/R/T capture:

- `common.py`: changed the trial directory and declared Burner resource owner;
  changed the eventual sequence labels from S to T. Kept local dependency/cache
  selectors, CCACHE_DISABLE=1, resource checks and command receipts.
- `development_setup.py` replaces `setup.py`: exports C source and overlays the
  worktree's R repair plus native change as an explicitly uncommitted T snapshot.
  It creates only the two development T environments. It never claims these are
  committed T or final C/R/T exports. Interpreter copying, locked uv dependency
  installation and original layout/CudaSynchronizer probes retain L's layout.
- `build.py`, `compiler_preflight.py` and `layout_probe.py` are unchanged script
  text. The original source Unix lock runner and native verifier are unchanged.
- `development_build*.py` replaces the build part of `run.py`: builds each T
  release separately, verifies wheel/installed/source identities, and records
  each attempt without overwriting prior receipts. Versions 2–4 retain the
  formatting failure, compiler inference failure, accidental repeated inference
  failure after an atomic patch rejected its documentation hunk, and corrected
  build. Debug check outputs are separate from release artifacts.
- `inventory.py` separates complete discovery from execution. It records ordered
  IDs and source inventories for both suites/interpreters. No explicit unittest
  top_level_dir is supplied. `development_tests.py` binds the new inventory to
  R's 519 IDs, allowing only six additions and the documented instrumentation
  rename, and executes four development correctness phases. Their results are
  never treated as final capture gates.
- `development_process.py` retains L's source/interpreter/native/runtime checks,
  child cache selectors and recording result. It adds process birth/affinity,
  verifies discovery against the prior inventory before execution, and disables
  all ordinary/auxiliary timing branches. `development_validation.py` retains
  exact skip-pair, executed/pass/failure and owner-suite checks, using the actual
  new inventory rather than a hard-coded 519 count.
- Removed S-only hash tests, hash/storage/constructor experiments and the
  six-way identical-native assumption. `native-input-binding.json` explicitly
  distinguishes unchanged C/R native inputs from T's two changed Rust files.
- `measure.py` is the unchanged 144-line R driver with the supplied SHA256; it
  has not been executed here. No ordinary sample, ratio or performance claim is
  derived from setup probes, correctness smoke samples or instrumented counts.

`capture-status.json` records the unstarted final protocol. It requires a
Burner-created semantic T commit, six new source exports/builds and a new freeze
of all scripts/identities/ordered inventories before four final correctness
phases, then twelve C1/R1/T1/T2/R2/C2 ordinary phases (3.12 first). None is
substituted by these development attempts. No final gate was started or retried.
