"""Audit completed development identities/results without interpreting timings."""
from common import *
assert state()['head']==REFS['C']
complete=json.loads((OUT/'development-tests-complete.json').read_text());assert not complete['failures']
identities=[];caches=[];results={}
for tag in ('312','314'):
 for phase in ('pointwise','owner'):
  directory=OUT/tag/'development'/phase
  marker=json.loads((directory/'post-verification-success.json').read_text())
  assert marker['success'] and marker['phase']==phase and marker['leg']=='T'
  for name,h in marker['files'].items():assert sha(OUT/name)==h,name
  receipt=json.loads((OUT/'receipts'/f'dev-{tag}-{phase}.json').read_text())
  assert receipt['returncode']==0 and receipt['error'] is None
  before=json.loads((directory/'process-before.json').read_text());after=json.loads((directory/'process-after.json').read_text())
  assert before['gpu_uuid'].replace('GPU-','')==after['gpu_uuid'].replace('GPU-','')==GPU.replace('GPU-','')
  identities.append((before['pid'],before['birth_stat'],before['ppid']))
  for key in ('CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','XDG_CACHE_HOME','TMPDIR'):
   value=receipt['environment'][key]
   assert before['cache_selectors'][key]==after['cache_selectors'][key]==value
   assert Path(value).resolve().is_relative_to(OUT/'command-caches'/f'dev-{tag}-{phase}')
   caches.append(value)
  assert before['pid']==after['pid'] and before['birth_stat']==after['birth_stat']
  assert after['threads_after']==dict(native=1,torch=1,torch_interop=1)
  result=json.loads((directory/'result.json').read_text())
  expected=json.loads((OUT/tag/'expected-inventory.json').read_text())[phase]
  assert result['executed_ids']==expected['test_ids']
  assert result['testsRun']==expected['countTestCases']
  assert result['successful'] and not result['expectedFailures'] and not result['unexpectedSuccesses']
  skips=json.loads((OUT/'R-test-expectations.json').read_text())[phase]['skips']
  assert result['skips']==skips
  assert result['passing_ids']==[t for t in expected['test_ids'] if t not in {p[0] for p in skips}]
  results[tag+'/'+phase]=dict(testsRun=result['testsRun'],passed=len(result['passing_ids']),skipped=len(skips),inventory_sha256=expected['test_ids_sha256'])
assert len(set(identities))==4 and len(set(caches))==20
for tag in ('312','314'):
 m=json.loads((OUT/tag/'T/source-manifest.json').read_text())
 for name,h in m['files'].items():
  assert sha(OUT/tag/'T/source'/name)==h,name
  if name.startswith(('python/','src/','tests/')):assert sha(ROOT/name)==h,name
save(OUT/'development-audit.json',dict(timestamp=now(),success=True,results=results,process_identities=identities,distinct_cache_paths=caches,final_capture=False,ordinary_samples=0))
print(json.dumps(results,indent=2))
