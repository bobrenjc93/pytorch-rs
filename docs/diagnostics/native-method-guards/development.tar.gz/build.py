"""Called only by the unchanged Unix-lock runner; records queue separately."""
from common import *
import sys
label,source,venv,queued=sys.argv[1:]
acquired=time.time()
save(OUT/'receipts'/(label+'-lock-acquired.json'),dict(queued_unix=float(queued),acquired_unix=acquired,queue_and_launcher_seconds=acquired-float(queued),note='Queue includes Unix-lock launcher startup; release duration is measured around maturin only.'))
run(label+'-release',[Path(venv)/'bin/maturin','build','--release','--locked','--offline','--out',Path(source).parent/'wheels'],cwd=Path(source),env=dict(os.environ))
