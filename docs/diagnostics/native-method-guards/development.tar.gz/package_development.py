"""Publish a compact, lossless selection of development receipts, not timings."""
from common import *
import tarfile,io,gzip
complete=json.loads((OUT/'development-tests-complete.json').read_text())
assert not complete['failures'],complete
phases={}
for tag in ('312','314'):
 for phase in ('pointwise','owner'):
  directory=OUT/tag/'development'/phase
  result=json.loads((directory/'result.json').read_text())
  assert result['successful'] and not result['failures'] and not result['errors']
  assert (directory/'post-verification-success.json').exists()
  phases[tag+'/'+phase]={k:result[k] for k in ('testsRun','skips','failures','errors','expectedFailures','unexpectedSuccesses')}
  phases[tag+'/'+phase]['passing']=len(result['passing_ids'])
 for name,h in json.loads((OUT/tag/'T/source-manifest.json').read_text())['files'].items():
  if name.startswith(('src/','python/','tests/')):assert sha(ROOT/name)==h,name
for tag in ('312','314'):
 metadata=json.loads((OUT/tag/'development/pointwise/process-after.json').read_text())
 for path,version in metadata['loaded_cuda_versions'].items():
  if 'libcudart.' in path:assert version==13000
  if 'libnvrtc.' in path:assert version==[13,0]
for label in ('dev4-rustfmt','dev4-cargo-check','dev-clippy','dev4-312-native-verifier','dev4-314-native-verifier','dev-312-layout-probe','dev-314-layout-probe'):
 receipt=json.loads((OUT/'receipts'/(label+'.json')).read_text());assert receipt['returncode']==0 and receipt['error'] is None
binding=json.loads((OUT/'semantic-binding.json').read_text())
for name,record in binding['files'].items():record['candidate_sha256']=sha(ROOT/name)
save(OUT/'semantic-binding.json',binding)
(OUT/'candidate.patch').write_bytes(git('diff','HEAD','--binary'))
save(OUT/'development-result-summary.json',dict(timestamp=now(),phases=phases,final_capture=False,source_head=state()['head'],candidate_commit=None,ordinary_timings=None,limitations='No committed T capture, C/R comparison, final gate, official score, or qualification. Single GPU only.'))
selected={}
def include(p,name=None):
 if p.is_file():selected[name or str(p.relative_to(OUT))]=p
for pattern in ('*.py','*.txt','*.json','*.log','*.patch','*.md'):
 for p in OUT.glob(pattern):include(p)
for p in (OUT/'receipts').iterdir():include(p)
for tag in ('312','314'):
 for name in ('bindings.json','expected-inventory.json'):include(OUT/tag/name)
 for name in ('interpreter.json','source-manifest.json','layout-probe-input.json'):include(OUT/tag/'T'/name)
 for base in (OUT/tag/'development',OUT/tag/'T/source/target/layout-probe'):
  for p in base.rglob('*'):include(p)
 for base in (OUT/tag/'T/source/target').glob('dispatch-smoke-*'):
  for p in base.glob('*.log'):include(p)
  for side in ('native','reference'):include(base/side/'report.json.gz')
 for p in (OUT/tag/'T/source/target/program-identity-compiler-failures').glob('*'):include(p)
include(ROOT/'tests/test_compile_pointwise_publication.py','source-additions/tests/test_compile_pointwise_publication.py')
dest=ROOT/'docs/diagnostics/native-method-guards';dest.mkdir(parents=True,exist_ok=True)
archive=dest/'development.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for name,p in sorted(selected.items()):
    info=tarfile.TarInfo(name);data=p.read_bytes();info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
manifest=dict(request='compile-native-method-guards-20260919-0n4jvB',status='development correctness only; final capture unavailable',source_head=state()['head'],candidate_commit=None,archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size),files={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in sorted(selected.items())},omitted_local_bundles=dict(root=str(OUT),paths=['312/T/source','314/T/source','312/T/wheels','314/T/wheels','cargo-home','uv-cache','command-caches'],note='Full source/interpreter/stdlib/wheel/installed/dependency/cache bytes stay local in target and are not publicly durable. Included manifests bind their identities; this archive does not contain those omitted bytes.'),results=phases,final_capture=json.loads((OUT/'capture-status.json').read_text()))
save(dest/'manifest.json',manifest)
# Check archived bytes against the readable manifest, not just archive size.
with tarfile.open(archive,'r:gz') as tar:
 assert tar.getnames()==sorted(selected)
 for member in tar:
  data=tar.extractfile(member).read()
  assert hashlib.sha256(data).hexdigest()==manifest['files'][member.name]['sha256']
print('PACKAGED',len(selected),archive.stat().st_size,sha(archive))
rows=[]
for tag,version in [('312','3.12.14'),('314','3.14.5')]:
 p=phases[tag+'/pointwise'];o=phases[tag+'/owner']
 rows.append(f"| {version} | {p['passing']} passed, {len(p['skips'])} skipped | {o['passing']} passed, {len(o['skips'])} skipped |")
text='''# Native compile method identity batch

This candidate carries C's required R publication repair plus one stateless
native method-identity batch. Python retains the inventory and expected objects;
no ShapeGuards hash change or other runtime optimization is included. The
[guide](../../compile-pointwise-jit.md) describes the boundary and publication lifetime.

## Development validation

Fresh, separate release builds used Python 3.12.14 and 3.14.5, Rust 1.92,
PyO3 0.29.2/ABI3, PyTorch 2.13.0+cu130 and H100 GPU0
`GPU-8f8e55a5-a9eb-eb79-bc43-807a19bcb1c1`. The selected runtime and NVRTC
reported 13.0; `nvcc` was 12.6. Format, Cargo check, Clippy with warnings denied,
the unchanged native verifier and local interpreter/CUDA containment probes passed.

| Python | Complete pointwise suite | Compiler-owner suite |
|---|---|---|
'''+ '\n'.join(rows)+'''

Each pointwise inventory contains 525 ordered IDs: R's 519 tests plus six new
boundary tests, with one instrumentation test renamed. The eight imported
`tests.*` IDs are unchanged. Only L's exact nine two-device reservation skip
pairs were accepted; these runs do not establish two-device restoration.

[Raw development evidence](development.tar.gz) and its [manifest](manifest.json)
retain complete test IDs/results/logs, both native/default smoke histories,
build failures and successful receipts, source/wheel/installed/interpreter
inventories, recipes and the exact L-to-development recipe diff. The ordinary
144-line driver is unchanged and was not run. Full source, wheel, interpreter
and cache bundles remain in local `target/native-method-guard-trial/`; their
hashes/locations are recorded, but their bytes are omitted from the compact
archive and those local paths are not publicly durable.

## Qualification status

These are uncommitted development snapshots, not final correctness gates.
This worker leaves commits to Burner; no semantic T commit or later evidence-only
commit was made. The required six fresh C/R/T builds, frozen four-gate capture
and twelve ordinary legs remain unavailable. Zero of 28,944 ordinary samples
were collected. No T/R or T/C ratio, speedup, default-Inductor performance parity,
official score or qualification is claimed. A Burner-created T commit and a
fresh final capture are required before drawing those conclusions.
'''
(dest/'README.md').write_text(text)
