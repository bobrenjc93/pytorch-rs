"""Collect, never execute, complete development candidate suites."""
from pathlib import Path
import hashlib,json,sys,unittest,runpy
source,out=map(Path,sys.argv[1:]);sys.path.insert(0,str(source))
runpy.run_path(str(source/'.github/scripts/verify_native_extension.py'))['verify']()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ids(group):
 for t in group:
  if isinstance(t,unittest.TestSuite):yield from ids(t)
  else:yield t.id()
records={}
for phase in ('pointwise','owner'):
 loader=unittest.TestLoader()
 suite=loader.discover(str(source/'tests'),pattern='test_compile_pointwise*.py') if phase=='pointwise' else loader.loadTestsFromName('tests.test_program_identity_compiler_failures')
 names=list(ids(suite));assert not loader.errors,loader.errors
 assert len(names)==len(set(names))==suite.countTestCases()
 files=sorted((source/'tests').glob('test_compile_pointwise*.py')) if phase=='pointwise' else [source/'tests/test_program_identity_compiler_failures.py']
 records[phase]=dict(test_ids=names,test_ids_sha256=hashlib.sha256(('\n'.join(names)+'\n').encode()).hexdigest(),countTestCases=suite.countTestCases(),source_inventory={str(p.relative_to(source)):sha(p) for p in files},loader_errors=loader.errors)
out.write_text(json.dumps(records,indent=2)+'\n')
print({k:(v['countTestCases'],v['test_ids_sha256']) for k,v in records.items()})
