from common import *
def validate_result(path,phase,label):
 path=Path(path);r=json.loads(path.read_text())
 assert label=='T' and phase in ('pointwise','owner')
 expected=json.loads((OUT/'R-test-expectations.json').read_text())[phase]
 collection=json.loads((path.parent/'collection-before.json').read_text());ids=(path.parent/'test-ids.txt').read_text().splitlines()
 assert r['collection']==collection and collection['phase']==phase
 assert r['successful'] and not r['errors'] and not r['failures'] and not r['unexpectedSuccesses'] and not r['expectedFailures']
 assert not collection['loader_errors']
 assert r['testsRun']==collection['countTestCases']==len(ids)==len(set(ids))
 assert collection['test_ids']==r['executed_ids']==ids
 assert sha(path.parent/'test-ids.txt')==collection['test_ids_sha256']
 assert r['skips']==expected['skips']
 skip_ids={t for t,reason in r['skips']}
 assert r['passing_ids']==[t for t in ids if t not in skip_ids]
 if phase=='owner':assert len(ids)==8 and not r['skips']
 return {str(p.relative_to(OUT)):sha(p) for p in (path,path.parent/'collection-before.json',path.parent/'test-ids.txt')}
