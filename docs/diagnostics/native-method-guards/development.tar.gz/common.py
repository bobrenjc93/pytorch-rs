from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'target/native-method-guard-trial'
REFS={'C':'81a1e9606571914711491285ad8534451f7dcf3a','R':'00bea94caaf70017cb347733fe7633a7b2b52637'}
EVIDENCE='0d441fe26f0e1804ff1500083c8e2beaa2ab98d6'
DRIVER_SHA='a5590e1abdf90585d8d9ecd70eee9eb60007ceb34f1884e42cafc5a06be34ebd'
ORDER=['C1','R1','T1','T2','R2','C2']
GPU='GPU-8f8e55a5-a9eb-eb79-bc43-807a19bcb1c1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def now():return datetime.now(timezone.utc).isoformat()
def envbase():
 e={k:v for k,v in os.environ.items() if not k.startswith(('CCACHE_','UV_','CARGO_','GIT_','PYO3_','PYTHON','RUST','TORCH_','TORCHINDUCTOR_','CUDA_','TRITON_')) and k not in ('VIRTUAL_ENV','CONDA_PREFIX','LD_LIBRARY_PATH')}
 e.update(CCACHE_DISABLE='1',CCACHE_DIR=str(OUT/'ccache/cache'),CCACHE_TEMPDIR=str(OUT/'ccache/tmp'),CCACHE_CONFIGPATH=str(OUT/'ccache/empty.conf'),CARGO_HOME=str(OUT/'cargo-home'),UV_CACHE_DIR=str(OUT/'uv-cache'),UV_PYTHON_INSTALL_DIR=str(OUT/'interpreters'),UV_PYTHON_BIN_DIR=str(OUT/'uv-bin'),UV_LINK_MODE='copy',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'tmp'),XDG_CACHE_HOME=str(OUT/'setup-cache'),CUDA_CACHE_PATH=str(OUT/'setup-cache/cuda'),TORCHINDUCTOR_CACHE_DIR=str(OUT/'setup-cache/inductor'),TRITON_CACHE_DIR=str(OUT/'setup-cache/triton'),CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',RAYON_NUM_THREADS='1',RUSTUP_TOOLCHAIN='1.92.0',GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',UV_PYTHON_DOWNLOADS='never')
 for k in ('CCACHE_DIR','CCACHE_TEMPDIR','CARGO_HOME','UV_CACHE_DIR','UV_PYTHON_INSTALL_DIR','UV_PYTHON_BIN_DIR','TMPDIR','XDG_CACHE_HOME','CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR'):Path(e[k]).mkdir(parents=True,exist_ok=True)
 config=Path(e['CCACHE_CONFIGPATH'])
 if not config.exists():config.write_bytes(b'')
 assert config.read_bytes()==b''
 if os.environ.get('HTTPS_PROXY'):e['CARGO_HTTP_PROXY']=os.environ['HTTPS_PROXY']
 elif os.environ.get('CARGO_HTTP_PROXY'):e['CARGO_HTTP_PROXY']=os.environ['CARGO_HTTP_PROXY']
 return e
def selectors(e):return {k:v for k,v in e.items() if k.startswith(('CCACHE_','UV_','CARGO_','GIT_','PYO3_','PYTHON','RUST','TORCH_','TORCHINDUCTOR_','CUDA_','TRITON_')) and 'PROXY' not in k or k in ('VIRTUAL_ENV','LD_LIBRARY_PATH','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','RAYON_NUM_THREADS','TMPDIR','XDG_CACHE_HOME','PATH','CC','CXX','CPP','LD','AR','AS','NM','RANLIB','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS') or k.startswith(('CC_','CXX_','HOST_','TARGET_'))}
def run(label,cmd,cwd=ROOT,env=None,phase=None):
 p=OUT/'receipts'/label;p.parent.mkdir(parents=True,exist_ok=True)
 log=p.with_suffix('.log');rec=p.with_suffix('.json')
 assert not log.exists(),str(log)
 started=now();tick=time.perf_counter();e=dict(env or envbase())
 for selector,folder in [('CUDA_CACHE_PATH','cuda'),('TORCHINDUCTOR_CACHE_DIR','inductor'),('TRITON_CACHE_DIR','triton'),('XDG_CACHE_HOME','xdg'),('TMPDIR','tmp')]:
  cache=OUT/'command-caches'/label/folder;cache.mkdir(parents=True,exist_ok=True);e[selector]=str(cache)
 rc=None;error=None;child_pid=None
 try:
  with log.open('w') as f:
   r=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=e,stdout=f,stderr=subprocess.STDOUT)
   child_pid=r.pid
   rc=r.wait()
 except Exception as ex:error=repr(ex)
 marker=None
 if phase is not None and rc==0 and error is None:
  try:
   mp=Path(phase['directory'])/'post-verification-success.json'
   m=json.loads(mp.read_text())
   assert m['command']==[str(x) for x in cmd] and m['phase']==phase['phase']
   assert m['leg']==phase['leg'] and m['version']==phase['version']
   marker=dict(path=str(mp.relative_to(OUT)),sha256=sha(mp))
  except Exception as ex:error=repr(ex)
 save(rec,dict(child_pid=child_pid,parent_pid=os.getpid(),selector_scope='selectors_before/after are the parent-supplied launch environment; actual child observations are process-before/after.json for process phases.',selectors_before=selectors(e),selectors_after=selectors(e),phase=phase,post_verification=marker,command=[str(x) for x in cmd],cwd=str(cwd),started=started,ended=now(),wall_seconds=time.perf_counter()-tick,returncode=rc,error=error,log=str(log.relative_to(OUT)),log_sha256=sha(log),environment=selectors(e)))
 if rc!=0 or error is not None:raise RuntimeError(f'{label}: returncode={rc}, error={error}; see {log}')
 return log.read_text()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,env=envbase())
def state():return dict(head=git('rev-parse','HEAD').decode().strip(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),diff_sha256=hashlib.sha256(git('diff','HEAD','--binary')).hexdigest())
def resources():
 rows={}
 for n in ('gpu','cpu-heavy'):
  p=Path('/data/users/bobren/a/pytorch-rs-burner/.burner/locks')/(n+'.lock');d=json.loads(p.read_text());assert d['owner']=='idea_2fed05cf';os.kill(d['pid'],0);rows[n]={k:d[k] for k in ('owner','pid','createdAt')}
 return rows
