from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, sysconfig, time
root=Path.cwd().resolve()
evidence=Path(os.environ['BURNER_EVALUATION_ARTIFACT_DIR']).resolve()
expected=root/'target/postcommit-8ac9d0e/venv'
assert evidence.is_relative_to(root) and Path(sys.prefix).resolve()==expected
commit='8ac9d0e768e2cd6faab558dc6838240231ccf585'

def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
def clean():
    assert git('rev-parse','HEAD')==commit
    assert not git('status','--porcelain'), git('status','--porcelain')
clean()
files=git('ls-files','src','python','tests','Cargo.toml','Cargo.lock','pyproject.toml','uv.lock').splitlines()
hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
(evidence/'source-before.json').write_text(json.dumps({'commit':commit,'dirty':False,'worktree':str(root),'source_hashes':hashes},indent=2)+'\n')
commands=[]
def run(name,args,overrides=None):
    clean()
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    t=time.monotonic()
    env=os.environ.copy();env.update(overrides or {})
    with (evidence/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    item={'name':name,'argv':list(map(str,args)),'cwd':str(root),'environment_overrides':overrides or {},'started_utc':start,'elapsed_seconds':time.monotonic()-t,'returncode':result.returncode,'commit':commit,'dirty':False,'log':name+'.log'}
    commands.append(item)
    (evidence/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name, 'returncode',result.returncode,'seconds',round(item['elapsed_seconds'],3),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
run('pip-config',[sys.executable,'-B','-I','-m','pip','--isolated','config','debug'])
run('gpu-before',['nvidia-smi','-i','0','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'])
run('build',[str(expected/'bin/maturin'),'build','--release','--locked','--interpreter',sys.executable,'--out',str(root/'target/postcommit-8ac9d0e/wheels')])
for k in ('purelib','platlib','scripts','data'):
    assert Path(sysconfig.get_path(k)).resolve().is_relative_to(expected)
run('install',[sys.executable,'-B','-I','-m','pip','--isolated','install','--no-deps',str(root/'target/postcommit-8ac9d0e/wheels/torch_rs-0.1.0-cp310-abi3-manylinux_2_34_x86_64.whl')])
run('verify-import',[sys.executable,'-B','.github/scripts/verify_native_extension.py'],{'TORCH_RS_VERIFY_VIRTUALENV':str(expected)})
run('focused-gpu',[sys.executable,'-B','-m','unittest','-v','tests.test_compile_pointwise_input_transpose','tests.test_cuda_add_inplace'])
run('focused-portable',[sys.executable,'-B','-m','unittest','-v','tests.test_compile_pointwise_input_transpose','tests.test_cuda_add_inplace'],{'CUDA_VISIBLE_DEVICES':''})
run('native-add',['cargo','test','--locked','--features','python-bindings','--lib','scalar_add_inplace_','--','--test-threads=1'])
run('native-graph',['cargo','test','--locked','--features','python-bindings','--lib','cuda_graph::tests','--','--test-threads=1'])
run('clippy',['cargo','clippy','--locked','--all-targets','--features','python-bindings','--','-D','warnings'])
run('fmt',['cargo','fmt','--check'])
run('gpu-after',['nvidia-smi','-i','0','--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used','--format=csv'])
clean()
for p,h in hashes.items(): assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
(evidence/'source-after.json').write_text(json.dumps({'commit':commit,'dirty':False,'source_hashes_match_before':True,'verified_count':len(hashes)},indent=2)+'\n')
