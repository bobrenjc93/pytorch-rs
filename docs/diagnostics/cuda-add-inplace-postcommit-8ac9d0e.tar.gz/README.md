# Clean-commit capability capture

Measured source: 8ac9d0e768e2cd6faab558dc6838240231ccf585.
Pinned base: 60202557b4f110d07777f585e804ab5f55e1ff7b.
The source worktree was clean for the build, installs, checks and identity capture.
Only evidence and accompanying docs were written to tracked locations afterward.

All shell commands used non-login bash from the worktree. `env.sh` clears active
CONDA_*/_CONDA_*, VIRTUAL_ENV, UV_PROJECT_ENVIRONMENT, PYTHONHOME and PYTHONPATH,
then selects the explicit local interpreter, install destination and writable
caches. GPU0 used the existing held gpu/cpu-heavy lease, with no parallel heavy
work. No shared Python installation was installed into or repaired.

Initial setup commands (before `run_checks.py`):

```bash
source target/postcommit-8ac9d0e/env.sh
/home/bobren/.local/share/uv/python/cpython-3.12.12-linux-x86_64-gnu/bin/python3.12 -B -I -m venv "$VIRTUAL_ENV"
"$PYO3_PYTHON" -B -I - <<'PY'
from pathlib import Path
import sys,sysconfig
expected=Path.cwd().resolve()/'target/postcommit-8ac9d0e/venv'
assert Path(sys.prefix).resolve()==expected
for key in ('purelib','platlib','scripts','data'):
    assert Path(sysconfig.get_path(key)).resolve().is_relative_to(expected)
PY
"$PYO3_PYTHON" -B -I -m pip --isolated --cache-dir "$PWD/target/author-add/cache/pip" install --require-hashes -r target/author-add/requirements.txt
uv --no-config export --locked --no-emit-project --group dev --group reference --format requirements-txt > target/postcommit-8ac9d0e/requirements.txt
cmp target/postcommit-8ac9d0e/requirements.txt target/author-add/requirements.txt
"$PYO3_PYTHON" -B target/postcommit-8ac9d0e/run_checks.py
"$PYO3_PYTHON" -B target/postcommit-8ac9d0e/capture_identity.py
"$PYO3_PYTHON" -B -I target/postcommit-8ac9d0e/summarize.py
```

The initial install destinations were asserted before pip, and again in
`run_checks.py` before wheel installation. Standard venv symlinks use the
read-only Python 3.12.12 base; sys.prefix and all package destinations are local.
Native compilation, CUDA, Inductor and Triton caches were fresh. Worktree-local
pip downloads and Cargo registry contents were reused. No dependency lock changed.

`commands.json` records exact build/install/check argv, environment overrides,
UTC start times, return codes and elapsed command durations. These durations are
operational receipts, not performance benchmarks. `source-before.json` and
`source-after.json` verify 900 source/test/build-input hashes. `identity.json`
verifies wheel versus installed-extension bytes, packaged Python versus current
sources, import destinations, runtime/driver/compiler identities and frozen files.
`report.json` is generated from those receipts and parsed complete test logs.

All captures passed on their first attempts. The original author archive retains
its first lint and fixture failures and is hash-verified unchanged. The current
PyTorch reference emits a non-failing script_method deprecation warning, retained
in the GPU log. Linux Clippy does not establish the supplied macOS CI outcome.
GPU0-only checks do not establish cross-device restoration.

No canonical evaluator was run: current operator instructions explicitly prohibit
manual canonical runs. The prior d22c5ac and 48c7b82 scored reports remain pinned,
unchanged and stale for this revision. Canonical refresh remains outstanding for
Burner; these focused tests provide no substitute score or performance credit.
Historical compute measurements and all original artifacts were preserved.

The archive includes all raw capture receipts and scripts. Full environments,
wheels and native build outputs remain under target/postcommit-8ac9d0e in this
worktree. `BURNER_EVALUATION_ARTIFACT_DIR` points at its evidence directory.
The checked-in report is byte-identical to report.json in this archive.
