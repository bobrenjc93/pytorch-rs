from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess,tarfile
root=Path.cwd().resolve(); e=root/'target/postcommit-8ac9d0e/evidence'
commit='8ac9d0e768e2cd6faab558dc6838240231ccf585'
def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==commit and not git('status','--porcelain')
identity=json.loads((e/'identity.json').read_text())
assert identity['measured_commit']==commit and identity['git_status']==''
commands=json.loads((e/'commands.json').read_text())
assert all(c['returncode']==0 and not c['dirty'] and c['commit']==commit for c in commands)
outcomes={}
for key in ('focused-gpu','focused-portable'):
    text=(e/(key+'.log')).read_text()
    count=int(re.search(r'Ran (\d+) tests',text).group(1))
    skip=re.search(r'OK \(skipped=(\d+)\)',text)
    skipped=int(skip.group(1)) if skip else 0
    assert re.search(r'^OK(?: \(skipped=\d+\))?$',text,re.M)
    outcomes[key]={'run':count,'passed':count-skipped,'skipped':skipped}
for key in ('native-add','native-graph'):
    text=(e/(key+'.log')).read_text()
    match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed;',text)
    assert match and int(match.group(2))==0
    outcomes[key]={'passed':int(match.group(1)),'failed':0}
for key in ('build','install','verify-import','clippy','fmt'):
    outcomes[key]={'returncode':next(c['returncode'] for c in commands if c['name']==key)}
preserved={}
for p in git('diff','--name-only','60202557b4f110d07777f585e804ab5f55e1ff7b..HEAD','--','docs/diagnostics').splitlines():
    content=(root/p).read_bytes()
    assert content==subprocess.check_output(['git','show',f'{commit}:{p}'])
    preserved[p]={'sha256':h(root/p),'unchanged_from_measured_commit':True}
    if p.endswith('.json'):
        preserved[p]['original_measured_commit']=json.loads(content)['provenance']['commit']
with tarfile.open(root/'docs/diagnostics/cuda-add-inplace-author.tar.gz') as a:
    for line in a.extractfile('SHA256SUMS').read().decode().splitlines():
        digest,name=line.split('  ',1);assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==digest
frozen=identity['frozen_unchanged_hashes']
for p,digest in frozen.items(): assert h(root/p)==digest,p
for p in ['.burner/evaluations.json','scripts/run_with_unix_lock.py','.github/scripts/verify_native_extension.py','scripts/evaluate_torch_compile_default.sh','scripts/evaluate_torch_compile_default.py','scripts/torch_compile_default_corpus.py','Cargo.lock','uv.lock']:
    assert (root/p).read_bytes()==subprocess.check_output(['git','show',f'60202557b4f110d07777f585e804ab5f55e1ff7b:{p}']),p
report={'kind':'postcommit-focused-capability-evidence','measured_commit':commit,'dirty_during_capture':False,
        'captured_utc':datetime.now(timezone.utc).isoformat(),'identity':identity,'outcomes':outcomes,'commands':commands,
        'cache_state':'fresh venv, Cargo target directory and CUDA/Inductor/Triton caches; worktree-local pip downloads and Cargo registry reused',
        'raw_artifact_directory':str(e),'source_before_after':json.loads((e/'source-after.json').read_text()),
        'preserved_candidate_evidence':preserved,'author_archive_manifest_verified':True,
        'canonical_evaluation':{'run':False,'scores':None,'refresh_outstanding':True,'reason':'Current operator requirements prohibit manually running the canonical evaluator. Older reports remain pinned and do not measure this revision; Burner owns the canonical evaluation stage.'},
        'limitations':['Linux checks do not establish macOS CI success','GPU0 only; no cross-device restoration check','Injected faults are portable, not real device failures','No new performance measurement or score']}
(e/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'commit':commit,'outcomes':outcomes,'preserved_artifacts':len(preserved),'source_count':report['source_before_after']['verified_count']},indent=2))
