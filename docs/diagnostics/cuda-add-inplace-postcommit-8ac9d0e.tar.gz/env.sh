for task_conda_name in ${!CONDA_@} ${!_CONDA_@}; do unset "$task_conda_name"; done
unset VIRTUAL_ENV UV_PROJECT_ENVIRONMENT PYTHONHOME PYTHONPATH
export VIRTUAL_ENV="$PWD/target/postcommit-8ac9d0e/venv"
export UV_PROJECT_ENVIRONMENT="$VIRTUAL_ENV" PYO3_PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PIP_CONFIG_FILE=/dev/null
export CUDA_VISIBLE_DEVICES=0
export CARGO_HOME="$PWD/target/author-add/cargo-home"
export CARGO_TARGET_DIR="$PWD/target/postcommit-8ac9d0e/cargo-target"
export XDG_CACHE_HOME="$PWD/target/postcommit-8ac9d0e/cache"
export UV_CACHE_DIR="$XDG_CACHE_HOME/uv" UV_PYTHON_INSTALL_DIR="$PWD/target/postcommit-8ac9d0e/python"
export CUDA_CACHE_PATH="$XDG_CACHE_HOME/cuda" TORCHINDUCTOR_CACHE_DIR="$XDG_CACHE_HOME/inductor" TRITON_CACHE_DIR="$XDG_CACHE_HOME/triton"
export TMPDIR="$PWD/target/postcommit-8ac9d0e/tmp"
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/postcommit-8ac9d0e/evidence"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CARGO_BUILD_JOBS=8
export TORCH_RS_CUDART="$VIRTUAL_ENV/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
