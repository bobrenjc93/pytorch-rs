set -euo pipefail
source target/full-call/env.sh
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/postcommit-ed614665/evidence"
export XDG_CACHE_HOME="$PWD/target/postcommit-ed614665/cache"
export UV_CACHE_DIR="$XDG_CACHE_HOME/uv"
export TMPDIR="$PWD/target/postcommit-ed614665/tmp"
mkdir -p "$TMPDIR"
set -x
for build in accepted incoming retained; do
 case "$build" in
 accepted) source="$PWD/target/postcommit-ed614665/sources/accepted"; revision=60202557b4f110d07777f585e804ab5f55e1ff7b ;;
 incoming) source="$PWD/target/postcommit-ed614665/sources/incoming"; revision=9a436482d3e49dd40df7ce1d75198890b16b8f95 ;;
 retained) source="$PWD"; revision=ed6146650aa1bf8d5ba13a17337b6331372c400c ;;
 esac
 export CARGO_TARGET_DIR="$PWD/target/postcommit-ed614665/build/$build"
 "$VIRTUAL_ENV/bin/maturin" build --release --locked --manifest-path "$source/Cargo.toml" --interpreter "$PYO3_PYTHON" --out "$PWD/target/postcommit-ed614665/wheels/$build" > "$BURNER_EVALUATION_ARTIFACT_DIR/$build-build.log" 2>&1
 wheels=("$PWD/target/postcommit-ed614665/wheels/$build/"*.whl)
 "$PYO3_PYTHON" -B -I "$BURNER_EVALUATION_ARTIFACT_DIR/verify-wheel.py" "$source" "${wheels[0]}" "$PWD/target/postcommit-ed614665/imports/$build" > "$BURNER_EVALUATION_ARTIFACT_DIR/$build-wheel.json"
 for pair in native-first:torch_rs reference-second:torch reference-first:torch native-second:torch_rs; do
  label="$build-${pair%:*}"; framework="${pair#*:}"
  export CUDA_CACHE_PATH="$XDG_CACHE_HOME/$label/cuda" TORCHINDUCTOR_CACHE_DIR="$XDG_CACHE_HOME/$label/inductor" TRITON_CACHE_DIR="$XDG_CACHE_HOME/$label/triton"
  options=()
  if [ "$framework" = torch_rs ]; then
   options=(--import-dir "$PWD/target/postcommit-ed614665/imports/$build" --wheel "${wheels[0]}")
  fi
  "$PYO3_PYTHON" -B -I scripts/diagnose_compile_full_call.py --framework "$framework" --label "$label" --source-root "$source" --source-commit "$revision" --output "$BURNER_EVALUATION_ARTIFACT_DIR/$label.json" "${options[@]}" > "$BURNER_EVALUATION_ARTIFACT_DIR/$label.log" 2>&1
 done
 done
