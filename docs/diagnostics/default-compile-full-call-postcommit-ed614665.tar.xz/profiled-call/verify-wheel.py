import hashlib, json, sys, zipfile
from pathlib import Path
source, wheel, destination = map(Path, sys.argv[1:])
root = Path.cwd()
for path in (source, wheel, destination, Path(sys.prefix)):
    assert path.resolve().is_relative_to(root), path
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
with zipfile.ZipFile(wheel) as archive:
    archive.extractall(destination)
for path in (source / 'python/torch_rs').rglob('*.py'):
    assert path.read_bytes() == (destination / 'torch_rs' / path.relative_to(source / 'python/torch_rs')).read_bytes(), path
sys.path.insert(0, str(destination))
import torch_rs
from torch_rs import _compile_trace
native = Path(_compile_trace._native.__file__)
assert native.is_relative_to(destination), native
print(json.dumps(dict(source=str(source), wheel=str(wheel), wheel_sha256=sha(wheel), package=torch_rs.__file__, native=str(native), native_sha256=sha(native), executable=sys.executable, prefix=sys.prefix), indent=2))
