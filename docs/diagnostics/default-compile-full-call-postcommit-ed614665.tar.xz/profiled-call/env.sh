for task_name in ${!CONDA_@} ${!_CONDA_@}; do unset "$task_name"; done
unset VIRTUAL_ENV UV_PROJECT_ENVIRONMENT PYTHONHOME PYTHONPATH
export VIRTUAL_ENV="$PWD/.venv" UV_PROJECT_ENVIRONMENT="$PWD/.venv"
export PYO3_PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
export CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CARGO_BUILD_JOBS=8
export XDG_CACHE_HOME="$PWD/target/full-call/cache"
export UV_CACHE_DIR="$XDG_CACHE_HOME/uv" CUDA_CACHE_PATH="$XDG_CACHE_HOME/cuda"
export CARGO_HOME="$PWD/target/full-call/cargo-home" CARGO_TARGET_DIR="$PWD/target/full-call/build-incoming"
export TMPDIR="$PWD/target/full-call/tmp"
export TORCHINDUCTOR_CACHE_DIR="$XDG_CACHE_HOME/inductor" TRITON_CACHE_DIR="$XDG_CACHE_HOME/triton"
export BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/full-call/evidence"
export TORCH_RS_CUDART="$VIRTUAL_ENV/lib/python3.12/site-packages/nvidia/cu13/lib/libcudart.so.13"
export PATH="$VIRTUAL_ENV/bin:/home/bobren/.cargo/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin"
