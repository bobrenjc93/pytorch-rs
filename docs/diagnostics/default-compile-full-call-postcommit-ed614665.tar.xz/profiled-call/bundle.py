#!/usr/bin/env python3
"""Package receipts or restore their deduplicated NPZ bytes; never compare timings."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE_SHA256 = '82ac63e93cee8d76d2f78226f9324ec92e032becf154bfac84861cd42c2ea265'
BASE_BYTES = 20204660


def sha(data):
    return hashlib.sha256(data).hexdigest()


def checked_base(path):
    data = path.read_bytes()
    if len(data) != BASE_BYTES or sha(data) != BASE_SHA256:
        raise ValueError('base archive hash/size mismatch')
    return tarfile.open(fileobj=io.BytesIO(data), mode='r:xz')


def checked(data, receipt):
    if len(data) != receipt['bytes'] or sha(data) != receipt['sha256']:
        raise ValueError('payload hash/size mismatch')
    return data


def basename(name):
    if Path(name).name != name:
        raise ValueError('expected a flat payload basename')
    return name


def pack(folder, base, output):
    payloads, arrays = {}, {}
    with checked_base(base) as archive:
        manifest = json.load(archive.extractfile('full-call/manifest.json'))
        available = {}
        for name, receipt in manifest.items():
            if name.endswith('.npz') and receipt['sha256'] not in available:
                member = 'full-call/' + name
                data = checked(archive.extractfile(member).read(), receipt)
                available[receipt['sha256']] = (member, data)
        for path in sorted(folder.iterdir()):
            if not path.is_file():
                raise ValueError('expected flat evidence directory')
            data = path.read_bytes()
            receipt = {'bytes': len(data), 'sha256': sha(data)}
            if path.suffix == '.npz':
                match = available.get(receipt['sha256'])
                if match is not None:
                    if data != match[1]:
                        raise ValueError('deduplicated bytes differ')
                    receipt['base_member'] = match[0]
                else:
                    payloads[path.name] = data
                arrays[path.name] = receipt
            else:
                payloads[path.name] = data
        for name, data in payloads.items():
            if name.endswith('.json'):
                report = json.loads(data)
                if isinstance(report, dict) and 'arrays' in report:
                    receipt = arrays[basename(Path(report['arrays']).name)]
                    if receipt['sha256'] != report['arrays_sha256']:
                        raise ValueError('capture/report NPZ hash mismatch')
    payloads['bundle.py'] = Path(__file__).read_bytes()
    metadata = {
        'purpose': 'Byte-preserving data deduplication; new timings retain their own receipts.',
        'base_archive': {'filename': base.name, 'bytes': BASE_BYTES, 'sha256': BASE_SHA256},
        'arrays': arrays,
        'payloads': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in payloads.items()},
    }
    payloads['bundle-manifest.json'] = (json.dumps(metadata, indent=2) + '\n').encode()
    with tarfile.open(output, 'w:xz') as archive:
        for name, data in payloads.items():
            member = tarfile.TarInfo('profiled-call/' + name)
            member.size, member.mode = len(data), 0o644
            archive.addfile(member, io.BytesIO(data))
    print(json.dumps({'archive': str(output), 'bytes': output.stat().st_size,
                      'sha256': sha(output.read_bytes()), 'payloads': len(payloads),
                      'arrays': len(arrays)}, indent=2))


def restore(folder, base):
    metadata = json.loads((folder / 'bundle-manifest.json').read_text())
    for name, receipt in metadata['payloads'].items():
        checked((folder / basename(name)).read_bytes(), receipt)
    with checked_base(base) as archive:
        for name, receipt in metadata['arrays'].items():
            target = folder / basename(name)
            if 'base_member' in receipt:
                data = checked(archive.extractfile(receipt['base_member']).read(), receipt)
                target.write_bytes(data)
            else:
                checked(target.read_bytes(), receipt)
    print(f"Verified all payloads; restored {len(metadata['arrays'])} NPZ files.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('pack', 'restore'))
    parser.add_argument('folder', type=Path)
    parser.add_argument('base', type=Path)
    parser.add_argument('output', type=Path, nargs='?')
    args = parser.parse_args()
    if args.action == 'pack':
        if args.output is None:
            parser.error('pack needs an output archive')
        pack(args.folder, args.base, args.output)
    else:
        restore(args.folder, args.base)
