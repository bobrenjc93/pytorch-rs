"""Offline verification/summary of this capture; delegates all comparisons to the committed comparator."""
import collections, datetime, hashlib, json, statistics, subprocess, sys, tarfile
from pathlib import Path
root = Path.cwd()
folder = Path(__file__).resolve().parent
revisions = dict(accepted='60202557b4f110d07777f585e804ab5f55e1ff7b', incoming='9a436482d3e49dd40df7ce1d75198890b16b8f95', retained='ed6146650aa1bf8d5ba13a17337b6331372c400c')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
summary = dict(purpose='Clean-commit non-scoring full-public-call evidence; descriptive statistics only.', timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), measured_commit=revisions['retained'], revisions=revisions, captures={}, comparisons=[], latency_comparisons=[])
for build, revision in revisions.items():
    wheel = json.loads((folder / (build + '-wheel.json')).read_text())
    assert sha(Path(wheel['wheel'])) == wheel['wheel_sha256']
    assert sha(Path(wheel['native'])) == wheel['native_sha256']
    for order in ('native-first', 'reference-second', 'reference-first', 'native-second'):
        name = build + '-' + order
        report = json.loads((folder / (name + '.json')).read_text())
        assert report['declared_source_commit'] == revision
        assert report['worktree_head']['stdout'] == revisions['retained']
        assert report['worktree_status']['stdout'] == ''
        assert report['script_sha256'] == sha(root / 'scripts/diagnose_compile_full_call.py')
        assert report['device_before']['uuid'] == report['device_after']['uuid'] == 'GPU-8f8e55a5-a9eb-eb79-bc43-807a19bcb1c1'
        assert report['torch_imported'] == (report['framework'] == 'torch')
        if report['framework'] == 'torch_rs':
            assert report['native_sha256'] == wheel['native_sha256']
            assert report['wheel_sha256'] == wheel['wheel_sha256']
            assert report['native_compilers']
        source = Path(report['source_root'])
        for path, expected in report['source_sha256'].items():
            assert sha(source / path) == expected, path
        counts = dict(collections.Counter(cell['status'] for cell in report['cells']))
        summary['captures'][name] = dict(statuses=counts, timestamp_ns=report['timestamp_ns'], samples=sum(len(c['samples_ns']) for c in report['cells']), sha256=sha(folder / (name + '.json')))
        assert not counts.get('error'), name
    for reference, native in [('reference-second','native-first'), ('reference-first','native-second')]:
        argv = [sys.executable, '-B', '-I', str(root / 'scripts/diagnose_compile_full_call.py'), '--compare', str(folder / (build + '-' + reference + '.json')), str(folder / (build + '-' + native + '.json'))]
        result = subprocess.run(argv, text=True, capture_output=True)
        (folder / (build + '-' + native + '-comparison.json')).write_text(result.stdout)
        summary['comparisons'].append(dict(argv=argv, returncode=result.returncode, stderr=result.stderr, result=json.loads(result.stdout)))
        assert result.returncode == 0, result.stderr
for prior in ('accepted', 'incoming'):
    for order in ('native-first', 'native-second'):
        old = json.loads((folder / (prior + '-' + order + '.json')).read_text())
        new = json.loads((folder / ('retained-' + order + '.json')).read_text())
        cells = []
        for a, b in zip(old['cells'], new['cells']):
            assert (a['program'],a['shape'],a['mode']) == (b['program'],b['shape'],b['mode'])
            if a['status'] == b['status'] == 'ok':
                before, after = statistics.median(a['samples_ns']), statistics.median(b['samples_ns'])
                cells.append(dict(program=a['program'], shape=a['shape'], mode=a['mode'], prior_median_ns=before, retained_median_ns=after, reduction_ns=before-after))
        summary['latency_comparisons'].append(dict(prior=prior, order=order, common_supported=len(cells), lower=sum(c['reduction_ns']>0 for c in cells), slower=sum(c['reduction_ns']<0 for c in cells), median_reduction_ns=statistics.median(c['reduction_ns'] for c in cells), cells=cells))
# The baseline snapshots are exact git-archive exports, checked after builds/captures.
summary['source_exports'] = {}
for build in ('accepted', 'incoming'):
    archive_path = folder.parent / (build + '-source.tar')
    source = folder.parent / 'sources' / build
    count = 0
    with tarfile.open(archive_path) as archive:
        for member in archive.getmembers():
            if member.isfile():
                assert (source / member.name).read_bytes() == archive.extractfile(member).read(), member.name
                count += 1
    summary['source_exports'][build] = dict(revision=revisions[build], archive_sha256=sha(archive_path), matched_regular_files=count)
(folder / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('latency_comparisons','comparisons')}, indent=2))
print(json.dumps([{k:v for k,v in row.items() if k!='cells'} for row in summary['latency_comparisons']], indent=2))
