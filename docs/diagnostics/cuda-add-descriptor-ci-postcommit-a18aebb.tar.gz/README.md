# Clean-commit portable descriptor verification

Measured commit: a18aebbc17dbce5c87f65216859ceaf7d8a5b530.
Pinned base: 60202557b4f110d07777f585e804ab5f55e1ff7b.
The clean source differs from the prior native implementation only in the
portable Tensor.add_ descriptor assertion; no earlier CUDA implementation work
or scored workload was reopened. The original author archive and first failed
environment-path attempt are preserved unchanged, not relabeled as this capture.

Every command used non-login bash, with env.sh clearing inherited CONDA_*/
_CONDA_*, VIRTUAL_ENV, UV_PROJECT_ENVIRONMENT, PYTHONHOME and PYTHONPATH before
explicit local selection. The existing author .venv was moved inside this
worktree to target/postcommit-a18aebb/prior-author-venv and not used afterward.
A fresh real .venv was created at the repository-supported path. The base
Python executable is read-only; the environment prefix, installs, native build,
new compiler caches and outputs are local. Worktree-local pip downloads and
Cargo registry contents were reused; Cargo's target directory was fresh.
No shared Python installation or configuration was modified or repaired.

Exact setup/build commands from the worktree root:

```bash
source target/postcommit-a18aebb/env.sh
mv .venv target/postcommit-a18aebb/prior-author-venv
/home/bobren/.local/share/uv/python/cpython-3.12.12-linux-x86_64-gnu/bin/python3.12 -B -I -m venv "$VIRTUAL_ENV"
"$PYO3_PYTHON" -B -I - <<'PY'
from pathlib import Path
import sys,sysconfig
expected=Path.cwd().resolve()/'.venv'
assert Path(sys.prefix).resolve()==expected
for key in ('purelib','platlib','scripts','data'):
    assert Path(sysconfig.get_path(key)).resolve().is_relative_to(expected)
PY
uv --no-config export --locked --no-emit-project --group dev --group reference --format requirements-txt > target/postcommit-a18aebb/requirements.txt
"$PYO3_PYTHON" -B -I -m pip --isolated --cache-dir "$PWD/target/descriptor-ci/cache/pip" install --require-hashes -r target/postcommit-a18aebb/requirements.txt
"$VIRTUAL_ENV/bin/maturin" build --release --locked --interpreter "$PYO3_PYTHON" --out target/postcommit-a18aebb/wheels
"$PYO3_PYTHON" -B -I target/postcommit-a18aebb/capture.py
```

capture.py repeats the destination assertions before wheel installation,
installs the exact wheel with pip --isolated --no-deps, invokes the unchanged
repository native-extension verifier, and compares wheel/extension and packaged
Python/source bytes before running the requested checks. commands.json records
those exact argv, overrides, UTC start times, durations and exit codes. Durations
are command receipts, not performance measurements.

```bash
"$PYO3_PYTHON" -B -m unittest -v tests.test_top_level_add tests.test_tensor_add tests.test_cuda_add_inplace.AddInplaceBindingTests
"$PYO3_PYTHON" -B -m unittest discover -s tests -p 'test_*.py'
```

Both processes use CUDA_VISIBLE_DEVICES='' and OMP/MKL limits of one. The existing
stack-validator unit fixture selects GPU0 in its child for environment metadata;
its unchanged smoke workload is part of the requested full suite, not a manual
canonical evaluator run. No separate GPU test or other device was requested.
The existing held gpu/cpu-heavy lease applies; no parallel heavy worker ran.

identity-before-tests.json and verification-after.json record the actual clean
commit, source hashes, prefix, imports, wheel/native bytes, versions and frozen
files. Prior committed evidence hashes are checked again after execution. All
raw logs, warnings and outcomes are retained. The diagnosis was previously read
in full; its SHA256 was reverified as
42534557744a208377976b8e2a47b58eb002e8b29e894cd05d049df8acd5a592.

This Linux x86_64/Python 3.12.12 capture is not macOS ARM64/Python 3.12 or Ubuntu/
Python 3.14 CI, independent review, canonical evaluation or publication approval.
No implementation, tests, locks, benchmark/evaluator inputs or progress artifacts
changed. No canonical scores were refreshed; current scope forbids manual runs
and does not revive earlier GPU/performance work. Original measured artifacts
remain pinned to their actual commits and receive no new performance credit here.
