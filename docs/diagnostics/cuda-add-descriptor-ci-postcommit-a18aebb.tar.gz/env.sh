for task_conda_name in ${!CONDA_@} ${!_CONDA_@}; do unset "$task_conda_name"; done
unset VIRTUAL_ENV UV_PROJECT_ENVIRONMENT PYTHONHOME PYTHONPATH
export VIRTUAL_ENV="$PWD/.venv"
export UV_PROJECT_ENVIRONMENT="$VIRTUAL_ENV" PYO3_PYTHON="$VIRTUAL_ENV/bin/python"
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 PIP_CONFIG_FILE=/dev/null
export CUDA_VISIBLE_DEVICES=''
export CARGO_HOME="$PWD/target/descriptor-ci/cargo-home" CARGO_TARGET_DIR="$PWD/target/postcommit-a18aebb/cargo-target"
export XDG_CACHE_HOME="$PWD/target/postcommit-a18aebb/cache" UV_CACHE_DIR="$PWD/target/postcommit-a18aebb/cache/uv"
export UV_PYTHON_INSTALL_DIR="$PWD/target/postcommit-a18aebb/python" CUDA_CACHE_PATH="$PWD/target/postcommit-a18aebb/cache/cuda"
export TORCHINDUCTOR_CACHE_DIR="$PWD/target/postcommit-a18aebb/cache/inductor" TRITON_CACHE_DIR="$PWD/target/postcommit-a18aebb/cache/triton"
export TMPDIR="$PWD/target/postcommit-a18aebb/tmp" BURNER_EVALUATION_ARTIFACT_DIR="$PWD/target/postcommit-a18aebb/evidence"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CARGO_BUILD_JOBS=8
