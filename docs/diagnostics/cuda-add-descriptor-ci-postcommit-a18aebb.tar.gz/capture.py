from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib, importlib.metadata, json, os, platform, subprocess, sys, sysconfig, time, zipfile
root=Path.cwd().resolve(); evidence=Path(os.environ['BURNER_EVALUATION_ARTIFACT_DIR']).resolve()
expected=root/'.venv'
assert evidence.is_relative_to(root) and Path(sys.prefix).resolve()==expected
parent='a18aebbc17dbce5c87f65216859ceaf7d8a5b530'
def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==parent
assert not git('status','--porcelain')
assert os.environ['CUDA_VISIBLE_DEVICES']==''
paths=git('ls-files','src','python','tests','Cargo.toml','Cargo.lock','uv.lock','pyproject.toml').splitlines()
sources={p:digest(root/p) for p in paths}
commands=[]
def run(name,args,overrides=None):
    env=os.environ.copy();env.update(overrides or {})
    started=datetime.now(timezone.utc).isoformat();before=time.monotonic()
    with (evidence/(name+'.log')).open('w') as out:
        result=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
    commands.append({'name':name,'argv':args,'cwd':str(root),'environment_overrides':overrides or {},'started_utc':started,'elapsed_seconds':time.monotonic()-before,'returncode':result.returncode})
    (evidence/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
for k in ('purelib','platlib','scripts','data'):
    assert Path(sysconfig.get_path(k)).resolve().is_relative_to(expected)
wheel=root/'target/postcommit-a18aebb/wheels/torch_rs-0.1.0-cp310-abi3-manylinux_2_34_x86_64.whl'
run('install',[sys.executable,'-B','-I','-m','pip','--isolated','install','--no-deps',str(wheel)])
run('verify-import',[sys.executable,'-B','.github/scripts/verify_native_extension.py'],{'TORCH_RS_VERIFY_VIRTUALENV':str(expected)})
package=importlib.import_module('torch_rs');native=importlib.import_module('torch_rs.torch_rs');torch=importlib.import_module('torch')
for m in (package,native,torch): assert Path(m.__file__).resolve().is_relative_to(expected),m.__file__
with zipfile.ZipFile(wheel) as z:
    extension=next(p for p in z.namelist() if p.endswith('.so'))
    assert hashlib.sha256(z.read(extension)).hexdigest()==digest(native.__file__)
    for p in (root/'python/torch_rs').rglob('*.py'):
        assert z.read(str(p.relative_to(root/'python')))==p.read_bytes(),p
frozen=['.burner/evaluations.json','scripts/run_with_unix_lock.py','.github/scripts/verify_native_extension.py','scripts/evaluate_torch_compile_default.sh','scripts/evaluate_torch_compile_default.py','scripts/torch_compile_default_corpus.py','Cargo.lock','uv.lock','README.md','docs/burner-evaluation-history.json','docs/burner-evaluation-progress.svg']
for p in frozen: assert (root/p).read_bytes()==subprocess.check_output(['git','show',f'HEAD:{p}']),p
preserved=git('ls-files','docs/diagnostics').splitlines()
receipt={'phase':'clean-commit portable descriptor verification; not CI/evaluation approval','captured_utc':datetime.now(timezone.utc).isoformat(),'measured_commit':parent,'pinned_base':'60202557b4f110d07777f585e804ab5f55e1ff7b','worktree':str(root),'git_status':git('status','--short'),'diff':git('diff','--','tests/test_top_level_add.py'),'source_hashes':sources,'frozen_hashes':{p:digest(root/p) for p in frozen},'preserved_evidence_hashes':{p:digest(root/p) for p in preserved},'python':{'version':sys.version,'executable':sys.executable,'prefix':sys.prefix,'base_prefix_read_only':sys.base_prefix,'destinations':{k:sysconfig.get_path(k) for k in ('purelib','platlib','scripts','data')}},'wheel':{'path':str(wheel),'sha256':digest(wheel),'installed_extension_matches':True,'packaged_python_matches_source':True},'imports':{m.__name__:{'path':m.__file__,'sha256':digest(m.__file__)} for m in (package,native,torch)},'torch_version':torch.__version__,'numpy_version':importlib.metadata.version('numpy'),'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'platform':platform.platform(),'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'cuda_available':torch.cuda.is_available(),'environment':{k:v for k,v in os.environ.items() if k.startswith(('CONDA_','_CONDA_')) or k in ('VIRTUAL_ENV','UV_PROJECT_ENVIRONMENT','PYO3_PYTHON','PYTHONHOME','PYTHONPATH','CARGO_HOME','CARGO_TARGET_DIR','XDG_CACHE_HOME','UV_CACHE_DIR','UV_PYTHON_INSTALL_DIR','TMPDIR','BURNER_EVALUATION_ARTIFACT_DIR','PIP_CONFIG_FILE','PYTHONNOUSERSITE','PYTHONDONTWRITEBYTECODE','CUDA_CACHE_PATH','TORCHINDUCTOR_CACHE_DIR','TRITON_CACHE_DIR','OMP_NUM_THREADS','MKL_NUM_THREADS')}}
assert not receipt['cuda_available']
(evidence/'identity-before-tests.json').write_text(json.dumps(receipt,indent=2)+'\n')
run('owner-tests',[sys.executable,'-B','-m','unittest','-v','tests.test_top_level_add','tests.test_tensor_add','tests.test_cuda_add_inplace.AddInplaceBindingTests'])
run('full-portable',[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_*.py'])
for p,h in sources.items(): assert digest(root/p)==h,p
for p,h in receipt['preserved_evidence_hashes'].items(): assert digest(root/p)==h,p
assert not git('status','--porcelain')
(evidence/'verification-after.json').write_text(json.dumps({'measured_commit':git('rev-parse','HEAD'),'source_hashes_unchanged':True,'source_count':len(sources),'prior_evidence_unchanged':True,'git_status':git('status','--short'),'captured_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')
