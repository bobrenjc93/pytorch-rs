from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess,tarfile
root=Path.cwd().resolve();e=root/'target/postcommit-a18aebb/evidence'
commit='a18aebbc17dbce5c87f65216859ceaf7d8a5b530'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
def counts(name):
 text=(e/(name+'.log')).read_text();count=int(re.search(r'Ran (\d+) tests?',text).group(1));skip=re.search(r'OK \(skipped=(\d+)\)',text)
 assert re.search(r'^OK(?: \(skipped=\d+\))?$',text,re.M)
 skipped=int(skip.group(1)) if skip else 0
 return {'run':count,'passed':count-skipped,'skipped':skipped,'failed':0}
assert git('rev-parse','HEAD')==commit and not git('status','--porcelain')
identity=json.loads((e/'identity-before-tests.json').read_text());after=json.loads((e/'verification-after.json').read_text())
assert identity['measured_commit']==after['measured_commit']==commit
assert identity['git_status']==after['git_status']==''
assert after['source_hashes_unchanged'] and after['prior_evidence_unchanged']
for key in ('source_hashes','frozen_hashes','preserved_evidence_hashes'):
 for p,h in identity[key].items():assert digest(root/p)==h,p
for archive_path in ('docs/diagnostics/cuda-add-descriptor-ci-author.tar.gz',):
 with tarfile.open(root/archive_path) as a:
  for line in a.extractfile('SHA256SUMS').read().decode().splitlines():
   h,n=line.split('  ',1);assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
commands=json.loads((e/'commands.json').read_text());assert all(x['returncode']==0 for x in commands)
owner=counts('owner-tests');full=counts('full-portable')
report={'kind':'clean-commit-portable-descriptor-evidence','measured_commit':commit,'captured_utc':datetime.now(timezone.utc).isoformat(),'dirty_during_capture':False,'owner_tests':owner,'full_portable_suite':full,'commands':commands,'source_hashes_verified':after['source_count'],'source_and_prior_evidence_unchanged':True,'author_archive_manifest_verified':True,'identity_file':'identity-before-tests.json','raw_directory':str(e),'scope':'Portable descriptor CI repair only; no CUDA reimplementation, scoring, independent review or CI approval','cache_state':'Fresh root .venv, Cargo target and compiler caches; existing worktree-local pip downloads and Cargo registry reused','limitations':['Linux x86_64/Python 3.12.12, not macOS ARM64/Python 3.12 or Ubuntu/Python 3.14 CI','No manual canonical evaluator or refreshed performance scores']}
(e/'report.json').write_text(json.dumps(report,indent=2)+'\n')
md=f'''# Clean-commit portable descriptor evidence

Captured from clean commit `{commit}` after the operator
released the author boundary. The only test/native-source change since `8ac9d0e`
is the corrected `Tensor.add_` descriptor assertion; this capture does not reopen
CUDA implementation or scoring work.

- Requested owner modules and portable `AddInplaceBindingTests`: {owner['passed']} passed.
- Full portable suite: {full['run']:,} run, {full['passed']:,} passed, {full['skipped']} skipped, zero failures.
- Fresh release wheel build, isolated install and repository native-import verifier: passed.
- {after['source_count']} source/test/build-input hashes and all prior evidence: unchanged through capture.

The [raw receipts](cuda-add-descriptor-ci-postcommit-a18aebb.tar.gz) include the
generated report, exact commands, source/wheel/import identities, complete logs
and warnings. Both requested test commands passed on their first attempts in this
capture. The environment was a fresh real worktree-root `.venv`, with explicit
Python 3.12.12 selection and destination checks before installation; locked
PyTorch 2.13.0 and CUDA-hidden suite execution were used. Build and compiler caches
were fresh, while local dependency downloads and the Cargo registry were reused.

The [original author record](cuda-add-descriptor-ci-author.md), its initial
`.venv` path-contract failure and all earlier measurements remain byte-identical
and pinned to their original identities. They have not been relabeled as this
clean capture. No implementation, tests, dependencies, validator/evaluator inputs,
managed progress artifacts or unrelated documentation changed in this step.

This Linux capture does not establish macOS ARM64/Python 3.12 or Ubuntu/Python
3.14 CI success. Those Actions and independent review remain required. No
canonical evaluator, performance recapture, commit, push or publication was run.
'''
(root/'docs/diagnostics/cuda-add-descriptor-ci-postcommit-a18aebb.md').write_text(md)
files=sorted(p for p in e.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(e/'SHA256SUMS').write_text(''.join(f'{digest(p)}  {p.relative_to(e)}\n' for p in files))
archive=root/'docs/diagnostics/cuda-add-descriptor-ci-postcommit-a18aebb.tar.gz'
with tarfile.open(archive,'w:gz') as a:
 for p in sorted(e.rglob('*')):
  if p.is_file():a.add(p,arcname=str(p.relative_to(e)),recursive=False)
with tarfile.open(archive,'r:gz') as a:
 for line in a.extractfile('SHA256SUMS').read().decode().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h,n
print(json.dumps(report,indent=2));print('archive',archive.stat().st_size,digest(archive))
