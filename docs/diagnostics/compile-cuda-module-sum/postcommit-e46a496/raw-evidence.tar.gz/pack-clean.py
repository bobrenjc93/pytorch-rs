"""Package actual clean-commit receipts; no workload or expected result changes."""
import hashlib, json, re, subprocess, tarfile
from pathlib import Path
ROOT=Path.cwd(); C=ROOT/'target/module-sum-postcommit-e46a496/checkout'; RAW=C/'target/module-sum-evidence'
DEST=ROOT/'docs/diagnostics/compile-cuda-module-sum/postcommit-e46a496'
HEAD='e46a496f995c1491a305f3038886e15cbb017fcf'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD'],text=True).strip()==HEAD
assert subprocess.check_output(['git','-C',str(C),'status','--porcelain'],text=True)==''
identity=read(RAW/'final-identity.log')
assert identity['source']['commit']==HEAD
assert identity['source']['production_diff_sha256']==sha(b'')
assert Path(identity['native']).is_relative_to(C/'.venv')
assert sha(Path(identity['native']).read_bytes())==identity['native_sha256']
for p in (C/'python/torch_rs').rglob('*.py'):
 assert p.read_bytes()==(Path(identity['native']).parent/p.relative_to(C/'python/torch_rs')).read_bytes()
receipts={p.stem:read(p) for p in RAW.glob('*.json') if 'source_hashes' in read(p)}
manifest=receipts['setup']['source_hashes']
for n,r in receipts.items():
 assert r['head']==HEAD and r['status']==0,(n,r['status'])
 assert r['source_hashes']==manifest,n
 assert sha((RAW/(n+'.log')).read_bytes())==r['log_sha256'],n
 if n!='bootstrap': assert r['clean_before']==r['clean_after']=='',n
 if n.startswith('rust-'):assert 'native' not in r
 if 'native' in r: assert r['native']['sha256']==identity['native_sha256']
for n,h in manifest.items():
 assert sha((C/n).read_bytes())==h,n
 assert sha(subprocess.check_output(['git','-C',str(C),'show',HEAD+':'+n]))==h,n
write(RAW/'source-manifest.json',dict(commit=HEAD,files=manifest,reconstruction='git show <commit>:<path>; verify each SHA-256',changes_from_commit=[]))
# Preserve the exact whole selection; shards change scheduling only.
rows=[]
for shard in range(2):
 folder=RAW/f'complete-{shard}'
 for r in read(folder/'results.json'):
  log=(folder/(r['module'].split('.')[-1]+'.log')).read_text()
  matches=re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$',log,re.M)
  assert len(matches)==1 and int(matches[0][0])>0 and r['status']==0,r
  skipped=re.search(r'^OK \(skipped=(\d+)\)$',log,re.M)
  rows.append(dict(**r,shard=shard,tests=int(matches[0][0]),skipped=int(skipped[1]) if skipped else 0,
    warning_lines=[s for s in log.splitlines() if 'Warning:' in s or re.match(r'^W\d{4} ',s)],
    skip_lines=[s for s in log.splitlines() if ' ... skipped ' in s],log_sha256=sha(log.encode())))
expected=sorted({'tests.'+p.stem for p in (C/'tests').glob('test_compile*.py')}|{'tests.test_top_level_compile'})
assert sorted(r['module'] for r in rows)==expected
selection=dict(selection='every tests/test_compile*.py plus tests/test_top_level_compile.py',modules=len(rows),tests=sum(r['tests'] for r in rows),skips=sum(r['skipped'] for r in rows),failures=0,results=sorted(rows,key=lambda r:r['module']),concurrent_disjoint_module_queues=2,timing_credit_claimed=False)
write(RAW/'complete-summary.json',selection)
# Compare actual replay inputs/programs/settings against historical baseline bytes.
with tarfile.open(C/'docs/diagnostics/compile-cuda-module-sum/raw-evidence.tar.gz') as t:
 baseline_bytes=t.extractfile('baseline.log').read(); baseline=json.loads(baseline_bytes)
 original=t.extractfile('original-probe-compiled-cuda-module-sum.py').read()
assert sha(original)=='9e8e66df128c5b7a7d0a56811dc1d704e6f2f8e4ff3867f3dc74568836f538c6'
probe=read(RAW/'candidate-probe.log')
assert len(baseline['cases'])==len(probe['cases'])==144
for a,b in zip(baseline['cases'],probe['cases']):
 for k in ('name','expression','arity','shape','input_sha256','reference_strict_parity_eligible','reference_inductor_cold_and_repeat_passed'):
  assert a[k]==b[k],(k,a['name'])
 assert all(call['passed'] for call in b['native_calls'])
assert baseline['unrelated_rebindings']==probe['unrelated_rebindings']
assert probe['source_provenance']==identity['source']
assert probe['native_extension_sha256']==identity['native_sha256']
closure=dict(verified=True,cells=144,closed_gaps=96,existing_controls=48,unrelated_rebindings=4,all_input_hashes_programs_reference_settings_match=True,historical_baseline_log_sha256=sha(baseline_bytes),original_probe_sha256=sha(original),candidate_probe_log_sha256=sha((RAW/'candidate-probe.log').read_bytes()))
write(RAW/'candidate-closure.json',closure)
checks={}
for n in ('two-gpu','eager-reference','final-hidden','final-docs'):
 s=(RAW/(n+'.log')).read_text();m=re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$',s,re.M);assert len(m)==1 and int(m[0][0])>0
 skip=re.search(r'^OK \(skipped=(\d+)\)$',s,re.M)
 checks[n]=dict(tests=int(m[0][0]),skips=int(skip[1]) if skip else 0,status=receipts[n]['status'],effective_mask=receipts[n]['effective_cuda_visible_devices'])
assert checks['two-gpu']['skips']==0 and checks['two-gpu']['effective_mask']=='0,1'
for n in ('rust-gpu','rust-planner'):
 s=(RAW/(n+'.log')).read_text();m=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)
 assert len(m)==1 and int(m[0][0])>0 and m[0][1:]==('0','0') and 'skipping' not in s.lower()
 checks[n]=dict(tests=int(m[0][0]),failed=0,ignored=0,hardware_early_return=False,status=receipts[n]['status'])
s=(RAW/'rust-final.log').read_text()
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)
assert counts and all(f==i=='0' for _,f,i in counts)
# Preserve suite order and all zero-test harnesses without crediting them as GPU execution.
sections=s.split('Running unittests src/lib.rs')
assert len(sections)==3
rust_totals=[sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',part)) for part in sections[1:]]
checks['rust-final']=dict(default_tests=rust_totals[0],python_binding_tests=rust_totals[1],total_tests=sum(int(n) for n,_,_ in counts),harness_counts=[int(n) for n,_,_ in counts],status=0,command=receipts['rust-final']['command'],includes_format_and_both_clippy_configs=True)
write(RAW/'checks-summary.json',checks)
# Exact source versions are reconstructible from this commit and retained manifest.
# Preserve scripts, receipts, logs and original committed recipes, omit redundant source blobs.
(RAW/'pack-clean.py').write_bytes(Path(__file__).read_bytes())
files=[p for p in RAW.rglob('*') if p.is_file() and 'sources' not in p.relative_to(RAW).parts and p.name!='archive-members.json']
write(RAW/'archive-members.json',{str(p.relative_to(RAW)):sha(p.read_bytes()) for p in sorted(files)})
DEST.mkdir(parents=True,exist_ok=True)
with tarfile.open(DEST/'raw-evidence.tar.gz','w:gz') as t:
 for p in sorted([*files,RAW/'archive-members.json']):t.add(p,arcname=str(p.relative_to(RAW)),recursive=False)
commands=[]
for n,r in sorted(receipts.items()):
 v={k:x for k,x in r.items() if k!='source_hashes'}
 v.update(name=n,source_manifest='source-manifest.json',warning_lines=[l for l in (RAW/(n+'.log')).read_text().splitlines() if 'Warning:' in l or re.match(r'^W\d{4} ',l)])
 commands.append(v)
write(DEST/'commands.json',commands)
summary=dict(kind='clean implementation commit capture; non-scoring correctness evidence',measured_commit=HEAD,checkout=str(C),clean_before_and_after=True,identity=identity,
 reference_compiler=read(RAW/'reference-compiler.log'),bootstrap=read(RAW/'bootstrap.log'),dependency_and_build_identity=read(RAW/'audit-bindings.log'),
 wheels=[dict(path=str(p),sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in (C/'target/clean-wheel').glob('*.whl')],
 compiler_selection={k:v for k,v in selection.items() if k!='results'},candidate_closure=closure,checks=checks,
 raw_evidence_sha256=sha((DEST/'raw-evidence.tar.gz').read_bytes()),historical_development_archive_sha256=sha((C/'docs/diagnostics/compile-cuda-module-sum/raw-evidence.tar.gz').read_bytes()),
 resources=['gpu','cpu-heavy'],resource_note='correctness workload concurrency only; no exclusive reservation or timing credit',gpu_snapshots_are_reservations=False,cache_state='new checkout, absent .venv and interpreter destination, empty worktree-local dependency/build/Inductor/Triton/CUDA caches at setup; caches reused within this capture',
 recipe_adaptations=['bootstrap root/head prerequisite only; original inventory assertions retained','run.py adds cleanliness and effective-mask provenance, disables user site/PYTHONPATH, omits extension attribution for Rust','complete-shard.py schedules unchanged unittest modules in two disjoint queues'],
 pending_review_and_merge_gates=True)
write(DEST/'capture.json',summary)
print(json.dumps(dict(destination=str(DEST),compiler=summary['compiler_selection'],checks=checks,closure=closure),indent=2))
