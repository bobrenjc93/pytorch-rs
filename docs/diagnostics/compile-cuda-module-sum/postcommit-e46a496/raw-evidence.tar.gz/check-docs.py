from pathlib import Path
import re, hashlib, json
files=['FEATURES.md','docs/README.md','docs/supported-surface.md','docs/compile-cuda-sum-rows.md','docs/diagnostics/compile-cuda-module-sum/README.md']
count=0
for name in files:
 p=Path(name)
 for dest in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in dest or dest.startswith('mailto:'):continue
  target=dest.split('#',1)[0]
  if target:
   assert (p.parent/target).exists(),(name,dest)
   count+=1
print(json.dumps({name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in files}, indent=2))
print('Existing relative documentation targets:',count)
source=re.findall(r'```python\n(.*?)```',Path('docs/compile-cuda-sum-rows.md').read_text(),re.S)
assert len(source)==1
exec(compile(source[0],'docs/compile-cuda-sum-rows.md','exec'))
print('Documented positional row-sum example: passed on CUDA:0')
