import hashlib, importlib.metadata, json, os, sys
from pathlib import Path
import numpy, torch, torch_rs
root=Path.cwd(); venv=root/'.venv'
paths={name:module.__file__ for name,module in [('numpy',numpy),('torch',torch),('torch_rs',torch_rs),('native',torch_rs._C)]}
for name,path in paths.items():assert Path(path).resolve().is_relative_to(venv),(name,path)
assert Path(sys.prefix).resolve()==venv
assert Path(sys.base_prefix).resolve().is_relative_to(root/'target/uv-python')
keys=['RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTUP_TOOLCHAIN','CARGO_ENCODED_RUSTFLAGS','TORCH_RS_CUDART','CUDA_VISIBLE_DEVICES','LD_LIBRARY_PATH','PYTHONPATH','PYTHONHOME']
print(json.dumps(dict(paths=paths,sys_path=sys.path,environment={k:os.environ.get(k) for k in keys},versions={name:importlib.metadata.version(name) for name in ('torch','numpy','maturin','torch-rs')},build_input_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ('Cargo.toml','Cargo.lock','pyproject.toml','uv.lock','rust-toolchain.toml')}),indent=2))
