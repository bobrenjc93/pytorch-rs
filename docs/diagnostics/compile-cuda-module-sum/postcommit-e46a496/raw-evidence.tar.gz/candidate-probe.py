"""Frozen, non-scoring pre-edit probe for top-level CUDA row-sum capture.

Run only after PR 1987 and all ten baseline promotions are independently
verified. Every cell must pass strict reference values and metadata; retain
any original failure before considering an explicit zero-credit exception.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from unittest.mock import patch

import numpy as np
import torch
import torch_rs as native

root = Path.cwd().resolve()
sys.path.insert(0, str(root))
from tests.test_cuda_contiguous import metadata
from scripts.evaluate_cuda_math import source_provenance


def program_for(expression, arity, module):
    namespace = {"__name__": __name__, "m": module, "sum_alias": module.sum}
    arguments = "x" if arity == 1 else "x, y"
    exec(f"def program({arguments}):\n    return {expression}\n", namespace)
    return namespace["program"]


def no_original_body(program, callback):
    def reject(frame, event, argument):
        if event == "call" and frame.f_code is program.__code__:
            raise AssertionError("native compiled execution entered original Python body")
    previous = sys.getprofile()
    try:
        sys.setprofile(reject)
        return callback()
    finally:
        sys.setprofile(previous)


def compare(actual, expected):
    assert metadata(actual) == metadata(expected), (metadata(actual), metadata(expected))
    np.testing.assert_allclose(
        np.asarray(actual.cpu().tolist(), dtype=np.float32).reshape(tuple(actual.shape)),
        expected.detach().cpu().numpy(), rtol=0, atol=0)


def gap(callback):
    try:
        callback()
    except NotImplementedError as error:
        assert type(error).__name__ == "CompileTraceUnsupportedError", repr(error)
        return {"type": type(error).__name__, "message": str(error)}
    raise AssertionError("Expected the native-module row-sum capture gap on main")


head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert len(sys.argv) == 3 and re.fullmatch(r"[0-9a-f]{40}", sys.argv[1]) and head == sys.argv[1]
# The pre-edit baseline retained the exact-main promotion prerequisites.
# Candidate runs are bound to their own HEAD and production source hash.
# Candidate changes are bound by source_provenance below.
assert os.environ["CUDA_VISIBLE_DEVICES"] == "0"
assert torch.cuda.is_available() and torch.cuda.device_count() == 1
assert torch.cuda.get_device_name(0) == "NVIDIA H100"
assert Path(sys.prefix).resolve() == root / ".venv"
assert Path(native._C.__file__).resolve().is_relative_to(root / ".venv")

source_before = source_provenance()
assert source_before["source_sha256"] == sys.argv[2]
assert source_before["commit"] == head
assert native.sum is native._C.sum
assert native.sum is native._C._VariableFunctionsClass.sum
specifications = (
    ("module_sum_dim_one", "m.sum(x, 1)", 1, True),
    ("imported_sum_dim_one", "sum_alias(x, 1)", 1, True),
    ("module_sum_dim_negative_one", "m.sum(x, -1)", 1, True),
    ("imported_sum_dim_negative_one", "sum_alias(x, -1)", 1, True),
    ("module_sum_after_add", "m.sum(x + x, 1)", 1, True),
    ("imported_sum_after_add", "sum_alias(x + x, 1)", 1, True),
    ("module_sum_before_relu", "m.relu(m.sum(x, 1))", 1, True),
    ("imported_sum_before_relu", "m.relu(sum_alias(x, 1))", 1, True),
    ("existing_method_sum", "x.sum(dim=1)", 1, False),
    ("existing_module_reshape", "m.reshape(x, {original_shape})", 1, False),
    ("existing_module_t", "m.t(x)", 1, False),
    ("existing_module_relu", "m.relu(x)", 1, False),
)
shapes = (
    (0, 0), (0, 3), (1, 0), (1, 1), (1, 3), (2, 1),
    (2, 3), (3, 2), (3, 7), (7, 3), (17, 65), (32, 1025),
)
view_labels = {"existing_module_reshape", "existing_module_t"}
rng = np.random.default_rng(198801)
cases = []
for label, expression_template, arity, expected_gap in specifications:
    for shape in shapes:
        expression = expression_template.format(original_shape=repr(shape))
        # Dyadic FP32 inputs keep these bounded reductions exactly representable.
        # This is a correctness/capture probe, not a performance measurement.
        data = [np.asarray(rng.integers(-31, 32, size=shape) * .125, dtype=np.float32)
                for _ in range(arity)]
        args = [native.tensor(value.reshape(-1)).reshape(shape).to("cuda:0") for value in data]
        refs = [torch.tensor(value.reshape(-1), device="cuda:0").reshape(shape) for value in data]
        for actual, expected in zip(args, refs):
            assert metadata(actual) == metadata(expected), (label, shape)
        program = program_for(expression, arity, native)
        reference_program = program_for(expression, arity, torch)
        expected = reference_program(*refs)
        eager = program(*args)
        compare(eager, expected)
        assert all(eager is not arg for arg in args)
        if label in view_labels:
            assert eager.data_ptr() == args[0].data_ptr()
            assert expected.data_ptr() == refs[0].data_ptr()
        torch._dynamo.reset()
        reference = torch.compile(reference_program, backend="inductor", fullgraph=True, dynamic=False)
        for reference_call in ("cold", "repeat"):
            actual_reference = reference(*refs)
            torch.testing.assert_close(actual_reference, expected, rtol=0, atol=0)
            assert metadata(actual_reference) == metadata(expected), (
                label, shape, reference_call, metadata(actual_reference), metadata(expected))
        compiled = no_original_body(program, lambda: native.compile(
            program, backend="eager", fullgraph=True, dynamic=False))
        results = []
        for call in ("cold", "repeat"):
            invoke = lambda: no_original_body(program, lambda: compiled(*args))
            if expected_gap:
                actual = invoke()
                compare(actual, expected)
                assert all(actual is not arg for arg in args)
                results.append({"call": call, "passed": True})
            else:
                actual = invoke()
                compare(actual, expected)
                assert all(actual is not arg for arg in args)
                if label in view_labels:
                    assert actual.data_ptr() == args[0].data_ptr()
                results.append({"call": call, "passed": True})
        for actual, reference_input in zip(args, refs):
            compare(actual, reference_input)
        cases.append({"name": label, "expression": expression, "arity": arity,
                      "shape": list(shape), "expected_gap": expected_gap,
                      "input_sha256": [hashlib.sha256(value.tobytes()).hexdigest() for value in data],
                      "native_eager_passed": True,
                      "reference_inductor_cold_and_repeat_passed": True,
                      "reference_strict_parity_eligible": True,
                      "original_native_program_body_not_executed": True, "native_calls": results})

unrelated_rebindings = []
for expression, reference_callback in (
    ("x.sum(dim=1)", lambda x: x.sum(dim=1)),
    ("m.reshape(x, (3, 2))", lambda x: x.reshape(3, 2)),
    ("m.t(x)", lambda x: x.t()),
    ("m.relu(x)", lambda x: x.relu()),
):
    calls = []
    def forbidden(*args, **kwargs):
        calls.append(True)
        raise AssertionError("executed unrelated replacement callable")
    program = program_for(expression, 1, native)
    values = [[1., -2., 3.], [4., 5., -6.]]
    x = native.tensor(values).to("cuda:0")
    tx = torch.tensor(values, device="cuda:0")
    expected = reference_callback(tx)
    compiled = native.compile(program, backend="eager", fullgraph=True, dynamic=False)
    compare(no_original_body(program, lambda: compiled(x)), expected)
    with patch.object(native, "sum", forbidden):
        compare(no_original_body(program, lambda: compiled(x)), expected)
        cold = native.compile(program, backend="eager", fullgraph=True, dynamic=False)
        compare(no_original_body(program, lambda: cold(x)), expected)
    assert not calls
    unrelated_rebindings.append({"attribute": "sum", "expression": expression,
                                 "existing_program_preserved": True,
                                 "replacement_callback_calls": len(calls)})

assert len(cases) == 144 and sum(case["expected_gap"] for case in cases) == 96
# Candidate changes are bound by source_provenance below.
assert source_provenance() == source_before
print(json.dumps({"verified_candidate_closure": True, "commit": head,
                  "diagnostic_protocol_version": 1, "frozen_seed": 198801,
                  "strict_reference_eligible_cases": 144,
                  "strict_reference_eligible_gap_cases": 96,
                  "reference_metadata_ineligible_cases": 0,
                  "source_provenance": source_before,
                  "genuine_sum_is_native_module_function": True,
                  "variable_function_owner_sum_is_genuine": True,
                  "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "metadata_helper_sha256": hashlib.sha256((root / "tests/test_cuda_contiguous.py").read_bytes()).hexdigest(),
                  "native_extension": native._C.__file__,
                  "native_extension_sha256": hashlib.sha256(Path(native._C.__file__).read_bytes()).hexdigest(),
                  "reference": torch.__version__, "gpu": torch.cuda.get_device_name(0),
                  "cases": cases, "unrelated_rebindings": unrelated_rebindings,
                  "closed_gap_cases": 96, "existing_positive_cases": 48,
                  "reference_compile_backend": "inductor", "native_compile_backend": "eager",
                  "native_backend_note": "Native CUDA graph capture/execution; original program body forbidden",
                  "cuda_performance_measured": False, "scores_changed": False,
                  "physical_gpu_snapshot_after": subprocess.check_output(["nvidia-smi",
                      "--query-gpu=index,uuid,name,utilization.gpu,memory.used", "--format=csv,noheader"], text=True),
                  "gpu_snapshot_is_not_reservation": True}, indent=2))
