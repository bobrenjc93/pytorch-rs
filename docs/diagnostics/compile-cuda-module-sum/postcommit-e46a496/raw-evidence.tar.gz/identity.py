import ctypes, hashlib, json, os, subprocess, sys
from pathlib import Path
import torch, torch_rs, numpy
from tests.test_cuda_add import runtime
from scripts.evaluate_cuda_math import source_provenance
root=Path.cwd(); native=Path(torch_rs._C.__file__)
assert Path(sys.prefix).resolve()==root/'.venv'
assert native.resolve().is_relative_to(root/'.venv')
for p in (root/'python/torch_rs').rglob('*.py'):
 installed=Path(torch_rs.__file__).parent/p.relative_to(root/'python/torch_rs')
 assert p.read_bytes()==installed.read_bytes(), str(p)
lib=runtime(); version=ctypes.c_int(); assert lib.cudaRuntimeGetVersion(ctypes.byref(version))==0
print(json.dumps(dict(source=source_provenance(),python=sys.version,executable=sys.executable,base_prefix=sys.base_prefix,native=str(native),native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),torch=torch.__version__,reference_cuda=torch.version.cuda,numpy=numpy.__version__,native_runtime=lib._name,native_runtime_version=version.value,cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'],rustc=subprocess.check_output(['rustc','--version'],text=True),cargo=subprocess.check_output(['cargo','--version'],text=True),nvcc=subprocess.check_output(['nvcc','--version'],text=True),cuda_libraries=[s for s in Path('/proc/self/maps').read_text().splitlines() if any(k in s for k in ('libcuda.','libcudart.'))]),indent=2))
