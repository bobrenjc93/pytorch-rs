import hashlib, json, re
from pathlib import Path
root=Path.cwd(); raw=root/'target/module-sum-evidence'
receipt=json.loads((raw/'complete.json').read_text())
assert receipt['status']==0
for name, digest in receipt['source_hashes'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest, name
rows=json.loads((raw/'complete/results.json').read_text())
expected=sorted({'tests.'+p.stem for p in (root/'tests').glob('test_compile*.py')} | {'tests.test_top_level_compile'})
assert sorted(r['module'] for r in rows)==expected
summaries=[]
for row in rows:
 text=(raw/'complete'/(row['module'].split('.')[-1]+'.log')).read_text()
 matches=re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$',text,re.M)
 assert len(matches)==1 and int(matches[0][0])>0,row
 assert row['status']==0,row
 skipped=re.search(r'^OK \(skipped=(\d+)\)$',text,re.M)
 summaries.append(dict(**row,tests=int(matches[0][0]),skipped=int(skipped[1]) if skipped else 0,
                       warning_lines=[line for line in text.splitlines() if 'Warning:' in line or re.match(r'^W\d{4} ',line)]))
summary=dict(selection='every tests/test_compile*.py plus tests/test_top_level_compile.py; disjoint module processes',
 modules=len(rows),tests=sum(r['tests'] for r in summaries),skipped=sum(r['skipped'] for r in summaries),
 failures=0,status=0,results=summaries,timing_credit_claimed=False)
(raw/'complete-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
a=json.loads((raw/'baseline.log').read_text());b=json.loads((raw/'candidate-probe.log').read_text())
assert len(a['cases'])==len(b['cases'])==144
for left,right in zip(a['cases'],b['cases']):
 for k in ('name','expression','arity','shape','input_sha256','reference_strict_parity_eligible','reference_inductor_cold_and_repeat_passed'):
  assert left[k]==right[k],(k,left,right)
 assert all(call['passed'] for call in right['native_calls'])
assert a['unrelated_rebindings']==b['unrelated_rebindings']
(raw/'candidate-closure.json').write_text(json.dumps(dict(verified=True,cells=144,closed_gaps=96,existing_controls=48,unrelated_rebindings=4,all_input_hashes_match_frozen_baseline=True,source_provenance=b['source_provenance'],native_sha256=b['native_extension_sha256']),indent=2)+'\n')
for name in ('rust-gpu','rust-planner'):
 text=(raw/(name+'.log')).read_text()
 matches=re.findall(r'test result: ok\. (\d+) passed;',text)
 assert len(matches)==1 and int(matches[0])>0
 assert 'skipping' not in text.lower()
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
