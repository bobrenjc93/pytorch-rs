import hashlib, json, os, subprocess
from pathlib import Path
import triton
from triton.backends.nvidia.compiler import get_ptxas
compiler=get_ptxas(90)
path=Path(compiler.path).resolve()
assert path.is_relative_to(Path.cwd()/'.venv'),path
print(json.dumps(dict(triton=triton.__version__,architecture=90,selected_ptxas=str(path),selected_ptxas_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),version=subprocess.check_output([str(path),'--version'],text=True),overrides={k:os.environ.get(k) for k in ('TRITON_PTXAS_PATH','TRITON_PTXAS_BLACKWELL_PATH','TRITON_MOCK_PTX_VERSION','PTXAS_OPTIONS','DISABLE_PTXAS_OPT')},native_cuda_compiler='embedded PTX, driver JIT; no nvcc or NVRTC invocation'),indent=2))
