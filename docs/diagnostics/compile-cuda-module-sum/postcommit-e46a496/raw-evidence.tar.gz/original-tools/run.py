import os, sys, subprocess, json, hashlib, time
from pathlib import Path
root=Path.cwd(); out=root/'target/module-sum-evidence'
env=os.environ.copy()
env.update({k:str(root/v) for k,v in {'UV_CACHE_DIR':'target/cache/uv','UV_PYTHON_INSTALL_DIR':'target/uv-python','CARGO_HOME':'target/cargo-home','CARGO_TARGET_DIR':'target','TMPDIR':'target/tmp','XDG_CACHE_HOME':'target/cache','TORCHINDUCTOR_CACHE_DIR':'target/cache/inductor','TRITON_CACHE_DIR':'target/cache/triton','CUDA_CACHE_PATH':'target/cache/cuda','PYO3_PYTHON':'.venv/bin/python','VIRTUAL_ENV':'.venv'}.items()})
env.update(CUDA_VISIBLE_DEVICES='0',PYTHONDONTWRITEBYTECODE='1',UV_PYTHON_DOWNLOADS='never',CARGO_BUILD_JOBS='8',RAYON_NUM_THREADS='8',OMP_NUM_THREADS='8')
env['PATH']='/home/bobren/.rustup/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin:'+str(root/'.venv/bin')+':'+env['PATH']
name=sys.argv[1]; command=sys.argv[2:]
snapshot=lambda:subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,utilization.gpu,memory.used,driver_version','--format=csv,noheader'],text=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=[p for d in ('src','python','tests') for p in (root/d).rglob('*') if p.is_file() and p.suffix in ('.py','.rs','.ptx')]
record=dict(command=command,environment={k:env[k] for k in env if k in ('PATH','CUDA_VISIBLE_DEVICES','PYTHONDONTWRITEBYTECODE','UV_PYTHON_DOWNLOADS','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','OMP_NUM_THREADS') or k.endswith(('_DIR','_HOME','_PATH','PYTHON'))},head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_hashes={str(p.relative_to(root)):sha(p) for p in sources},before_gpu=snapshot(),start=time.time())
# Preserve every executed source by content; fixtures are never reconstructed from assumptions.
store=out/'sources';store.mkdir(exist_ok=True)
for p in sources:
 dest=store/record['source_hashes'][str(p.relative_to(root))]
 if not dest.exists():dest.write_bytes(p.read_bytes())
for p in (root/'.venv/lib/python3.12/site-packages/torch_rs').glob('*.so'):
 record['native']={'path':str(p),'sha256':sha(p)}
with (out/(name+'.log')).open('w') as log:
 result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(status=result.returncode,end=time.time(),after_gpu=snapshot(),log_sha256=sha(out/(name+'.log')))
(out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(name,result.returncode,flush=True)
sys.exit(result.returncode)
