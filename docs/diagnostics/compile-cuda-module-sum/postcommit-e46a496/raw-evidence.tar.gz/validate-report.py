"""Read-only checks for the generated evidence and its navigation."""
import hashlib,json,re,subprocess,sys,tarfile,time
from pathlib import Path
root=Path.cwd();base=root/'docs/diagnostics/compile-cuda-module-sum';dest=base/'postcommit-e46a496';capture=json.loads((dest/'capture.json').read_text());head=capture['measured_commit'];c=Path(capture['checkout']);sha=lambda b:hashlib.sha256(b).hexdigest()
start=time.time();assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert subprocess.check_output(['git','-C',str(c),'status','--porcelain'],text=True)==''
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();assert changed==['docs/compile-cuda-sum-rows.md'],changed
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
assert all(n.startswith(str(dest.relative_to(root))+'/') for n in untracked),untracked
for p in base.iterdir():
 if p.is_file():assert p.read_bytes()==subprocess.check_output(['git','show',head+':'+str(p.relative_to(root))]),p
assert sha((dest/'raw-evidence.tar.gz').read_bytes())==capture['raw_evidence_sha256']
with tarfile.open(dest/'raw-evidence.tar.gz') as archive:
 names=archive.getnames();assert len(names)==len(set(names))
 members=json.load(archive.extractfile('archive-members.json'))
 for n,h in members.items():assert sha(archive.extractfile(n).read())==h,n
 commands=json.loads((dest/'commands.json').read_text())
 for receipt in commands:
  assert receipt['head']==head and receipt['status']==0
  assert sha(archive.extractfile(receipt['name']+'.log').read())==receipt['log_sha256']
 source=json.load(archive.extractfile('source-manifest.json'))
 for n,h in source['files'].items():assert sha((c/n).read_bytes())==h
 tests=json.load(archive.extractfile('complete-summary.json'))
 expected=sorted({'tests.'+p.stem for p in (c/'tests').glob('test_compile*.py')}|{'tests.test_top_level_compile'})
 assert sorted(r['module'] for r in tests['results'])==expected
 assert all(r['status']==0 and r['tests']>0 for r in tests['results'])
 assert tests['tests']==sum(r['tests'] for r in tests['results'])
 assert tests['skips']==sum(r['skipped'] for r in tests['results'])
 warning_lines=sum(len(r['warning_lines']) for r in tests['results'])
files=['FEATURES.md','docs/README.md','docs/supported-surface.md','docs/compile-cuda-sum-rows.md',str((dest/'README.md').relative_to(root))]
links=0
for n in files:
 p=root/n
 for value in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in value or value.startswith('mailto:'):continue
  target=value.split('#',1)[0]
  if target:assert (p.parent/target).exists(),(n,value);links+=1
subprocess.run(['git','diff','--check'],check=True)
result=dict(verified=True,command=[sys.executable,str(Path(__file__).resolve())],cwd=str(root),start=start,end=time.time(),measured_commit=head,clean_measured_checkout=True,historical_files_unchanged=True,archive_members=len(names),source_files=len(source['files']),compiler_modules=len(expected),compiler_tests=tests['tests'],compiler_skips=tests['skips'],compiler_warning_lines=warning_lines,relative_documentation_targets=links,documentation_sha256={n:sha((root/n).read_bytes()) for n in files},raw_evidence_sha256=capture['raw_evidence_sha256'],status=0)
(dest/'report-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
