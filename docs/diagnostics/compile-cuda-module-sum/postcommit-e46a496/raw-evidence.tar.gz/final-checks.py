import json, subprocess, sys
from pathlib import Path
root=Path.cwd(); out=root/'target/module-sum-evidence'
checks=[('candidate-probe',[str(root/'.venv/bin/python'),str(out/'candidate-probe.py'),subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),json.loads((out/'final-identity.log').read_text())['source']['source_sha256']]),
 ('two-gpu',['env','CUDA_VISIBLE_DEVICES=0,1',str(root/'.venv/bin/python'),'-m','unittest','-v','tests.test_compile_cuda_module_sum.ModuleSumDeviceTests','tests.test_compile_cuda_sum_rows.CompileCudaSumDeviceTests']),
 ('eager-reference',[str(root/'.venv/bin/python'),'-m','unittest','-v','tests.test_cuda_sum_rows','tests.test_top_level_sum','tests.test_top_level_sum_reference','tests.test_tensor_sum_reference']),
 ('rust-final',['bash','-c','cargo fmt --check && cargo test --locked --all-targets && cargo test --locked --features python-bindings --all-targets && cargo clippy --locked --all-targets -- -D warnings && cargo clippy --locked --all-targets --features python-bindings -- -D warnings']),
 ('rust-gpu',['cargo','test','--locked','--test','cuda_sum_rows','--','--nocapture']),
 ('rust-planner',['cargo','test','--locked','--features','python-bindings','--lib','python::compile_cuda_graph::tests','--','--nocapture']),
 ('final-hidden',['env','CUDA_VISIBLE_DEVICES=',str(root/'.venv/bin/python'),'-m','unittest','-v','tests.test_compile_cuda_module_sum.ModuleSumFrontendTests','tests.test_compile_sum_lowering','tests.test_top_level_compile']),
 ('doc-example',[str(root/'.venv/bin/python'),str(out/'check-docs.py')]),
 ('audit-bindings',[str(root/'.venv/bin/python'),str(out/'audit-bindings.py')]),
 ('final-docs',[str(root/'.venv/bin/python'),'-m','unittest','-v','tests.test_readme_quickstart'])]
for name,command in checks:
 r=subprocess.run(['python3','-B',str(out/'run.py'),name,*command]);print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
