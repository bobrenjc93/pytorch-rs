"""Exhaustive disjoint module processes; retain all outputs and statuses."""
import json, os, subprocess, sys
from pathlib import Path
root=Path.cwd(); out=root/'target/module-sum-evidence/complete';out.mkdir(exist_ok=True)
files=sorted(set((root/'tests').glob('test_compile*.py')) | {root/'tests/test_top_level_compile.py'})
results=[]
for p in files:
 module='tests.'+p.stem
 command=[sys.executable,'-m','unittest','-v',module]
 with (out/(p.stem+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(module=module,command=command,status=result.returncode))
 print(module,result.returncode,flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert len(results)==len(files)
sys.exit(any(r['status'] for r in results))
