import json, subprocess, time
from pathlib import Path
p=Path('target/module-sum-evidence/complete.json')
while not p.exists():time.sleep(1)
assert json.loads(p.read_text())['status']==0, 'inspect complete selection failures first'
raise SystemExit(subprocess.run(['python3','-B','target/module-sum-evidence/final-checks.py']).returncode)
