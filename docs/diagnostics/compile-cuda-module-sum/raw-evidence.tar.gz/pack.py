"""Retain compact, losslessly reconstructable non-scoring development evidence."""
import gzip, hashlib, io, json, re, subprocess, tarfile
from pathlib import Path
root=Path.cwd(); raw=root/'target/module-sum-evidence'; out=root/'docs/diagnostics/compile-cuda-module-sum'
base='a8ea1225406d3aaa0412d74091ecd8aef97ea1a7'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write_json(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
# All unchanged sources reconstruct from this retained git commit; changed and
# newly added sources are stored by content. No source version is inferred.
base_manifest=json.loads((raw/'setup.json').read_text())['source_hashes']
for name,h in base_manifest.items():
 assert sha(subprocess.check_output(['git','show',base+':'+name]))==h,name
history={}; commands=[]; extra=set()
for p in sorted(raw.glob('*.json')):
 record=json.loads(p.read_text())
 if 'command' not in record or 'source_hashes' not in record:continue
 manifest=record.pop('source_hashes');key=sha(json.dumps(manifest,sort_keys=True).encode())
 delta={p:h for p,h in manifest.items() if base_manifest.get(p)!=h}
 deleted=sorted(set(base_manifest)-set(manifest))
 history[key]={'changed_or_added':delta,'deleted':deleted}
 extra.update(delta.values())
 record['source_snapshot']=key;record['name']=p.stem
 record['effective_cuda_visible_devices']=record['environment']['CUDA_VISIBLE_DEVICES']
 if record['command'][0]=='env':
  for arg in record['command'][1:]:
   if arg.startswith('CUDA_VISIBLE_DEVICES='):record['effective_cuda_visible_devices']=arg.split('=',1)[1]
 if p.stem.startswith('rust-'):
  record.pop('native',None)
  record['python_extension_used']=False
 log=(raw/(p.stem+'.log')).read_text()
 counts=re.findall(r'Ran (\d+) tests? in ([\d.]+)s',log)
 if counts:record['unittest_summaries']=[dict(tests=int(n),seconds=float(sec)) for n,sec in counts]
 record['warning_lines']=[line for line in log.splitlines() if 'Warning:' in line]
 commands.append(record)
write_json('source-history.json',dict(base_commit=base,base_manifest_sha256=sha(json.dumps(base_manifest,sort_keys=True).encode()),snapshots=history))
# Compress exact original logs, receipts, scripts, and non-base source blobs.
# Development receipts contain all original manifests and before/after GPU data.
paths=[p for p in raw.rglob('*') if p.is_file() and 'sources' not in p.relative_to(raw).parts]
paths += [raw/'sources'/h for h in sorted(extra)]
with (out/'raw-evidence.tar.gz').open('wb') as sink:
 with gzip.GzipFile(fileobj=sink,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as archive:
   for p in sorted(paths):
    data=p.read_bytes();info=tarfile.TarInfo(p.relative_to(raw).as_posix());info.size=len(data);info.mode=0o644
    archive.addfile(info,io.BytesIO(data))
write_json('commands.json',commands)
# Preserve native and wheel identity without checking binary artifacts into git.
builds={}
for directory in ('baseline-wheel','candidate-wheel'):
 builds[directory]=[{"path":str(p.relative_to(root)),"sha256":sha(p.read_bytes()),"bytes":p.stat().st_size} for p in (root/'target'/directory).glob('*.whl')]
identity=json.loads((raw/'final-identity.log').read_text())
write_json('development.json',dict(kind='dirty-worktree development; not clean implementation commit',base_commit=base,
 final_identity=identity,reference_compiler=json.loads((raw/'reference-compiler.log').read_text()),builds=builds,compiler_selection=json.loads((raw/'complete-summary.json').read_text()),candidate_closure=json.loads((raw/'candidate-closure.json').read_text()),dependency_and_build_identity=json.loads((raw/'audit-bindings.log').read_text()),baseline_reproduction=json.loads((raw/'baseline-reproduction.json').read_text()),
 resources=['gpu','cpu-heavy'],exclusive_gpu_reservation_claimed=False,scores_changed=False,
 commands='commands.json',source_history='source-history.json',raw_evidence_sha256=sha((out/'raw-evidence.tar.gz').read_bytes()),
 clean_commit_capture={'status':'pending Burner-managed implementation commit','reason':'implementation agent may not create commits or run delivery gates on a nonexistent commit'}))
print('packed',len(commands),'commands',len(history),'source versions',len(extra),'non-base blobs', (out/'raw-evidence.tar.gz').stat().st_size,'archive bytes')
